"""Training pipeline for geometry-class routing."""
from __future__ import annotations

import uuid
from pathlib import Path

import numpy as np
from sklearn.calibration import CalibratedClassifierCV  # type: ignore[import-untyped]
from sklearn.ensemble import RandomForestClassifier  # type: ignore[import-untyped]
from sklearn.metrics import accuracy_score, confusion_matrix  # type: ignore[import-untyped]
from sklearn.model_selection import train_test_split  # type: ignore[import-untyped]

from gwdh_core.config import ClassifierConfig
from gwdh_core.types import GeometryClass

from .features import GeometryFeatureExtractor
from .model import save_classifier_bundle


class GeometryClassifierPipeline:
    """Train and register a geometry routing classifier."""

    def __init__(self, extractor: GeometryFeatureExtractor | None = None):
        self.extractor = extractor or GeometryFeatureExtractor()

    def train(self, data_lake, config: ClassifierConfig) -> str:
        X, y, class_counts = self._load_training_matrix(data_lake)
        unique_classes = np.unique(y)
        if unique_classes.size < 2:
            raise ValueError("Geometry classifier training requires at least two geometry classes.")

        X_train, X_holdout, y_train, y_holdout = self._split_dataset(X, y, config)
        model, calibrated = self._fit_model(X_train, y_train, config)

        if X_holdout.size > 0:
            y_pred = model.predict(X_holdout)
            holdout_accuracy = float(accuracy_score(y_holdout, y_pred))
            labels = [geometry.value for geometry in GeometryClass if geometry.value in unique_classes]
            cm = confusion_matrix(y_holdout, y_pred, labels=labels).tolist()
        else:
            holdout_accuracy = 0.0
            labels = [geometry.value for geometry in GeometryClass if geometry.value in unique_classes]
            cm = []

        validated_for_auto_route = self._validated_for_auto_route(
            present_classes=unique_classes.tolist(),
            holdout_accuracy=holdout_accuracy,
            min_accuracy=config.auto_route_min_accuracy,
        )

        model_id = f"geometry-router-{uuid.uuid4().hex[:12]}"
        bundle_path = Path(data_lake.config.tensor_dir) / "classifiers" / f"{model_id}.pkl"
        artifact_path = save_classifier_bundle(
            bundle_path,
            {
                "model": model,
                "feature_version": self.extractor.FEATURE_VERSION,
                "feature_names": self.extractor.feature_names(),
                "geometry_classes": labels,
            },
        )

        holdout_metrics = {
            "holdout_accuracy": holdout_accuracy,
            "sample_count_by_class": class_counts,
            "present_classes": labels,
            "feature_version": self.extractor.FEATURE_VERSION,
            "confusion_matrix": cm,
        }
        data_lake.register_classifier(
            model_id=model_id,
            training_sample_count=int(X.shape[0]),
            training_geometry_classes=labels,
            holdout_metrics=holdout_metrics,
            model_artifact_path=artifact_path,
            calibrated=calibrated,
            validated_for_auto_route=validated_for_auto_route,
        )
        return model_id

    def _load_training_matrix(self, data_lake) -> tuple[np.ndarray, np.ndarray, dict[str, int]]:
        feature_rows: list[np.ndarray] = []
        labels: list[str] = []
        class_counts: dict[str, int] = {}

        for geometry_class in GeometryClass:
            try:
                loaded = data_lake.load_training_data(geometry_class)
            except FileNotFoundError:
                continue

            if len(loaded) == 2:
                _, zdata_batch = loaded
            else:
                _, _, zdata_batch = loaded

            if zdata_batch.size == 0:
                continue

            class_counts[geometry_class.value] = int(zdata_batch.shape[0])
            for zdata in zdata_batch:
                feature_rows.append(self.extractor.extract(zdata))
                labels.append(geometry_class.value)

        if not feature_rows:
            raise ValueError("No training data is available for classifier training.")

        return np.vstack(feature_rows), np.asarray(labels, dtype=object), class_counts

    def _split_dataset(
        self,
        X: np.ndarray,
        y: np.ndarray,
        config: ClassifierConfig,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        class_counts = {label: int(np.sum(y == label)) for label in np.unique(y)}
        can_stratify = (
            0.0 < config.validation_split < 1.0
            and all(count >= 2 for count in class_counts.values())
            and X.shape[0] >= 4
        )
        if not can_stratify:
            return X, np.empty((0, X.shape[1]), dtype=float), y, np.empty((0,), dtype=object)

        return train_test_split(
            X,
            y,
            test_size=config.validation_split,
            random_state=config.random_seed,
            stratify=y,
        )

    def _fit_model(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        config: ClassifierConfig,
    ):
        estimator = RandomForestClassifier(
            n_estimators=config.n_estimators,
            random_state=config.random_seed,
            class_weight="balanced",
        )

        class_counts = {label: int(np.sum(y_train == label)) for label in np.unique(y_train)}
        min_class_count = min(class_counts.values())
        if min_class_count >= 2:
            cv = min(3, min_class_count)
            model = CalibratedClassifierCV(estimator=estimator, method="sigmoid", cv=cv)
            model.fit(X_train, y_train)
            return model, True

        estimator.fit(X_train, y_train)
        return estimator, False

    def _validated_for_auto_route(
        self,
        *,
        present_classes: list[str],
        holdout_accuracy: float,
        min_accuracy: float,
    ) -> bool:
        required_classes = {geometry.value for geometry in GeometryClass}
        return set(present_classes) == required_classes and holdout_accuracy >= min_accuracy
