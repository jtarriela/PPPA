"""Feature extraction for geometry-class routing from target ZDATA."""
from __future__ import annotations

import numpy as np

from gwdh_core.types import ZDATA_SHAPE, ZonalZDATA

EPS = 1.0e-9


class GeometryFeatureExtractor:
    """Extract scale-invariant routing features from zonal ZDATA."""

    FEATURE_VERSION = "geometry-router-v1"

    def extract(self, zdata: ZonalZDATA | np.ndarray) -> np.ndarray:
        data = self._coerce_zdata(zdata)
        velocity = np.asarray(data[:, 0], dtype=float)
        counts = np.clip(np.asarray(data[:, 1], dtype=float), 0.0, None)
        lambda_profile = np.asarray(data[:, 2], dtype=float)
        mu_profile = np.asarray(data[:, 3], dtype=float)

        mass_fraction = counts / max(float(counts.sum()), EPS)
        velocity_shape = velocity / max(float(np.mean(np.abs(velocity))), EPS)
        lambda_shape = lambda_profile / max(float(np.mean(np.abs(lambda_profile))), EPS)
        mu_shape = mu_profile / max(float(np.mean(np.abs(mu_profile))), EPS)

        angular_axis = np.linspace(-1.0, 1.0, ZDATA_SHAPE[0], dtype=float)
        centroid = float(np.sum(angular_axis * mass_fraction))
        spread = float(np.sqrt(np.sum(((angular_axis - centroid) ** 2) * mass_fraction)))
        forward_mass = float(np.sum(mass_fraction[ZDATA_SHAPE[0] // 2:]))
        rear_mass = float(np.sum(mass_fraction[: ZDATA_SHAPE[0] // 2]))
        forward_rear_ratio = float(np.log((forward_mass + EPS) / (rear_mass + EPS)))
        zone_fill_fraction = float(np.mean(counts > 0.0))
        max_zone_fraction = float(np.max(mass_fraction))
        entropy = float(
            -np.sum(mass_fraction * np.log(mass_fraction + EPS)) / np.log(ZDATA_SHAPE[0])
        )
        weighted_velocity_mean = float(np.sum(velocity * mass_fraction))
        weighted_velocity_spread = float(
            np.sqrt(np.sum(((velocity - weighted_velocity_mean) ** 2) * mass_fraction))
            / max(abs(weighted_velocity_mean), EPS)
        )

        return np.concatenate(
            [
                mass_fraction,
                velocity_shape,
                lambda_shape,
                mu_shape,
                np.array(
                    [
                        centroid,
                        spread,
                        forward_rear_ratio,
                        zone_fill_fraction,
                        max_zone_fraction,
                        entropy,
                        weighted_velocity_mean / max(float(np.mean(np.abs(velocity))), EPS),
                        weighted_velocity_spread,
                    ],
                    dtype=float,
                ),
            ]
        )

    def feature_names(self) -> list[str]:
        names = [f"mass_fraction_{idx}" for idx in range(ZDATA_SHAPE[0])]
        names.extend(f"velocity_shape_{idx}" for idx in range(ZDATA_SHAPE[0]))
        names.extend(f"lambda_shape_{idx}" for idx in range(ZDATA_SHAPE[0]))
        names.extend(f"mu_shape_{idx}" for idx in range(ZDATA_SHAPE[0]))
        names.extend(
            [
                "angular_centroid",
                "angular_spread",
                "forward_rear_ratio",
                "zone_fill_fraction",
                "max_zone_fraction",
                "mass_entropy",
                "weighted_velocity_mean",
                "weighted_velocity_spread",
            ]
        )
        return names

    def _coerce_zdata(self, zdata: ZonalZDATA | np.ndarray) -> np.ndarray:
        if isinstance(zdata, ZonalZDATA):
            return zdata.data
        array = np.asarray(zdata, dtype=float)
        if array.shape != ZDATA_SHAPE:
            raise ValueError(f"Expected ZDATA shape {ZDATA_SHAPE}, got {array.shape}.")
        return array
