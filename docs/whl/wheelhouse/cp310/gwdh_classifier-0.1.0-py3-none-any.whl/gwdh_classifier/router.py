"""Runtime routing helpers for geometry expert selection."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from gwdh_core.config import RoutingConfig
from gwdh_core.types import GeometryClass, ZonalZDATA

from .features import GeometryFeatureExtractor
from .model import load_classifier_bundle


@dataclass(frozen=True)
class RouteDecision:
    top_class: GeometryClass
    class_probabilities: dict[str, float]
    classifier_model_id: str | None


class GeometryRouter:
    """Route target ZDATA to the most likely geometry expert."""

    def __init__(self, extractor: GeometryFeatureExtractor | None = None):
        self.extractor = extractor or GeometryFeatureExtractor()

    def route(
        self,
        target_zdata: ZonalZDATA | np.ndarray,
        model_id: str | None,
        data_lake,
    ) -> RouteDecision:
        record = (
            data_lake.get_classifier_record(model_id)
            if model_id
            else data_lake.get_latest_validated_classifier_record()
        )
        bundle = load_classifier_bundle(record["model_artifact_path"])
        feature_row = self.extractor.extract(target_zdata).reshape(1, -1)
        probabilities = {geometry.value: 0.0 for geometry in GeometryClass}

        predicted = bundle["model"].predict_proba(feature_row)[0]
        for geometry_label, probability in zip(bundle["geometry_classes"], predicted):
            probabilities[geometry_label] = float(probability)

        top_class = max(probabilities.items(), key=lambda item: item[1])[0]
        return RouteDecision(
            top_class=GeometryClass(top_class),
            class_probabilities=probabilities,
            classifier_model_id=record["model_id"],
        )

    def resolve_runtime_geometry(
        self,
        target_zdata: ZonalZDATA | np.ndarray,
        routing: RoutingConfig,
        data_lake,
    ) -> RouteDecision:
        if routing.route_mode == "manual":
            manual_class = GeometryClass(routing.geometry_class_override)
            return RouteDecision(
                top_class=manual_class,
                class_probabilities={
                    geometry.value: 1.0 if geometry is manual_class else 0.0
                    for geometry in GeometryClass
                },
                classifier_model_id=routing.classifier_model_id or None,
            )

        if routing.route_mode != "auto":
            raise ValueError(f"Unsupported route_mode {routing.route_mode!r}.")

        record = (
            data_lake.get_classifier_record(routing.classifier_model_id)
            if routing.classifier_model_id
            else data_lake.get_latest_validated_classifier_record()
        )
        if not record["validated_for_auto_route"]:
            raise RuntimeError("Auto-routing requires a classifier validated_for_auto_route.")

        decision = self.route(target_zdata, record["model_id"], data_lake)
        if not data_lake.has_validated_expert(decision.top_class):
            raise RuntimeError(
                f"Auto-routing selected {decision.top_class.value}, but no validated expert is registered."
            )
        return decision
