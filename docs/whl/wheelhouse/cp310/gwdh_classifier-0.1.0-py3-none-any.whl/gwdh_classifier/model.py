"""Persistence helpers for geometry routing models."""
from __future__ import annotations

import pickle
from pathlib import Path
from typing import Any


def save_classifier_bundle(path: str | Path, bundle: dict[str, Any]) -> str:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("wb") as handle:
        pickle.dump(bundle, handle)
    return str(target)


def load_classifier_bundle(path: str | Path) -> dict[str, Any]:
    with Path(path).open("rb") as handle:
        return pickle.load(handle)
