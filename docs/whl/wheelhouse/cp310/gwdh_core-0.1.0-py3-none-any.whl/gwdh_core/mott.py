"""Mott distribution fitting, sampling, and KE calculations.

Mott cumulative fragment count: N(m) = N0 * exp(-(m/mu)^lambda)

Parameters:
    N0:  Total fragment count
    lambda: Distribution shape exponent
    mu:  Distribution scale (characteristic mass)

Reference: ARL-TN-541, docs/planning/methodology/ZDATA REDUCTION.md
"""
from __future__ import annotations

import logging

import numpy as np
import scipy.special as sc
from scipy.optimize import curve_fit

logger = logging.getLogger(__name__)


def fit_mott(
    masses: np.ndarray, counts: np.ndarray
) -> tuple[float, float, float, float]:
    """Fit Mott distribution parameters to mass/count data.

    Fits the cumulative model: N(m) = N0 * exp(-(m/mu)^lambda)

    Args:
        masses: (n_mass_groups,) fragment mass bins
        counts: (n_mass_groups,) fragment counts per bin

    Returns:
        (N0, lambda, mu, R^2)
    """
    if len(masses) < 3 or np.sum(counts) < 1e-10:
        total_n = float(np.sum(counts))
        avg_m = float(np.mean(masses)) if len(masses) > 0 else 1.0
        return total_n, 1.0, avg_m, 0.0

    order = np.argsort(masses)
    m_sorted = masses[order]
    n_sorted = counts[order]

    total_n = np.sum(n_sorted)
    cum_n = np.cumsum(n_sorted[::-1])[::-1]

    valid = cum_n > 0
    if np.sum(valid) < 3:
        return float(total_n), 1.0, float(np.mean(masses)), 0.0

    m_valid = m_sorted[valid]
    cum_valid = cum_n[valid]

    def mott_model(m: np.ndarray, n0: float, lam: float, mu: float) -> np.ndarray:
        return n0 * np.exp(-((m / mu) ** lam))

    try:
        popt, _ = curve_fit(
            mott_model,
            m_valid,
            cum_valid,
            p0=[total_n, 1.0, float(np.median(m_valid))],
            bounds=([0, 0.01, 1e-10], [1e10, 10.0, 1e10]),
            maxfev=5000,
        )
        n0, lam, mu = popt

        predicted = mott_model(m_valid, *popt)
        ss_res = np.sum((cum_valid - predicted) ** 2)
        ss_tot = np.sum((cum_valid - np.mean(cum_valid)) ** 2)
        r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

        return float(n0), float(lam), float(mu), float(r2)

    except (RuntimeError, ValueError) as e:
        logger.warning("Mott fit failed: %s", e)
        return float(total_n), 1.0, float(np.mean(masses)), 0.0


def mott_expected_mass(mu: float, lam: float) -> float:
    """Expected fragment mass from Mott distribution: E[m] = mu * Gamma(1 + 1/lam)."""
    lam_safe = max(lam, 0.1)
    return mu * float(sc.gamma(1 + 1 / lam_safe))


def compute_ke_zonal(zdata: np.ndarray) -> np.ndarray:
    """Calculate kinetic energy for each zone.

    KE_j = 0.5 * N0_j * E[m_j] * V_j^2

    Args:
        zdata: (36, 4) array with columns [V, N0, lambda, mu]

    Returns:
        (36,) KE per zone
    """
    V = zdata[:, 0]
    N0 = zdata[:, 1]
    lam = zdata[:, 2]
    mu = zdata[:, 3]

    lam_safe = np.where(lam > 0, lam, 1e-8)
    lam_safe = np.clip(lam_safe, 0.1, 10.0)
    mass_expected = mu * sc.gamma(1 + 1 / lam_safe)
    return 0.5 * N0 * mass_expected * V ** 2


def compute_ke_batch(predictions: np.ndarray) -> np.ndarray:
    """Total KE for a batch of predictions.

    Args:
        predictions: (N, 36, 4)

    Returns:
        (N,) total KE per design
    """
    N = predictions.shape[0]
    ke = np.zeros(N)
    for i in range(N):
        ke[i] = np.sum(compute_ke_zonal(predictions[i]))
    return ke
