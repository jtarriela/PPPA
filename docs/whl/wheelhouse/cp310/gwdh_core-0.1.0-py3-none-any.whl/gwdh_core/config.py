"""All configuration for GWDH subsystems.

Design pattern: Typed Configuration Tree. Every configurable dial in
the system is mapped to a typed Python dataclass with a default.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import cast


@dataclass
class DataLakeConfig:
    db_path: str = "gwdh_datalake/db/gwdh.duckdb"
    tensor_dir: str = "gwdh_datalake/tensors"
    schema_version: int = 2


@dataclass
class OptimizationConfig:
    sigma: float = 0.3
    restarts: int = 5
    bipop: bool = True
    budget: int = 2000
    constraint_phase: int = 1  # 1=bounds, 2=+mass, 3=+D+L
    penalty_weight: float = 100.0


@dataclass
class HPCConfig:
    # Empty means "use the template bundled with gwdh_hpc".
    apre_template_path: str = ""
    # Empty means "use the template bundled with gwdh_hpc".
    slurm_template_path: str = ""
    # Command template used by worker_lifecycle to launch CTH.
    # Supported placeholders: {ntasks}, {apre_path}
    launch_command: str = "mpirun -np {ntasks} cth -i {apre_path}"
    partition: str = "standard"
    ntasks: int = 64
    walltime: str = "02:00:00"
    account: str = ""
    queue_timeout_s: int = 3600
    execution_timeout_s: int = 7200
    kill_grace_period_s: int = 30
    process_verify_retries: int = 5
    process_verify_interval_s: float = 2.0
    observer_poll_interval_s: float = 10.0  # how often host polls observer_status.yaml


@dataclass
class ObservationRunnerConfig:
    poll_interval_s: float = 5.0
    velocity_window_size: int = 20
    velocity_slope_threshold: float = 0.01
    steady_state_patience: int = 3
    tracer_majority_fraction: float = 0.8
    max_observation_time_s: int = 7200
    # These fields must live here so ObservationRunner owns its verify config
    # (mirrors HPCConfig.process_verify_* for the worker-side runner)
    process_verify_retries: int = 5
    process_verify_interval_s: float = 2.0


@dataclass
class CampaignConfig:
    max_iterations: int = 20
    cmaes_budget: int = 2000
    validation_count: int = 5  # top-K for hydrocode
    convergence_threshold: float = 0.01
    sigma_collapse_threshold: float = 1e-12
    memoization_tolerance: float = 1e-6
    checkpoint_dir: str = "checkpoints"
    metrics_csv_path: str = "metrics.csv"
    run_yaml_path: str = "run.yaml"
    plot_dir: str = "plots"
    plot_every_n_gen: int = 5


@dataclass
class RoutingConfig:
    route_mode: str = "manual"
    geometry_class_override: str = "CYL"
    classifier_model_id: str = ""


@dataclass
class ClassifierConfig:
    n_estimators: int = 200
    validation_split: float = 0.25
    random_seed: int = 0
    auto_route_min_accuracy: float = 0.9


@dataclass
class TelemetryConfig:
    log_per_generation: bool = True
    csv_flush_every_n_eval: int = 10
    telemetry_jsonl_path: str = "telemetry.jsonl"


@dataclass
class TrainingConfig:
    stage1_epochs: int = 500
    stage2_epochs: int = 500
    batch_size: int = 64
    learning_rate: float = 1e-3
    early_stopping_patience: int = 50
    validation_split: float = 0.2
    random_seed: int = 0
    stage1_hidden_layers: tuple[int, ...] = (64, 64)
    stage2_hidden_layers: tuple[int, ...] = (128, 64)
    n_cv_folds: int = 5
    stage1_activation: str = "relu"
    stage1_max_iter: int | None = None
    stage1_early_stopping: bool = False
    stage1_tol: float = 1e-4
    stage2_activation: str = "relu"
    stage2_max_iter: int | None = None
    gpr_kernel: str = "rbf"
    gpr_n_restarts_optimizer: int = 3
    gpr_alpha: float = 1e-10
    gpr_max_train_samples: int | None = 500
    model_selection_strategy: str = "per_group"
    gate_stage1_velocity_re: float = 0.02
    gate_stage1_angle_re: float = 0.03
    gate_stage2_velocity_re: float = 0.02
    gate_stage2_n0_re: float = 0.05
    gate_stage2_lambda_re: float = 0.05
    gate_stage2_mu_re: float = 0.15

    def __post_init__(self) -> None:
        self.stage1_hidden_layers = tuple(self.stage1_hidden_layers)
        self.stage2_hidden_layers = tuple(self.stage2_hidden_layers)
        if self.stage1_max_iter is None:
            self.stage1_max_iter = self.stage1_epochs
        if self.stage2_max_iter is None:
            self.stage2_max_iter = self.stage2_epochs


@dataclass
class GWDHConfig:
    """Root configuration. Loaded from YAML, validated, immutable at runtime."""
    data_lake: DataLakeConfig = field(default_factory=DataLakeConfig)
    optimization: OptimizationConfig = field(default_factory=OptimizationConfig)
    hpc: HPCConfig = field(default_factory=HPCConfig)
    observation_runner: ObservationRunnerConfig = field(
        default_factory=ObservationRunnerConfig
    )
    campaign: CampaignConfig = field(default_factory=CampaignConfig)
    routing: RoutingConfig = field(default_factory=RoutingConfig)
    classifier: ClassifierConfig = field(default_factory=ClassifierConfig)
    telemetry: TelemetryConfig = field(default_factory=TelemetryConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)

    @classmethod
    def from_yaml(cls, path: str) -> GWDHConfig:
        """Load from YAML with validation."""
        import yaml  # type: ignore[import-untyped]

        with open(path) as f:
            raw = yaml.safe_load(f)
        if raw is None:
            return cls()
        return cast(GWDHConfig, _build_config(cls, raw))


def _build_config(config_cls: type, raw: dict) -> object:
    """Recursively construct a dataclass config from a dict."""
    import dataclasses
    import typing

    if not dataclasses.is_dataclass(config_cls):
        return raw

    # Use get_type_hints() to resolve forward-reference strings safely without eval()
    try:
        resolved_hints = typing.get_type_hints(config_cls)
    except Exception:
        # Fallback: build a map from field names only (no type-based recursion)
        resolved_hints = {}

    kwargs = {}
    for key, value in raw.items():
        field_names = {f.name for f in dataclasses.fields(config_cls)}
        if key in field_names:
            field_type = resolved_hints.get(key)
            if field_type is not None and dataclasses.is_dataclass(field_type) and isinstance(value, dict):
                kwargs[key] = _build_config(field_type, value)
            else:
                kwargs[key] = value
    return config_cls(**kwargs)
