"""Read/write ZDATA files per ARL-TN-541 specification.

Canonical parser for the ZDATA file format used throughout GWDH.
Python port of the C++ StringToZdata/AnalyzeZdata functions.

Reference: docs/supplementary/Reading_Writing_and_Analyzing_ZDATA_Files_Using_C++.md
"""
from __future__ import annotations

import logging
from pathlib import Path

import numpy as np

from .mott import fit_mott
from .types import (
    N_ZONES,
    RawZDATA,
    ZDATAStats,
    ZonalZDATA,
)

logger = logging.getLogger(__name__)


def read_zdata(path: str) -> RawZDATA:
    """Parse a standard ZDATA file into a RawZDATA object."""
    text = Path(path).read_text()
    return parse_zdata_string(text)


def parse_zdata_string(text: str) -> RawZDATA:
    """Parse ZDATA from a string (mirrors C++ StringToZdata).

    Format:
        ZDATA  <n_zones>
        <AL> <AM> <AU> <VL> <VM> <VU> <n_mass_groups>
        <mass_1> <mass_2> ... <mass_n>   (7 per line)
        <count_1> <count_2> ... <count_n> (7 per line)
        ... (repeated for each zone)
        <shape_factor>
    """
    tokens = text.split()
    idx = 0

    if tokens[idx].upper() != "ZDATA":
        raise ValueError(f"Expected 'ZDATA' header, got '{tokens[idx]}'")
    idx += 1
    n_zones = int(tokens[idx])
    idx += 1

    al = np.zeros(n_zones)
    am = np.zeros(n_zones)
    au = np.zeros(n_zones)
    vl = np.zeros(n_zones)
    vm = np.zeros(n_zones)
    vu = np.zeros(n_zones)
    masses: list[np.ndarray] = []
    counts: list[np.ndarray] = []

    for i in range(n_zones):
        al[i] = float(tokens[idx]); idx += 1
        am[i] = float(tokens[idx]); idx += 1
        au[i] = float(tokens[idx]); idx += 1
        vl[i] = float(tokens[idx]); idx += 1
        vm[i] = float(tokens[idx]); idx += 1
        vu[i] = float(tokens[idx]); idx += 1
        n_mass = int(tokens[idx]); idx += 1

        zone_masses = np.zeros(n_mass)
        for j in range(n_mass):
            zone_masses[j] = float(tokens[idx]); idx += 1
        masses.append(zone_masses)

        zone_counts = np.zeros(n_mass)
        for j in range(n_mass):
            zone_counts[j] = float(tokens[idx]); idx += 1
        counts.append(zone_counts)

    shape_factor = float(tokens[idx])

    return RawZDATA(
        n_zones=n_zones,
        lower_angles=al,
        midpoint_angles=am,
        upper_angles=au,
        lower_speeds=vl,
        midpoint_speeds=vm,
        upper_speeds=vu,
        masses=masses,
        counts=counts,
        shape_factor=shape_factor,
    )


def write_zdata(raw: RawZDATA, path: str) -> None:
    """Write a RawZDATA object to standard ZDATA file format."""
    lines: list[str] = []
    lines.append(f"ZDATA  {raw.n_zones}")

    for i in range(raw.n_zones):
        n_mass = len(raw.masses[i])
        lines.append(
            f"  {raw.lower_angles[i]:.4f}  {raw.midpoint_angles[i]:.4f}  "
            f"{raw.upper_angles[i]:.4f}  {raw.lower_speeds[i]:.4f}  "
            f"{raw.midpoint_speeds[i]:.4f}  {raw.upper_speeds[i]:.4f}  {n_mass}"
        )

        # Write masses, 7 per line
        for start in range(0, n_mass, 7):
            chunk = raw.masses[i][start : start + 7]
            lines.append("  " + "  ".join(f"{v:.6f}" for v in chunk))

        # Write counts, 7 per line
        for start in range(0, n_mass, 7):
            chunk = raw.counts[i][start : start + 7]
            lines.append("  " + "  ".join(f"{v:.6f}" for v in chunk))

    lines.append(f"  {raw.shape_factor:.6f}")

    Path(path).write_text("\n".join(lines) + "\n")


def analyze_zdata(raw: RawZDATA) -> ZDATAStats:
    """Compute summary statistics (mirrors C++ AnalyzeZdata)."""
    total_mass = 0.0
    total_count = 0.0
    total_ke = 0.0

    for i in range(raw.n_zones):
        v_avg_sq = (
            raw.lower_speeds[i] ** 2
            + raw.midpoint_speeds[i] ** 2
            + raw.upper_speeds[i] ** 2
        ) / 3.0

        for j in range(len(raw.masses[i])):
            total_count += raw.counts[i][j]
            total_mass += raw.counts[i][j] * raw.masses[i][j]
            total_ke += 0.5 * raw.masses[i][j] * raw.counts[i][j] * v_avg_sq

    avg_mass = total_mass / total_count if total_count > 0 else 0.0
    avg_speed = np.sqrt(2 * total_ke / total_mass) if total_mass > 0 else 0.0

    return ZDATAStats(
        total_mass=total_mass,
        total_count=total_count,
        total_ke=total_ke,
        avg_mass=avg_mass,
        avg_speed=avg_speed,
    )


def raw_to_zonal(raw: RawZDATA) -> tuple[ZonalZDATA, np.ndarray]:
    """Convert RawZDATA to internal (36, 4) representation.

    For each zone, compute:
    - V_mid: midpoint fragment speed
    - N0: Mott total fragment count parameter
    - lambda: Mott distribution shape exponent
    - mu: Mott distribution scale parameter

    Returns:
        (ZonalZDATA, mott_fit_r2) where mott_fit_r2 is (n_zones,)
        per-zone R^2 of the Mott fit.
    """
    n = min(raw.n_zones, N_ZONES)
    data = np.zeros((N_ZONES, 4))
    r2_scores = np.zeros(N_ZONES)

    for i in range(n):
        data[i, 0] = raw.midpoint_speeds[i]
        n0, lam, mu, r2 = fit_mott(raw.masses[i], raw.counts[i])
        data[i, 1] = n0
        data[i, 2] = lam
        data[i, 3] = mu
        r2_scores[i] = r2

    return ZonalZDATA(data=data), r2_scores
