"""Geometry class-specific bounds and defaults."""
from gwdh_core.geometry.classes.cylinder import (
    BOUNDS as CYL_BOUNDS,
    default_primitives as cyl_defaults,
)
from gwdh_core.geometry.classes.cylinder_cone import (
    BOUNDS as CYL_CONE_BOUNDS,
    default_primitives as cyl_cone_defaults,
)
from gwdh_core.geometry.classes.cylinder_cone_ogive import (
    BOUNDS as CYL_CONE_OGIVE_BOUNDS,
    default_primitives as cyl_cone_ogive_defaults,
)

__all__ = [
    "CYL_BOUNDS",
    "CYL_CONE_BOUNDS",
    "CYL_CONE_OGIVE_BOUNDS",
    "cyl_defaults",
    "cyl_cone_defaults",
    "cyl_cone_ogive_defaults",
]
