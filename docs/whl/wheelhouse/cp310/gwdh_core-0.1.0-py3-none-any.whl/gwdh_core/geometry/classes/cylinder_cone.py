"""CYL_CONE-specific bounds, defaults, and helpers."""
from __future__ import annotations

import numpy as np

from gwdh_core.types import CasingMaterial, ExplosiveType, InitiationPoint
from gwdh_core.geometry.primitives import CylinderConePrimitives

BOUNDS = {
    "D": (0.02, 0.30),
    "L_D": (1.0, 6.0),
    "T_D": (0.02, 0.15),
    "L_cone": (0.01, 0.20),                                    # m
    "D_cone_front": (0.01, 0.25),                               # m
    "explosive": tuple(ExplosiveType),                          # categorical
    "initiation": tuple(InitiationPoint),                       # categorical
    "casing_material": tuple(CasingMaterial),                   # categorical
}


def default_primitives() -> CylinderConePrimitives:
    """A physically plausible default CYL_CONE geometry."""
    return CylinderConePrimitives(
        D=0.10,
        L_D=3.0,
        T_D=0.05,
        explosive=ExplosiveType.COMP_B,
        initiation=InitiationPoint.BASE,
        casing=CasingMaterial.STEEL_4340,
        L_cone=0.05,
        D_cone_front=0.06,
    )


BODY_FRACTIONS = np.array([0.0, 0.25, 0.5, 0.75, 1.0], dtype=float)
NOSE_FRACTIONS = np.array([0.25, 0.5, 0.75, 1.0], dtype=float)


def sample_cylinder_cone_profile(
    *,
    total_length_m: float,
    cone_length_m: float,
    case_radius_m: float,
    front_case_radius_m: float,
    explosive_radius_m: float,
    front_explosive_radius_m: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return the canonical 9-station cylinder-plus-cone profile."""
    body_length = total_length_m - cone_length_m
    axial = np.concatenate(
        [
            body_length * BODY_FRACTIONS,
            body_length + cone_length_m * NOSE_FRACTIONS,
        ]
    ).astype(float)
    case_radii = np.concatenate(
        [
            np.full(BODY_FRACTIONS.size, case_radius_m, dtype=float),
            np.linspace(
                case_radius_m,
                front_case_radius_m,
                NOSE_FRACTIONS.size + 1,
                dtype=float,
            )[1:],
        ]
    )
    explosive_radii = np.concatenate(
        [
            np.full(BODY_FRACTIONS.size, explosive_radius_m, dtype=float),
            np.linspace(
                explosive_radius_m,
                front_explosive_radius_m,
                NOSE_FRACTIONS.size + 1,
                dtype=float,
            )[1:],
        ]
    )
    return axial, case_radii, explosive_radii
