"""CYL_CONE_OGIVE-specific bounds, defaults, and helpers."""
from __future__ import annotations

import numpy as np

from gwdh_core.types import CasingMaterial, ExplosiveType, InitiationPoint
from gwdh_core.geometry.primitives import CylinderConeOgivePrimitives

BOUNDS = {
    "D": (0.02, 0.30),
    "L_D": (1.0, 6.0),
    "T_D": (0.02, 0.15),
    "L_cone": (0.01, 0.20),
    "D_cone_front": (0.01, 0.25),
    "R_ogive": (0.01, 0.50),                                    # m
    "explosive": tuple(ExplosiveType),                          # categorical
    "initiation": tuple(InitiationPoint),                       # categorical
    "casing_material": tuple(CasingMaterial),                   # categorical
}


def default_primitives() -> CylinderConeOgivePrimitives:
    """A physically plausible default CYL_CONE_OGIVE geometry."""
    return CylinderConeOgivePrimitives(
        D=0.10,
        L_D=3.0,
        T_D=0.05,
        explosive=ExplosiveType.COMP_B,
        initiation=InitiationPoint.BASE,
        casing=CasingMaterial.STEEL_4340,
        L_cone=0.05,
        D_cone_front=0.06,
        R_ogive=0.15,
    )


BODY_FRACTIONS = np.array([0.0, 0.25, 0.5, 0.75, 1.0], dtype=float)
NOSE_FRACTIONS = np.array([0.25, 0.5, 0.75, 1.0], dtype=float)


def ogive_exponent(case_radius_m: float, ogive_radius_m: float) -> float:
    return max(float(ogive_radius_m / max(case_radius_m, 1e-9)), 1.0)


def sample_cylinder_cone_ogive_profile(
    *,
    total_length_m: float,
    nose_length_m: float,
    case_radius_m: float,
    front_case_radius_m: float,
    explosive_radius_m: float,
    front_explosive_radius_m: float,
    ogive_radius_m: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return the canonical 9-station ogive-backed nose profile."""
    body_length = total_length_m - nose_length_m
    axial = np.concatenate(
        [
            body_length * BODY_FRACTIONS,
            body_length + nose_length_m * NOSE_FRACTIONS,
        ]
    ).astype(float)

    exponent = ogive_exponent(case_radius_m, ogive_radius_m)
    nose_scale = 1.0 - np.power(NOSE_FRACTIONS, exponent)
    case_nose = front_case_radius_m + (case_radius_m - front_case_radius_m) * nose_scale
    explosive_nose = front_explosive_radius_m + (
        explosive_radius_m - front_explosive_radius_m
    ) * nose_scale

    case_radii = np.concatenate(
        [
            np.full(BODY_FRACTIONS.size, case_radius_m, dtype=float),
            case_nose.astype(float),
        ]
    )
    explosive_radii = np.concatenate(
        [
            np.full(BODY_FRACTIONS.size, explosive_radius_m, dtype=float),
            explosive_nose.astype(float),
        ]
    )
    return axial, case_radii, explosive_radii
