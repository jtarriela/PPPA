"""CYL-specific bounds, defaults, and helpers."""
from __future__ import annotations

import numpy as np

from gwdh_core.types import CasingMaterial, ExplosiveType, InitiationPoint
from gwdh_core.geometry.primitives import CylinderPrimitives

# Parameter bounds: (min, max) for continuous params
# Categorical params: (tuple of valid enum values)
BOUNDS = {
    "D": (0.02, 0.30),                                         # m
    "L_D": (1.0, 6.0),                                         # dimensionless
    "T_D": (0.02, 0.15),                                       # dimensionless
    "explosive": tuple(ExplosiveType),                          # categorical
    "initiation": tuple(InitiationPoint),                       # categorical
    "casing_material": tuple(CasingMaterial),                   # categorical
}


def default_primitives() -> CylinderPrimitives:
    """A physically plausible default CYL geometry."""
    return CylinderPrimitives(
        D=0.10,
        L_D=3.0,
        T_D=0.05,
        explosive=ExplosiveType.COMP_B,
        initiation=InitiationPoint.BASE,
        casing=CasingMaterial.STEEL_4340,
    )


def sample_cylinder_profile(
    *,
    total_length_m: float,
    case_radius_m: float,
    explosive_radius_m: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return the canonical 9-station cylindrical Layer 2 profile."""
    axial = np.linspace(0.0, total_length_m, num=9, dtype=float)
    case_radii = np.full(9, case_radius_m, dtype=float)
    explosive_radii = np.full(9, explosive_radius_m, dtype=float)
    return axial, case_radii, explosive_radii
