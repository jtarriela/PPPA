"""Layer 1 <-> Layer 2 conversion for the active geometry classes."""
from __future__ import annotations

import numpy as np

from gwdh_core.geometry.primitives import (
    CylinderConePrimitives,
    CylinderConeOgivePrimitives,
    CylinderPrimitives,
)
from gwdh_core.types import (
    CasingMaterial,
    DesignVector,
    ExplosiveType,
    GeometryClass,
    InitiationPoint,
)
from .classes.cylinder_cone import BODY_FRACTIONS as CONE_BODY_FRACTIONS
from .classes.cylinder_cone import NOSE_FRACTIONS as CONE_NOSE_FRACTIONS
from .classes.cylinder_cone import sample_cylinder_cone_profile
from .classes.cylinder_cone_ogive import sample_cylinder_cone_ogive_profile
from .primitives import (
    EXPLOSIVE_PROPERTIES,
    CylinderConeOgivePrimitives,
    CylinderConePrimitives,
    CylinderPrimitives,
    INITIATION_ENCODING,
)
from .validator import ValidationError, validate, validate_design_vector

# Material property lookup tables
_DET_VELOCITY = {
    ExplosiveType.TNT: 6900.0,      # m/s
    ExplosiveType.COMP_B: 7980.0,   # m/s
}
VECTOR_RTOL = 1e-6
VECTOR_ATOL = 1e-9

# Integer code encoded at design vector [35].
# Increment when adding new CasingMaterial variants.
_CASING_CODE = {
    CasingMaterial.STEEL_4340: 0.0,
    CasingMaterial.STEEL_1018: 1.0,
    CasingMaterial.TUNGSTEN:   2.0,
}

# Reverse map: code → CasingMaterial (used by Reconstructor)
CASING_CODE_TO_MATERIAL: dict[float, CasingMaterial] = {
    v: k for k, v in _CASING_CODE.items()
}


def encode_casing_code(casing_material: CasingMaterial) -> float:
    """Return the canonical design-vector code for a casing material."""
    return _CASING_CODE[casing_material]


class Discretizer:
    """Convert validated Layer 1 primitives into the canonical 36D vector."""

    def to_vector(self, primitives: CylinderPrimitives) -> DesignVector:
        validate(primitives)
        axial, case_radii, explosive_radii = primitives.profile_arrays()
        material_props = primitives.material_properties_vector()
        return DesignVector(
            data=np.concatenate([axial, case_radii, explosive_radii, material_props]).astype(float)
        )

    def from_vector(
        self,
        vector: DesignVector | np.ndarray,
        geometry_class: GeometryClass,
    ) -> CylinderPrimitives | CylinderConePrimitives | CylinderConeOgivePrimitives:
        data = self._coerce_vector(vector)
        validate_design_vector(data)
        explosive = self._decode_explosive(data[27:36])
        initiation = self._decode_initiation(float(data[29]))
        casing = self._decode_casing(float(data[35]))

        if geometry_class is GeometryClass.CYL:
            primitives = self._decode_cylinder(data, explosive, initiation, casing)
        elif geometry_class is GeometryClass.CYL_CONE:
            primitives = self._decode_cylinder_cone(data, explosive, initiation, casing)
        elif geometry_class is GeometryClass.CYL_CONE_OGIVE:
            primitives = self._decode_cylinder_cone_ogive(data, explosive, initiation, casing)
        else:
            raise ValidationError(f"Unsupported geometry class: {geometry_class!r}")

        if not np.allclose(
            data[27:36],
            primitives.material_properties_vector(),
            rtol=VECTOR_RTOL,
            atol=VECTOR_ATOL,
        ):
            raise ValidationError(
                f"Design vector material slots do not match the canonical {geometry_class.value} encoding."
            )
        return primitives

    def _coerce_vector(self, vector: DesignVector | np.ndarray) -> np.ndarray:
        if isinstance(vector, DesignVector):
            return vector.data
        return np.asarray(vector, dtype=float)

    def _decode_explosive(self, material_slots: np.ndarray) -> ExplosiveType:
        target = np.asarray(
            [material_slots[0], material_slots[1], material_slots[7]],
            dtype=float,
        )
        matches: list[ExplosiveType] = []
        for explosive, properties in EXPLOSIVE_PROPERTIES.items():
            candidate = np.array(
                [
                    properties.gurney_constant_m_s,
                    properties.detonation_velocity_m_s,
                    properties.density_kg_m3,
                ],
                dtype=float,
            )
            if np.allclose(target, candidate, rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
                matches.append(explosive)
        if len(matches) != 1:
            raise ValidationError("Design vector does not encode a supported pilot explosive type.")
        return matches[0]

    def _decode_initiation(self, initiation_flag: float) -> InitiationPoint:
        matches = [
            initiation
            for initiation, encoded in INITIATION_ENCODING.items()
            if np.isclose(initiation_flag, encoded, rtol=VECTOR_RTOL, atol=VECTOR_ATOL)
        ]
        if len(matches) != 1:
            raise ValidationError("Design vector does not encode a supported pilot initiation point.")
        return matches[0]

    def _decode_casing(self, casing_code: float) -> CasingMaterial:
        key = round(float(casing_code))
        if float(key) not in CASING_CODE_TO_MATERIAL:
            raise ValidationError(f"Unsupported casing material code: {casing_code!r}")
        return CASING_CODE_TO_MATERIAL[float(key)]

    def _validate_canonical_cylinder(self, data: np.ndarray) -> None:
        axial = data[0:9]
        case_radii = data[9:18]
        explosive_radii = data[18:27]
        expected_axial = np.linspace(axial[0], axial[-1], num=9, dtype=float)
        if not np.allclose(axial, expected_axial, rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
            raise ValidationError("CYL design vectors must use evenly spaced axial coordinates.")
        if not np.allclose(case_radii, np.full(9, case_radii[0]), rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
            raise ValidationError("CYL design vectors must use constant case radii.")
        if not np.allclose(
            explosive_radii,
            np.full(9, explosive_radii[0]),
            rtol=VECTOR_RTOL,
            atol=VECTOR_ATOL,
        ):
            raise ValidationError("CYL design vectors must use constant explosive radii.")

    def _decode_cylinder(
        self,
        data: np.ndarray,
        explosive: ExplosiveType,
        initiation: InitiationPoint,
        casing: CasingMaterial,
    ) -> CylinderPrimitives:
        self._validate_canonical_cylinder(data)
        outer_radius = float(data[9])
        inner_radius = float(data[18])
        diameter = 2.0 * outer_radius
        length = float(data[8] - data[0])
        thickness = outer_radius - inner_radius
        return CylinderPrimitives(
            D=diameter,
            L_D=length / diameter,
            T_D=thickness / diameter,
            explosive=explosive,
            initiation=initiation,
            casing=casing,
        )

    def _decode_cylinder_cone(
        self,
        data: np.ndarray,
        explosive: ExplosiveType,
        initiation: InitiationPoint,
        casing: CasingMaterial,
    ) -> CylinderConePrimitives:
        axial = data[0:9]
        case_radii = data[9:18]
        explosive_radii = data[18:27]
        body_length = float(axial[4] - axial[0])
        cone_length = float(axial[8] - axial[4])
        expected_axial = np.concatenate(
            [
                axial[0] + body_length * CONE_BODY_FRACTIONS,
                axial[4] + cone_length * CONE_NOSE_FRACTIONS,
            ]
        )
        if not np.allclose(axial, expected_axial, rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
            raise ValidationError("CYL_CONE design vectors must use the canonical body/nose station layout.")

        outer_radius = float(case_radii[0])
        inner_radius = float(explosive_radii[0])
        front_case_radius = float(case_radii[-1])
        front_explosive_radius = float(explosive_radii[-1])
        expected_case = sample_cylinder_cone_profile(
            total_length_m=float(axial[-1] - axial[0]),
            cone_length_m=cone_length,
            case_radius_m=outer_radius,
            front_case_radius_m=front_case_radius,
            explosive_radius_m=inner_radius,
            front_explosive_radius_m=front_explosive_radius,
        )[1]
        expected_explosive = sample_cylinder_cone_profile(
            total_length_m=float(axial[-1] - axial[0]),
            cone_length_m=cone_length,
            case_radius_m=outer_radius,
            front_case_radius_m=front_case_radius,
            explosive_radius_m=inner_radius,
            front_explosive_radius_m=front_explosive_radius,
        )[2]
        if not np.allclose(case_radii, expected_case, rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
            raise ValidationError("CYL_CONE design vectors must match the canonical linear nose profile.")
        if not np.allclose(explosive_radii, expected_explosive, rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
            raise ValidationError("CYL_CONE explosive radii must match the canonical linear nose profile.")

        diameter = 2.0 * outer_radius
        length = float(axial[-1] - axial[0])
        thickness = outer_radius - inner_radius
        return CylinderConePrimitives(
            D=diameter,
            L_D=length / diameter,
            T_D=thickness / diameter,
            explosive=explosive,
            initiation=initiation,
            casing=casing,
            L_cone=cone_length,
            D_cone_front=2.0 * front_case_radius,
        )

    def _decode_cylinder_cone_ogive(
        self,
        data: np.ndarray,
        explosive: ExplosiveType,
        initiation: InitiationPoint,
        casing: CasingMaterial,
    ) -> CylinderConeOgivePrimitives:
        axial = data[0:9]
        case_radii = data[9:18]
        explosive_radii = data[18:27]
        body_length = float(axial[4] - axial[0])
        nose_length = float(axial[8] - axial[4])
        expected_axial = np.concatenate(
            [
                axial[0] + body_length * CONE_BODY_FRACTIONS,
                axial[4] + nose_length * CONE_NOSE_FRACTIONS,
            ]
        )
        if not np.allclose(axial, expected_axial, rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
            raise ValidationError("CYL_CONE_OGIVE design vectors must use the canonical body/nose station layout.")

        outer_radius = float(case_radii[0])
        inner_radius = float(explosive_radii[0])
        front_case_radius = float(case_radii[-1])
        front_explosive_radius = float(explosive_radii[-1])
        diameter = 2.0 * outer_radius
        length = float(axial[-1] - axial[0])
        thickness = outer_radius - inner_radius

        case_delta = outer_radius - front_case_radius
        if case_delta <= 1e-12:
            raise ValidationError("CYL_CONE_OGIVE vectors must taper the nose radius.")
        s = CONE_NOSE_FRACTIONS[1]
        normalized = 1.0 - ((case_radii[6] - front_case_radius) / case_delta)
        normalized = min(max(float(normalized), 1e-12), 1.0 - 1e-12)
        exponent = float(np.log(normalized) / np.log(s))
        ogive_radius = exponent * outer_radius

        expected_case = sample_cylinder_cone_ogive_profile(
            total_length_m=length,
            nose_length_m=nose_length,
            case_radius_m=outer_radius,
            front_case_radius_m=front_case_radius,
            explosive_radius_m=inner_radius,
            front_explosive_radius_m=front_explosive_radius,
            ogive_radius_m=ogive_radius,
        )[1]
        expected_explosive = sample_cylinder_cone_ogive_profile(
            total_length_m=length,
            nose_length_m=nose_length,
            case_radius_m=outer_radius,
            front_case_radius_m=front_case_radius,
            explosive_radius_m=inner_radius,
            front_explosive_radius_m=front_explosive_radius,
            ogive_radius_m=ogive_radius,
        )[2]
        if not np.allclose(case_radii, expected_case, rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
            raise ValidationError("CYL_CONE_OGIVE vectors must match the canonical ogive nose profile.")
        if not np.allclose(explosive_radii, expected_explosive, rtol=VECTOR_RTOL, atol=VECTOR_ATOL):
            raise ValidationError("CYL_CONE_OGIVE explosive radii must match the canonical ogive nose profile.")

        return CylinderConeOgivePrimitives(
            D=diameter,
            L_D=length / diameter,
            T_D=thickness / diameter,
            explosive=explosive,
            initiation=initiation,
            casing=casing,
            L_cone=nose_length,
            D_cone_front=2.0 * front_case_radius,
            R_ogive=ogive_radius,
        )
