"""Inverse Layer 2 -> Layer 1 helpers."""
from __future__ import annotations

import numpy as np

from gwdh_core.types import DesignVector, GeometryClass
from .discretizer import Discretizer
from .primitives import (
    CylinderConeOgivePrimitives,
    CylinderConePrimitives,
    CylinderPrimitives,
)


class Reconstructor:
    """Reconstruct Layer 1 primitives from a canonical design vector."""

    def __init__(self) -> None:
        self._discretizer = Discretizer()

    def from_vector(
        self,
        vector: DesignVector | np.ndarray,
        geometry_class: GeometryClass,
    ) -> CylinderPrimitives | CylinderConePrimitives | CylinderConeOgivePrimitives:
        return self._discretizer.from_vector(vector, geometry_class)
