"""Primitives → 2D XY polygons for CTH APRE `insert uds` blocks.

Generates closed 2D cross-section polygons for the Fragment shell and
HE_FILL packages. These polygons define the axisymmetric material
boundaries in the CTH input deck.

Coordinate convention (matching CTH 2DC geometry):
    x = radial direction (horizontal)
    y = axial direction (vertical)
    Units: centimeters (APRE/CTH convention)

The primitives store dimensions in meters; this module converts to cm.

Reference: templates/dakota/penetrator_.apre for polygon format
"""
from __future__ import annotations

import numpy as np

from gwdh_core.geometry.primitives import (
    CylinderConePrimitives,
    CylinderConeOgivePrimitives,
    CylinderPrimitives,
)

# Meters → centimeters conversion
_M_TO_CM = 100.0


def generate_fragment_polygon(
    primitives: CylinderPrimitives,
    n_axial: int = 9,
    n_nose: int = 5,
) -> np.ndarray:
    """Generate closed 2D (x, y) polygon for the Fragment shell package.

    Traces: outer wall up → across nose → inner wall down → across base.

    Args:
        primitives: Layer 1 geometry parameters.
        n_axial: Number of stations along the axial direction for each wall.
        n_nose: Number of points to discretize the nose cap/closure.

    Returns:
        (N, 2) array of (x, y) coordinates in cm.
    """
    if isinstance(primitives, CylinderConeOgivePrimitives):
        return _fragment_cyl_cone_ogive(primitives, n_axial, n_nose)
    elif isinstance(primitives, CylinderConePrimitives):
        return _fragment_cyl_cone(primitives, n_axial, n_nose)
    else:
        return _fragment_cyl(primitives, n_axial)


def generate_he_fill_polygon(
    primitives: CylinderPrimitives,
    n_axial: int = 9,
) -> np.ndarray:
    """Generate closed 2D (x, y) polygon for the HE_FILL package.

    Traces the explosive fill boundary (interior of the case).

    Args:
        primitives: Layer 1 geometry parameters.
        n_axial: Number of stations along the axial direction.

    Returns:
        (M, 2) array of (x, y) coordinates in cm.
    """
    if isinstance(primitives, CylinderConeOgivePrimitives):
        return _he_cyl_cone_ogive(primitives, n_axial)
    elif isinstance(primitives, CylinderConePrimitives):
        return _he_cyl_cone(primitives, n_axial)
    else:
        return _he_cyl(primitives, n_axial)


# ── CYL helpers ──────────────────────────────────────────────


def _fragment_cyl(p: CylinderPrimitives, n_axial: int) -> np.ndarray:
    """Fragment polygon for pure cylinder: rectangular annulus."""
    R = p.D / 2.0 * _M_TO_CM
    r_inner = (p.D / 2.0 - p.T) * _M_TO_CM
    L = p.L * _M_TO_CM

    points = []
    axial = np.linspace(0.0, L, n_axial)

    # Outer wall: bottom to top at R
    for y in axial:
        points.append([R, y])

    # Nose cap: across top from outer to inner
    points.append([r_inner, L])

    # Inner wall: top to bottom at r_inner
    for y in reversed(axial):
        points.append([r_inner, y])

    # Base closure: across bottom from inner to outer
    points.append([R, 0.0])

    return np.array(points, dtype=np.float64)


def _he_cyl(p: CylinderPrimitives, n_axial: int) -> np.ndarray:
    """HE_FILL polygon for pure cylinder: interior fill."""
    r_inner = (p.D / 2.0 - p.T) * _M_TO_CM
    L = p.L * _M_TO_CM

    points = []
    axial = np.linspace(0.0, L, n_axial)

    # Along axis at base
    points.append([0.0, 0.0])

    # Inner wall: bottom to top at r_inner
    for y in axial:
        points.append([r_inner, y])

    # Across top to axis
    points.append([0.0, L])

    # Down axis back to origin
    points.append([0.0, 0.0])

    return np.array(points, dtype=np.float64)


# ── CYL_CONE helpers ────────────────────────────────────────


def _outer_profile_cone(
    p: CylinderConePrimitives, n_axial: int
) -> tuple[np.ndarray, np.ndarray]:
    """Compute outer radius profile for cylinder-cone.

    Returns (axial_cm, radii_cm) arrays of length n_axial.
    """
    R = p.D / 2.0
    R_front = p.D_cone_front / 2.0
    L = p.L
    L_cyl = L - p.L_cone

    axial_m = np.linspace(0.0, L, n_axial)
    radii_m = np.full(n_axial, R)

    for i in range(n_axial):
        if axial_m[i] > L_cyl and p.L_cone > 0:
            frac = (axial_m[i] - L_cyl) / p.L_cone
            radii_m[i] = R + frac * (R_front - R)

    return axial_m * _M_TO_CM, radii_m * _M_TO_CM


def _inner_profile_cone(
    p: CylinderConePrimitives, n_axial: int
) -> tuple[np.ndarray, np.ndarray]:
    """Compute inner radius profile for cylinder-cone (outer - T)."""
    axial_cm, outer_cm = _outer_profile_cone(p, n_axial)
    T_cm = p.T * _M_TO_CM
    inner_cm = np.maximum(outer_cm - T_cm, 0.0)
    return axial_cm, inner_cm


def _fragment_cyl_cone(
    p: CylinderConePrimitives, n_axial: int, n_nose: int
) -> np.ndarray:
    """Fragment polygon for cylinder-cone."""
    axial_cm, outer_cm = _outer_profile_cone(p, n_axial)
    _, inner_cm = _inner_profile_cone(p, n_axial)

    points = []

    # Outer wall: bottom to top
    for i in range(n_axial):
        points.append([outer_cm[i], axial_cm[i]])

    # Nose cap: transition from outer tip to inner tip
    r_out_tip = outer_cm[-1]
    r_in_tip = inner_cm[-1]
    y_tip = axial_cm[-1]
    if n_nose > 0 and r_out_tip > r_in_tip:
        for t in np.linspace(0.0, 1.0, n_nose + 2)[1:-1]:
            points.append([
                r_out_tip + t * (r_in_tip - r_out_tip),
                y_tip,
            ])

    # Inner wall: top to bottom
    for i in reversed(range(n_axial)):
        points.append([inner_cm[i], axial_cm[i]])

    # Base closure: across bottom
    points.append([outer_cm[0], axial_cm[0]])

    return np.array(points, dtype=np.float64)


def _he_cyl_cone(
    p: CylinderConePrimitives, n_axial: int
) -> np.ndarray:
    """HE_FILL polygon for cylinder-cone."""
    axial_cm, inner_cm = _inner_profile_cone(p, n_axial)

    points = []

    # Start at axis base
    points.append([0.0, 0.0])

    # Inner wall: bottom to top
    for i in range(n_axial):
        points.append([inner_cm[i], axial_cm[i]])

    # Across top to axis
    points.append([0.0, axial_cm[-1]])

    # Down axis to origin
    points.append([0.0, 0.0])

    return np.array(points, dtype=np.float64)


# ── CYL_CONE_OGIVE helpers ─────────────────────────────────


def _outer_profile_ogive(
    p: CylinderConeOgivePrimitives, n_axial: int
) -> tuple[np.ndarray, np.ndarray]:
    """Compute outer radius profile for cylinder-cone-ogive.

    Applies ogive curvature correction in the cone/nose section.
    """
    R = p.D / 2.0
    R_front = p.D_cone_front / 2.0
    L = p.L
    L_cyl = L - p.L_cone

    axial_m = np.linspace(0.0, L, n_axial)
    radii_m = np.full(n_axial, R)

    for i in range(n_axial):
        if axial_m[i] > L_cyl and p.L_cone > 0:
            frac = (axial_m[i] - L_cyl) / p.L_cone
            r_linear = R + frac * (R_front - R)
            # Ogive curvature correction (same formula as discretizer)
            ogive_corr = p.R_ogive * (1.0 - np.sqrt(1.0 - frac**2 + 1e-12))
            radii_m[i] = r_linear - ogive_corr * (R - R_front) / p.R_ogive
            radii_m[i] = max(radii_m[i], p.T + 1e-6)

    return axial_m * _M_TO_CM, radii_m * _M_TO_CM


def _inner_profile_ogive(
    p: CylinderConeOgivePrimitives, n_axial: int
) -> tuple[np.ndarray, np.ndarray]:
    """Compute inner radius profile for cylinder-cone-ogive."""
    axial_cm, outer_cm = _outer_profile_ogive(p, n_axial)
    T_cm = p.T * _M_TO_CM
    inner_cm = np.maximum(outer_cm - T_cm, 0.0)
    return axial_cm, inner_cm


def _fragment_cyl_cone_ogive(
    p: CylinderConeOgivePrimitives, n_axial: int, n_nose: int
) -> np.ndarray:
    """Fragment polygon for cylinder-cone-ogive."""
    axial_cm, outer_cm = _outer_profile_ogive(p, n_axial)
    _, inner_cm = _inner_profile_ogive(p, n_axial)

    points = []

    # Outer wall: bottom to top
    for i in range(n_axial):
        points.append([outer_cm[i], axial_cm[i]])

    # Nose cap: transition from outer tip to inner tip
    r_out_tip = outer_cm[-1]
    r_in_tip = inner_cm[-1]
    y_tip = axial_cm[-1]
    if n_nose > 0 and r_out_tip > r_in_tip:
        for t in np.linspace(0.0, 1.0, n_nose + 2)[1:-1]:
            points.append([
                r_out_tip + t * (r_in_tip - r_out_tip),
                y_tip,
            ])

    # Inner wall: top to bottom
    for i in reversed(range(n_axial)):
        points.append([inner_cm[i], axial_cm[i]])

    # Base closure
    points.append([outer_cm[0], axial_cm[0]])

    return np.array(points, dtype=np.float64)


def _he_cyl_cone_ogive(
    p: CylinderConeOgivePrimitives, n_axial: int
) -> np.ndarray:
    """HE_FILL polygon for cylinder-cone-ogive."""
    axial_cm, inner_cm = _inner_profile_ogive(p, n_axial)

    points = []
    points.append([0.0, 0.0])

    for i in range(n_axial):
        points.append([inner_cm[i], axial_cm[i]])

    points.append([0.0, axial_cm[-1]])
    points.append([0.0, 0.0])

    return np.array(points, dtype=np.float64)
