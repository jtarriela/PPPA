"""Geometry validation helpers."""
from __future__ import annotations

import numpy as np
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gwdh_core.geometry.primitives import (
        CylinderConePrimitives,
        CylinderConeOgivePrimitives,
        CylinderPrimitives,
    )


class ValidationError(ValueError):
    """Raised when a Layer 1 or Layer 2 geometry is physically invalid."""


def validate_cylinder_ratios(
    diameter_m: float,
    length_to_diameter: float,
    thickness_to_diameter: float,
) -> None:
    if diameter_m <= 0.0:
        raise ValidationError("Diameter must be positive.")
    if length_to_diameter <= 0.0:
        raise ValidationError("L/D ratio must be positive.")
    if thickness_to_diameter <= 0.0:
        raise ValidationError("T/D ratio must be positive.")
    if thickness_to_diameter >= 0.5:
        raise ValidationError("Cylinder thickness-to-diameter ratio must be < 0.5.")


def validate_cone_parameters(
    outer_diameter_m: float,
    total_length_m: float,
    case_thickness_m: float,
    cone_length_m: float,
    front_diameter_m: float,
) -> None:
    if cone_length_m <= 0.0:
        raise ValidationError("Cone length must be positive.")
    if cone_length_m >= total_length_m:
        raise ValidationError("Cone length must be < total length.")
    if front_diameter_m <= 0.0:
        raise ValidationError("Cone front diameter must be positive.")
    if front_diameter_m >= outer_diameter_m:
        raise ValidationError("Cone front diameter must be < outer diameter.")
    if (front_diameter_m / 2.0) <= case_thickness_m:
        raise ValidationError("Cone front diameter must leave a positive explosive radius.")


def validate_ogive_parameters(
    case_radius_m: float,
    front_radius_m: float,
    ogive_radius_m: float,
) -> None:
    if ogive_radius_m <= 0.0:
        raise ValidationError("Ogive radius must be positive.")
    if ogive_radius_m <= max(case_radius_m, front_radius_m):
        raise ValidationError("Ogive radius must exceed the body and nose radii.")


def validate(primitives: "CylinderPrimitives") -> None:
    validate_cylinder_ratios(primitives.D, primitives.L_D, primitives.T_D)

    from gwdh_core.geometry.primitives import (
        CylinderConeOgivePrimitives,
        CylinderConePrimitives,
    )

    if isinstance(primitives, CylinderConePrimitives):
        validate_cone_parameters(
            primitives.D,
            primitives.L,
            primitives.T,
            primitives.L_cone,
            primitives.D_cone_front,
        )

    if isinstance(primitives, CylinderConeOgivePrimitives):
        validate_ogive_parameters(
            primitives.case_radius,
            primitives.front_case_radius,
            primitives.R_ogive,
        )


def validate_design_vector(vector: np.ndarray) -> None:
    """Validate the minimum physical assumptions required by the geometry engine."""
    if vector.shape != (36,):
        raise ValidationError(f"Expected a 36-element design vector, got {vector.shape}.")

    axial = vector[0:9]
    case_radii = vector[9:18]
    explosive_radii = vector[18:27]

    if not np.all(np.diff(axial) >= 0.0):
        raise ValidationError("Axial coordinates must be monotonically non-decreasing.")
    if axial[-1] <= axial[0]:
        raise ValidationError("Axial coordinates must span a positive length.")
    if np.any(case_radii < 0.0):
        raise ValidationError("Case radii must be non-negative.")
    if np.all(case_radii == 0.0):
        raise ValidationError("Case radii must contain at least one positive value.")
    if np.any(explosive_radii < 0.0):
        raise ValidationError("Explosive radii must be non-negative.")
    if np.any(explosive_radii > case_radii):
        raise ValidationError("Explosive radii must be strictly smaller than case radii.")
    positive_shell = np.any((case_radii - explosive_radii) > 0.0)
    if not positive_shell:
        raise ValidationError("Case radii must exceed explosive radii in at least one station.")
