"""Layer 1 primitive definitions and canonical profile helpers."""
from __future__ import annotations

from dataclasses import dataclass
from math import isclose

import numpy as np

from gwdh_core.materials import CASING_LIBRARY
from gwdh_core.types import CasingMaterial, ExplosiveType, InitiationPoint
from .validator import ValidationError


@dataclass(frozen=True)
class ExplosiveProperties:
    """Explosive properties embedded into the Layer 2 material slots."""

    gurney_constant_m_s: float
    detonation_velocity_m_s: float
    density_kg_m3: float


EXPLOSIVE_PROPERTIES = {
    ExplosiveType.TNT: ExplosiveProperties(
        gurney_constant_m_s=2.4e6,
        detonation_velocity_m_s=6.90e3,
        density_kg_m3=1.65e3,
    ),
    ExplosiveType.COMP_B: ExplosiveProperties(
        gurney_constant_m_s=2.7e6,
        detonation_velocity_m_s=7.98e3,
        density_kg_m3=1.72e3,
    ),
}

INITIATION_ENCODING = {
    InitiationPoint.CENTER: 0.0,
    InitiationPoint.BASE: 1.0,
}


def _integrate_revolved_volume(axial_coords: np.ndarray, radii: np.ndarray) -> float:
    dz = np.diff(axial_coords)
    r_avg = (radii[:-1] + radii[1:]) / 2.0
    return float(np.sum(np.pi * r_avg**2 * dz))


@dataclass
class CylinderPrimitives:
    """Layer 1 for CYL class."""

    D: float  # Outer diameter (m)
    L_D: float  # Length-to-diameter ratio
    T_D: float  # Thickness-to-diameter ratio
    explosive: ExplosiveType
    initiation: InitiationPoint
    casing: CasingMaterial = CasingMaterial.STEEL_4340

    def __post_init__(self) -> None:
        # Preserve the guard against a degenerate zero-radius core, but leave
        # broader validation to explicit validate()/Discretizer paths so legacy
        # callers can still construct placeholder payloads.
        if isclose(self.T_D, 0.5, rel_tol=0.0, abs_tol=1e-12):
            raise ValidationError("Cylinder thickness-to-diameter ratio must be < 0.5.")

    @property
    def L(self) -> float:
        return self.D * self.L_D

    @property
    def T(self) -> float:
        return self.D * self.T_D

    @property
    def case_radius(self) -> float:
        return self.D / 2.0

    @property
    def explosive_radius(self) -> float:
        return self.case_radius - self.T

    @property
    def explosive_properties(self) -> ExplosiveProperties:
        return EXPLOSIVE_PROPERTIES[self.explosive]

    def profile_arrays(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        from .classes.cylinder import sample_cylinder_profile

        return sample_cylinder_profile(
            total_length_m=self.L,
            case_radius_m=self.case_radius,
            explosive_radius_m=self.explosive_radius,
        )

    @property
    def case_volume(self) -> float:
        axial, case_radii, explosive_radii = self.profile_arrays()
        return _integrate_revolved_volume(axial, case_radii) - _integrate_revolved_volume(
            axial, explosive_radii
        )

    @property
    def explosive_volume(self) -> float:
        axial, _, explosive_radii = self.profile_arrays()
        return _integrate_revolved_volume(axial, explosive_radii)

    @property
    def case_mass(self) -> float:
        return self.case_volume * CASING_LIBRARY[self.casing].density

    @property
    def explosive_mass(self) -> float:
        return self.explosive_volume * self.explosive_properties.density_kg_m3

    def material_properties_vector(self) -> np.ndarray:
        """Return the canonical nine material/detonation slots."""
        props = self.explosive_properties
        from .discretizer import encode_casing_code

        return np.array(
            [
                props.gurney_constant_m_s,
                props.detonation_velocity_m_s,
                INITIATION_ENCODING[self.initiation],
                CASING_LIBRARY[self.casing].density,
                self.T_D,
                self.L_D,
                self.D,
                props.density_kg_m3,
                encode_casing_code(self.casing),
            ],
            dtype=float,
        )


@dataclass
class CylinderConePrimitives(CylinderPrimitives):
    """Layer 1 for CYL_CONE."""

    L_cone: float = 0.0  # Cone section length (m)
    D_cone_front: float = 0.0  # Front diameter of cone (m)

    def __post_init__(self) -> None:
        super().__post_init__()

    @property
    def front_case_radius(self) -> float:
        return self.D_cone_front / 2.0

    @property
    def front_explosive_radius(self) -> float:
        return self.front_case_radius - self.T

    def profile_arrays(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        from .classes.cylinder_cone import sample_cylinder_cone_profile

        return sample_cylinder_cone_profile(
            total_length_m=self.L,
            cone_length_m=self.L_cone,
            case_radius_m=self.case_radius,
            front_case_radius_m=self.front_case_radius,
            explosive_radius_m=self.explosive_radius,
            front_explosive_radius_m=self.front_explosive_radius,
        )


@dataclass
class CylinderConeOgivePrimitives(CylinderConePrimitives):
    """Layer 1 for CYL_CONE_OGIVE."""

    R_ogive: float = 0.0  # Ogive radius (m)

    def __post_init__(self) -> None:
        super().__post_init__()

    def profile_arrays(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        from .classes.cylinder_cone_ogive import sample_cylinder_cone_ogive_profile

        return sample_cylinder_cone_ogive_profile(
            total_length_m=self.L,
            nose_length_m=self.L_cone,
            case_radius_m=self.case_radius,
            front_case_radius_m=self.front_case_radius,
            explosive_radius_m=self.explosive_radius,
            front_explosive_radius_m=self.front_explosive_radius,
            ogive_radius_m=self.R_ogive,
        )
