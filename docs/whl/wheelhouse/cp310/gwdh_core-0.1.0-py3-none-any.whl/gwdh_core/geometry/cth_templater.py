"""Layer 1 primitive -> APRE text rendering helpers."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from gwdh_core.types import CasingMaterial, ExplosiveType, InitiationPoint

from gwdh_core.geometry.primitives import (
    CylinderConePrimitives,
    CylinderConeOgivePrimitives,
    CylinderPrimitives,
)

CM_PER_M = 100.0
DEFAULT_APRE_TITLE = "GDWH Generated Penetrator"
DEFAULT_RUN_TIME_S = 1.0e-4
REQUIRED_TOKENS = (
    "@@TITLE@@",
    "@@RUN_TIME_S@@",
    "@@X_MESH_MAX_CM@@",
    "@@Y_MESH_MIN_CM@@",
    "@@Y_MESH_MAX_CM@@",
    "@@CASE_UDS_POINTS_CM@@",
    "@@HE_UDS_POINTS_CM@@",
    "@@GWDH_TRACERS@@",
)
PrimitivePayload = CylinderPrimitives | CylinderConePrimitives | CylinderConeOgivePrimitives


def primitives_to_template_params(primitives: CylinderPrimitives) -> dict:
    """Serialize typed primitives into a template-friendly mapping."""
    params: dict = {
        "D": primitives.D,
        "L": primitives.L,
        "T": primitives.T,
        "L_D": primitives.L_D,
        "T_D": primitives.T_D,
        "explosive": primitives.explosive.value,
        "initiation": primitives.initiation.value,
        "casing_material": primitives.casing.value,
        "casing": primitives.casing.value,
    }

    if isinstance(primitives, CylinderConePrimitives):
        params["L_cone"] = primitives.L_cone
        params["D_cone_front"] = primitives.D_cone_front

    if isinstance(primitives, CylinderConeOgivePrimitives):
        params["R_ogive"] = primitives.R_ogive

    return params


def derive_mesh_params(primitives: CylinderPrimitives) -> dict:
    """Derive simple CTH mesh bounds from the geometry envelope."""
    L_cm = primitives.L * CM_PER_M
    D_cm = primitives.D * CM_PER_M
    R_cm = D_cm / 2.0

    return {
        "X_MESH_MIN": 0.0,
        "X_MESH_MAX": R_cm * 1.5,
        "Y_MESH_MIN": -1.0,  # small margin below base
        "Y_MESH_MAX": L_cm * 1.5,
        "FINE_MESH": min(D_cm, L_cm) / 100.0,
    }


def derive_run_time(primitives: CylinderPrimitives) -> float:
    """Estimate CTH simulation stop time (seconds)."""
    det_vel = primitives.explosive_properties.detonation_velocity_m_s
    transit_time = primitives.L / max(det_vel, 1e-8)
    return transit_time * 3.0


class CTHTemplater:
    """Render APRE templates from canonical Layer 1 primitives."""

    def primitives_from_mapping(self, primitive_params: Mapping[str, Any]) -> PrimitivePayload:
        try:
            diameter = float(primitive_params["D"])
            length_ratio = float(primitive_params["L_D"])
            thickness_ratio = float(primitive_params["T_D"])
        except KeyError as exc:
            raise KeyError(
                "primitive_params must include keys: D, L_D, T_D, explosive, initiation"
            ) from exc

        explosive = self._coerce_explosive(primitive_params.get("explosive"))
        initiation = self._coerce_initiation(primitive_params.get("initiation"))
        casing = self._coerce_casing(
            primitive_params.get("casing", primitive_params.get("casing_material"))
        )

        if "R_ogive" in primitive_params:
            return CylinderConeOgivePrimitives(
                D=diameter,
                L_D=length_ratio,
                T_D=thickness_ratio,
                explosive=explosive,
                initiation=initiation,
                casing=casing,
                L_cone=float(primitive_params["L_cone"]),
                D_cone_front=float(primitive_params["D_cone_front"]),
                R_ogive=float(primitive_params["R_ogive"]),
            )
        if "L_cone" in primitive_params or "D_cone_front" in primitive_params:
            return CylinderConePrimitives(
                D=diameter,
                L_D=length_ratio,
                T_D=thickness_ratio,
                explosive=explosive,
                initiation=initiation,
                casing=casing,
                L_cone=float(primitive_params["L_cone"]),
                D_cone_front=float(primitive_params["D_cone_front"]),
            )
        return CylinderPrimitives(
            D=diameter,
            L_D=length_ratio,
            T_D=thickness_ratio,
            explosive=explosive,
            initiation=initiation,
            casing=casing,
        )

    def validate_template_text(self, template_text: str) -> None:
        for token in REQUIRED_TOKENS:
            count = template_text.count(token)
            if count != 1:
                if token == "@@GWDH_TRACERS@@" and count == 0:
                    raise ValueError(
                        "APRE template is missing required tracer marker '@@GWDH_TRACERS@@'."
                    )
                raise ValueError(
                    f"APRE template must contain token {token!r} exactly once; found {count}."
                )

    def render_text(
        self,
        template_text: str,
        primitives: PrimitivePayload,
        *,
        title: str | None = None,
        run_time_s: float = DEFAULT_RUN_TIME_S,
    ) -> str:
        self.validate_template_text(template_text)
        replacements = self._build_replacements(
            primitives=primitives,
            title=title or self._default_title(primitives),
            run_time_s=run_time_s,
        )
        rendered = template_text
        for token, value in replacements.items():
            rendered = rendered.replace(token, value)
        return rendered

    def render_file(
        self,
        template_path: str | Path,
        output_path: str | Path,
        primitives: PrimitivePayload,
        *,
        title: str | None = None,
        run_time_s: float = DEFAULT_RUN_TIME_S,
    ) -> None:
        template = Path(template_path).read_text()
        rendered = self.render_text(
            template,
            primitives,
            title=title,
            run_time_s=run_time_s,
        )
        Path(output_path).write_text(rendered)

    def _build_replacements(
        self,
        *,
        primitives: PrimitivePayload,
        title: str,
        run_time_s: float,
    ) -> dict[str, str]:
        axial_m, case_radii_m, explosive_radii_m = primitives.profile_arrays()
        axial_cm = axial_m * CM_PER_M
        case_radii_cm = case_radii_m * CM_PER_M
        explosive_radii_cm = explosive_radii_m * CM_PER_M
        mesh = derive_mesh_params(primitives)
        return {
            "@@TITLE@@": self._quote_title(title),
            "@@RUN_TIME_S@@": f"{run_time_s:.8e}",
            "@@X_MESH_MAX_CM@@": f"{mesh['X_MESH_MAX']:.5f}",
            "@@Y_MESH_MIN_CM@@": f"{mesh['Y_MESH_MIN']:.5f}",
            "@@Y_MESH_MAX_CM@@": f"{mesh['Y_MESH_MAX']:.5f}",
            "@@CASE_UDS_POINTS_CM@@": self._format_uds_points(
                self._case_polygon_points_cm(axial_cm, case_radii_cm, explosive_radii_cm)
            ),
            "@@HE_UDS_POINTS_CM@@": self._format_uds_points(
                self._explosive_polygon_points_cm(axial_cm, explosive_radii_cm)
            ),
        }

    def _default_title(self, primitives: PrimitivePayload) -> str:
        if isinstance(primitives, CylinderConeOgivePrimitives):
            return f"{DEFAULT_APRE_TITLE} CYL_CONE_OGIVE"
        if isinstance(primitives, CylinderConePrimitives) and type(primitives) is CylinderConePrimitives:
            return f"{DEFAULT_APRE_TITLE} CYL_CONE"
        return f"{DEFAULT_APRE_TITLE} CYL"

    def _case_polygon_points_cm(
        self,
        axial_cm,
        case_radii_cm,
        explosive_radii_cm,
    ) -> list[tuple[float, float]]:
        points = list(zip(case_radii_cm.tolist(), axial_cm.tolist()))
        inner_points = list(zip(explosive_radii_cm.tolist(), axial_cm.tolist()))
        points.extend([(0.0, float(axial_cm[-1]))])
        points.extend(list(reversed(inner_points)))
        points.append((float(case_radii_cm[0]), float(axial_cm[0])))
        return self._dedupe_sequential(points)

    def _explosive_polygon_points_cm(self, axial_cm, explosive_radii_cm) -> list[tuple[float, float]]:
        points = [(0.0, float(axial_cm[0]))]
        points.extend(zip(explosive_radii_cm.tolist(), axial_cm.tolist()))
        points.append((0.0, float(axial_cm[-1])))
        return self._dedupe_sequential(points)

    def _format_uds_points(self, points: list[tuple[float, float]]) -> str:
        return "\n".join(
            f"                point {radius_cm:.5f} {axial_cm:.5f}"
            for radius_cm, axial_cm in points
        )

    def _dedupe_sequential(self, points: list[tuple[float, float]]) -> list[tuple[float, float]]:
        deduped: list[tuple[float, float]] = []
        for point in points:
            rounded = (round(float(point[0]), 10), round(float(point[1]), 10))
            if not deduped or rounded != deduped[-1]:
                deduped.append(rounded)
        return deduped

    def _quote_title(self, title: str) -> str:
        stripped = title.strip()
        if stripped.startswith('"') and stripped.endswith('"'):
            return stripped
        return f'"{stripped}"'

    def _coerce_explosive(self, value: Any) -> ExplosiveType:
        if isinstance(value, ExplosiveType):
            return value
        if isinstance(value, str):
            return ExplosiveType(value)
        raise ValueError("primitive_params['explosive'] must be an ExplosiveType or str.")

    def _coerce_initiation(self, value: Any) -> InitiationPoint:
        if isinstance(value, InitiationPoint):
            return value
        if isinstance(value, str):
            return InitiationPoint(value)
        raise ValueError("primitive_params['initiation'] must be an InitiationPoint or str.")

    def _coerce_casing(self, value: Any) -> CasingMaterial:
        if value is None:
            return CasingMaterial.STEEL_4340
        if isinstance(value, CasingMaterial):
            return value
        if isinstance(value, str):
            return CasingMaterial(value)
        raise ValueError("primitive_params['casing'] must be a CasingMaterial or str.")
