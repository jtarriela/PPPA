"""Physics formulas: Gurney velocity, mass calculations, geometry extraction.

Canonical home for warhead physics computations used across all GWDH libs.
All functions operate on raw numpy arrays (Layer 2 design vectors).

Design vector layout (36 elements):
    [0:9]   — 9 axial coordinates
    [9:18]  — 9 case (outer) radii
    [18:27] — 9 explosive (inner) radii
    [27:36] — 9 material/detonation properties
"""
from __future__ import annotations

import numpy as np

# ── Material constants ──────────────────────────────────────

RHO_COMP_B: float = 1.72e3     # kg/m^3 — Composition B explosive density
RHO_STEEL: float = 7.85e3      # kg/m^3 — Steel casing density (legacy default)
E_GURNEY_DEFAULT: float = 2.5e6  # J/kg — Gurney energy for Comp-B
ETA_EFFICIENCY_DEFAULT: float = 0.3  # Thermodynamic efficiency factor

# Design vector index that stores casing density (set by Discretizer._encode_material)
_DV_CASING_DENSITY_IDX: int = 30


# ── Single-design functions ─────────────────────────────────


def compute_explosive_mass(design: np.ndarray, rho: float = RHO_COMP_B) -> float:
    """Compute explosive charge mass for a single (36,) design vector.

    Uses trapezoidal cylinder approximation: V = pi * r_avg^2 * dz.
    """
    axial = design[0:9]
    expl_r = design[18:27]
    dz = np.diff(axial)
    r_avg = (expl_r[:-1] + expl_r[1:]) / 2
    return float(np.sum(np.pi * r_avg ** 2 * dz) * rho)


def compute_case_mass(design: np.ndarray, rho: float | None = None) -> float:
    """Compute casing mass for a single (36,) design vector.

    Uses annular cylinder approximation: V = pi * (r_out^2 - r_in^2) * dz.

    Args:
        design: (36,) design vector.
        rho: Casing density (kg/m³).  If None, reads from design[30] (set by
             Discretizer for the actual casing material).
    """
    if rho is None:
        rho = float(design[_DV_CASING_DENSITY_IDX])
    axial = design[0:9]
    case_r = design[9:18]
    expl_r = design[18:27]
    dz = np.diff(axial)
    r_out_avg = (case_r[:-1] + case_r[1:]) / 2
    r_in_avg = (expl_r[:-1] + expl_r[1:]) / 2
    return float(np.sum(np.pi * (r_out_avg ** 2 - r_in_avg ** 2) * dz) * rho)


def compute_diameter(design: np.ndarray) -> float:
    """Max outer diameter for a single design vector."""
    return float(2.0 * np.max(design[9:18]))


def compute_length(design: np.ndarray) -> float:
    """Total length for a single design vector."""
    return float(design[8] - design[0])


def gurney_ke_limit(
    mass_charge: float,
    E_gurney: float = E_GURNEY_DEFAULT,
    eta: float = ETA_EFFICIENCY_DEFAULT,
) -> float:
    """Thermodynamic KE ceiling: KE_max = m_charge * E_gurney * eta."""
    return mass_charge * E_gurney * eta


# ── Batch functions (N, 36) ─────────────────────────────────


def compute_explosive_mass_batch(
    X: np.ndarray, rho: float = RHO_COMP_B
) -> np.ndarray:
    """Compute explosive mass for a batch of (N, 36) design vectors."""
    axial = X[:, 0:9]
    expl_r = X[:, 18:27]
    dz = np.diff(axial, axis=1)
    r_avg = (expl_r[:, :-1] + expl_r[:, 1:]) / 2
    return np.sum(np.pi * r_avg ** 2 * dz, axis=1) * rho


def compute_case_mass_batch(
    X: np.ndarray, rho: np.ndarray | float | None = None
) -> np.ndarray:
    """Compute casing mass for a batch of (N, 36) design vectors.

    Args:
        X: (N, 36) design matrix.
        rho: Casing density. If None, reads per-row from X[:, 30] (set by
             Discretizer for the actual casing material).  Pass a scalar float
             to override all rows with a fixed density.
    """
    if rho is None:
        rho = X[:, _DV_CASING_DENSITY_IDX]  # (N,) per-design density
    axial = X[:, 0:9]
    case_r = X[:, 9:18]
    expl_r = X[:, 18:27]
    dz = np.diff(axial, axis=1)
    r_out_avg = (case_r[:, :-1] + case_r[:, 1:]) / 2
    r_in_avg = (expl_r[:, :-1] + expl_r[:, 1:]) / 2
    volumes = np.sum(np.pi * (r_out_avg ** 2 - r_in_avg ** 2) * dz, axis=1)  # (N,)
    return volumes * rho


def compute_diameter_batch(X: np.ndarray) -> np.ndarray:
    """Max outer diameter for a batch of (N, 36) design vectors."""
    return 2.0 * np.max(X[:, 9:18], axis=1)


def compute_length_batch(X: np.ndarray) -> np.ndarray:
    """Total length for a batch of (N, 36) design vectors."""
    return X[:, 8] - X[:, 0]
