"""Casing material property registry.

Central lookup for fragment casing physical properties and CTH EOS/strength model
text blocks.  The CASING_LIBRARY maps each CasingMaterial enum value to a
CasingProperties object that carries:

  * density      — used in the 36-element DesignVector at index [30] and in mass
                   calculations throughout gwdh_core.physics
  * eos_block    — verbatim APRE text that replaces the MATERIAL1 line inside the
                   EOS block
  * strength_block — verbatim APRE text that replaces the MATEP 1 lines inside
                     EPDATA

To add a new material:
1. Add an entry to CasingMaterial in gwdh_core.types.
2. Add the corresponding CasingProperties entry here.
3. Assign the next available integer in _CASING_CODE inside
   gwdh_core.geometry.discretizer.

Reference: docs/adrs/ADR-0006-profile-generator-over-ffd.md
"""
from __future__ import annotations

from dataclasses import dataclass

from gwdh_core.types import CasingMaterial


@dataclass(frozen=True)
class CasingProperties:
    """Physical constants + CTH model text for one casing material."""
    density: float       # kg/m³
    eos_block: str       # APRE EOS model line (inserted after MATERIAL1 keyword)
    strength_block: str  # APRE EPDATA block (replaces MATEP 1 ... block)


CASING_LIBRARY: dict[CasingMaterial, CasingProperties] = {
    CasingMaterial.STEEL_4340: CasingProperties(
        density=7850.0,
        eos_block="MGR 100STEEL_TEP",
        strength_block=(
            "EPPVM USER\n"
            "        Yield = 0\n"
            "        Poisson = 0.33"
        ),
    ),
    CasingMaterial.STEEL_1018: CasingProperties(
        density=7870.0,
        eos_block="MGR 100STEEL_TEP",
        strength_block=(
            "EPPVM USER\n"
            "        Yield = 0\n"
            "        Poisson = 0.29"
        ),
    ),
    CasingMaterial.TUNGSTEN: CasingProperties(
        density=19250.0,
        eos_block="SESAME TUNGSTEN",
        strength_block="JOHNSON TUNGSTEN",
    ),
}
