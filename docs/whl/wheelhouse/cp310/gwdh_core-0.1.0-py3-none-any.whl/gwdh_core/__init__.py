"""gwdh-core: Canonical types and configuration for the GWDH system."""

from gwdh_core.config import (
    CampaignConfig,
    ClassifierConfig,
    DataLakeConfig,
    GWDHConfig,
    HPCConfig,
    ObservationRunnerConfig,
    OptimizationConfig,
    RoutingConfig,
    TelemetryConfig,
    TrainingConfig,
)
from gwdh_core.types import (
    CampaignStatus,
    DesignVector,
    EvalResult,
    EvalStatus,
    ExplosiveType,
    FailType,
    GeometryClass,
    InitiationPoint,
    JobHandle,
    ObserverState,
    ObserverStatus,
    RawZDATA,
    SectionOutput,
    SimulationRecord,
    SimulationSource,
    ZDATAStats,
    ZonalZDATA,
)

# Geometry subpackage
from gwdh_core.geometry import (
    CylinderConePrimitives,
    CylinderConeOgivePrimitives,
    CylinderPrimitives,
    Discretizer,
    Reconstructor,
    ValidationError,
)

__all__ = [
    # Config
    "CampaignConfig",
    "ClassifierConfig",
    "DataLakeConfig",
    "GWDHConfig",
    "HPCConfig",
    "ObservationRunnerConfig",
    "OptimizationConfig",
    "RoutingConfig",
    "TelemetryConfig",
    "TrainingConfig",
    # Enums
    "CampaignStatus",
    "EvalStatus",
    "ExplosiveType",
    "FailType",
    "GeometryClass",
    "InitiationPoint",
    "ObserverState",
    "SimulationSource",
    # Value objects & dataclasses
    "DesignVector",
    "EvalResult",
    "JobHandle",
    "ObserverStatus",
    "RawZDATA",
    "SectionOutput",
    "SimulationRecord",
    "ZDATAStats",
    "ZonalZDATA",
    # Geometry
    "CylinderPrimitives",
    "CylinderConePrimitives",
    "CylinderConeOgivePrimitives",
    "Discretizer",
    "Reconstructor",
    "ValidationError",
]
