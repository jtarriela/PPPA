"""Canonical data types shared across all GWDH libs."""
from __future__ import annotations

import uuid as _uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Protocol, runtime_checkable

import numpy as np

# ── Enums ────────────────────────────────────────────────────


class GeometryClass(str, Enum):
    CYL = "CYL"
    CYL_CONE = "CYL_CONE"
    CYL_CONE_OGIVE = "CYL_CONE_OGIVE"


class ExplosiveType(str, Enum):
    TNT = "TNT"
    COMP_B = "COMP_B"


class InitiationPoint(str, Enum):
    CENTER = "CENTER"
    BASE = "BASE"


class CasingMaterial(str, Enum):
    """Fragment casing material.

    Each label maps to a density and CTH EOS/strength model via
    gwdh_core.materials.CASING_LIBRARY.  Add new materials there.
    """
    STEEL_4340 = "STEEL_4340"
    STEEL_1018 = "STEEL_1018"
    TUNGSTEN   = "TUNGSTEN"


class SimulationSource(str, Enum):
    OPTIMIZATION = "OPTIMIZATION"
    VALIDATION = "VALIDATION"
    EXPLORATION = "EXPLORATION"
    DOE = "DOE"


class CampaignStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class EvalStatus(str, Enum):
    """Status of a single design evaluation."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CACHED = "cached"


class FailType(str, Enum):
    """Exhaustive classification of failure modes across the GDWH pipeline.

    Naming convention: STAGE_CAUSE
    """
    # Preprocessing failures
    PREPROCESS_APRE_MISSING = "preprocess_apre_missing"
    PREPROCESS_APRE_INVALID = "preprocess_apre_invalid"
    PREPROCESS_BOUNDS_VIOLATED = "preprocess_bounds_violated"

    # Slurm / submission failures
    SLURM_SUBMIT_REJECTED = "slurm_submit_rejected"
    SLURM_QUEUE_TIMEOUT = "slurm_queue_timeout"
    SLURM_NODE_FAIL = "slurm_node_fail"
    SLURM_PREEMPTED = "slurm_preempted"
    SLURM_OOM = "slurm_oom"

    # CTH hydrocode failures
    CTH_CRASH = "cth_crash"
    CTH_DIVERGED = "cth_diverged"
    CTH_TIMEOUT = "cth_timeout"
    CTH_INCOMPLETE_OUTPUT = "cth_incomplete_output"

    # Observation runner failures
    OBS_RUNNER_CRASH = "obs_runner_crash"
    OBS_STEADY_STATE_TIMEOUT = "obs_steady_state_timeout"
    OBS_KILL_FAILED = "obs_kill_failed"
    OBS_PROCESS_VERIFY_FAILED = "obs_process_verify_failed"

    # Postprocessing failures
    POSTPROCESS_PARSE_ERROR = "postprocess_parse_error"
    POSTPROCESS_MOTT_FIT_FAILED = "postprocess_mott_fit_failed"
    POSTPROCESS_ZDATA_INVALID = "postprocess_zdata_invalid"

    # Optimizer-level failures
    OPTIM_CACHE_CORRUPTED = "optim_cache_corrupted"
    OPTIM_CHECKPOINT_LOAD_FAILED = "optim_checkpoint_load_failed"

    # Catch-all
    UNKNOWN = "unknown"


class ObserverState(str, Enum):
    """State transitions for the HPC observation runner."""
    INITIALIZING = "initializing"
    LAUNCHING_CTH = "launching_cth"
    MONITORING_CTH = "monitoring_cth"
    KILLING_CTH = "killing_cth"
    VERIFYING_CTH_DEAD = "verifying_cth_dead"
    POSTPROCESSING = "postprocessing"
    COMPLETED = "completed"
    FAILED = "failed"


# ── Protocols ────────────────────────────────────────────────


@runtime_checkable
class SurrogateProtocol(Protocol):
    """Duck-type interface for surrogate models.

    Any object with a compatible predict_batch method satisfies this protocol.
    Used for isinstance() checks at interface boundaries.
    """

    def predict_batch(self, design_matrix: np.ndarray) -> np.ndarray:
        """Predict ZDATA from design vectors.

        Args:
            design_matrix: (N, 36) design vectors.

        Returns:
            (N, 36, 4) predicted ZDATA.
        """
        ...


# ── Constants ────────────────────────────────────────────────

N_ZONES = 36
N_ZONE_PARAMS = 4
N_SECTIONS = 8
N_SECTION_PARAMS = 2
DISCRETIZED_DIM = 36
STAGE1_OUT_DIM = N_SECTIONS * N_SECTION_PARAMS  # 16
STAGE2_IN_DIM = DISCRETIZED_DIM + STAGE1_OUT_DIM  # 52
ZDATA_SHAPE = (N_ZONES, N_ZONE_PARAMS)  # (36, 4)

ZONE_PARAM_NAMES = ["velocity", "N0", "lambda", "mu"]
DEFAULT_DISTANCE_WEIGHTS = np.array([1.0, 0.8, 0.3, 0.5])

MAX_ANGULAR_ZONES = 50
MAX_MASS_GROUPS_PER_ZONE = 25

# ── Value Objects ────────────────────────────────────────────


@dataclass(frozen=True)
class ZonalZDATA:
    """Layer 3: 36 zones x 4 parameters. Immutable."""
    data: np.ndarray  # shape (36, 4): columns are V, N0, lambda, mu

    def __post_init__(self):
        if self.data.shape != ZDATA_SHAPE:
            raise ValueError(f"Expected {ZDATA_SHAPE}, got {self.data.shape}")

    @property
    def velocity(self) -> np.ndarray:
        return self.data[:, 0]

    @property
    def N0(self) -> np.ndarray:
        return self.data[:, 1]

    @property
    def lam(self) -> np.ndarray:
        return self.data[:, 2]

    @property
    def mu(self) -> np.ndarray:
        return self.data[:, 3]

    def to_flat(self) -> np.ndarray:
        return self.data.ravel(order="F")

    @classmethod
    def from_flat(cls, flat: np.ndarray) -> ZonalZDATA:
        return cls(data=np.asarray(flat).reshape(ZDATA_SHAPE, order="F"))


@dataclass(frozen=True)
class DesignVector:
    """Layer 2: Discretized shape vector (36 params). Immutable."""
    data: np.ndarray  # shape (36,)

    def __post_init__(self):
        if self.data.shape != (DISCRETIZED_DIM,):
            raise ValueError(f"Expected ({DISCRETIZED_DIM},), got {self.data.shape}")

    @property
    def axial_coords(self) -> np.ndarray:
        return self.data[0:9]

    @property
    def case_radii(self) -> np.ndarray:
        return self.data[9:18]

    @property
    def explosive_radii(self) -> np.ndarray:
        return self.data[18:27]

    @property
    def material_props(self) -> np.ndarray:
        return self.data[27:36]


@dataclass(frozen=True)
class SectionOutput:
    """Stage 1 surrogate output: 8 sections x (velocity, angle) = 16 values."""
    data: np.ndarray  # shape (16,)

    @property
    def velocities(self) -> np.ndarray:
        return self.data[0:8]

    @property
    def angles(self) -> np.ndarray:
        return self.data[8:16]


@dataclass
class RawZDATA:
    """Full-fidelity ZDATA file contents per ARL-TN-541 spec.

    Unlike ZonalZDATA (which is the reduced (36,4) representation),
    this preserves the raw mass/count distributions with variable
    mass bins per zone.
    """
    n_zones: int
    lower_angles: np.ndarray       # (n_zones,) degrees
    midpoint_angles: np.ndarray    # (n_zones,) degrees
    upper_angles: np.ndarray       # (n_zones,) degrees
    lower_speeds: np.ndarray       # (n_zones,) ft/s
    midpoint_speeds: np.ndarray    # (n_zones,) ft/s
    upper_speeds: np.ndarray       # (n_zones,) ft/s
    masses: list[np.ndarray]       # list of (n_mass_groups,) per zone, grains
    counts: list[np.ndarray]       # list of (n_mass_groups,) per zone
    shape_factor: float            # ft^2 * gr^(1/3) / lb


@dataclass
class ZDATAStats:
    """Summary statistics for a ZDATA file, per ARL-TN-541 ZSTATS."""
    total_mass: float      # grains
    total_count: float     # expected fragment count (not necessarily integer)
    total_ke: float        # grains * ft^2/s^2
    avg_mass: float        # grains
    avg_speed: float       # ft/s


@dataclass
class SimulationRecord:
    """Full provenance record for one hydrocode simulation."""
    uuid: str = field(default_factory=lambda: str(_uuid.uuid4()))
    campaign_id: str = ""
    geometry_class: GeometryClass = GeometryClass.CYL
    source: SimulationSource = SimulationSource.DOE
    # Layer 1 (optional): primitive geometry/material parameters used to generate the design.
    # Stored as JSON in DuckDB (designs.primitive_params) for provenance/querying.
    primitive_params: Optional[dict] = None
    design_vector: Optional[DesignVector] = None
    stage1_output: Optional[SectionOutput] = None
    zdata: Optional[ZonalZDATA] = None
    sha256: str = ""
    cth_walltime_s: float = 0.0
    mott_fit_r2: Optional[np.ndarray] = None  # (36,) per-zone fit quality


@dataclass
class EvalResult:
    """Result of a single design evaluation (hydrocode or cached)."""
    eval_id: str
    design_vector: DesignVector
    status: EvalStatus
    fail_type: Optional[FailType] = None
    objectives: Optional[np.ndarray] = None
    stage1_output: Optional[SectionOutput] = None
    zdata: Optional[ZonalZDATA] = None
    mott_fit_r2: Optional[np.ndarray] = None
    runtime_sec: float = 0.0
    slurm_job_id: Optional[str] = None
    cth_version: Optional[str] = None
    parse_version: Optional[str] = None
    input_deck_sha256: Optional[str] = None
    timestamp: Optional[str] = None


@dataclass(frozen=True)
class JobHandle:
    """Handle for a submitted Slurm job."""
    job_id: str
    eval_id: str
    working_dir: str
    submit_time: str  # ISO8601


@dataclass
class ObserverStatus:
    """State written by the observation runner to observer_status.yaml."""
    slurm_job_id: str
    eval_id: str
    campaign_id: str
    state: ObserverState
    timestamp: str
    cth_pid: Optional[int] = None
    n_tracers: int = 0
    tracers_steady: int = 0
    tracers_total: int = 0
    velocity_mean: Optional[float] = None
    velocity_min: Optional[float] = None
    velocity_max: Optional[float] = None
    elapsed_sec: float = 0.0
    message: str = ""
    fail_type: Optional[FailType] = None
