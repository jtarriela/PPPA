# GFS Physics C++ Module Diagrams

This document provides **Mermaid UML-style diagrams** for each major C++ submodule, including data-flow, control-flow, and state diagrams. The diagrams are intentionally verbose to make the math/control sequencing explicit for audit and onboarding.

> Note: The diagrams reflect the current C++ implementation and its module boundaries in `gfs-cpp/include/gfs` and `gfs-cpp/src`.

## Legend and conventions

* **Data flow** diagrams emphasize payloads: tables, configs, buffers, and outputs.
* **Control flow** diagrams emphasize sequencing and branching.
* **State diagrams** show high-level state transitions for runtime structures (`CaseState`, `StepState`, `ZoneState`, etc.).

---

## Engine: `GFSMEngine`

### Data flow

```mermaid
flowchart LR
  Input[ImmutableInput] -->|cfg + tables| Engine[GFSMEngine::run_case]
  Engine --> Buffers[CaseBuffers/CaseState]
  Buffers --> Output[Output modules / bindings]
```

### Control flow

```mermaid
flowchart TD
  Start([run_case]) --> Init[make_case_state]
  Init --> COTM{cfg.nnnn?}
  COTM -- yes --> ApplyCOTM[Apply COTM cutoff logic]
  COTM -- no --> VectoringGate
  ApplyCOTM --> VectoringGate{cfg.nwc1 || cfg.nwc2?}
  VectoringGate -- yes --> Vectoring[Vectoring::run]
  VectoringGate -- no --> MatrixGate
  Vectoring --> MatrixGate{cfg.matz?}
  MatrixGate -- yes --> SetupDiag[Matrix::setup_diag]
  MatrixGate -- no --> Integration
  SetupDiag --> Integration[Integration::run]
  Integration --> End([done])
```

### State diagram (Engine lifecycle)

```mermaid
stateDiagram-v2
  [*] --> Idle
  Idle --> CaseInit: run_case()
  CaseInit --> PreProcess: make_case_state
  PreProcess --> Integration: modules invoked
  Integration --> Done: outputs ready
  Done --> Idle
```

---

## Input parsing: `InputParser`

### Data flow

```mermaid
flowchart LR
  Lines[IP.DAT lines] --> Parser[InputParser]
  Parser --> CaseConfigs[CaseConfig[]]
```

### Control flow

```mermaid
flowchart TD
  Start([parse_cases]) --> Split[Split into case blocks]
  Split --> Loop{More cases?}
  Loop -- yes --> ParseCase[parse_case]
  ParseCase --> Normalize[Normalize defaults/flags]
  Normalize --> Store[Append CaseConfig]
  Store --> Loop
  Loop -- no --> End([return configs])
```

### State diagram (CaseConfig creation)

```mermaid
stateDiagram-v2
  [*] --> Empty
  Empty --> Parsed: parse_case
  Parsed --> Normalized: defaults + flags
  Normalized --> Finalized: ready for finalize_shapes
```

---

## Loaders: ZDATA / RCAS / CDRAG / INTRVC

### Data flow

```mermaid
flowchart LR
  Raw[Raw file or stream] --> Loader[Loaders::*]
  Loader --> Tables[ZDataTable / RcasTable / CDragTable / IntrvcTable]
```

### Control flow (generic loader shape)

```mermaid
flowchart TD
  Start([load_*]) --> Read[Read headers + dimensions]
  Read --> Parse[Parse numeric rows]
  Parse --> Normalize[Normalize types + precompute]
  Normalize --> Validate[Validate monotonic vectors]
  Validate --> End([return table])
```

### State diagram (Table lifecycle)

```mermaid
stateDiagram-v2
  [*] --> Unloaded
  Unloaded --> Loaded: load_*()
  Loaded --> Normalized: precompute + align
  Normalized --> Ready
```

---

## Model finalization: `finalize_shapes`

### Data flow

```mermaid
flowchart LR
  CaseConfig --> Finalize[finalize_shapes]
  Tables --> Finalize
  Finalize --> ImmutableInput
```

### Control flow

```mermaid
flowchart TD
  Start([finalize_shapes]) --> Validate[Validate configuration]
  Validate --> MatrixRules[Normalize MATRIX fields]
  MatrixRules --> Sizes[Compute zone/step sizes]
  Sizes --> Emit[Return ImmutableInput]
```

### State diagram (ImmutableInput)

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Derived: compute sizes
  Derived --> Immutable: ready for engine
```

---

## Vectoring module

### Data flow

```mermaid
flowchart LR
  In[ImmutableInput] --> Vectoring[Vectoring::run]
  Buf[CaseBuffers/CaseState] --> Vectoring
  Vectoring --> Buf
```

### Control flow

```mermaid
flowchart TD
  Start([Vectoring::run]) --> InitZones[Initialize zone geometry]
  InitZones --> Angles[Compute angles + transforms]
  Angles --> Boundaries[Apply boundary limits]
  Boundaries --> End([return])
```

### State diagram (ZoneState)

```mermaid
stateDiagram-v2
  [*] --> Uninitialized
  Uninitialized --> GeometryReady: vectoring init
  GeometryReady --> AnglesReady: transforms done
  AnglesReady --> ReadyForIntegration
```

---

## Integration module

### Data flow

```mermaid
flowchart LR
  In[ImmutableInput] --> Integration[Integration::run]
  Buf[CaseBuffers/CaseState] --> Integration
  Integration --> StepState[StepState]
  Integration --> ZoneState[ZoneState updates]
  Integration --> Buf
```

### Control flow (math loop)

```mermaid
flowchart TD
  Start([Integration::run]) --> H3[Compute h3]
  H3 --> T3[Compute t3]
  T3 --> Gate{t3 > 0?}
  Gate -- no --> End([return])
  Gate -- yes --> MatrixInit{cfg.matz?}
  MatrixInit -- yes --> RNum[Matrix::rnum]
  MatrixInit -- no --> Setup
  RNum --> Setup[Setup integration params]
  Setup --> Loop[Integration loop over steps]
  Loop --> StepStateInit[make_step_state]
  StepStateInit --> TEV[PhysicsTEV::run]
  TEV --> Calc[Calc::run]
  Calc --> MatrixAccum{cfg.matz?}
  MatrixAccum -- yes --> Matrix[Matrix::accumulate]
  MatrixAccum -- no --> Next
  Matrix --> Next[Advance step]
  Next --> Loop
  Loop --> End([return])
```

### State diagram (StepState)

```mermaid
stateDiagram-v2
  [*] --> Initialized
  Initialized --> TEVReady: TEV precompute
  TEVReady --> CalcReady: calc inputs ready
  CalcReady --> Accumulated: matrix outputs updated
  Accumulated --> Completed
```

---

## PhysicsTEV module

### Data flow

```mermaid
flowchart LR
  In[ImmutableInput] --> TEV[PhysicsTEV]
  State[CaseState] --> TEV
  TEV --> Scratch[TevScratch]
  TEV --> State
```

### Control flow (math)

```mermaid
flowchart TD
  Start([PhysicsTEV]) --> LoadXele{scratch.xele_loaded?}
  LoadXele -- no --> BuildXele[Load xele brackets]
  LoadXele -- yes --> Planes
  BuildXele --> Planes[Prepare tza/tppa planes]
  Planes --> Interp[Interpolate TEV surfaces]
  Interp --> End([return])
```

### State diagram (TevScratch)

```mermaid
stateDiagram-v2
  [*] --> Empty
  Empty --> XeleLoaded: xele built
  XeleLoaded --> PlanesReady: tza/tppa planes
  PlanesReady --> Interpolated
```

---

## Calc module

### Data flow

```mermaid
flowchart LR
  In[ImmutableInput] --> Calc[Calc::run]
  State[CaseState + StepState + ZoneState] --> Calc
  Calc --> State
```

### Control flow (math)

```mermaid
flowchart TD
  Start([Calc::run]) --> PerZone[Loop zones]
  PerZone --> Drag[Apply drag + velocity]
  Drag --> Cutoff{INTRVC enabled?}
  Cutoff -- yes --> InterpCutoff[Interpolate cutoff]
  Cutoff -- no --> Lethality
  InterpCutoff --> Lethality[Compute lethality]
  Lethality --> Accum[Accumulate pk/box]
  Accum --> NextZone[Next zone]
  NextZone --> PerZone
  PerZone --> End([return])
```

### State diagram (SeksScratch)

```mermaid
stateDiagram-v2
  [*] --> Empty
  Empty --> Sized: resize
  Sized --> Populated: calc intermediates
  Populated --> Used: lethality computed
```

---

## Matrix module

### Data flow

```mermaid
flowchart LR
  In[CaseConfig] --> Matrix[Matrix::*]
  State[CaseState] --> Matrix
  Matrix --> State
```

### Control flow (math)

```mermaid
flowchart TD
  Start([Matrix]) --> Setup[setup_diag]
  Setup --> RNum[rnum grid sizing]
  RNum --> GridWalk[cell/grid]
  GridWalk --> Accum[update box/abox]
  Accum --> End([return])
```

### State diagram (Matrix accumulation)

```mermaid
stateDiagram-v2
  [*] --> EmptyGrid
  EmptyGrid --> DiagReady: setup_diag
  DiagReady --> Accumulating: rnum/cell loop
  Accumulating --> FinalGrid
```

---

## Output module

### Data flow

```mermaid
flowchart LR
  Buffers[CaseBuffers] --> Output[Output::*]
  Input[ImmutableInput] --> Output
  Output --> Files[PKVSR/LAM2/summary]
```

### Control flow

```mermaid
flowchart TD
  Start([write_output_files]) --> PKVSR[write_pkvsr]
  PKVSR --> LAM2[write_lam2]
  LAM2 --> Summary[write_summary]
  Summary --> End([done])
```

### State diagram (Output lifecycle)

```mermaid
stateDiagram-v2
  [*] --> Pending
  Pending --> Writing: outputs requested
  Writing --> Complete
```

---

## Bindings module: `GFSContext`

### Data flow

```mermaid
flowchart LR
  Input[Raw data bytes] --> Ctx[GFSContext]
  Ctx --> Tables[Cached tables]
  Ctx --> InputFinal[ImmutableInput]
  InputFinal --> Engine[GFSMEngine]
  Engine --> Result[CaseResult/BatchResult]
```

### Control flow

```mermaid
flowchart TD
  Start([run_batch]) --> Parse[InputParser.parse_cases]
  Parse --> Loop{cases}
  Loop -- next --> Build[build_input]
  Build --> Run[GFSMEngine::run_case]
  Run --> Extract[extract_result]
  Extract --> Loop
  Loop --> End([BatchResult])
```

### State diagram (GFSContext)

```mermaid
stateDiagram-v2
  [*] --> Empty
  Empty --> TablesLoaded: load_* called
  TablesLoaded --> Ready
  Ready --> Running: run_batch
  Running --> Ready
```

---

## State diagrams for core runtime structures

### CaseState

```mermaid
stateDiagram-v2
  [*] --> Allocated
  Allocated --> Initialized: make_case_state
  Initialized --> TEVReady: tev scratch sized
  TEVReady --> Integrated: integration loop
  Integrated --> Completed
```

### StepState

```mermaid
stateDiagram-v2
  [*] --> Allocated
  Allocated --> ScalarsReady: make_step_state
  ScalarsReady --> VectorsReady: set zz/q1/ratf
  VectorsReady --> UsedInCalc: calc loop
  UsedInCalc --> Completed
```

### ZoneState

```mermaid
stateDiagram-v2
  [*] --> Allocated
  Allocated --> GeometryReady: vectoring
  GeometryReady --> Integrated: calc/integration
  Integrated --> Completed
```

---

## Verbose control-flow narrative (math-centric)

1. **Vectoring** initializes per-zone geometry, angles, and boundary conditions from `CaseConfig` and ZDATA. This feeds the integration loop with consistent zone geometry and velocity control flags.
2. **Integration** computes the step schedule: it derives `h3` and `t3`, handles matrix-mode sizing (`Matrix::rnum`), and then iterates over steps. Each step prepares `StepState`, evaluates TEV interpolation, and invokes the core physics calculations.
3. **PhysicsTEV** constructs and interpolates TEV planes, caching the expensive `xele` brackets to avoid repeated lower-bound searches during integration. This precomputation drives downstream lethality computations.
4. **Calc** performs the main lethality evaluation: it updates drag, applies cutoff interpolation (INTRVC), and accumulates per-zone lethality into matrix accumulators (`box`, `abox`).
5. **Matrix** handles diagnostics and accumulation for MATRIX mode, using `setup_diag` and grid-walking helpers to update the output grid.
6. **Output** serializes `CaseBuffers` into LAM2 or PKVSR outputs for CLI usage, while `GFSContext` extracts matrix grids directly for Python.

