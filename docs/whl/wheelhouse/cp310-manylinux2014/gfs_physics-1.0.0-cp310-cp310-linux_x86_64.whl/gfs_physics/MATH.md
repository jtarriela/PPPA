# GFSM C++ Math and Control-Flow Details

This document explains **how the current C++ implementation computes the core physics quantities**, step by step, by module. The goal is to make the math and control flow explicit for audits and parity checks with `python_refactored/`.

> Scope: This document describes what is **implemented today** in `gfs-cpp/src`. It uses equations where the code exposes explicit formulas and provides algorithmic steps where formulas are embedded in longer procedural logic.

---

## 1) Notation and units

- `f32` operations are used throughout to mirror the Python reference and avoid unintended double-precision drift.
- Angles are often expressed in degrees in configuration and converted internally with `kRad2Deg` or `kDeg2Rad` helpers.
- Table indices are **0-based** but many loops preserve **1-based semantics** by offsetting index usage, matching legacy data conventions.

---

## 2) Engine-level control flow (context)

`GFSMEngine::run_case` orchestrates the per-case compute pipeline:

1. Build `CaseState` from `ImmutableInput`.
2. Apply COTM pre-processing (if `cfg.nnnn`).
3. Run `Vectoring` if velocity-control flags are set (`cfg.nwc1` or `cfg.nwc2`).
4. Initialize MATRIX diagnostics (if `cfg.matz`).
5. Enter `Integration::run`, which drives TEV precompute, physics calculations, and matrix accumulation per step.

This control order is important because each module’s computations depend on the state initialized by the previous module.

---

## 3) Vectoring module (`Vectoring.cpp`)

### 3.1 Angle normalization

The helper `angle_0_180(y, x)` normalizes a 2D angle into **[0°, 180°]**:

- If `x == 0`, the result is `90°`.
- Otherwise, it computes `atan2(y, x)` in radians and converts to degrees.
- If negative, the angle is shifted by `+180°` to land in the positive half-plane.【F:gfs-cpp/src/modules/Vectoring.cpp†L41-L47】

### 3.2 Drag distance integral (`xdrg`)

The `xdrg` function computes a **drag-integrated distance** between two velocities using CDRAG table parameters. It derives a scaled coefficient:

\[ cndc = \rho_{nhdt} \cdot skt_{nhdt} \cdot inv\_cbrt\_cmqq \]

If `cndc` is effectively zero, the function returns 0. Otherwise it uses the reciprocal:\
\[ inv\_cndc = 1 / cndc \]【F:gfs-cpp/src/modules/Vectoring.cpp†L53-L63】

For a CDRAG segment `(alh, bta)`, the local drag integral uses a log ratio:

- Define:

\[ cd\_{hi} = alh \cdot v_{hi} + bta \]
\[ cd\_{lo} = alh \cdot v_{lo} + bta \]

Clamped to avoid zero or negative values. If `alh ≈ 0`, the integral simplifies to:

\[ d = (inv\_bta \cdot inv\_cndc) \cdot \ln( v_{hi}/v_{lo} ) \]

Otherwise:

\[ d = (inv\_bta \cdot inv\_cndc) \cdot \ln\left( \frac{v_{hi} \cdot cd_{lo}}{v_{lo} \cdot cd_{hi}} \right) \]

This is the core integral used by `xdrg` to accumulate distance contributions across velocity segments.【F:gfs-cpp/src/modules/Vectoring.cpp†L66-L89】

The function then:

1. Locates the velocity bracket `iiv` where `vcf[iiv] <= voq`.
2. Computes partial segment integrals (`dxi`, `dxt`).
3. Adds any full-segment prefix sums from `seg_cum` when spanning multiple segments.
4. Returns the accumulated distance (or 0 when velocity bounds are out of range).【F:gfs-cpp/src/modules/Vectoring.cpp†L91-L155】

### 3.3 First-path range reduction (`drrr_first`)

`drrr_first` computes the first-path reduction distance for a zone:

1. Determine cutoff velocity `vtq` from `cfg.c3` or INTRVC (`wz4`) tables.
2. Clamp `vtq` to at least 1.0 after rounding; if `vtq >= c1j`, return 0.
3. Compute the inverse cube-root mass `inv_cbrt_cmqq` from ZDATA.
4. Return `xdrg(voq=c1j, inv_cbrt_cmqq, vtq)`, optionally limited by `rm1_limit` if requested.【F:gfs-cpp/src/modules/Vectoring.cpp†L158-L186】

---

## 4) Integration module (`Integration.cpp`)

### 4.1 Newton helper (`fx_fpx`)

`fx_fpx` computes the Newton function and derivative for a root-finding step:

- Define:

\[ a = \frac{ tlog (x_n + 1) - t_3 }{ x_n } \]

- Define the power term (guarded for `a > 0`):

\[ p = a^{1/(x_n - 1)} \]

- Then:

\[ f(a) = a^{x_n/(x_n - 1)} - tlog = a \cdot p - tlog \]
\[ f'(a) = \left(\frac{x_n + 1}{x_n - 1}\right) p - 1 \]

These values are returned as `NewtonEval` for use in the integration loop’s root solve steps.【F:gfs-cpp/src/modules/Integration.cpp†L40-L46】

### 4.2 Maximum range height (`compute_h3`)

`compute_h3` computes the effective height `h3` as:

\[ h_3 = \max_j h_1[j] \]

Then applies two adjustments:

1. If the revetment condition is met (`q41[1] < revht` and `pb_h < revht`), set:
   \[ h_3 = revdis + revbas \]
2. If `h3 >= rd1` or `idht` is false, then clamp the height to at least `rb2` if necessary.

These steps are applied sequentially as implemented in code.【F:gfs-cpp/src/modules/Integration.cpp†L49-L70】

### 4.3 Primary integration range `t3`

The integration loop derives a primary range variable `t3`:

1. Compute:

\[ x = |pb_h - q41[1]| \]

2. If `x < h3`, then:

\[ t_3 = \sqrt{ h_3^2 - x^2 } \]

3. Else if `idht` is false, exit early. Otherwise `t3 = rd1`.

If `t3 <= 0`, the integration exits early as well.【F:gfs-cpp/src/modules/Integration.cpp†L162-L175】

### 4.4 Matrix-aware integration setup

When MATRIX mode is active, the integration loop derives grid bounds and sizing using:

- `xmax = rar[nrg + 1]`
- `xmin = rar[1]`
- `ymax = dar[ndg/2 + 1]`

and then calls `Matrix::rnum` to compute range parameters that influence the integration schedule. These values then feed the loop setup that follows.【F:gfs-cpp/src/modules/Integration.cpp†L177-L200】

---

## 5) Output math (Python bindings)

`GFSContext::extract_result` computes LAM2-style results from the matrix accumulators.

### 5.1 Lethal area

For each range bin `i` and half-deflection bin `j`, it computes the area contribution:

\[ x_1 = rar[i+1] - rar[i] \]
\[ denm = (dar[j+1] - dar[j]) \cdot x_1 \]
\[ avg\_pk = box[j,i] / abox[j,i] \]

The total area accumulates `avg_pk * denm` over the half-grid, and the final lethal area doubles it to account for symmetry:

\[ lethal\_area = 2 \cdot \sum_{i=1}^{nrg} \sum_{j=1}^{ndg/2} avg\_pk \cdot denm \]

The code guards `abox` being zero and clamps NaNs to 0 when extracting `pk` values later.【F:gfs-cpp/src/bindings/GFSContext.cpp†L91-L151】

### 5.2 Axis construction

The deflection axis is constructed by taking cell centers of `dar[j]`/`dar[j+1]` for the positive half, mirroring to negative, and converting from feet to meters. The range axis is built as cell centers of `rar[i]`/`rar[i+1]`, also converted to meters.【F:gfs-cpp/src/bindings/GFSContext.cpp†L110-L128】

### 5.3 Grid extraction

The output grid is row-major and mirrors the half-grid so it matches LAM2 semantics. Each cell value is `box/abox` (or 0 if `abox` is 0), with NaNs clamped to 0.【F:gfs-cpp/src/bindings/GFSContext.cpp†L130-L151】

---

## 6) Module-by-module compute steps (summary)

These steps summarize the **control flow for math** in each module; the exact formulae live in their corresponding `.cpp` files.

### Vectoring

- Computes angles and geometric transforms for each zone.
- Evaluates drag-based distance integrals (`xdrg`) and velocity cutoff logic (`drrr_first`).【F:gfs-cpp/src/modules/Vectoring.cpp†L41-L187】

### PhysicsTEV

- Interpolates TEV surfaces from RCAS/ZDATA tables.
- Caches the `xele` brackets and builds TEV planes to reduce repeated searches during integration.

### Calc

- Drives per-zone physics and lethality evaluation.
- Applies cutoff interpolation (INTRVC) and updates matrix accumulators (`box`, `abox`).

### Matrix

- Initializes diagnostics for MATRIX mode and accumulates output grids based on per-step results.

### Output

- Serializes matrix outputs (LAM2-style) or PKVSR series using the values accumulated in `CaseState`.

---

## 7) Using this document

- Use this document alongside `ARCHITECTURE.md` and `DIAGRAMS.md` to understand **structure**, **control flow**, and **math**.
- When verifying parity with Python, align this document’s steps with the inline source references embedded in the C++ implementation.

