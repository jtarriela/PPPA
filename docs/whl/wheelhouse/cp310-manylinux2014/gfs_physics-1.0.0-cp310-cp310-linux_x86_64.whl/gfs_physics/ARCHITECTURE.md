# GFS Physics C++ Module Architecture (gfs_physics)

## Scope and purpose

This document describes the architecture of the **gfs_physics** C++ module and its Python binding layer. It audits the code as it exists today in `gfs-cpp/`, explains the core data flow, and records the rationale behind key design decisions based on the broader project documentation (e.g., the C++ implementation plan).

The C++ implementation lives under `gfs-cpp/include` and `gfs-cpp/src`, while the `gfs_physics` Python package (this folder) provides the import surface for the `_gfs_py` extension module. The Python package is intentionally thin: it directly imports the compiled extension and exposes `GFSContext` and result types. It also aliases the module name to `gfs_py` for compatibility with existing scripts.

## High-level architecture

```
+-------------------------+
| Python gfs_physics      |
| __init__.py             |
|  - import _gfs_py        |
|  - re-export API         |
+------------+------------+
             |
             v
+-------------------------+
| pybind11 module _gfs_py |
| src/bindings/gfs_py.cpp |
+------------+------------+
             |
             v
+-------------------------+
| GFSContext (PIMPL)      |
|  - cache tables         |
|  - parse cases          |
|  - build ImmutableInput |
|  - run GFSMEngine       |
+------------+------------+
             |
             v
+-------------------------+
| C++ core (gfs_lib)      |
|  InputParser/Loaders    |
|  ImmutableInput         |
|  GFSMEngine             |
|  Vectoring/Integration  |
|  PhysicsTEV/Calc/Matrix |
|  Output helpers         |
+-------------------------+
```

The C++ core is compiled as `gfs_lib` and also as the `_gfs_py` Python extension when `GFS_BUILD_PYTHON=ON` is enabled in CMake. The C++ library can be used directly through CLI tools (e.g., `gfs_run_case`) or via Python bindings.

## Directory layout (audit)

### `gfs-cpp/gfs_physics/` (Python package)

* `__init__.py` — package entry point; direct import of `_gfs_py` and compatibility alias for `gfs_py`.

### `gfs-cpp/include/gfs/` (public C++ API)

| Area | Key headers | Responsibility |
| --- | --- | --- |
| Core | `core/Types.hpp`, `core/MathF32.hpp`, `core/Constants.hpp`, `core/Profiling.hpp` | Numeric types, float32 math wrappers, constants, optional profiling hooks. |
| Model | `model/CaseConfig.hpp`, `model/ImmutableInput.hpp`, `model/Tables.hpp`, `model/State.hpp`, `model/Buffers.hpp` | Immutable inputs, table storage, and mutable per-case/step/zone state. |
| IO | `io/InputParser.hpp`, `io/Loaders.hpp`, `io/Output.hpp`, `io/DataDir.hpp` | Parsing IP.DAT, loading data tables, and writing outputs. |
| Engine | `engine/GFSMEngine.hpp` | Orchestration entry points for running cases/batches. |
| Modules | `modules/Vectoring.hpp`, `modules/Integration.hpp`, `modules/PhysicsTEV.hpp`, `modules/Calc.hpp`, `modules/Matrix.hpp` | Core compute phases. |
| Bindings | `bindings/GFSContext.hpp` | Python-facing interface for the engine. |
| Verification | `verify/GoldenHarness.hpp` | Parity-testing harness. |

### `gfs-cpp/src/` (implementation)

Source files align one-to-one with the public headers above, plus the pybind11 module `src/bindings/gfs_py.cpp` that exposes `GFSContext` to Python.

## Runtime data flow

1. **Input ingestion**
   * Python (or CLI) provides raw input text from `IP.DAT` plus static data files (ZDATA, RCAS, CDRAG, INTRVC).
   * `InputParser` converts input lines into `CaseConfig` objects.
   * `Loaders` convert static data files into normalized `Tables` data structures.

2. **Finalization / shape computation**
   * `finalize_shapes` consumes a `CaseConfig` and loaded `Tables` to produce an `ImmutableInput` with derived sizing information (`static_zones`, `dynamic_zones`, `step_count`).

3. **Engine execution**
   * `GFSMEngine::run_case` creates the `CaseState` and applies optional pre-processing (e.g., COTM cutoff logic).
   * `Vectoring` runs when velocity-control flags are active.
   * `Matrix::setup_diag` runs when MATRIX mode is active.
   * `Integration::run` drives the integration loop, which invokes `PhysicsTEV`, `Calc`, and `Matrix` helpers as needed.

4. **Output extraction**
   * For Python use, `GFSContext::extract_result` builds a `CaseResult` with LAM2-style grid outputs and axes.
   * For CLI use, `io/Output` can write PKVSR and LAM2 output files or summary text.

## Core data model (audit)

### CaseConfig (input configuration)

`CaseConfig` holds the parsed IP.DAT card data, including ZDATA/RCAS/CDRAG/INTRVC codes, matrix-mode parameters, correction flags, and a large set of ballistic/fragmentation parameters. It is the authoritative configuration for a single case before finalization.

### Tables (immutable lookup data)

Tables are normalized, aligned, and stored as flat 0-based arrays for CPU/GPU parity. Key tables include:

* `ZDataTable` — zone geometry and fragment mass/velocity distributions.
* `RcasTable` — target vulnerability tables (elevation, mass, velocity).
* `CDragTable` — drag coefficients and precomputed interpolation factors.
* `IntrvcTable` — cutoff-velocity curve and interpolated grid.

### ImmutableInput (finalized case)

`ImmutableInput` bundles the `CaseConfig` and `Tables` plus derived sizing info used to allocate runtime state. This object is passed to the engine and remains read-only during execution.

### CaseState and buffers

`CaseState` is the primary mutable state during execution. It contains pre-sized tables and scratch buffers for the integration loop, TEV interpolation, and matrix output accumulation. `CaseBuffers` currently wraps this state as a single struct.

## Engine and module boundaries

### GFSMEngine

`GFSMEngine` is the orchestration layer. It exposes `run_case` and `run_batch` and currently executes the workflow in the same order as the Python reference.

### Modules

The modules are structured as discrete compute phases:

* **Vectoring** — target geometry and velocity control pre-processing.
* **Integration** — main step loop that calculates per-step physics, invoking TEV and Calc as needed.
* **PhysicsTEV** — TEV-related interpolation and precomputation.
* **Calc** — lethality and fragmentation calculations.
* **Matrix** — MATRIX mode grid setup and accumulation.

This modular structure mirrors the architecture described in the C++ implementation plan, making it easier to map Python functions to C++ counterparts and to reason about future GPU kernel boundaries.

## Python bindings and gfs_physics package

* `GFSContext` exposes a higher-level API for loading static tables, parsing input cases, and running batches.
* It uses a PIMPL to keep the ABI stable and keep implementation details out of the header.
* The `gfs_physics` package currently imports `_gfs_py` directly and does **not** include runtime compilation logic. The module also registers itself under `gfs_py` for compatibility with older tooling.

## Build and configuration

The C++ library uses CMake with configurable architecture targets (`GFS_ARCH`) and optional features (OpenMP, fast math, LTO, profiling, MKL, Eigen). The default `skylake-epyc` target corresponds to the x86-64-v3 baseline, while `intel`, `amd`, and `generic` targets provide specialized builds for heterogeneous HPC environments.

The Python extension `_gfs_py` is built with pybind11 when `GFS_BUILD_PYTHON=ON` and installed into the `gfs_physics` package directory, enabling `import gfs_physics` to resolve the extension.

## Design decisions and rationale (from existing docs)

The architecture reflects several project-wide decisions documented elsewhere:

1. **Float32 math wrappers** — `core/MathF32.hpp` provides explicit `*f` math routines (e.g., `expf`, `sqrtf`) to keep the C++ calculations aligned with the Python reference and avoid inadvertent double-precision drift. This follows the C++ implementation plan’s requirement to preserve Python semantics for validation.

2. **Flat, aligned tables** — `model/Tables.hpp` stores data in flat 0-based arrays with alignment, matching the implementation plan’s push for SoA layouts and future CUDA compatibility.

3. **Module boundaries** — `Vectoring`, `Integration`, `PhysicsTEV`, `Calc`, and `Matrix` are distinct phases. This mirrors the plan’s call graph and keeps the compute pipeline transparent for verification.

4. **Architecture-specific builds** — The CMake `GFS_ARCH` options allow specialized builds when needed, but the current distribution favors a single x86-64-v3 (skylake-epyc) build to simplify deployment across Intel/AMD nodes. Earlier lazy-compilation guidance in the ADR is now obsolete.

## Current audit notes / constraints

* **Matrix-only extraction in Python**: `GFSContext::run_batch` skips non-MATRIX cases in IP.DAT, matching the current requirement to emit LAM2-style grids only.
* **Single-arch distribution**: The current package expects a single precompiled x86-64-v3 build and does not include per-node runtime compilation.
* **Profiling hooks**: Profiling is compiled in via `GFS_ENABLE_PROFILING` and emits CSVs when `GFS_PROFILE_CSV` is set.

## Suggested future extensions

* Expand `CaseBuffers` from a monolithic `CaseState` into SoA buffer groups if/when GPU backend work begins.
* Add a documented mapping table between each C++ module and the Python reference functions to formalize parity checks.
* See `DIAGRAMS.md` in this folder for module-level data-flow, control-flow, and state diagrams.
* See `MATH.md` in this folder for math/control-flow details and equations tied to the current implementation.
