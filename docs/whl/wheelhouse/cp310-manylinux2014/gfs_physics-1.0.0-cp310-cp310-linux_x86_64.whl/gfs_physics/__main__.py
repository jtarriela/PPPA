"""Read-only command-line entry point for gfs_physics."""

from __future__ import annotations

import argparse
import importlib
import importlib.metadata as metadata
from datetime import datetime, timezone
from pathlib import Path
import platform
import sys
from typing import Iterable

import gfs_physics


def _package_version() -> str:
    try:
        return metadata.version("gfs-physics")
    except metadata.PackageNotFoundError:
        return getattr(gfs_physics, "__version__", "unknown")


def _extension_module():
    return importlib.import_module("gfs_physics._gfs_py")


def _format_path(path: str | Path | None) -> str:
    if not path:
        return "not found"
    return str(Path(path))


def _format_mtime(path: str | Path | None) -> str:
    if not path:
        return "n/a"
    file_path = Path(path)
    if not file_path.exists():
        return "n/a"
    stamp = datetime.fromtimestamp(file_path.stat().st_mtime, tz=timezone.utc)
    return stamp.isoformat(timespec="seconds")


def _print_lines(lines: Iterable[str]) -> None:
    for line in lines:
        print(line)


def doctor() -> int:
    ext = _extension_module()
    ext_path = getattr(ext, "__file__", None)
    pkg_path = getattr(gfs_physics, "__file__", None)
    _print_lines(
        [
            "gfs_physics doctor",
            f"package_version: {_package_version()}",
            f"python_version: {platform.python_version()}",
            f"python_executable: {sys.executable}",
            f"platform: {platform.platform()}",
            f"machine: {platform.machine()}",
            f"processor: {platform.processor() or 'unknown'}",
            f"package_path: {_format_path(pkg_path)}",
            f"extension_path: {_format_path(ext_path)}",
            f"extension_mtime_utc: {_format_mtime(ext_path)}",
            f"gfs_py_alias: {'yes' if sys.modules.get('gfs_py') is gfs_physics else 'no'}",
        ]
    )
    return 0


def status() -> int:
    ext = _extension_module()
    ext_path = getattr(ext, "__file__", None)
    _print_lines(
        [
            "gfs_physics status",
            f"package_version: {_package_version()}",
            f"package_module: {gfs_physics.__name__}",
            f"package_path: {_format_path(getattr(gfs_physics, '__file__', None))}",
            f"extension_module: {ext.__name__}",
            f"extension_path: {_format_path(ext_path)}",
            f"extension_exists: {'yes' if ext_path else 'no'}",
            "commands: doctor, status",
        ]
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m gfs_physics")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("doctor", help="Show environment and package information")
    subparsers.add_parser("status", help="Show installed package and extension details")

    args = parser.parse_args(argv)
    if args.command == "doctor":
        return doctor()
    if args.command == "status":
        return status()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
