"""
GFS Physics Engine - C++ implementation with Python bindings.

This package provides high-performance physics simulation for lethality
analysis. Use as a drop-in replacement for Fortran-based solvers.

Usage:
    from gfs_physics import GFSContext

    ctx = GFSContext()
    ctx.load_cdrag(cdrag_bytes)
    ctx.load_zdata(1200, zdata_bytes)
    ctx.load_rcas(1001, rcas_bytes)

    result = ctx.run_batch(ip_dat_bytes)

Build Configuration:
    The package is pre-compiled for x86-64-v3 (Intel Skylake / AMD EPYC)
    with AVX2 and FMA support. No lazy compilation required.
"""
import sys

__version__ = "1.0.0"

# =============================================================================
# Import from compiled extension (direct import - no lazy loading)
# =============================================================================
try:
    from gfs_physics._gfs_py import (
        GFSContext,
        BatchResult,
        CaseResult,
        CaseHeader,
    )
except ImportError as e:
    raise ImportError(
        f"Failed to import _gfs_py extension. "
        f"Ensure the package was installed with 'pip install gfs-physics'. "
        f"Original error: {e}"
    ) from e

__all__ = ["GFSContext", "BatchResult", "CaseResult", "CaseHeader"]

# Backward compatibility: allow `import gfs_py` to work
# This ensures existing validation scripts and code continue to function
sys.modules['gfs_py'] = sys.modules[__name__]
