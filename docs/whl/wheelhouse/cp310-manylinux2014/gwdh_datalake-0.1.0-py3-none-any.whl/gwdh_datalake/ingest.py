"""External data ingestion: ZDATA + geometry → datalake.

Provides utilities to ingest external warhead simulation data
(ZDATA files + 2D geometry profiles) into the datalake for
surrogate training. Handles the conversion from 2D XY profile
points to Layer 2 DesignVector representation.
"""
from __future__ import annotations

import logging
import os

import numpy as np

from gwdh_core.geometry.discretizer import encode_casing_code
from gwdh_core.geometry.primitives import EXPLOSIVE_PROPERTIES, INITIATION_ENCODING
from gwdh_core.materials import CASING_LIBRARY
from gwdh_core.types import (
    CasingMaterial,
    DISCRETIZED_DIM,
    DesignVector,
    ExplosiveType,
    GeometryClass,
    InitiationPoint,
    SimulationRecord,
    SimulationSource,
)
from gwdh_core.zdata_io import read_zdata, raw_to_zonal

logger = logging.getLogger(__name__)


def profile_to_design_vector(
    fragment_points: np.ndarray,
    he_points: np.ndarray,
    geometry_class: GeometryClass,
    explosive: ExplosiveType = ExplosiveType.COMP_B,
    initiation: InitiationPoint = InitiationPoint.BASE,
    casing_material: CasingMaterial = CasingMaterial.STEEL_4340,
) -> DesignVector:
    """Convert 2D profile XY points to a 36-element DesignVector.

    Samples 9 evenly-spaced axial stations from the profiles,
    extracts radial dimensions at each station, and encodes
    material properties.

    Args:
        fragment_points: (N, 2) outer shell XY in cm. x=radial, y=axial.
        he_points: (M, 2) explosive fill XY in cm. x=radial, y=axial.
        geometry_class: Geometry class for material defaults.
        explosive: Explosive type for material encoding.
        initiation: Initiation point type.

    Returns:
        DesignVector with (36,) data array in meters.
    """
    CM_TO_M = 0.01

    # Extract axial range from fragment profile
    frag_y = fragment_points[:, 1]
    y_min = frag_y.min()
    y_max = frag_y.max()

    # Sample 9 axial stations
    axial_cm = np.linspace(y_min, y_max, 9)

    # For each station, find the max radial extent (outer = fragment, inner = HE)
    case_radii_cm = np.zeros(9)
    explosive_radii_cm = np.zeros(9)

    for i, y in enumerate(axial_cm):
        # Find fragment points near this axial station
        case_radii_cm[i] = _max_radius_at_axial(fragment_points, y)
        explosive_radii_cm[i] = _max_radius_at_axial(he_points, y)

    # Convert to meters
    vec = np.zeros(DISCRETIZED_DIM)
    vec[0:9] = axial_cm * CM_TO_M
    vec[9:18] = case_radii_cm * CM_TO_M
    vec[18:27] = explosive_radii_cm * CM_TO_M

    # Material encoding
    D = 2.0 * case_radii_cm.max() * CM_TO_M
    L = (y_max - y_min) * CM_TO_M
    T = np.mean(case_radii_cm - explosive_radii_cm) * CM_TO_M
    L_D = L / D if D > 0 else 1.0
    T_D = T / D if D > 0 else 0.05

    explosive_props = EXPLOSIVE_PROPERTIES[explosive]
    vec[27] = explosive_props.gurney_constant_m_s
    vec[28] = explosive_props.detonation_velocity_m_s
    vec[29] = INITIATION_ENCODING[initiation]
    vec[30] = CASING_LIBRARY[casing_material].density
    vec[31] = T_D
    vec[32] = L_D
    vec[33] = D
    vec[34] = explosive_props.density_kg_m3
    vec[35] = encode_casing_code(casing_material)

    return DesignVector(data=vec)


def _max_radius_at_axial(
    points: np.ndarray, y_target: float, tolerance: float = None
) -> float:
    """Find maximum radial extent of a polygon at a given axial position.

    Interpolates between polygon edges that straddle the target y.
    """
    if tolerance is None:
        y_range = points[:, 1].max() - points[:, 1].min()
        tolerance = y_range * 0.05

    # Find points close to this y
    mask = np.abs(points[:, 1] - y_target) < tolerance
    if np.any(mask):
        return float(points[mask, 0].max())

    # Interpolate: find edges that cross this y
    max_r = 0.0
    n = len(points)
    for j in range(n):
        p1 = points[j]
        p2 = points[(j + 1) % n]
        y1, y2 = p1[1], p2[1]

        if (y1 <= y_target <= y2) or (y2 <= y_target <= y1):
            if abs(y2 - y1) < 1e-12:
                r = max(p1[0], p2[0])
            else:
                t = (y_target - y1) / (y2 - y1)
                r = p1[0] + t * (p2[0] - p1[0])
            max_r = max(max_r, r)

    return float(max_r)


def ingest_zdata_with_geometry(
    data_lake,
    zdata_path: str,
    fragment_points: np.ndarray,
    he_points: np.ndarray,
    geometry_class: GeometryClass,
    campaign_id: str = "external",
    source: SimulationSource = SimulationSource.DOE,
    explosive: ExplosiveType = ExplosiveType.COMP_B,
    initiation: InitiationPoint = InitiationPoint.BASE,
    casing_material: CasingMaterial = CasingMaterial.STEEL_4340,
) -> str:
    """Ingest an external ZDATA file + 2D geometry into the datalake.

    Converts:
    - 2D profile points → DesignVector (Layer 2) via profile_to_design_vector
    - ZDATA file → ZonalZDATA (Layer 3) via gwdh_core.zdata_io

    Args:
        data_lake: DataLake instance.
        zdata_path: Path to the ZDATA file.
        fragment_points: (N, 2) outer shell XY in cm.
        he_points: (M, 2) explosive fill XY in cm.
        geometry_class: Geometry class.
        campaign_id: Campaign identifier for the ingested record.
        source: Simulation source label.
        explosive: Explosive type.
        initiation: Initiation point type.

    Returns:
        UUID of ingested record.
    """
    # Parse ZDATA
    raw = read_zdata(zdata_path)
    zonal, mott_r2 = raw_to_zonal(raw)

    # Convert geometry to DesignVector
    dv = profile_to_design_vector(
        fragment_points, he_points, geometry_class,
        explosive=explosive, initiation=initiation,
        casing_material=casing_material,
    )

    record = SimulationRecord(
        campaign_id=campaign_id,
        geometry_class=geometry_class,
        source=source,
        design_vector=dv,
        zdata=zonal,
        mott_fit_r2=mott_r2,
        cth_walltime_s=0.0,
    )

    uid = data_lake.ingest_simulation(record)
    logger.info(
        "Ingested external ZDATA %s as %s (geometry_class=%s)",
        zdata_path, uid, geometry_class.value,
    )
    return uid


def ingest_zdata_directory(
    data_lake,
    directory: str,
    geometry_class: GeometryClass,
    fragment_points: np.ndarray,
    he_points: np.ndarray,
    campaign_id: str = "external",
    source: SimulationSource = SimulationSource.DOE,
    casing_material: CasingMaterial = CasingMaterial.STEEL_4340,
) -> list[str]:
    """Ingest all ZDATA files from a directory.

    Uses the same geometry profile for all files (common warhead design).

    Returns list of UUIDs.
    """
    uuids = []
    for fname in sorted(os.listdir(directory)):
        lower = fname.lower()
        if "zdata" in lower and not lower.endswith((".py", ".pyc")):
            path = os.path.join(directory, fname)
            uid = ingest_zdata_with_geometry(
                data_lake, path,
                fragment_points, he_points,
                geometry_class,
                campaign_id=campaign_id,
                source=source,
                casing_material=casing_material,
            )
            uuids.append(uid)
    return uuids
