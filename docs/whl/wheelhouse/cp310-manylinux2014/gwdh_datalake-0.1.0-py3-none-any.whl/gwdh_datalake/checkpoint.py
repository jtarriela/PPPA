"""CMA-ES checkpoint save/load for campaign resume.

Stores optimizer state (mean, covariance, sigma, evolution paths, RNG)
as pickle files on Lustre with metadata in DuckDB.
"""
from __future__ import annotations

import os
import pickle
import uuid
from typing import Optional

import duckdb
import numpy as np


class CheckpointStore:
    """Save and load CMA-ES optimizer state for resume after crashes."""

    def __init__(
        self,
        conn: duckdb.DuckDBPyConnection,
        checkpoint_dir: str,
        max_checkpoints: int = 10,
    ):
        self.conn = conn
        self.checkpoint_dir = checkpoint_dir
        self.max_checkpoints = max_checkpoints
        os.makedirs(checkpoint_dir, exist_ok=True)

    def save(
        self,
        campaign_id: str,
        generation: int,
        optimizer_state: dict,
    ) -> str:
        """Save optimizer state and record metadata in DuckDB.

        Args:
            campaign_id: Campaign this checkpoint belongs to.
            generation: Generation number.
            optimizer_state: Dict with keys: mean, C, sigma, pc, ps,
                             rng_state, generation, eval_count.

        Returns:
            checkpoint_id
        """
        checkpoint_id = str(uuid.uuid4())
        campaign_dir = os.path.join(self.checkpoint_dir, campaign_id)
        os.makedirs(campaign_dir, exist_ok=True)

        state_path = os.path.join(campaign_dir, f"gen_{generation:06d}.pkl")
        with open(state_path, "wb") as f:
            pickle.dump(optimizer_state, f, protocol=pickle.HIGHEST_PROTOCOL)

        sigma = float(optimizer_state.get("sigma", 0.0))
        mean = optimizer_state.get("mean")
        mean_norm = float(np.linalg.norm(mean)) if mean is not None else 0.0
        best_f = float(optimizer_state.get("best_f", float("inf")))

        self.conn.execute(
            "INSERT INTO checkpoints "
            "(checkpoint_id, campaign_id, generation, state_path, sigma, mean_norm, best_f) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            [checkpoint_id, campaign_id, generation, state_path, sigma, mean_norm, best_f],
        )

        self._prune_old_checkpoints(campaign_id)
        return checkpoint_id

    def load_latest(self, campaign_id: str) -> Optional[dict]:
        """Load the most recent checkpoint for a campaign."""
        row = self.conn.execute(
            "SELECT state_path, generation FROM checkpoints "
            "WHERE campaign_id = ? ORDER BY generation DESC LIMIT 1",
            [campaign_id],
        ).fetchone()

        if row is None:
            return None

        state_path = row[0]
        if not os.path.exists(state_path):
            return None

        with open(state_path, "rb") as f:
            return pickle.load(f)  # noqa: S301

    def load_generation(self, campaign_id: str, generation: int) -> Optional[dict]:
        """Load a specific generation's checkpoint."""
        row = self.conn.execute(
            "SELECT state_path FROM checkpoints "
            "WHERE campaign_id = ? AND generation = ?",
            [campaign_id, generation],
        ).fetchone()

        if row is None or not os.path.exists(row[0]):
            return None

        with open(row[0], "rb") as f:
            return pickle.load(f)  # noqa: S301

    def _prune_old_checkpoints(self, campaign_id: str) -> None:
        """Keep only the most recent N checkpoints per campaign."""
        rows = self.conn.execute(
            "SELECT checkpoint_id, state_path FROM checkpoints "
            "WHERE campaign_id = ? ORDER BY generation DESC",
            [campaign_id],
        ).fetchall()

        if len(rows) <= self.max_checkpoints:
            return

        to_delete = rows[self.max_checkpoints:]
        for checkpoint_id, state_path in to_delete:
            try:
                os.remove(state_path)
            except FileNotFoundError:
                # Concurrent prune from another process already deleted this file;
                # not an error — proceed to remove the DB record.
                pass
            self.conn.execute(
                "DELETE FROM checkpoints WHERE checkpoint_id = ?",
                [checkpoint_id],
            )
