"""DuckDB schema definitions for the GWDH data lake.

All DDL statements are idempotent (CREATE IF NOT EXISTS).
"""
from __future__ import annotations

import duckdb


SCHEMA_VERSION = 1

DDL_STATEMENTS = [
    # ── Core tables ──────────────────────────────────────────
    """
    CREATE TABLE IF NOT EXISTS designs (
        uuid TEXT PRIMARY KEY,
        campaign_id TEXT,
        geometry_class TEXT NOT NULL,
        source TEXT NOT NULL,
        primitive_params JSON,
        discretized_vector DOUBLE[36],
        h5_row_index INTEGER,
        sha256 TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        cth_walltime_s DOUBLE,
        mott_fit_r2 DOUBLE[36]
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS campaigns (
        campaign_id TEXT PRIMARY KEY,
        geometry_class TEXT NOT NULL,
        target_zdata_path TEXT,
        optimizer_config JSON,
        surrogate_version TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'PENDING'
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS surrogate_registry (
        model_id TEXT PRIMARY KEY,
        geometry_class TEXT NOT NULL,
        stage INTEGER NOT NULL,
        training_sample_count INTEGER,
        holdout_metrics JSON,
        model_artifact_path TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS classifier_registry (
        model_id TEXT PRIMARY KEY,
        training_sample_count INTEGER,
        training_geometry_classes JSON,
        holdout_metrics JSON,
        model_artifact_path TEXT,
        calibrated BOOLEAN DEFAULT FALSE,
        validated_for_auto_route BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """,
    # ── Evaluation harness tables ────────────────────────────
    """
    CREATE TABLE IF NOT EXISTS eval_cache (
        design_hash TEXT PRIMARY KEY,
        design_vector DOUBLE[36],
        eval_id TEXT,
        objectives DOUBLE[],
        status TEXT,
        fail_type TEXT,
        runtime_sec DOUBLE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS checkpoints (
        checkpoint_id TEXT PRIMARY KEY,
        campaign_id TEXT,
        generation INTEGER,
        state_path TEXT,
        sigma DOUBLE,
        mean_norm DOUBLE,
        best_f DOUBLE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS eval_log (
        eval_id TEXT PRIMARY KEY,
        iter_id INTEGER,
        campaign_id TEXT,
        timestamp TEXT,
        design_vector DOUBLE[36],
        x_norm DOUBLE,
        pct_bounds_hit DOUBLE,
        objectives DOUBLE[],
        penalty DOUBLE,
        is_feasible BOOLEAN,
        status TEXT,
        fail_type TEXT,
        runtime_sec DOUBLE,
        slurm_job_id TEXT,
        input_deck_sha256 TEXT,
        cth_version TEXT,
        parse_version TEXT
    )
    """,
    # ── Schema metadata ──────────────────────────────────────
    """
    CREATE TABLE IF NOT EXISTS schema_meta (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    """,
]


def initialize_schema(conn: duckdb.DuckDBPyConnection) -> None:
    """Create all tables if they don't exist and record schema version."""
    for ddl in DDL_STATEMENTS:
        conn.execute(ddl)
    # Record schema version once; do not overwrite existing versions.
    # Version upgrades require explicit migrations rather than silent bumps.
    existing = conn.execute(
        "SELECT value FROM schema_meta WHERE key = 'schema_version'"
    ).fetchone()
    if existing is None:
        conn.execute(
            "INSERT INTO schema_meta (key, value) VALUES ('schema_version', ?)",
            [str(SCHEMA_VERSION)],
        )


def get_schema_version(conn: duckdb.DuckDBPyConnection) -> int:
    """Return the current schema version, or 0 if not initialized."""
    try:
        result = conn.execute(
            "SELECT value FROM schema_meta WHERE key = 'schema_version'"
        ).fetchone()
        return int(result[0]) if result else 0
    except duckdb.CatalogException:
        return 0
