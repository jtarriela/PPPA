"""Memoization cache for design evaluations.

Uses a quantized SHA256 hash for fast lookup, with L2-norm verification
for tolerance matching. Backed by DuckDB eval_cache table.
"""
from __future__ import annotations

import hashlib
from typing import Optional

import duckdb
import numpy as np

from gwdh_core.types import EvalResult, EvalStatus, FailType, DesignVector


class EvalCache:
    """Cache evaluated designs to avoid redundant hydrocode runs."""

    def __init__(self, conn: duckdb.DuckDBPyConnection, tolerance: float = 1e-6):
        self.conn = conn
        self.tolerance = tolerance

    def lookup(self, design: DesignVector) -> Optional[EvalResult]:
        """Check if a design (within tolerance) has been evaluated.

        Strategy:
        1. Quantize design vector to 6 decimal places
        2. Compute SHA256 of quantized vector bytes
        3. Look up in eval_cache table
        4. If found, verify L2 distance < tolerance
        """
        design_hash = self._hash_design(design.data)
        row = self.conn.execute(
            "SELECT design_vector, eval_id, objectives, status, fail_type, runtime_sec "
            "FROM eval_cache WHERE design_hash = ?",
            [design_hash],
        ).fetchone()

        if row is None:
            return None

        cached_vector = np.array(row[0])
        l2_dist = np.linalg.norm(design.data - cached_vector)
        if l2_dist > self.tolerance:
            return None

        return EvalResult(
            eval_id=row[1],
            design_vector=design,
            status=EvalStatus.CACHED,
            objectives=np.array(row[2]) if row[2] is not None else None,
            fail_type=FailType(row[4]) if row[4] else None,
            runtime_sec=row[5],
        )

    def store(self, design: DesignVector, result: EvalResult) -> None:
        """Store a completed evaluation in the cache."""
        design_hash = self._hash_design(design.data)
        self.conn.execute(
            "INSERT OR REPLACE INTO eval_cache "
            "(design_hash, design_vector, eval_id, objectives, status, fail_type, runtime_sec) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                design_hash,
                design.data.tolist(),
                result.eval_id,
                result.objectives.tolist() if result.objectives is not None else None,
                result.status.value,
                result.fail_type.value if result.fail_type else None,
                result.runtime_sec,
            ],
        )

    def _hash_design(self, vector: np.ndarray) -> str:
        """Quantize to 6 decimal places and compute SHA256.

        Canonicalizes -0.0 to 0.0 before hashing to avoid hash divergence
        for values near zero (np.round can produce -0.0 vs +0.0 for values
        that differ only in sign, but are equal to zero at 6 decimal places).
        """
        quantized = np.round(vector, decimals=6)
        # -0.0 and +0.0 are equal values but have different byte representations;
        # canonicalize to avoid false cache misses for designs near zero.
        quantized = np.where(quantized == 0.0, 0.0, quantized)
        return hashlib.sha256(quantized.tobytes()).hexdigest()
