"""CSV-based bulk migration and LHS design-matrix generator.

Intended for a junior engineer running CTH parametric studies:

1. Generate a Latin Hypercube design matrix CSV:
       python -m gwdh_datalake.migrate lhs \\
           --geometry-class CYL --n-samples 50 --output matrix.csv

2. Run CTH simulations, filling in the zdata_path column.

3. Validate the completed CSV before ingestion:
       python -m gwdh_datalake.migrate validate --csv matrix.csv

4. Bulk-ingest into the datalake:
       python -m gwdh_datalake.migrate ingest \\
           --csv matrix.csv \\
           --db-path data/gwdh.duckdb \\
           --tensor-dir data/tensors/ \\
           --campaign-id "cth_lhs_cyl_2026q1"

CSV Schema
----------
row_id, geometry_class, D, L_D, T_D, explosive, initiation, casing_material,
[L_cone, D_cone_front,]  zdata_path

The L_cone / D_cone_front columns are required for CYL_CONE rows and must be
blank for CYL rows.
"""
from __future__ import annotations

import argparse
import csv
import datetime
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from gwdh_core.config import DataLakeConfig
from gwdh_core.geometry.discretizer import Discretizer
from gwdh_core.geometry.primitives import CylinderConePrimitives, CylinderPrimitives
from gwdh_core.types import (
    CasingMaterial,
    ExplosiveType,
    GeometryClass,
    InitiationPoint,
    SimulationRecord,
    SimulationSource,
)
from gwdh_core.zdata_io import raw_to_zonal, read_zdata

from gwdh_datalake.datalake import DataLake

logger = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────

_REQUIRED_COLUMNS = {
    "row_id", "geometry_class", "D", "L_D", "T_D",
    "explosive", "initiation", "casing_material", "zdata_path",
}
_CONE_COLUMNS = {"L_cone", "D_cone_front"}

_CONT_BOUNDS_CYL = {
    "D": (0.02, 0.30),
    "L_D": (1.0, 6.0),
    "T_D": (0.02, 0.15),
}
_CONT_BOUNDS_CONE = {
    **_CONT_BOUNDS_CYL,
    "L_cone": (0.01, 0.20),
    "D_cone_front": (0.01, 0.25),
}

_VALID_GEOMETRY = {gc.value for gc in GeometryClass if gc != GeometryClass.CYL_CONE_OGIVE}
_VALID_EXPLOSIVE = {e.value for e in ExplosiveType}
_VALID_INITIATION = {i.value for i in InitiationPoint}
_VALID_CASING = {c.value for c in CasingMaterial}


# ── Result dataclass ─────────────────────────────────────────


@dataclass
class MigrationResult:
    """Summary of a bulk migrate_csv run."""
    total_rows: int = 0
    ingested: int = 0
    failed: int = 0
    errors: list[tuple[int, str]] = field(default_factory=list)
    campaign_id: str = ""
    uuids: list[str] = field(default_factory=list)


# ── Internal helpers ─────────────────────────────────────────


def _parse_row(row: dict, csv_dir: Path) -> tuple[CylinderPrimitives, str]:
    """Convert a validated CSV row → (primitives, resolved_zdata_path)."""
    geo = row["geometry_class"]
    explosive = ExplosiveType(row["explosive"])
    initiation = InitiationPoint(row["initiation"])
    casing = CasingMaterial(row["casing_material"])

    base_kwargs = dict(
        D=float(row["D"]),
        L_D=float(row["L_D"]),
        T_D=float(row["T_D"]),
        explosive=explosive,
        initiation=initiation,
        casing=casing,
    )

    if geo == "CYL_CONE":
        prims = CylinderConePrimitives(
            **base_kwargs,
            L_cone=float(row["L_cone"]),
            D_cone_front=float(row["D_cone_front"]),
        )
    else:
        prims = CylinderPrimitives(**base_kwargs)

    # Resolve zdata_path relative to the CSV's directory
    zdata_path = row["zdata_path"].strip()
    if not os.path.isabs(zdata_path):
        zdata_path = str(csv_dir / zdata_path)

    return prims, zdata_path


def _validate_row(row: dict, csv_dir: Path) -> list[str]:
    """Return a list of error strings for a single CSV row (empty = ok)."""
    errors: list[str] = []

    geo = row.get("geometry_class", "")
    if geo not in _VALID_GEOMETRY:
        errors.append(f"geometry_class must be one of {_VALID_GEOMETRY}, got {geo!r}")

    for col, (lo, hi) in _CONT_BOUNDS_CYL.items():
        val = row.get(col, "")
        try:
            v = float(val)
            if not (lo <= v <= hi):
                errors.append(f"{col}={v} out of bounds [{lo}, {hi}]")
        except (ValueError, TypeError):
            errors.append(f"{col}={val!r} is not a number")

    if row.get("explosive", "") not in _VALID_EXPLOSIVE:
        errors.append(f"explosive must be one of {_VALID_EXPLOSIVE}")
    if row.get("initiation", "") not in _VALID_INITIATION:
        errors.append(f"initiation must be one of {_VALID_INITIATION}")
    if row.get("casing_material", "") not in _VALID_CASING:
        errors.append(f"casing_material must be one of {_VALID_CASING}")

    if geo == "CYL_CONE":
        lo_lc, hi_lc = _CONT_BOUNDS_CONE["L_cone"]
        lo_dc, hi_dc = _CONT_BOUNDS_CONE["D_cone_front"]
        for col, (lo, hi) in [("L_cone", (lo_lc, hi_lc)), ("D_cone_front", (lo_dc, hi_dc))]:
            val = row.get(col, "")
            try:
                v = float(val)
                if not (lo <= v <= hi):
                    errors.append(f"{col}={v} out of bounds [{lo}, {hi}]")
            except (ValueError, TypeError):
                errors.append(f"{col}={val!r} must be a number for CYL_CONE")

        # Feasibility checks
        try:
            D = float(row.get("D", 0))
            L_D = float(row.get("L_D", 0))
            D_cone_front = float(row.get("D_cone_front", 0))
            L_cone = float(row.get("L_cone", 0))
            if D_cone_front >= D:
                errors.append(f"D_cone_front ({D_cone_front}) must be < D ({D})")
            if L_cone >= D * L_D:
                errors.append(f"L_cone ({L_cone}) must be < L=D*L_D ({D * L_D:.4f})")
        except (ValueError, TypeError):
            pass
    else:
        if row.get("L_cone", "").strip():
            errors.append("L_cone must be blank for CYL rows")
        if row.get("D_cone_front", "").strip():
            errors.append("D_cone_front must be blank for CYL rows")

    zdata_path = row.get("zdata_path", "").strip()
    if not zdata_path:
        errors.append("zdata_path is required")
    else:
        resolved = zdata_path if os.path.isabs(zdata_path) else str(csv_dir / zdata_path)
        if not os.path.exists(resolved):
            errors.append(f"zdata_path not found: {resolved}")

    return errors


def _read_csv_rows(
    csv_path: str,
) -> tuple[list[str] | None, list[dict[str, str]], list[tuple[int, str]]]:
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            return None, [], [(0, "CSV file is empty or has no header")]
        rows = list(reader)
        return list(reader.fieldnames), rows, []


def _validate_headers(fieldnames: list[str] | None) -> list[tuple[int, str]]:
    if fieldnames is None:
        return [(0, "CSV file is empty or has no header")]

    missing = _REQUIRED_COLUMNS - set(fieldnames)
    if missing:
        return [(0, f"CSV missing required columns: {sorted(missing)}")]
    return []


def _validate_geometry_classes(rows: list[dict[str, str]]) -> list[tuple[int, str]]:
    geometry_values = {
        row.get("geometry_class", "").strip()
        for row in rows
        if row.get("geometry_class", "").strip()
    }
    if len(geometry_values) > 1:
        return [
            (0, "mixed geometry_class values are not supported; split the CSV by geometry_class")
        ]
    return []


def _parse_row_id(row: dict[str, str], csv_line: int) -> tuple[int, str | None]:
    raw = row.get("row_id", "")
    try:
        return int(raw), None
    except (TypeError, ValueError):
        return 0, f"csv_line={csv_line} row_id={raw!r} must be an integer"


# ── Public API ───────────────────────────────────────────────


def validate_csv(csv_path: str) -> list[tuple[int, str]]:
    """Dry-run validation of a migration CSV.

    Returns a list of (row_id, error_message) pairs.  An empty list means
    all rows are valid.
    """
    csv_dir = Path(csv_path).parent
    fieldnames, rows, read_errors = _read_csv_rows(csv_path)
    if read_errors:
        return read_errors

    header_errors = _validate_headers(fieldnames)
    if header_errors:
        return header_errors

    geometry_errors = _validate_geometry_classes(rows)
    if geometry_errors:
        return geometry_errors

    errors: list[tuple[int, str]] = []
    for csv_line, row in enumerate(rows, start=2):
        row_id, row_id_error = _parse_row_id(row, csv_line)
        if row_id_error is not None:
            errors.append((0, row_id_error))
            continue
        for msg in _validate_row(row, csv_dir):
            errors.append((row_id, msg))

    return errors


def migrate_csv(
    csv_path: str,
    db_path: str,
    tensor_dir: str,
    campaign_id: Optional[str] = None,
    source: SimulationSource = SimulationSource.DOE,
    strict: bool = True,
) -> MigrationResult:
    """Bulk-ingest a validated CSV into the datalake.

    For each row:
    1. Construct primitives (CylinderPrimitives or CylinderConePrimitives)
    2. ``Discretizer().to_vector()`` → DesignVector(36,)
    3. ``read_zdata()`` + ``raw_to_zonal()`` → ZonalZDATA + mott_fit_r2
    4. ``DataLake.ingest_simulation()``

    Args:
        csv_path:    Path to the migration CSV.
        db_path:     Path to the DuckDB database file.
        tensor_dir:  Directory for HDF5 tensor files.
        campaign_id: Optional identifier. Auto-generated as
                     ``cth_migration_YYYYMMDD_HHMMSS`` when None.
        source:      SimulationSource label applied to all records.
        strict:      If True, abort on the first error.  If False, skip bad
                     rows and continue, collecting errors in MigrationResult.

    Returns:
        MigrationResult with counts, campaign_id, and list of UUIDs.
    """
    if campaign_id is None:
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        campaign_id = f"cth_migration_{ts}"

    result = MigrationResult(campaign_id=campaign_id)
    csv_dir = Path(csv_path).parent
    disc = Discretizer()
    fieldnames, rows, read_errors = _read_csv_rows(csv_path)
    result.total_rows = len(rows)
    if read_errors:
        result.errors.extend(read_errors)
        return result

    header_errors = _validate_headers(fieldnames)
    if header_errors:
        result.errors.extend(header_errors)
        return result

    geometry_errors = _validate_geometry_classes(rows)
    if geometry_errors:
        result.errors.extend(geometry_errors)
        return result

    if not rows:
        return result

    config = DataLakeConfig(db_path=db_path, tensor_dir=tensor_dir)
    lake = DataLake(config)
    campaign_geometry = GeometryClass(rows[0]["geometry_class"])
    lake.create_campaign(
        campaign_id=campaign_id,
        geometry_class=campaign_geometry,
        target_zdata_path="",
        optimizer_config={"source": "csv_migration", "csv_path": csv_path},
    )

    try:
        for csv_line, row in enumerate(rows, start=2):
            row_id, row_id_error = _parse_row_id(row, csv_line)
            if row_id_error is not None:
                result.errors.append((0, row_id_error))
                logger.warning("[migrate] Row at csv_line=%d skipped: %s", csv_line, row_id_error)
                if strict:
                    break
                continue

            row_errors = _validate_row(row, csv_dir)
            if row_errors:
                msg = "; ".join(row_errors)
                result.errors.append((row_id, msg))
                result.failed += 1
                logger.warning("[migrate] Row %d skipped: %s", row_id, msg)
                if strict:
                    break
                continue

            try:
                prims, zdata_path = _parse_row(row, csv_dir)
                dv = disc.to_vector(prims)

                raw = read_zdata(zdata_path)
                zonal, mott_r2 = raw_to_zonal(raw)

                geo_class = GeometryClass(row["geometry_class"])
                record = SimulationRecord(
                    campaign_id=campaign_id,
                    geometry_class=geo_class,
                    source=source,
                    design_vector=dv,
                    zdata=zonal,
                    mott_fit_r2=mott_r2,
                    cth_walltime_s=0.0,
                )
                uid = lake.ingest_simulation(record)
                result.uuids.append(uid)
                result.ingested += 1

                if result.ingested % 50 == 0:
                    logger.info(
                        "[migrate] Progress: %d/%d ingested",
                        result.ingested, result.total_rows,
                    )

            except Exception as exc:  # noqa: BLE001
                msg = str(exc)
                result.errors.append((row_id, msg))
                result.failed += 1
                logger.warning("[migrate] Row %d error: %s", row_id, msg)
                if strict:
                    break
    finally:
        lake.close()

    logger.info(
        "[migrate] Done: %d ingested, %d failed, campaign=%s",
        result.ingested, result.failed, campaign_id,
    )
    return result


def generate_lhs_csv(
    csv_path: str,
    geometry_class: str,
    n_samples: int,
    seed: int = 42,
    zdata_dir_template: str = "results/run_{row_id:03d}/ZDATA",
) -> None:
    """Generate a Latin Hypercube design matrix CSV.

    Produces an ``n_samples``-row CSV with:
    - Continuous parameters sampled via LHS (scipy.stats.qmc.LatinHypercube)
    - Categorical parameters (explosive, initiation, casing_material) balanced
      with stratified round-robin assignment
    - zdata_path filled from ``zdata_dir_template`` (engineer fills in actual paths)

    Args:
        csv_path:             Output path for the generated CSV.
        geometry_class:       ``"CYL"`` or ``"CYL_CONE"``.
        n_samples:            Number of design points.
        seed:                 Random seed for reproducibility.
        zdata_dir_template:   f-string template for zdata_path; receives
                              ``row_id`` keyword.
    """
    try:
        from scipy.stats.qmc import LatinHypercube
    except ImportError as exc:
        raise ImportError(
            "scipy is required for LHS generation.  "
            "Install with: pip install scipy"
        ) from exc

    import numpy as np

    geo_class = geometry_class.upper()
    if geo_class not in _VALID_GEOMETRY:
        raise ValueError(f"geometry_class must be one of {_VALID_GEOMETRY}")

    if geo_class == "CYL":
        cont_params = list(_CONT_BOUNDS_CYL.items())   # [(name, (lo, hi)), ...]
    else:
        cont_params = list(_CONT_BOUNDS_CONE.items())

    n_cont = len(cont_params)
    sampler = LatinHypercube(d=n_cont, seed=seed)
    samples_unit = sampler.random(n=n_samples)  # (n_samples, n_cont) in [0,1]

    # Scale to physical bounds
    rng = np.random.default_rng(seed)
    cont_values: dict[str, list[float]] = {}
    for j, (pname, (lo, hi)) in enumerate(cont_params):
        cont_values[pname] = (lo + samples_unit[:, j] * (hi - lo)).tolist()

    # For CYL_CONE: ensure feasibility D_cone_front < D and L_cone < L
    if geo_class == "CYL_CONE":
        D_arr = np.array(cont_values["D"])
        LD_arr = np.array(cont_values["L_D"])
        # Re-sample D_cone_front as fraction of D (avoids rejection loop)
        fracs_dc = 0.1 + samples_unit[:, list(k for k, _ in cont_params).index("D_cone_front")] * 0.8
        cont_values["D_cone_front"] = (fracs_dc * D_arr).tolist()
        # Re-sample L_cone as fraction of L = D * L_D
        L_arr = D_arr * LD_arr
        lc_bounds = _CONT_BOUNDS_CONE["L_cone"]
        fracs_lc = lc_bounds[0] / L_arr + samples_unit[:, list(k for k, _ in cont_params).index("L_cone")] * (
            np.minimum(lc_bounds[1], L_arr * 0.9) / L_arr - lc_bounds[0] / L_arr
        )
        cont_values["L_cone"] = (fracs_lc * L_arr).tolist()

    # Categorical parameters: stratified round-robin
    explosives = [e.value for e in ExplosiveType]
    initiations = [i.value for i in InitiationPoint]
    casings = [c.value for c in CasingMaterial]

    # Generate balanced combinations then shuffle
    combos = [
        (exp, ini, cas)
        for exp in explosives
        for ini in initiations
        for cas in casings
    ]
    rng.shuffle(combos)
    cat_rows = [combos[i % len(combos)] for i in range(n_samples)]

    fieldnames = [
        "row_id", "geometry_class", "D", "L_D", "T_D",
        "explosive", "initiation", "casing_material",
        "L_cone", "D_cone_front", "zdata_path",
    ]

    with open(csv_path, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()

        for i in range(n_samples):
            row_id = i + 1
            exp, ini, cas = cat_rows[i]
            row: dict = {
                "row_id": row_id,
                "geometry_class": geo_class,
                "D": f"{cont_values['D'][i]:.6f}",
                "L_D": f"{cont_values['L_D'][i]:.6f}",
                "T_D": f"{cont_values['T_D'][i]:.6f}",
                "explosive": exp,
                "initiation": ini,
                "casing_material": cas,
                "L_cone": "",
                "D_cone_front": "",
                "zdata_path": zdata_dir_template.format(row_id=row_id),
            }
            if geo_class == "CYL_CONE":
                row["L_cone"] = f"{cont_values['L_cone'][i]:.6f}"
                row["D_cone_front"] = f"{cont_values['D_cone_front'][i]:.6f}"
            writer.writerow(row)

    logger.info("[migrate] Generated LHS CSV: %s (%d rows, geo=%s)", csv_path, n_samples, geo_class)


# ── CLI ──────────────────────────────────────────────────────


def _cli_lhs(args: argparse.Namespace) -> None:
    generate_lhs_csv(
        csv_path=args.output,
        geometry_class=args.geometry_class,
        n_samples=args.n_samples,
        seed=args.seed,
        zdata_dir_template=args.zdata_template,
    )
    print(f"Generated {args.n_samples}-row LHS CSV → {args.output}")


def _cli_validate(args: argparse.Namespace) -> None:
    errors = validate_csv(args.csv)
    if not errors:
        print("Validation passed — all rows OK.")
    else:
        for row_id, msg in errors:
            print(f"  Row {row_id}: {msg}")
        raise SystemExit(1)


def _cli_ingest(args: argparse.Namespace) -> None:
    result = migrate_csv(
        csv_path=args.csv,
        db_path=args.db_path,
        tensor_dir=args.tensor_dir,
        campaign_id=args.campaign_id,
        source=SimulationSource(args.source),
        strict=args.strict,
    )
    print(
        f"Migration complete: {result.ingested} ingested, "
        f"{result.failed} failed, campaign={result.campaign_id}"
    )
    if result.errors:
        print("Errors:")
        for row_id, msg in result.errors:
            print(f"  Row {row_id}: {msg}")
        if args.strict:
            raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="python -m gwdh_datalake.migrate",
        description="GDWH CSV migration and LHS generator",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # lhs subcommand
    lhs_p = sub.add_parser("lhs", help="Generate LHS design matrix CSV")
    lhs_p.add_argument("--geometry-class", required=True, choices=["CYL", "CYL_CONE"])
    lhs_p.add_argument("--n-samples", type=int, required=True)
    lhs_p.add_argument("--seed", type=int, default=42)
    lhs_p.add_argument("--output", required=True, help="Output CSV path")
    lhs_p.add_argument(
        "--zdata-template",
        default="results/run_{row_id:03d}/ZDATA",
        help="f-string template for zdata_path column",
    )

    # validate subcommand
    val_p = sub.add_parser("validate", help="Validate a migration CSV")
    val_p.add_argument("--csv", required=True)

    # ingest subcommand
    ing_p = sub.add_parser("ingest", help="Ingest a CSV into the datalake")
    ing_p.add_argument("--csv", required=True)
    ing_p.add_argument("--db-path", required=True)
    ing_p.add_argument("--tensor-dir", required=True)
    ing_p.add_argument("--campaign-id", default=None)
    ing_p.add_argument("--source", default="DOE", choices=[s.value for s in SimulationSource])
    ing_p.add_argument("--strict", action="store_true", default=False)

    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    if args.command == "lhs":
        _cli_lhs(args)
    elif args.command == "validate":
        _cli_validate(args)
    elif args.command == "ingest":
        _cli_ingest(args)


if __name__ == "__main__":
    main()
