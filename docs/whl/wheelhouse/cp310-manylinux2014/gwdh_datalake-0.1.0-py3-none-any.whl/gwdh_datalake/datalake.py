"""GWDH Data Lake: unified interface over DuckDB metadata + HDF5 tensors.

Key design decision: workers write result.json to Lustre;
only the host node writes to DuckDB (single-writer constraint).
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
from glob import glob
from typing import Optional

import duckdb
import numpy as np

from gwdh_core.config import DataLakeConfig
from gwdh_core.types import (
    EvalResult,
    GeometryClass,
    SimulationRecord,
)

from .cache import EvalCache
from .checkpoint import CheckpointStore
from .hdf5_store import HDF5Store
from .schema import get_schema_version, initialize_schema

logger = logging.getLogger(__name__)


class DataLake:
    """Unified data lake for GWDH simulations, models, and campaigns."""

    def __init__(self, config: DataLakeConfig):
        self.config = config
        os.makedirs(os.path.dirname(config.db_path) or ".", exist_ok=True)
        self.conn = duckdb.connect(config.db_path)
        initialize_schema(self.conn)
        actual = get_schema_version(self.conn)
        expected = int(self.config.schema_version)
        if not self._schema_version_is_compatible(expected, actual):
            self.conn.close()
            raise RuntimeError(
                "DataLake schema_version mismatch: "
                f"expected={expected}, actual={actual}, db_path={self.config.db_path}. "
                "Run a schema migration/backfill tool or point to a compatible database."
            )
        self._h5_stores: dict[str, HDF5Store] = {}
        self._reconcile_hdf5_tail_orphans()

    @staticmethod
    def _schema_version_is_compatible(expected: int, actual: int) -> bool:
        if actual == expected:
            return True
        # Keep the newer config default working against the legacy DuckDB schema
        # used by the current repo fixtures until a real migration lands.
        return expected == 2 and actual == 1

    def close(self) -> None:
        self.conn.close()

    def _get_h5_store(self, geometry_class: str) -> HDF5Store:
        if geometry_class not in self._h5_stores:
            self._h5_stores[geometry_class] = HDF5Store(
                self.config.tensor_dir,
                geometry_class,
                schema_version=self.config.schema_version,
            )
        return self._h5_stores[geometry_class]

    # ── Simulation ingestion ─────────────────────────────────

    def ingest_simulation(self, record: SimulationRecord) -> str:
        """Insert a simulation record into DuckDB + HDF5.

        Returns the UUID.
        """
        if record.design_vector is None or record.zdata is None:
            raise ValueError("SimulationRecord must have design_vector and zdata")

        if record.design_vector.data.shape != (36,):
            raise ValueError(
                f"design_vector must be (36,), got {record.design_vector.data.shape}"
            )
        if record.zdata.data.shape != (36, 4):
            raise ValueError(
                f"zdata must be (36, 4), got {record.zdata.data.shape}"
            )

        primitive_params = self._resolve_primitive_params(record)

        geo = record.geometry_class.value
        h5 = self._get_h5_store(geo)

        # Compute SHA256 of all stored tensors for provenance (FR-8.4)
        sha256_obj = hashlib.sha256()
        sha256_obj.update(np.ascontiguousarray(record.design_vector.data).tobytes())
        sha256_obj.update(np.ascontiguousarray(record.zdata.data).tobytes())
        if record.stage1_output is not None:
            sha256_obj.update(np.ascontiguousarray(record.stage1_output.data).tobytes())
        if record.mott_fit_r2 is not None:
            sha256_obj.update(np.ascontiguousarray(record.mott_fit_r2).tobytes())
        sha256 = sha256_obj.hexdigest()
        record.sha256 = sha256

        # Append to HDF5
        h5_row = h5.append(
            design_vectors=record.design_vector.data.reshape(1, -1),
            zdata=record.zdata.data.reshape(1, *record.zdata.data.shape),
            uuids=[record.uuid],
            stage1_outputs=(
                record.stage1_output.data.reshape(1, -1)
                if record.stage1_output
                else None
            ),
            mott_fit_r2=(
                record.mott_fit_r2.reshape(1, -1) if record.mott_fit_r2 is not None else None
            ),
        )
        h5_row_index = int(h5_row)

        try:
            self.conn.execute(
                "INSERT INTO designs "
                "(uuid, campaign_id, geometry_class, source, primitive_params, discretized_vector, "
                "h5_row_index, sha256, cth_walltime_s, mott_fit_r2) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [
                    record.uuid,
                    record.campaign_id,
                    geo,
                    record.source.value,
                    json.dumps(primitive_params),
                    record.design_vector.data.tolist(),
                    h5_row_index,
                    sha256,
                    record.cth_walltime_s,
                    record.mott_fit_r2.tolist() if record.mott_fit_r2 is not None else None,
                ],
            )
        except Exception:
            h5.truncate_to(int(h5_row))
            raise

        logger.info(
            "[DATA_LAKE] Ingested simulation uuid=%s, campaign=%s, geometry=%s",
            record.uuid,
            record.campaign_id,
            geo,
        )
        return record.uuid

    def _resolve_primitive_params(self, record: SimulationRecord) -> dict:
        primitive_params = record.primitive_params
        if primitive_params is not None:
            return primitive_params

        from gwdh_core.geometry.cth_templater import primitives_to_template_params
        from gwdh_core.geometry.reconstructor import Reconstructor

        try:
            prims = Reconstructor().from_vector(
                record.design_vector, record.geometry_class
            )
            primitive_params = primitives_to_template_params(prims)
        except Exception:
            primitive_params = self._summarize_design_vector(
                record.design_vector.data,
                record.geometry_class,
            )

        record.primitive_params = primitive_params
        return primitive_params

    @staticmethod
    def _summarize_design_vector(
        design_vector: np.ndarray,
        geometry_class: GeometryClass,
    ) -> dict:
        axial = np.asarray(design_vector[0:9], dtype=float)
        case_radii = np.asarray(design_vector[9:18], dtype=float)
        explosive_radii = np.asarray(design_vector[18:27], dtype=float)

        diameter = float(2.0 * np.max(case_radii)) if case_radii.size else 0.0
        length = float(axial[-1] - axial[0]) if axial.size else 0.0
        thickness = (
            float(np.max(case_radii) - np.max(explosive_radii))
            if case_radii.size and explosive_radii.size
            else 0.0
        )

        params = {
            "D": diameter,
            "L": length,
            "T": thickness,
            "L_D": length / diameter if diameter else 0.0,
            "T_D": thickness / diameter if diameter else 0.0,
            "explosive": "UNKNOWN",
            "initiation": "UNKNOWN",
            "casing_material": "UNKNOWN",
            "casing": "UNKNOWN",
        }

        if geometry_class in {GeometryClass.CYL_CONE, GeometryClass.CYL_CONE_OGIVE}:
            params["L_cone"] = float(axial[-1] - axial[4]) if axial.size >= 9 else 0.0
            params["D_cone_front"] = float(2.0 * case_radii[-1]) if case_radii.size else 0.0

        if geometry_class is GeometryClass.CYL_CONE_OGIVE:
            params["R_ogive"] = float(max(case_radii[-1], 0.0)) if case_radii.size else 0.0

        return params

    # ── Training data loading ────────────────────────────────

    def load_training_data(
        self, geometry_class: GeometryClass
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Load all training tensors for a geometry class.

        Returns:
            (N, 36) design vectors, (N, 16) stage1 outputs, and
            (N, 36, 4) ZDATA arrays.
        """
        h5 = self._get_h5_store(geometry_class.value)
        return h5.read_training_tensors()

    def get_training_set(
        self,
        geometry_class: GeometryClass,
        stage: int,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Return stage-specific training matrices from persisted tensors."""
        if stage not in {1, 2}:
            raise ValueError(f"stage must be 1 or 2, got {stage!r}")

        h5 = self._get_h5_store(geometry_class.value)
        design_vectors, stage1_outputs, zdata = h5.read_stagewise_batch()
        complete_rows = np.all(np.isfinite(stage1_outputs), axis=1)
        if not np.any(complete_rows):
            raise ValueError(
                f"No complete training rows with stage1_outputs are available for "
                f"geometry class {geometry_class.value!r}."
            )

        design_vectors = design_vectors[complete_rows]
        stage1_outputs = stage1_outputs[complete_rows]
        zdata = zdata[complete_rows]

        if stage == 1:
            return design_vectors, stage1_outputs

        augmented_inputs = np.concatenate([stage1_outputs, design_vectors], axis=1)
        flattened_zdata = zdata.reshape(zdata.shape[0], -1)
        return augmented_inputs, flattened_zdata

    # ── Eval log ─────────────────────────────────────────────

    def log_eval(self, result: EvalResult, iter_id: int, campaign_id: str) -> None:
        """Record an evaluation result in the eval_log table."""
        x = result.design_vector.data
        x_norm = float(np.linalg.norm(x))

        self.conn.execute(
            "INSERT INTO eval_log "
            "(eval_id, iter_id, campaign_id, timestamp, design_vector, x_norm, "
            "pct_bounds_hit, objectives, penalty, is_feasible, "
            "status, fail_type, runtime_sec, slurm_job_id, "
            "input_deck_sha256, cth_version, parse_version) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                result.eval_id,
                iter_id,
                campaign_id,
                result.timestamp,
                x.tolist(),
                x_norm,
                None,  # pct_bounds_hit: populated by MetricsCSVWriter, not here
                result.objectives.tolist() if result.objectives is not None else None,
                None,  # penalty: populated by MetricsCSVWriter, not here
                None,  # is_feasible: populated by MetricsCSVWriter, not here
                result.status.value,
                result.fail_type.value if result.fail_type else None,
                result.runtime_sec,
                result.slurm_job_id,
                result.input_deck_sha256,
                result.cth_version,
                result.parse_version,
            ],
        )

    # ── Surrogate registry ───────────────────────────────────

    def register_surrogate(
        self,
        model_id: str,
        geometry_class: GeometryClass,
        stage: int,
        training_sample_count: int,
        holdout_metrics: dict,
        model_artifact_path: str,
    ) -> None:
        """Register a trained surrogate model."""
        self.conn.execute(
            "INSERT OR REPLACE INTO surrogate_registry "
            "(model_id, geometry_class, stage, training_sample_count, "
            "holdout_metrics, model_artifact_path) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [
                model_id,
                geometry_class.value,
                stage,
                training_sample_count,
                json.dumps(holdout_metrics),
                model_artifact_path,
            ],
        )

    def load_surrogate_metadata(self, model_id: str) -> dict | None:
        """Load a surrogate registry entry by model_id.

        Returns dict with keys: model_id, geometry_class, stage,
        training_sample_count, holdout_metrics, model_artifact_path, created_at.
        Returns None if not found.
        """
        result = self.conn.execute(
            "SELECT * FROM surrogate_registry WHERE model_id = ?",
            [model_id],
        ).fetchone()
        if result is None:
            return None
        cols = [
            "model_id", "geometry_class", "stage",
            "training_sample_count", "holdout_metrics",
            "model_artifact_path", "created_at",
        ]
        row = dict(zip(cols, result))
        if isinstance(row.get("holdout_metrics"), str):
            row["holdout_metrics"] = json.loads(row["holdout_metrics"])
        return row

    def get_surrogate_record(self, model_id: str, stage: int) -> dict:
        """Fetch a stage-specific surrogate registry record for a model bundle."""
        if stage not in {1, 2}:
            raise ValueError(f"stage must be 1 or 2, got {stage!r}")

        canonical_model_id = f"{model_id}:stage{stage}"
        row = self.conn.execute(
            "SELECT model_id, geometry_class, stage, training_sample_count, "
            "holdout_metrics, model_artifact_path "
            "FROM surrogate_registry WHERE model_id = ?",
            [canonical_model_id],
        ).fetchone()
        if row is None:
            raise KeyError(
                f"No surrogate registry record found for model_id={model_id!r}, stage={stage}."
            )

        return {
            "model_id": row[0],
            "geometry_class": row[1],
            "stage": row[2],
            "training_sample_count": row[3],
            "holdout_metrics": json.loads(row[4]) if row[4] else {},
            "model_artifact_path": row[5],
        }

    def has_validated_expert(self, geometry_class: GeometryClass) -> bool:
        """Return True when a geometry class has both validated stage records."""
        rows = self.conn.execute(
            "SELECT DISTINCT stage FROM surrogate_registry WHERE geometry_class = ?",
            [geometry_class.value],
        ).fetchall()
        observed_stages = {int(row[0]) for row in rows}
        return {1, 2}.issubset(observed_stages)

    def list_surrogates(
        self, geometry_class: GeometryClass | None = None
    ) -> list[dict]:
        """List registered surrogates, optionally filtered by geometry class."""
        if geometry_class is not None:
            rows = self.conn.execute(
                "SELECT * FROM surrogate_registry WHERE geometry_class = ? "
                "ORDER BY created_at DESC",
                [geometry_class.value],
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM surrogate_registry ORDER BY created_at DESC"
            ).fetchall()
        cols = [
            "model_id", "geometry_class", "stage",
            "training_sample_count", "holdout_metrics",
            "model_artifact_path", "created_at",
        ]
        result = []
        for row in rows:
            d = dict(zip(cols, row))
            if isinstance(d.get("holdout_metrics"), str):
                d["holdout_metrics"] = json.loads(d["holdout_metrics"])
            result.append(d)
        return result

    def register_classifier(
        self,
        model_id: str,
        training_sample_count: int,
        training_geometry_classes: list[str],
        holdout_metrics: dict,
        model_artifact_path: str,
        *,
        calibrated: bool,
        validated_for_auto_route: bool,
    ) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO classifier_registry "
            "(model_id, training_sample_count, training_geometry_classes, "
            "holdout_metrics, model_artifact_path, calibrated, validated_for_auto_route) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                model_id,
                training_sample_count,
                json.dumps(training_geometry_classes),
                json.dumps(holdout_metrics),
                model_artifact_path,
                calibrated,
                validated_for_auto_route,
            ],
        )

    def get_classifier_record(self, model_id: str) -> dict:
        row = self.conn.execute(
            "SELECT model_id, training_sample_count, training_geometry_classes, "
            "holdout_metrics, model_artifact_path, calibrated, validated_for_auto_route "
            "FROM classifier_registry WHERE model_id = ?",
            [model_id],
        ).fetchone()
        if row is None:
            raise KeyError(f"No classifier registry record found for model_id={model_id!r}.")

        return {
            "model_id": row[0],
            "training_sample_count": row[1],
            "training_geometry_classes": json.loads(row[2]) if row[2] else [],
            "holdout_metrics": json.loads(row[3]) if row[3] else {},
            "model_artifact_path": row[4],
            "calibrated": bool(row[5]),
            "validated_for_auto_route": bool(row[6]),
        }

    def get_latest_validated_classifier_record(self) -> dict:
        row = self.conn.execute(
            "SELECT model_id FROM classifier_registry "
            "WHERE validated_for_auto_route = TRUE "
            "ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        if row is None:
            raise KeyError("No validated classifier is registered for auto-routing.")
        return self.get_classifier_record(row[0])

    def get_latest_surrogate(
        self,
        geometry_class: GeometryClass,
        stage: int | None = None,
    ) -> dict | None:
        """Get the most recently registered surrogate for a geometry class."""
        query = (
            "SELECT * FROM surrogate_registry WHERE geometry_class = ?"
        )
        params: list = [geometry_class.value]
        if stage is not None:
            query += " AND stage = ?"
            params.append(stage)
        query += " ORDER BY created_at DESC LIMIT 1"

        result = self.conn.execute(query, params).fetchone()
        if result is None:
            return None
        cols = [
            "model_id", "geometry_class", "stage",
            "training_sample_count", "holdout_metrics",
            "model_artifact_path", "created_at",
        ]
        row = dict(zip(cols, result))
        if isinstance(row.get("holdout_metrics"), str):
            row["holdout_metrics"] = json.loads(row["holdout_metrics"])
        return row

    # ── Campaign management ──────────────────────────────────

    def create_campaign(
        self,
        campaign_id: str,
        geometry_class: GeometryClass,
        target_zdata_path: str,
        optimizer_config: dict,
        surrogate_version: Optional[str] = None,
    ) -> None:
        self.conn.execute(
            "INSERT INTO campaigns "
            "(campaign_id, geometry_class, target_zdata_path, optimizer_config, surrogate_version) "
            "VALUES (?, ?, ?, ?, ?)",
            [
                campaign_id,
                geometry_class.value,
                target_zdata_path,
                json.dumps(optimizer_config),
                surrogate_version,
            ],
        )

    def update_campaign_status(self, campaign_id: str, status: str) -> None:
        self.conn.execute(
            "UPDATE campaigns SET status = ? WHERE campaign_id = ?",
            [status, campaign_id],
        )

    # ── Convenience accessors ────────────────────────────────

    def get_eval_cache(self, tolerance: float = 1e-6) -> EvalCache:
        return EvalCache(self.conn, tolerance)

    def get_checkpoint_store(self, checkpoint_dir: str) -> CheckpointStore:
        return CheckpointStore(self.conn, checkpoint_dir)

    def _reconcile_hdf5_tail_orphans(self) -> None:
        """Repair pure HDF5 tail orphans and fail fast on deeper inconsistencies."""
        if not os.path.isdir(self.config.tensor_dir):
            return

        for h5_path in glob(os.path.join(self.config.tensor_dir, "*.h5")):
            geometry_class = os.path.splitext(os.path.basename(h5_path))[0]
            store = self._get_h5_store(geometry_class)
            actual_uuids = store.read_uuids()
            rows = self.conn.execute(
                "SELECT uuid, h5_row_index FROM designs "
                "WHERE geometry_class = ? ORDER BY h5_row_index",
                [geometry_class],
            ).fetchall()

            expected_uuids = [row[0] for row in rows]
            expected_indices = [int(row[1]) for row in rows]
            if expected_indices != list(range(len(expected_uuids))):
                raise RuntimeError(
                    "Inconsistent DataLake state: DuckDB h5_row_index sequence is not contiguous "
                    f"for geometry_class={geometry_class}"
                )

            prefix_len = len(expected_uuids)
            if actual_uuids == expected_uuids:
                continue

            if actual_uuids[:prefix_len] == expected_uuids and len(actual_uuids) >= prefix_len:
                logger.warning(
                    "Reconciling orphaned HDF5 tail rows for geometry_class=%s: %d -> %d",
                    geometry_class,
                    len(actual_uuids),
                    prefix_len,
                )
                store.truncate_to(prefix_len)
                continue

            raise RuntimeError(
                "Inconsistent DataLake state: HDF5/DuckDB UUID prefix mismatch "
                f"for geometry_class={geometry_class}"
            )
