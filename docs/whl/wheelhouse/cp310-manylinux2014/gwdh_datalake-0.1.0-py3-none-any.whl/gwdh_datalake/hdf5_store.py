"""HDF5 tensor storage optimized for Lustre HPC filesystems.

Design:
- One HDF5 file per geometry class (e.g. CYL.h5)
- Chunked along axis 0 (batch dimension) for Lustre stripe-aligned I/O
- Append support via resizable datasets
"""
from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from typing import Optional

import h5py
import numpy as np
from gwdh_core.types import DISCRETIZED_DIM, STAGE1_OUT_DIM

# Chunk size along batch dimension; aligns with Lustre stripe units
BATCH_CHUNK_SIZE = 64
COMPRESSION = "gzip"
COMPRESSION_OPTS = 4

logger = logging.getLogger(__name__)


class HDF5Store:
    """Per-geometry-class HDF5 tensor store."""

    def __init__(self, tensor_dir: str, geometry_class: str, schema_version: int = 1):
        self.tensor_dir = tensor_dir
        self.geometry_class = geometry_class
        self.schema_version = int(schema_version)
        self.h5_path = os.path.join(tensor_dir, f"{geometry_class}.h5")
        os.makedirs(tensor_dir, exist_ok=True)

    def append(
        self,
        design_vectors: np.ndarray,
        zdata: np.ndarray,
        uuids: list[str],
        stage1_outputs: Optional[np.ndarray] = None,
        mott_fit_r2: Optional[np.ndarray] = None,
    ) -> int:
        """Append a batch of simulation results. Returns the starting row index."""
        n = design_vectors.shape[0]
        if len(uuids) != n:
            raise ValueError(f"Expected {n} uuids, got {len(uuids)}.")

        with h5py.File(self.h5_path, "a", libver="latest") as f:
            # Set file-level attributes on first write
            if "design_vectors" not in f:
                self._create_datasets(f, design_vectors, zdata)
                f.attrs["schema_version"] = self.schema_version
                f.attrs["geometry_class"] = self.geometry_class
                f.attrs["n_simulations"] = 0
            else:
                self._validate_file_metadata(f)
            self._ensure_stagewise_datasets(f)
            self._validate_row_alignment(f)

            start_idx = int(f.attrs["n_simulations"])
            new_size = start_idx + n

            # Resize and write
            f["design_vectors"].resize(new_size, axis=0)
            f["design_vectors"][start_idx:new_size] = design_vectors

            f["zdata"].resize(new_size, axis=0)
            f["zdata"][start_idx:new_size] = zdata

            f["uuids"].resize(new_size, axis=0)
            for i, uid in enumerate(uuids):
                f["uuids"][start_idx + i] = uid

            # Always resize optional datasets; fill with NaN when None (FR-8.3)
            f["stage1_outputs"].resize(new_size, axis=0)
            if stage1_outputs is not None:
                self._validate_stage1_outputs(stage1_outputs, n)
                f["stage1_outputs"][start_idx:new_size] = stage1_outputs
            else:
                f["stage1_outputs"][start_idx:new_size] = np.full((n, STAGE1_OUT_DIM), np.nan)

            f["mott_fit_r2"].resize(new_size, axis=0)
            if mott_fit_r2 is not None:
                self._validate_mott_fit_r2(mott_fit_r2, n)
                f["mott_fit_r2"][start_idx:new_size] = mott_fit_r2
            else:
                f["mott_fit_r2"][start_idx:new_size] = np.full((n, DISCRETIZED_DIM), np.nan)

            f.attrs["n_simulations"] = new_size
            self._validate_row_alignment(f)

            # Best-effort SWMR enablement for crash safety + concurrent readers.
            # Do not fail ingest if SWMR is unsupported by the local h5py/HDF5 build.
            f.flush()
            try:
                f.swmr_mode = True
            except Exception as exc:
                logger.debug(
                    "Could not enable SWMR mode for %s: %s", self.h5_path, exc
                )

            return start_idx

    def read_batch(
        self,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Read all design vectors and ZDATA for training.

        Returns (design_vectors, zdata) arrays.
        """
        if not os.path.exists(self.h5_path):
            return (
                np.empty((0, 36), dtype=np.float64),
                np.empty((0, 36, 4), dtype=np.float64),
            )

        with self._open_for_read() as f:
            self._validate_file_metadata(f)
            design_vectors = f["design_vectors"][:]
            zdata = f["zdata"][:]
        return design_vectors, zdata

    def read_training_tensors(
        self,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Read design vectors, stage1 outputs, and ZDATA for training."""
        if not os.path.exists(self.h5_path):
            return (
                np.empty((0, 36), dtype=np.float64),
                np.empty((0, 16), dtype=np.float64),
                np.empty((0, 36, 4), dtype=np.float64),
            )

        with self._open_for_read() as f:
            self._validate_file_metadata(f)
            design_vectors = f["design_vectors"][:]
            stage1_outputs = f["stage1_outputs"][:]
            zdata = f["zdata"][:]
        return design_vectors, stage1_outputs, zdata

    def read_stagewise_batch(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Read design vectors, Stage 1 outputs, and ZDATA with row-alignment checks."""
        if not os.path.exists(self.h5_path):
            raise FileNotFoundError(f"No HDF5 store found for geometry class {self.geometry_class!r}.")

        with h5py.File(self.h5_path, "a") as f:
            self._validate_file_metadata(f)
            self._ensure_stagewise_datasets(f)
            self._validate_row_alignment(f)
            design_vectors = f["design_vectors"][:]
            stage1_outputs = f["stage1_outputs"][:]
            zdata = f["zdata"][:]
        return design_vectors, stage1_outputs, zdata

    def read_range(
        self, start: int, end: int
    ) -> tuple[np.ndarray, np.ndarray]:
        """Read a contiguous range of rows."""
        with self._open_for_read() as f:
            self._validate_file_metadata(f)
            design_vectors = f["design_vectors"][start:end]
            zdata = f["zdata"][start:end]
        return design_vectors, zdata

    @property
    def n_simulations(self) -> int:
        if not os.path.exists(self.h5_path):
            return 0
        with self._open_for_read() as f:
            self._validate_file_metadata(f)
            return int(f.attrs.get("n_simulations", 0))

    def read_uuids(self) -> list[str]:
        """Return stored UUIDs in row order."""
        if not os.path.exists(self.h5_path):
            return []

        with self._open_for_read() as f:
            self._validate_file_metadata(f)
            raw_uuids = f["uuids"][:]

        uuids: list[str] = []
        for raw in raw_uuids:
            if isinstance(raw, bytes):
                uuids.append(raw.decode("utf-8"))
            else:
                uuids.append(str(raw))
        return uuids

    def truncate_to(self, size: int) -> None:
        """Shrink all datasets to ``size`` rows."""
        if not os.path.exists(self.h5_path):
            return

        with h5py.File(self.h5_path, "r+") as f:
            self._validate_file_metadata(f)
            current = int(f.attrs.get("n_simulations", 0))
            if size < 0 or size > current:
                raise ValueError(f"truncate_to size {size} out of range 0..{current}")

            for name in (
                "design_vectors",
                "zdata",
                "uuids",
                "stage1_outputs",
                "mott_fit_r2",
            ):
                f[name].resize(size, axis=0)
            f.attrs["n_simulations"] = size
            f.flush()

    def _validate_file_metadata(self, f: h5py.File) -> None:
        if "schema_version" not in f.attrs:
            raise RuntimeError(
                f"HDF5 schema_version missing in {self.h5_path} "
                f"(expected={self.schema_version})"
            )

        actual = int(f.attrs["schema_version"])
        if actual != self.schema_version:
            raise RuntimeError(
                "HDF5 schema_version mismatch: "
                f"expected={self.schema_version}, actual={actual}, path={self.h5_path}"
            )

        if "geometry_class" in f.attrs:
            raw_geo = f.attrs["geometry_class"]
            if isinstance(raw_geo, bytes):
                raw_geo = raw_geo.decode("utf-8")
            if str(raw_geo) != self.geometry_class:
                raise RuntimeError(
                    "HDF5 geometry_class mismatch: "
                    f"expected={self.geometry_class}, actual={raw_geo}, path={self.h5_path}"
                )

    @contextmanager
    def _open_for_read(self) -> h5py.File:
        """Open HDF5 for read with best-effort SWMR fallback."""
        try:
            f = h5py.File(self.h5_path, "r", swmr=True)
        except Exception:
            f = h5py.File(self.h5_path, "r")
        try:
            yield f
        finally:
            f.close()

    def _create_datasets(
        self,
        f: h5py.File,
        design_vectors: np.ndarray,
        zdata: np.ndarray,
    ) -> None:
        """Create resizable, chunked, compressed datasets."""
        n_dim = design_vectors.shape[1]  # 36
        z_shape = zdata.shape[1:]  # (36, 4)

        f.create_dataset(
            "design_vectors",
            shape=(0, n_dim),
            maxshape=(None, n_dim),
            dtype="float64",
            chunks=(BATCH_CHUNK_SIZE, n_dim),
            compression=COMPRESSION,
            compression_opts=COMPRESSION_OPTS,
        )
        f.create_dataset(
            "zdata",
            shape=(0, *z_shape),
            maxshape=(None, *z_shape),
            dtype="float64",
            chunks=(BATCH_CHUNK_SIZE, *z_shape),
            compression=COMPRESSION,
            compression_opts=COMPRESSION_OPTS,
        )
        dt = h5py.string_dtype()
        f.create_dataset(
            "uuids",
            shape=(0,),
            maxshape=(None,),
            dtype=dt,
        )
        # Always create optional datasets so they're never silently dropped (FR-8.3)
        f.create_dataset(
            "stage1_outputs",
            shape=(0, STAGE1_OUT_DIM),
            maxshape=(None, STAGE1_OUT_DIM),
            dtype="float64",
            chunks=(BATCH_CHUNK_SIZE, STAGE1_OUT_DIM),
            compression=COMPRESSION,
            compression_opts=COMPRESSION_OPTS,
        )
        f.create_dataset(
            "mott_fit_r2",
            shape=(0, DISCRETIZED_DIM),
            maxshape=(None, DISCRETIZED_DIM),
            dtype="float64",
            chunks=(BATCH_CHUNK_SIZE, DISCRETIZED_DIM),
            compression=COMPRESSION,
            compression_opts=COMPRESSION_OPTS,
        )

    def _ensure_stagewise_datasets(self, f: h5py.File) -> None:
        row_count = self._row_count(f, "design_vectors")
        self._ensure_float_dataset(f, "stage1_outputs", row_count, STAGE1_OUT_DIM)
        self._ensure_float_dataset(f, "mott_fit_r2", row_count, DISCRETIZED_DIM)

    def _ensure_float_dataset(self, f: h5py.File, name: str, row_count: int, width: int) -> None:
        if name in f:
            dataset = f[name]
            if dataset.ndim != 2 or dataset.shape[1] != width:
                raise ValueError(
                    f"HDF5 store for geometry class {self.geometry_class!r} has invalid "
                    f"{name!r} shape {dataset.shape}; expected (*, {width})."
                )
            return

        f.create_dataset(
            name,
            shape=(row_count, width),
            maxshape=(None, width),
            dtype="float64",
            chunks=(BATCH_CHUNK_SIZE, width),
            compression=COMPRESSION,
            compression_opts=COMPRESSION_OPTS,
        )
        if row_count > 0:
            f[name][:] = np.full((row_count, width), np.nan, dtype=float)

    def _validate_row_alignment(self, f: h5py.File) -> None:
        dataset_names = ("design_vectors", "zdata", "uuids", "stage1_outputs", "mott_fit_r2")
        missing = [name for name in dataset_names if name not in f]
        if missing:
            raise ValueError(
                f"HDF5 store for geometry class {self.geometry_class!r} is missing datasets: "
                f"{', '.join(missing)}."
            )

        counts = {name: self._row_count(f, name) for name in dataset_names}
        counts["n_simulations"] = int(f.attrs.get("n_simulations", counts["design_vectors"]))
        if len(set(counts.values())) != 1:
            count_summary = ", ".join(f"{name}={count}" for name, count in counts.items())
            raise ValueError(
                f"HDF5 store for geometry class {self.geometry_class!r} has misaligned datasets: "
                f"{count_summary}."
            )

    def _validate_stage1_outputs(self, stage1_outputs: np.ndarray, n_rows: int) -> None:
        if stage1_outputs.shape != (n_rows, STAGE1_OUT_DIM):
            raise ValueError(
                f"Expected stage1_outputs shape {(n_rows, STAGE1_OUT_DIM)}, got {stage1_outputs.shape}."
            )

    def _validate_mott_fit_r2(self, mott_fit_r2: np.ndarray, n_rows: int) -> None:
        if mott_fit_r2.shape != (n_rows, DISCRETIZED_DIM):
            raise ValueError(
                f"Expected mott_fit_r2 shape {(n_rows, DISCRETIZED_DIM)}, got {mott_fit_r2.shape}."
            )

    def _row_count(self, f: h5py.File, name: str) -> int:
        if name not in f:
            raise ValueError(
                f"HDF5 store for geometry class {self.geometry_class!r} is missing dataset {name!r}."
            )
        return int(f[name].shape[0])
