"""Full optimization campaign lifecycle.

Orchestrates: optimizer.ask() -> eval_harness.evaluate_batch() -> optimizer.tell()
with checkpointing, telemetry, metrics CSV, and run manifest.
Resume-safe via checkpoint save/load every generation.
"""
from __future__ import annotations

import logging
import math

from gwdh_core.config import CampaignConfig
from gwdh_core.geometry.cth_templater import primitives_to_template_params
from gwdh_core.geometry.reconstructor import Reconstructor
from gwdh_core.types import DesignVector, GeometryClass

from gwdh_datalake.checkpoint import CheckpointStore
from gwdh_datalake.datalake import DataLake

from .eval_harness import EvalHarness
from .metrics_writer import MetricsCSVWriter
from .optimizer import CMAESOptimizer
from .plotting import generate_all_plots
from .run_manifest import RunManifest
from .telemetry import TelemetryLogger

logger = logging.getLogger(__name__)


class Campaign:
    """Full optimization campaign lifecycle.

    Main loop:
        generate run.yaml manifest
        for gen in range(start_gen, max_iterations):
            candidates = optimizer.ask()
            results = eval_harness.evaluate_batch(candidates)
            optimizer.tell(results)
            checkpoint_store.save(...)
            telemetry.log_generation(...)
            metrics_writer.write_batch(...)
            if gen % N == 0: generate_plots()
    """

    def __init__(
        self,
        optimizer: CMAESOptimizer,
        eval_harness: EvalHarness,
        checkpoint_store: CheckpointStore,
        telemetry: TelemetryLogger,
        metrics_writer: MetricsCSVWriter,
        data_lake: DataLake,
        config: CampaignConfig,
        campaign_id: str,
        geometry_class: GeometryClass = GeometryClass.CYL,
        seed: int = 42,
    ):
        self.optimizer = optimizer
        self.eval_harness = eval_harness
        self.checkpoint_store = checkpoint_store
        self.telemetry = telemetry
        self.metrics_writer = metrics_writer
        self.data_lake = data_lake
        self.config = config
        self.campaign_id = campaign_id
        self.geometry_class = geometry_class
        self.seed = seed

    def run(
        self,
        primitive_params_fn=None,
    ) -> None:
        """Run the campaign loop. Resume-safe via checkpointing.

        Args:
            primitive_params_fn: Callable(DesignVector) -> dict that converts
                a design vector to primitive parameters for CTH. If None,
                designs are passed as empty dicts.
        """
        # Generate run manifest
        manifest = RunManifest.generate(
            campaign_id=self.campaign_id,
            seed=self.seed,
            optimization_config=self.optimizer.config,
            lower_bounds=self.optimizer.problem.xl.tolist(),
            upper_bounds=self.optimizer.problem.xu.tolist(),
        )
        RunManifest.write(
            manifest,
            self.config.run_yaml_path,
        )

        # Try to resume from checkpoint
        start_gen = self.optimizer.generation

        self.data_lake.update_campaign_status(self.campaign_id, "RUNNING")

        logger.info(
            "[CAMPAIGN] Starting campaign %s from generation %d",
            self.campaign_id, start_gen,
        )

        for gen in range(start_gen, self.config.max_iterations):
            logger.info(
                "[CAMPAIGN] === Generation %d/%d ===",
                gen, self.config.max_iterations,
            )

            # Ask
            X = self.optimizer.ask()
            designs = [DesignVector(data=X[i]) for i in range(X.shape[0])]

            # Build primitive params for each design
            # Auto-reconstruct from design vector if no fn provided
            if primitive_params_fn is None:
                _recon = Reconstructor()

                def _auto_params_fn(dv: DesignVector) -> dict:
                    try:
                        prims = _recon.from_vector(dv, self.geometry_class)
                    except Exception:
                        return {}
                    return primitives_to_template_params(prims)

                primitive_params_fn = _auto_params_fn

            primitives = [primitive_params_fn(d) for d in designs]

            # Evaluate
            results = self.eval_harness.evaluate_batch(
                designs, primitives, self.campaign_id, gen
            )

            # Tell
            self.optimizer.tell(results)

            # Checkpoint every generation
            self.checkpoint_store.save(
                self.campaign_id, gen, self.optimizer.get_state()
            )

            # Telemetry
            self.telemetry.log_generation(gen, results, self.optimizer)

            # Metrics CSV
            self.metrics_writer.write_batch(results, gen)

            # Log evaluations to data lake
            for result in results:
                self.data_lake.log_eval(result, gen, self.campaign_id)

            # Periodic plots
            if gen % self.config.plot_every_n_gen == 0:
                generate_all_plots(
                    self.telemetry.history, self.config.plot_dir
                )

            # Check convergence
            if self._check_convergence(gen):
                logger.info(
                    "[CAMPAIGN] Converged at generation %d (best_f=%.6f)",
                    gen, self.optimizer.best_f,
                )
                break

        # Final plots
        generate_all_plots(self.telemetry.history, self.config.plot_dir)

        self.data_lake.update_campaign_status(self.campaign_id, "COMPLETED")
        logger.info(
            "[CAMPAIGN] Campaign %s completed. Best objective: %.6f",
            self.campaign_id, self.optimizer.best_f,
        )

    def _check_convergence(self, gen: int) -> bool:
        """Check if optimization has converged.

        Convergence criteria (FR-6.3):
        1. Sigma collapse: CMA-ES step size below threshold
        2. Stability: cumulative best stable for 5+ generations

        Uses cumulative best over the last 5 generations (derived from
        telemetry per-generation best values), rather than raw per-generation
        bests, to avoid false convergence when a good generation is followed
        by worse ones.
        """
        # Criterion 1: sigma collapse
        state = self.optimizer.get_state()
        sigma = state.get("sigma", float("inf"))
        if sigma < self.config.sigma_collapse_threshold:
            logger.info(
                "[CAMPAIGN] Sigma collapsed (%.2e < %.2e)",
                sigma, self.config.sigma_collapse_threshold,
            )
            return True

        # Criterion 2: stability over last 5 generations
        if gen < 4:
            return False

        history = self.telemetry.history
        if len(history) < 5:
            return False

        running_best = float("inf")
        cumulative_bests: list[float] = []
        for s in history:
            running_best = min(running_best, s.best_f)
            cumulative_bests.append(running_best)

        recent_cumulative = cumulative_bests[-5:]
        if any(not math.isfinite(v) for v in recent_cumulative):
            return False

        improvement = max(recent_cumulative) - min(recent_cumulative)
        return improvement < self.config.convergence_threshold
