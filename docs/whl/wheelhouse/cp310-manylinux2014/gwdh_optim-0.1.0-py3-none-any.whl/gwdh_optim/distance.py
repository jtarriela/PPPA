"""Hybrid Spatial-Lethality distance metric (Layer 3 -> Layer 4).

Blends 1D Earth Mover's Distance for macro-steering with
Max-Envelope Weighted Euclidean for micro-matching.

KE computation is delegated to gwdh_core.mott.

Reference: docs/architecture/003_optimizer.md Section 4
"""
from __future__ import annotations

import numpy as np

from gwdh_core.mott import compute_ke_batch, compute_ke_zonal
from gwdh_core.types import DEFAULT_DISTANCE_WEIGHTS


def hybrid_distance(
    predicted: np.ndarray,
    target: np.ndarray,
    sigma: np.ndarray,
    weights: np.ndarray = DEFAULT_DISTANCE_WEIGHTS,
    alpha: float = 1.0,
    beta: float = 1.0,
) -> float:
    """Hybrid Spatial-Lethality Objective Function.

    Args:
        predicted: (36, 4) predicted ZDATA
        target: (36, 4) target ZDATA
        sigma: (4,) normalization scales per parameter
        weights: (4,) per-parameter importance weights
        alpha: EMD weight
        beta: Euclidean weight

    Returns:
        Scalar distance (lower is better)
    """
    # KE prep
    ke_pred = compute_ke_zonal(predicted)
    ke_tgt = compute_ke_zonal(target)

    total_ke_tgt = np.sum(ke_tgt)
    if total_ke_tgt == 0:
        total_ke_tgt = 1e-8
    total_ke_pred = np.sum(ke_pred)
    if total_ke_pred == 0:
        total_ke_pred = 1e-8

    # 1D Earth Mover's Distance (EMD_spatial)
    pdf_pred = ke_pred / total_ke_pred
    pdf_tgt = ke_tgt / total_ke_tgt
    cdf_pred = np.cumsum(pdf_pred)
    cdf_tgt = np.cumsum(pdf_tgt)
    emd_spatial = np.sum(np.abs(cdf_pred - cdf_tgt))

    # Max-Envelope Weighting
    W_j = np.maximum(ke_tgt, ke_pred) / total_ke_tgt

    # Micro-parameter Weighted Euclidean
    diff = (predicted - target) / sigma  # (36, 4)
    zone_sq = np.sum(weights * diff ** 2, axis=1)  # (36,)
    euclidean_sq = np.sum(W_j * zone_sq)
    weighted_euclidean = np.sqrt(euclidean_sq)

    return alpha * emd_spatial + beta * weighted_euclidean


def hybrid_distance_batch(
    predictions: np.ndarray,
    target: np.ndarray,
    sigma: np.ndarray,
    weights: np.ndarray = DEFAULT_DISTANCE_WEIGHTS,
    alpha: float = 1.0,
    beta: float = 1.0,
) -> np.ndarray:
    """Batch computation of hybrid distance.

    Args:
        predictions: (N, 36, 4)
        target: (36, 4)
        sigma: (4,)
        weights: (4,)

    Returns:
        (N,) distances
    """
    N = predictions.shape[0]
    distances = np.zeros(N)
    for i in range(N):
        distances[i] = hybrid_distance(
            predictions[i], target, sigma, weights, alpha, beta
        )
    return distances
