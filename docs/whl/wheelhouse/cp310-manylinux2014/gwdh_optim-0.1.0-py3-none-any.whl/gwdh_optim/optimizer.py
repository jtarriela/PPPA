"""CMA-ES optimizer with ask/tell interface and checkpointing.

Wraps pymoo's CMAES with BIPOP restarts. Provides ask/tell batch
interface for integration with the evaluation harness.

Reference: docs/architecture/003_optimizer.md Section 5
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import numpy as np
from pymoo.algorithms.soo.nonconvex.cmaes import CMAES
from pymoo.constraints.as_penalty import ConstraintsAsPenalty
from pymoo.core.population import Population

from gwdh_core.config import OptimizationConfig
from gwdh_core.types import EvalResult, EvalStatus

from .problem import ZDATAProblem

logger = logging.getLogger(__name__)

def _is_pymoo_set_optimum_error(exc: ValueError) -> bool:
    """Return True only for the known pymoo `_set_optimum` ValueError.

    We intentionally avoid catching arbitrary ValueErrors from `tell()`,
    which could mask real bugs (shape mismatches, invalid fitness values, etc.).
    """
    msg = str(exc)
    if "_set_optimum" in msg:
        return True

    # Fallback: check traceback origin when the message is unhelpful.
    try:
        import traceback

        for frame in traceback.extract_tb(exc.__traceback__):
            if frame.name == "_set_optimum" and "pymoo" in frame.filename:
                return True
    except Exception:
        return False

    return False


class CMAESOptimizer:
    """Ask/tell CMA-ES optimizer with checkpointing support.

    Usage:
        optimizer = CMAESOptimizer(problem, config)
        candidates = optimizer.ask()
        # ... evaluate candidates externally ...
        optimizer.tell(results)
        state = optimizer.get_state()
    """

    def __init__(
        self,
        problem: ZDATAProblem,
        config: OptimizationConfig,
        seed: int = 42,
    ):
        self.problem = problem
        self.config = config
        self.seed = seed
        self._rng = np.random.RandomState(seed)

        self.algorithm = CMAES(
            x0=None,
            sigma=config.sigma,
            restarts=config.restarts,
            bipop=config.bipop,
        )

        # Wrap constraints as penalty if needed
        if problem.n_ieq_constr > 0:
            self._eval_problem = ConstraintsAsPenalty(
                problem, penalty=config.penalty_weight
            )
        else:
            self._eval_problem = problem

        # Initialize the algorithm
        self.algorithm.setup(self._eval_problem, seed=seed)

        self._generation = 0
        self._eval_count = 0
        self._best_f = float("inf")
        self._best_x = None

    def ask(self) -> np.ndarray:
        """Propose next generation of candidate vectors.

        Returns:
            (pop_size, 36) array of candidate design vectors
        """
        pop = self.algorithm.ask()
        X = pop.get("X")
        logger.info(
            "[OPTIMIZER] Generation %d: asking for %d candidates",
            self._generation, X.shape[0],
        )
        return X

    def score_candidates(self, X: np.ndarray) -> np.ndarray:
        """Score candidates with the same penalized objective used by CMA-ES.

        This method evaluates the optimizer's configured problem wrapper
        (`ZDATAProblem` or `ConstraintsAsPenalty`) and returns scalar
        objective values suitable for ranking and tell().
        """
        matrix = np.asarray(X, dtype=float)
        if matrix.ndim != 2 or matrix.shape[1] != self.problem.n_var:
            raise ValueError(
                f"Expected an (N, {self.problem.n_var}) candidate matrix, got {matrix.shape}."
            )

        values = self._eval_problem.evaluate(
            matrix,
            return_values_of=["F"],
            return_as_dictionary=True,
        )
        scores = np.asarray(values["F"], dtype=float)
        if scores.ndim == 2 and scores.shape[1] == 1:
            return scores[:, 0]
        return scores.reshape(-1)

    def tell(self, results: list[EvalResult]) -> None:
        """Feed evaluation results back to CMA-ES.

        Failed evaluations receive a large penalty value.
        Results with None design_vector (e.g. from observation_runner before
        dispatch fills them in) receive a zeroed sentinel vector.
        """
        n = len(results)
        F = np.zeros((n, 1))
        X_rows = []

        for i, result in enumerate(results):
            if result.status == EvalStatus.COMPLETED and result.objectives is not None:
                F[i, 0] = (
                    result.objectives[0]
                    if result.objectives.ndim > 0
                    else float(result.objectives)
                )
            else:
                F[i, 0] = 1e9

            # Guard against None design_vector (partial results from observation_runner)
            if result.design_vector is not None:
                X_rows.append(result.design_vector.data)
            else:
                logger.warning(
                    "[OPTIMIZER] result %d has design_vector=None; using zero sentinel",
                    i,
                )
                X_rows.append(np.zeros(self.problem.n_var))

        X = np.array(X_rows)
        pop = Population.new("X", X)
        pop.set("F", F)

        try:
            self.algorithm.tell(infills=pop)
        except ValueError as exc:
            # pymoo 0.6.x + numpy >= 2.0 compatibility: `_set_optimum` can
            # raise ValueError even after CMA-ES state has advanced. We still
            # track best_x/best_f manually, so we can safely continue in this
            # narrow case.
            if not _is_pymoo_set_optimum_error(exc):
                raise
            logger.debug(
                "[OPTIMIZER] pymoo _set_optimum raised ValueError; "
                "best tracking handled manually.",
                exc_info=True,
            )

        # Track best
        gen_best_idx = np.argmin(F[:, 0])
        gen_best_f = F[gen_best_idx, 0]
        if gen_best_f < self._best_f:
            self._best_f = gen_best_f
            self._best_x = X[gen_best_idx].copy()

        self._eval_count += n
        self._generation += 1

        success_count = sum(
            1
            for r in results
            if r.status in (EvalStatus.COMPLETED, EvalStatus.CACHED)
        )
        logger.info(
            "[OPTIMIZER] Generation %d complete: best_f=%.4f, success=%d/%d",
            self._generation - 1, gen_best_f, success_count, n,
        )

    @property
    def generation(self) -> int:
        return self._generation

    @property
    def best_f(self) -> float:
        return self._best_f

    @property
    def best_x(self) -> Optional[np.ndarray]:
        return self._best_x

    def get_state(self) -> dict:
        """Return CMA-ES internal state for checkpointing."""
        state: dict[str, Any] = {
            "generation": self._generation,
            "eval_count": self._eval_count,
            "best_f": self._best_f,
            "best_x": self._best_x.copy() if self._best_x is not None else None,
            "seed": self.seed,
            "rng_state": self._rng.get_state(),
        }

        try:
            cma = self.algorithm
            if hasattr(cma, "es") and cma.es is not None:
                es = cma.es
                state["mean"] = np.array(es.mean) if hasattr(es, "mean") else None
                state["sigma"] = float(es.sigma) if hasattr(es, "sigma") else self.config.sigma
                if hasattr(es, "C"):
                    state["C"] = np.array(es.C)
                if hasattr(es, "pc"):
                    state["pc"] = np.array(es.pc)
                if hasattr(es, "ps"):
                    state["ps"] = np.array(es.ps)
            else:
                state["sigma"] = self.config.sigma
                state["mean"] = None
        except Exception as e:
            logger.warning("Could not extract CMA-ES internals: %s", e)
            state["sigma"] = self.config.sigma
            state["mean"] = None

        return state

    @classmethod
    def from_checkpoint(
        cls,
        state: dict,
        problem: ZDATAProblem,
        config: OptimizationConfig,
    ) -> CMAESOptimizer:
        """Reconstruct optimizer from checkpoint state.

        pymoo's CMAES lazily creates the underlying cma.CMAEvolutionStrategy
        on the first ask() call. To restore saved CMA-ES state we must force
        initialization first, then overwrite the internal fields.
        """
        optimizer = cls(problem, config, seed=state.get("seed", 42))
        optimizer._generation = state.get("generation", 0)
        optimizer._eval_count = state.get("eval_count", 0)
        optimizer._best_f = state.get("best_f", float("inf"))
        optimizer._best_x = state.get("best_x")

        if "rng_state" in state:
            optimizer._rng.set_state(state["rng_state"])

        # Force CMA-ES to initialize its internal `es` object by calling ask() once.
        # Without this, optimizer.algorithm.es does not exist yet and the state
        # restoration block below is silently skipped (a no-op).
        try:
            _dummy_pop = optimizer.algorithm.ask()
            # Feed back neutral values so algorithm state is consistent
            _n = _dummy_pop.get("X").shape[0]
            _F_dummy = np.full((_n, 1), 1e9)
            _dummy_pop.set("F", _F_dummy)
            optimizer.algorithm.tell(infills=_dummy_pop)
        except Exception as e:
            logger.warning("[OPTIMIZER] Could not force CMA-ES init for restore: %s", e)

        try:
            if hasattr(optimizer.algorithm, "es") and optimizer.algorithm.es is not None:
                es = optimizer.algorithm.es
                if state.get("mean") is not None:
                    es.mean = state["mean"]
                if state.get("sigma") is not None:
                    es.sigma = state["sigma"]
                if state.get("C") is not None:
                    es.C = state["C"]
                if state.get("pc") is not None:
                    es.pc = state["pc"]
                if state.get("ps") is not None:
                    es.ps = state["ps"]
            else:
                logger.warning(
                    "[OPTIMIZER] CMA-ES 'es' object still not available after forced init; "
                    "checkpoint state restoration incomplete — optimizer starts fresh."
                )
        except Exception as e:
            logger.warning("Could not restore CMA-ES internals: %s", e)

        return optimizer
