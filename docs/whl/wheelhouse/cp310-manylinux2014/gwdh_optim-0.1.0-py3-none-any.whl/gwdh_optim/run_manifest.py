"""Generate run.yaml with campaign provenance for reproducibility.

Fields: campaign_id, seed, timestamp, objective_definitions, bounds,
optimizer_settings, and machine_info.
"""
from __future__ import annotations

import os
import platform
import socket
from datetime import datetime, timezone
from typing import Optional

import yaml  # type: ignore[import-untyped]

from gwdh_core.config import OptimizationConfig


class RunManifest:
    """Generate and write run.yaml for a campaign."""

    @staticmethod
    def generate(
        campaign_id: str,
        seed: int,
        optimization_config: OptimizationConfig,
        lower_bounds: list[float],
        upper_bounds: list[float],
        target_zdata_path: Optional[str] = None,
    ) -> dict:
        return {
            "campaign_id": campaign_id,
            "seed": seed,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "objective_definitions": {
                "type": "hybrid_spatial_lethality",
                "description": "EMD + Max-Envelope Weighted Euclidean",
            },
            "target_zdata_path": target_zdata_path,
            "bounds": {
                "lower": lower_bounds,
                "upper": upper_bounds,
            },
            "optimizer_settings": {
                "algorithm": "BIPOP-CMA-ES",
                "sigma": optimization_config.sigma,
                "bipop": optimization_config.bipop,
                "restarts": optimization_config.restarts,
                "budget": optimization_config.budget,
                "constraint_phase": optimization_config.constraint_phase,
                "penalty_weight": optimization_config.penalty_weight,
            },
            "machine_info": {
                "hostname": socket.gethostname(),
                "platform": platform.platform(),
                "python_version": platform.python_version(),
                "cpu_count": os.cpu_count(),
            },
        }

    @staticmethod
    def write(manifest: dict, path: str) -> None:
        with open(path, "w") as f:
            yaml.safe_dump(manifest, f, default_flow_style=False, sort_keys=False)
