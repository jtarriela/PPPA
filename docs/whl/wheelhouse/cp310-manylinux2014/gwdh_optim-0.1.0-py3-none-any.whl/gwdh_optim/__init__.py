"""gwdh-optim: CMA-ES optimizer, evaluation harness, and campaign orchestration."""

from gwdh_optim.active_learning import ActiveLearningCampaign
from gwdh_optim.campaign import Campaign
from gwdh_optim.distance import hybrid_distance, hybrid_distance_batch
from gwdh_optim.eval_harness import EvalHarness
from gwdh_optim.metrics_writer import MetricsCSVWriter
from gwdh_optim.optimizer import CMAESOptimizer
from gwdh_optim.plotting import generate_all_plots
from gwdh_optim.problem import ZDATAProblem
from gwdh_optim.run_manifest import RunManifest
from gwdh_optim.telemetry import GenerationStats, TelemetryLogger

__all__ = [
    "ActiveLearningCampaign",
    "Campaign",
    "CMAESOptimizer",
    "EvalHarness",
    "GenerationStats",
    "MetricsCSVWriter",
    "RunManifest",
    "TelemetryLogger",
    "ZDATAProblem",
    "generate_all_plots",
    "hybrid_distance",
    "hybrid_distance_batch",
]
