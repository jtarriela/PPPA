"""Command-line entrypoints for running GWDH optimization on Slurm.

This module intentionally keeps orchestration "thin" and defers most logic
to the existing `gwdh_optim` and `gwdh_hpc` APIs.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import logging
import os
import shlex
import uuid
from importlib import import_module
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from gwdh_core.config import GWDHConfig
from gwdh_core.types import DEFAULT_DISTANCE_WEIGHTS, DISCRETIZED_DIM, GeometryClass, ZonalZDATA

from gwdh_datalake.datalake import DataLake
from gwdh_hpc.dispatch import HPCDispatch
from gwdh_hpc.slurm_client import SlurmClient
from gwdh_hpc.zdata_extractor import ZDATAExtractor

from .active_learning import ActiveLearningCampaign
from .metrics_writer import MetricsCSVWriter
from .optimizer import CMAESOptimizer
from .problem import ZDATAProblem
from .telemetry import TelemetryLogger

logger = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="gwdh_optim")
    sub = parser.add_subparsers(dest="cmd", required=True)

    run = sub.add_parser("run-active-learning", help="Run active learning (intended for Slurm).")
    run.add_argument("--config", required=True, help="Path to GWDHConfig YAML.")
    run.add_argument("--target-zdata", required=True, help="Path to target ZDATA (.npy or raw ZDATA).")
    run.add_argument(
        "--geometry-class",
        required=True,
        choices=[g.value for g in GeometryClass],
        help="Geometry class label.",
    )
    run.add_argument("--apre-template", required=True, help="Path to APRE template for CTH.")
    run.add_argument("--base-dir", required=True, help="Shared filesystem base for eval dirs.")
    run.add_argument("--campaign-id", default=None, help="Campaign id (default: random).")
    run.add_argument("--surrogate-loader", required=True, help="module:function returning surrogate.")
    run.add_argument(
        "--primitive-params-fn",
        default=None,
        help="Optional module:function mapping DesignVector -> dict.",
    )
    run.add_argument(
        "--max-al-iterations",
        type=int,
        default=None,
        help="Max active learning iterations (default: config.campaign.max_iterations).",
    )

    submit = sub.add_parser(
        "submit-active-learning",
        help="Submit the full optimizer as a Slurm job (outer job).",
    )
    for arg in run._actions:
        if arg.dest in {"help", "cmd"}:
            continue
        # Copy run-active-learning args so users can specify once.
        submit._add_action(arg)

    submit.add_argument(
        "--slurm-template",
        default=None,
        help="Slurm template for optimizer job (default: repo template).",
    )
    submit.add_argument("--job-name", default=None, help="Slurm job name (default: gdwh_optim_<campaign_id>).")
    submit.add_argument("--walltime", default=None, help="Slurm walltime (default: config.hpc.walltime).")
    submit.add_argument("--partition", default=None, help="Slurm partition (default: config.hpc.partition).")
    submit.add_argument("--account", default=None, help="Slurm account (default: config.hpc.account).")

    return parser


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    if args.cmd == "run-active-learning":
        run_active_learning(args)
        return 0

    if args.cmd == "submit-active-learning":
        job_id = submit_active_learning(args)
        print(job_id)
        return 0

    raise ValueError(f"Unknown command: {args.cmd!r}")


def _load_callable(spec: str) -> Callable:
    if ":" not in spec:
        raise ValueError(f"Expected spec 'module:function', got: {spec!r}")
    module_name, func_name = spec.split(":", 1)
    mod = import_module(module_name)
    fn = getattr(mod, func_name, None)
    if fn is None or not callable(fn):
        raise ValueError(f"Callable not found: {spec!r}")
    return fn


def _load_target_zdata(path: str) -> ZonalZDATA:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)

    if p.suffix.lower() == ".npy":
        arr = np.load(str(p))
        return ZonalZDATA(data=arr)

    extractor = ZDATAExtractor()
    raw = extractor.parse_zdata_file(str(p))
    zonal, _ = extractor.raw_to_zonal(raw)
    return zonal


def _default_bounds() -> tuple[np.ndarray, np.ndarray]:
    # TODO: replace with geometry-class-specific bounds from gwdh-core.
    lower = np.zeros(DISCRETIZED_DIM, dtype=float)
    upper = np.ones(DISCRETIZED_DIM, dtype=float)
    return lower, upper


def _optimizer_template_default() -> str:
    """Best-effort resolution of the repo default optimizer Slurm template."""
    candidates = []
    candidates.append(Path.cwd() / "templates" / "slurm" / "run_optimizer_template.slurm")

    # Walk upwards from this file to locate the monorepo root.
    here = Path(__file__).resolve()
    for parent in here.parents:
        cand = parent / "templates" / "slurm" / "run_optimizer_template.slurm"
        candidates.append(cand)
        if (parent / "pyproject.toml").exists() and (parent / "libs").exists():
            break

    for c in candidates:
        if c.exists():
            return str(c)

    raise FileNotFoundError(
        "Could not locate default optimizer Slurm template "
        "(templates/slurm/run_optimizer_template.slurm)."
    )


def run_active_learning(args: argparse.Namespace) -> None:
    cfg = GWDHConfig.from_yaml(args.config)
    campaign_id = args.campaign_id or str(uuid.uuid4())[:12]
    geometry_class = GeometryClass(args.geometry_class)

    target_zonal = _load_target_zdata(args.target_zdata)
    lower, upper = _default_bounds()

    os.makedirs(os.path.dirname(cfg.campaign.metrics_csv_path) or ".", exist_ok=True)
    os.makedirs(cfg.campaign.plot_dir, exist_ok=True)

    surrogate_loader = _load_callable(args.surrogate_loader)
    surrogate = surrogate_loader()
    if not hasattr(surrogate, "predict_batch"):
        raise TypeError("Loaded surrogate does not implement predict_batch(X).")

    sigma = np.ones(4, dtype=float)
    problem = ZDATAProblem(
        surrogate=surrogate,
        target_zdata=target_zonal.data,
        sigma=sigma,
        lower_bounds=lower,
        upper_bounds=upper,
        weights=DEFAULT_DISTANCE_WEIGHTS,
        constraint_phase=cfg.optimization.constraint_phase,
    )
    optimizer = CMAESOptimizer(problem, cfg.optimization, seed=42)

    data_lake = DataLake(cfg.data_lake)
    try:
        data_lake.create_campaign(
            campaign_id=campaign_id,
            geometry_class=geometry_class,
            target_zdata_path=args.target_zdata,
            optimizer_config=dataclasses.asdict(cfg.optimization),
        )

        checkpoint_store = data_lake.get_checkpoint_store(cfg.campaign.checkpoint_dir)
        telemetry = TelemetryLogger(cfg.telemetry, output_dir=".")
        metrics_writer = MetricsCSVWriter(
            cfg.campaign.metrics_csv_path,
            lower,
            upper,
        )

        hpc = HPCDispatch(
            hpc_config=cfg.hpc,
            obs_config=cfg.observation_runner,
            apre_template_path=args.apre_template,
            geometry_class=geometry_class,
            base_dir=args.base_dir,
        )

        primitive_params_fn = None
        if args.primitive_params_fn:
            primitive_params_fn = _load_callable(args.primitive_params_fn)

        max_iters = args.max_al_iterations or cfg.campaign.max_iterations
        campaign = ActiveLearningCampaign(
            optimizer=optimizer,
            surrogate=surrogate,
            hpc_dispatch=hpc,
            data_lake=data_lake,
            checkpoint_store=checkpoint_store,
            telemetry=telemetry,
            metrics_writer=metrics_writer,
            config=cfg.campaign,
            campaign_id=campaign_id,
            target_zdata=target_zonal,
            geometry_class=geometry_class,
        )
        campaign.run(
            max_al_iterations=max_iters,
            retrain_fn=None,
            primitive_params_fn=primitive_params_fn,
        )
    finally:
        data_lake.close()


def submit_active_learning(args: argparse.Namespace) -> str:
    cfg = GWDHConfig.from_yaml(args.config)
    campaign_id = args.campaign_id or str(uuid.uuid4())[:12]
    job_name = args.job_name or f"gdwh_optim_{campaign_id}"

    template_path = args.slurm_template or _optimizer_template_default()
    walltime = args.walltime or cfg.hpc.walltime
    partition = args.partition or cfg.hpc.partition
    account = args.account if args.account is not None else cfg.hpc.account

    base_dir = args.base_dir
    optimizer_working_dir = os.path.join(base_dir, campaign_id, "optimizer_job")
    os.makedirs(optimizer_working_dir, exist_ok=True)

    # Record the args for provenance/debugging (not consumed by the job).
    run_args_path = os.path.join(optimizer_working_dir, "run_args.json")
    with open(run_args_path, "w") as f:
        json.dump(vars(args), f, indent=2)

    cmd_parts = [
        "python",
        "-m",
        "gwdh_optim",
        "run-active-learning",
        "--config",
        args.config,
        "--target-zdata",
        args.target_zdata,
        "--geometry-class",
        args.geometry_class,
        "--apre-template",
        args.apre_template,
        "--base-dir",
        base_dir,
        "--campaign-id",
        campaign_id,
        "--surrogate-loader",
        args.surrogate_loader,
    ]
    if args.primitive_params_fn:
        cmd_parts += ["--primitive-params-fn", args.primitive_params_fn]
    if args.max_al_iterations is not None:
        cmd_parts += ["--max-al-iterations", str(args.max_al_iterations)]

    command = " ".join(shlex.quote(p) for p in cmd_parts)

    client = SlurmClient(cfg.hpc)
    script_path = client.prepare_command_script(
        working_dir=optimizer_working_dir,
        job_name=job_name,
        command=command,
        template_path=template_path,
        ntasks=1,
        walltime=walltime,
        partition=partition,
        account=account or "",
    )

    job_id = client.submit(script_path, optimizer_working_dir)
    logger.info("[SUBMIT] Optimizer submitted as job %s", job_id)
    return job_id
