"""Active learning campaign: surrogate + hydrocode feedback loop.

Runs CMA-ES against the surrogate, selects top-K diverse candidates
for hydrocode validation, ingests ground truth, retrains surrogate,
and repeats until convergence.

Reference: docs/architecture/003_optimizer.md Section 5.1
"""
from __future__ import annotations

import logging
import uuid

import numpy as np

from gwdh_core.config import CampaignConfig
from gwdh_core.geometry.cth_templater import primitives_to_template_params
from gwdh_core.geometry.reconstructor import Reconstructor
from gwdh_core.types import (
    DesignVector,
    EvalResult,
    EvalStatus,
    GeometryClass,
    SimulationRecord,
    SimulationSource,
    ZonalZDATA,
)

from gwdh_datalake.checkpoint import CheckpointStore
from gwdh_datalake.datalake import DataLake

from gwdh_hpc.dispatch import HPCDispatch

from .metrics_writer import MetricsCSVWriter
from .optimizer import CMAESOptimizer
from .plotting import generate_all_plots
from .telemetry import TelemetryLogger

logger = logging.getLogger(__name__)


class ActiveLearningCampaign:
    """Surrogate-guided optimization with hydrocode validation feedback.

    Campaign loop:
    1. Run CMA-ES against surrogate until convergence
    2. Select top-K geometrically diverse candidates
    3. Dispatch to HPC for hydrocode validation
    4. Ingest ground truth into data lake
    5. Retrain surrogate on updated data
    6. Repeat until validation error is acceptable
    """

    def __init__(
        self,
        optimizer: CMAESOptimizer,
        surrogate,
        hpc_dispatch: HPCDispatch,
        data_lake: DataLake,
        checkpoint_store: CheckpointStore,
        telemetry: TelemetryLogger,
        metrics_writer: MetricsCSVWriter,
        config: CampaignConfig,
        campaign_id: str,
        target_zdata: ZonalZDATA,
        geometry_class: GeometryClass,
    ):
        self.optimizer = optimizer
        self.surrogate = surrogate
        self.hpc_dispatch = hpc_dispatch
        self.data_lake = data_lake
        self.checkpoint_store = checkpoint_store
        self.telemetry = telemetry
        self.metrics_writer = metrics_writer
        self.config = config
        self.campaign_id = campaign_id
        self.target_zdata = target_zdata
        self.geometry_class = geometry_class

    def run(
        self,
        max_al_iterations: int = 10,
        retrain_fn=None,
        primitive_params_fn=None,
    ) -> None:
        """Run the active learning loop.

        Args:
            max_al_iterations: Max surrogate-hydrocode feedback iterations.
            retrain_fn: Callable(DataLake, GeometryClass) -> new_surrogate.
                If None, surrogate is not retrained.
            primitive_params_fn: Callable(DesignVector) -> dict.
                If None, auto-reconstructs from design vector via Reconstructor.
        """
        # Auto-reconstruct primitives if no fn provided
        if primitive_params_fn is None:
            _recon = Reconstructor()
            _geo_class = self.geometry_class

            def primitive_params_fn(dv: DesignVector) -> dict:
                try:
                    prims = _recon.from_vector(dv, _geo_class)
                except Exception:
                    return {}
                return primitives_to_template_params(prims)

        self.data_lake.update_campaign_status(self.campaign_id, "RUNNING")

        for al_iter in range(max_al_iterations):
            logger.info(
                "[AL] === Active Learning Iteration %d/%d ===",
                al_iter, max_al_iterations,
            )

            # Step 1: Run CMA-ES against surrogate
            best_designs = self._run_surrogate_optimization(
                primitive_params_fn
            )

            # Step 2: Select top-K diverse candidates
            top_k = self._select_diverse_candidates(
                best_designs, k=self.config.validation_count
            )

            # Step 3: Dispatch to HPC for validation
            validation_results = self._validate_with_hydrocode(
                top_k, primitive_params_fn
            )

            # Step 4: Ingest ground truth
            self._ingest_validation_results(validation_results)

            # Step 5: Retrain surrogate
            if retrain_fn is not None:
                logger.info("[AL] Retraining surrogate on updated data")
                self.surrogate = retrain_fn(self.data_lake, self.geometry_class)
                # Update the problem's surrogate reference
                self.optimizer.problem.surrogate = self.surrogate

            # Step 6: Check if validation error is acceptable
            val_errors = [
                r.objectives[0]
                for r in validation_results
                if r.status == EvalStatus.COMPLETED and r.objectives is not None
            ]
            if val_errors:
                mean_error = np.mean(val_errors)
                logger.info(
                    "[AL] Iteration %d: mean validation error = %.4f",
                    al_iter, mean_error,
                )
                if mean_error < self.config.convergence_threshold:
                    logger.info("[AL] Converged — validation error below threshold")
                    break

        # Final plots
        generate_all_plots(self.telemetry.history, self.config.plot_dir)
        self.data_lake.update_campaign_status(self.campaign_id, "COMPLETED")

    def _run_surrogate_optimization(
        self, primitive_params_fn
    ) -> list[tuple[DesignVector, float]]:
        """Run CMA-ES against surrogate, collect best designs."""
        all_designs: list[tuple[DesignVector, float]] = []
        consumed_evals = 0
        gen = 0
        while consumed_evals < self.config.cmaes_budget:
            X = self.optimizer.ask()
            designs = [DesignVector(data=X[i]) for i in range(X.shape[0])]

            # Evaluate with the same penalized objective path used by CMA-ES.
            distances = self.optimizer.score_candidates(X)

            results = []
            for i, d in enumerate(designs):
                results.append(
                    EvalResult(
                        eval_id=str(uuid.uuid4())[:12],
                        design_vector=d,
                        status=EvalStatus.COMPLETED,
                        objectives=np.array([distances[i]]),
                        runtime_sec=0.0,
                    )
                )

            self.optimizer.tell(results)
            self.telemetry.log_generation(gen, results, self.optimizer)

            for i, d in enumerate(designs):
                all_designs.append((d, distances[i]))
            consumed_evals += len(designs)
            gen += 1

        # Sort by distance
        all_designs.sort(key=lambda x: x[1])
        return all_designs

    def _select_diverse_candidates(
        self,
        designs: list[tuple[DesignVector, float]],
        k: int,
    ) -> list[DesignVector]:
        """Select top-K geometrically diverse candidates.

        Uses greedy farthest-point sampling from the top 10% of designs.
        """
        # Take top 10% by objective
        n_top = max(k * 5, len(designs) // 10)
        top_designs = [d for d, _ in designs[:n_top]]

        if len(top_designs) <= k:
            return top_designs[:k]

        # Greedy farthest-point sampling
        X = np.array([d.data for d in top_designs])
        selected = [0]  # start with the best

        for _ in range(k - 1):
            min_dists = np.full(len(X), np.inf)
            for s in selected:
                dists = np.linalg.norm(X - X[s], axis=1)
                min_dists = np.minimum(min_dists, dists)
            min_dists[selected] = -1  # exclude already selected
            next_idx = int(np.argmax(min_dists))
            selected.append(next_idx)

        return [top_designs[i] for i in selected]

    def _validate_with_hydrocode(
        self,
        designs: list[DesignVector],
        primitive_params_fn,
    ) -> list[EvalResult]:
        """Submit top-K designs to HPC for hydrocode validation."""
        pairs = []
        for d in designs:
            primitives = primitive_params_fn(d) if primitive_params_fn else {}
            pairs.append((d, primitives))

        handles = self.hpc_dispatch.submit_batch(pairs, self.campaign_id)

        results = []
        for handle in handles:
            result = self.hpc_dispatch.wait_and_extract(handle)
            results.append(result)

        return results

    def _ingest_validation_results(
        self, results: list[EvalResult]
    ) -> None:
        """Ingest hydrocode validation results into the data lake."""
        for result in results:
            if result.status != EvalStatus.COMPLETED or result.zdata is None:
                continue

            record = SimulationRecord(
                campaign_id=self.campaign_id,
                geometry_class=self.geometry_class,
                source=SimulationSource.VALIDATION,
                design_vector=result.design_vector,
                stage1_output=result.stage1_output,
                zdata=result.zdata,
                cth_walltime_s=result.runtime_sec,
                mott_fit_r2=result.mott_fit_r2,
            )
            self.data_lake.ingest_simulation(record)
            logger.info(
                "[AL] Ingested validation result %s into data lake",
                result.eval_id,
            )
