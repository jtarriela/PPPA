"""Lightweight plot generation for optimization monitoring.

Generates per-run PNG artifacts using matplotlib with Agg backend
(headless for HPC). No Prometheus/Grafana needed.

Plots:
- best_f_vs_eval.png
- sigma_vs_gen.png
- eval_runtime_vs_eval.png
- failures_by_type.png
"""
from __future__ import annotations

import logging
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .telemetry import GenerationStats

logger = logging.getLogger(__name__)


def plot_best_f_vs_eval(
    history: list[GenerationStats], output_dir: str
) -> str:
    """Line plot: cumulative best objective value vs generation."""
    if not history:
        return ""

    gens = [s.gen for s in history]
    best_fs = [s.best_f for s in history]

    # Cumulative best
    cum_best = []
    running_best = float("inf")
    for f in best_fs:
        running_best = min(running_best, f)
        cum_best.append(running_best)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(gens, cum_best, "b-o", markersize=4, label="Cumulative best")
    ax.plot(gens, best_fs, "r--", alpha=0.5, label="Generation best")
    ax.set_xlabel("Generation")
    ax.set_ylabel("Objective (distance)")
    ax.set_title("Best Objective vs Generation")
    ax.legend()
    ax.grid(True, alpha=0.3)

    path = os.path.join(output_dir, "best_f_vs_eval.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Plot saved: %s", path)
    return path


def plot_sigma_vs_gen(
    history: list[GenerationStats], output_dir: str
) -> str:
    """Line plot: CMA-ES sigma (step size) vs generation."""
    if not history:
        return ""

    gens = [s.gen for s in history]
    sigmas = [s.sigma for s in history]

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.semilogy(gens, sigmas, "g-o", markersize=4)
    ax.set_xlabel("Generation")
    ax.set_ylabel("Sigma (step size)")
    ax.set_title("CMA-ES Step Size vs Generation")
    ax.grid(True, alpha=0.3)

    path = os.path.join(output_dir, "sigma_vs_gen.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Plot saved: %s", path)
    return path


def plot_eval_runtime(
    history: list[GenerationStats], output_dir: str
) -> str:
    """Line plot: p50 and p90 eval runtime vs generation."""
    if not history:
        return ""

    gens = [s.gen for s in history]
    p50s = [s.runtime_p50 for s in history]
    p90s = [s.runtime_p90 for s in history]

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(gens, p50s, "b-o", markersize=4, label="p50")
    ax.plot(gens, p90s, "r-s", markersize=4, label="p90")
    ax.set_xlabel("Generation")
    ax.set_ylabel("Runtime (seconds)")
    ax.set_title("Evaluation Runtime vs Generation")
    ax.legend()
    ax.grid(True, alpha=0.3)

    path = os.path.join(output_dir, "eval_runtime_vs_eval.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Plot saved: %s", path)
    return path


def plot_failures_by_type(
    history: list[GenerationStats], output_dir: str
) -> str:
    """Stacked bar chart: fail counts by FailType per generation."""
    if not history:
        return ""

    # Collect all failure types
    all_types: set[str] = set()
    for s in history:
        all_types.update(s.fail_counts.keys())

    if not all_types:
        return ""

    sorted_types = sorted(all_types)
    gens = [s.gen for s in history]

    fig, ax = plt.subplots(figsize=(12, 6))
    bottom = np.zeros(len(gens))

    for ftype in sorted_types:
        counts = [s.fail_counts.get(ftype, 0) for s in history]
        ax.bar(gens, counts, bottom=bottom, label=ftype, width=0.8)
        bottom += np.array(counts)

    ax.set_xlabel("Generation")
    ax.set_ylabel("Failure Count")
    ax.set_title("Failures by Type per Generation")
    ax.legend(bbox_to_anchor=(1.05, 1), loc="upper left", fontsize=8)
    ax.grid(True, alpha=0.3, axis="y")

    path = os.path.join(output_dir, "failures_by_type.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Plot saved: %s", path)
    return path


def generate_all_plots(
    history: list[GenerationStats], output_dir: str
) -> list[str]:
    """Generate all monitoring plots. Returns list of file paths."""
    os.makedirs(output_dir, exist_ok=True)
    paths = []
    for plot_fn in (
        plot_best_f_vs_eval,
        plot_sigma_vs_gen,
        plot_eval_runtime,
        plot_failures_by_type,
    ):
        path = plot_fn(history, output_dir)
        if path:
            paths.append(path)
    return paths
