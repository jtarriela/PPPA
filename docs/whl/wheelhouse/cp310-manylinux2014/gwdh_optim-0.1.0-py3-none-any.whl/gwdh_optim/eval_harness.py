"""Core evaluation harness: x -> hydrocode -> parse -> objectives.

Handles memoization, parallel dispatch, hard timeouts, failure
classification, and provenance tracking.
"""
from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timezone
from typing import Optional

import numpy as np

from gwdh_core.config import CampaignConfig
from gwdh_core.types import (
    DesignVector,
    EvalResult,
    EvalStatus,
    FailType,
    ZonalZDATA,
)

from gwdh_datalake.cache import EvalCache
from gwdh_hpc.dispatch import HPCDispatch

from .distance import hybrid_distance

logger = logging.getLogger(__name__)


class EvalHarness:
    """Pipeline: x -> hydrocode -> parse -> objectives.

    Responsibilities:
    - Memoization: check cache before dispatching
    - Parallel dispatch: submit batch to HPC
    - Timeout: hard per-eval timeout
    - Fail classification: map every failure to FailType
    - Provenance: record input_deck_sha256, cth_version, parse_version
    """

    def __init__(
        self,
        hpc_dispatch: HPCDispatch,
        eval_cache: EvalCache,
        target_zdata: ZonalZDATA,
        sigma: np.ndarray,
        config: CampaignConfig,
    ):
        self.hpc_dispatch = hpc_dispatch
        self.eval_cache = eval_cache
        self.target_zdata = target_zdata
        self.sigma = sigma
        self.config = config

    def evaluate_batch(
        self,
        designs: list[DesignVector],
        primitive_params_list: list[dict],
        campaign_id: str,
        generation: int,
    ) -> list[EvalResult]:
        """Evaluate a batch of designs. Returns results in same order.

        Steps per design:
        1. Check memoization cache (within tolerance)
        2. If miss: submit to HPC via HPCDispatch
        3. Wait with hard timeout
        4. Classify result (success or specific FailType)
        5. Compute objectives
        6. Record provenance
        7. Update cache
        """
        results: list[Optional[EvalResult]] = [None] * len(designs)
        to_evaluate: list[tuple[int, DesignVector, dict]] = []

        # Step 1: Check cache
        for i, design in enumerate(designs):
            cached = self.eval_cache.lookup(design)
            if cached is not None:
                # Do not mutate the cached object; create a copy with CACHED status instead
                import dataclasses
                cached_with_status = dataclasses.replace(cached, status=EvalStatus.CACHED)
                results[i] = cached_with_status
                logger.info(
                    "[HARNESS] Cache hit for design %d (eval_id=%s)",
                    i, cached.eval_id,
                )
            else:
                to_evaluate.append((i, design, primitive_params_list[i]))

        if not to_evaluate:
            assert all(r is not None for r in results)
            return [r for r in results if r is not None]

        # Step 2: Submit all cache misses to HPC
        design_pairs = [(d, p) for _, d, p in to_evaluate]
        handles = self.hpc_dispatch.submit_batch(design_pairs, campaign_id)

        # Step 3: Wait for all results
        for j, (idx, design, _) in enumerate(to_evaluate):
            handle = handles[j]
            try:
                result = self.hpc_dispatch.wait_and_extract(handle)
            except Exception as exc:
                logger.error(
                    "[HARNESS] wait_and_extract raised for eval %s: %s",
                    handle.eval_id, exc,
                )
                result = EvalResult(
                    eval_id=handle.eval_id,
                    design_vector=design,
                    status=EvalStatus.FAILED,
                    fail_type=FailType.UNKNOWN,
                    slurm_job_id=getattr(handle, "job_id", None),
                    timestamp=datetime.now(timezone.utc).isoformat(),
                )

            # Step 5: Compute objectives if ZDATA is available
            if result.status == EvalStatus.COMPLETED and result.zdata is not None:
                dist = hybrid_distance(
                    result.zdata.data,
                    self.target_zdata.data,
                    self.sigma,
                )
                result.objectives = np.array([dist])

            # Step 6: Provenance
            result.input_deck_sha256 = hashlib.sha256(
                design.data.tobytes()
            ).hexdigest()

            # Step 7: Update cache
            if result.status in (EvalStatus.COMPLETED, EvalStatus.FAILED):
                self.eval_cache.store(design, result)

            results[idx] = result

        assert all(r is not None for r in results)
        return [r for r in results if r is not None]
