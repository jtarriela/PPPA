"""Per-generation CMA-ES telemetry logging.

Logs: gen, popsize, n_dim, sigma, ||m||, ||delta_m||, best_f,
median_f, mean_f, success_rate, fail_counts, runtime_stats.
"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import asdict, dataclass, field
from typing import Optional

import numpy as np

from gwdh_core.config import TelemetryConfig
from gwdh_core.types import EvalResult, EvalStatus

from .optimizer import CMAESOptimizer

logger = logging.getLogger(__name__)

# Objectives at or above this threshold are treated as penalty values and
# excluded from statistics. Must be less than the penalty value in constraints.py
# (currently 1e9) so that real objectives are never accidentally filtered.
PENALTY_THRESHOLD = 1e8


@dataclass
class GenerationStats:
    """Per-generation telemetry record."""
    gen: int
    popsize: int
    n_dim: int
    sigma: float
    mean_norm: float
    delta_mean_norm: float
    best_f: float
    median_f: float
    mean_f: float
    success_rate: float
    fail_counts: dict[str, int] = field(default_factory=dict)
    runtime_p50: float = 0.0
    runtime_p90: float = 0.0


class TelemetryLogger:
    """Compute and log per-generation telemetry."""

    def __init__(self, config: TelemetryConfig, output_dir: str):
        self.config = config
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self._history: list[GenerationStats] = []
        self._prev_mean: Optional[np.ndarray] = None
        self._jsonl_path = os.path.join(output_dir, config.telemetry_jsonl_path)

    def log_generation(
        self,
        gen: int,
        results: list[EvalResult],
        optimizer: CMAESOptimizer,
    ) -> GenerationStats:
        """Compute and log all per-generation telemetry."""
        popsize = len(results)
        n_dim = 36

        # Extract optimizer state
        state = optimizer.get_state()
        sigma = state.get("sigma", 0.0)
        mean = state.get("mean")
        mean_norm = float(np.linalg.norm(mean)) if mean is not None else 0.0

        delta_mean_norm = 0.0
        if self._prev_mean is not None and mean is not None:
            delta_mean_norm = float(np.linalg.norm(mean - self._prev_mean))
        self._prev_mean = mean.copy() if mean is not None else None

        # Objective stats
        obj_values = []
        for r in results:
            if r.objectives is not None:
                val = r.objectives[0] if r.objectives.ndim > 0 else float(r.objectives)
                if val < PENALTY_THRESHOLD:  # exclude penalty values
                    obj_values.append(val)

        best_f = min(obj_values) if obj_values else float("inf")
        median_f = float(np.median(obj_values)) if obj_values else float("inf")
        mean_f = float(np.mean(obj_values)) if obj_values else float("inf")

        # Success rate
        success_count = sum(
            1 for r in results
            if r.status in (EvalStatus.COMPLETED, EvalStatus.CACHED)
        )
        success_rate = success_count / popsize if popsize > 0 else 0.0

        # Fail counts by type
        fail_counts: dict[str, int] = {}
        for r in results:
            if r.status == EvalStatus.FAILED and r.fail_type:
                key = r.fail_type.value
                fail_counts[key] = fail_counts.get(key, 0) + 1

        # Runtime stats
        runtimes = [r.runtime_sec for r in results if r.runtime_sec > 0]
        runtime_p50 = float(np.percentile(runtimes, 50)) if runtimes else 0.0
        runtime_p90 = float(np.percentile(runtimes, 90)) if runtimes else 0.0

        stats = GenerationStats(
            gen=gen,
            popsize=popsize,
            n_dim=n_dim,
            sigma=sigma,
            mean_norm=mean_norm,
            delta_mean_norm=delta_mean_norm,
            best_f=best_f,
            median_f=median_f,
            mean_f=mean_f,
            success_rate=success_rate,
            fail_counts=fail_counts,
            runtime_p50=runtime_p50,
            runtime_p90=runtime_p90,
        )

        self._history.append(stats)

        # Log to structured logger
        logger.info(
            "[OPTIMIZER] Gen %d | sigma=%.4f | best_f=%.4f | "
            "median_f=%.4f | success=%.0f%% | p90_runtime=%.1fs",
            gen, sigma, best_f, median_f, success_rate * 100, runtime_p90,
        )

        # Append to JSONL file
        if self.config.log_per_generation:
            with open(self._jsonl_path, "a") as f:
                f.write(json.dumps(asdict(stats)) + "\n")

        return stats

    @property
    def history(self) -> list[GenerationStats]:
        return self._history
