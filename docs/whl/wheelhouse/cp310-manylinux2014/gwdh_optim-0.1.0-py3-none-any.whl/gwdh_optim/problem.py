"""pymoo Problem subclass for ZDATA inverse design.

Single-objective: minimize ZDATA distance using the Hybrid
Spatial-Lethality Metric with 3-Tiered Defense System.

Reference: docs/architecture/003_optimizer.md Section 3
"""
from __future__ import annotations

from typing import Optional

import numpy as np
from pymoo.core.problem import Problem

from gwdh_core.types import DEFAULT_DISTANCE_WEIGHTS, DISCRETIZED_DIM

from .constraints import (
    compute_case_mass_batch,
    compute_diameter_batch,
    compute_explosive_mass_batch,
    compute_length_batch,
    compute_predicted_fragment_mass_batch,
    evaluate_gurney_penalty,
    evaluate_manifold_penalty,
    evaluate_mass_conservation_penalty,
)
from .distance import compute_ke_batch, hybrid_distance_batch


class ZDATAProblem(Problem):
    """Single-objective ZDATA distance minimization with physics constraints.

    The 3-Tiered Defense System:
    - Tier 1: Box bounds via pymoo xl/xu
    - Tier 2: Physics guardrails (Gurney limit, mass conservation)
    - Tier 3: Manifold trust region (One-Class SVM, optional)
    """

    def __init__(
        self,
        surrogate,
        target_zdata: np.ndarray,
        sigma: np.ndarray,
        lower_bounds: np.ndarray,
        upper_bounds: np.ndarray,
        weights: np.ndarray = DEFAULT_DISTANCE_WEIGHTS,
        anomaly_detector=None,
        E_gurney: float = 2.5e6,
        eta_efficiency: float = 0.3,
        constraint_phase: int = 1,
        M_max: Optional[float] = None,
        D_max: Optional[float] = None,
        L_max: Optional[float] = None,
    ):
        if constraint_phase not in {1, 2, 3}:
            raise ValueError(
                f"constraint_phase must be 1, 2, or 3; got {constraint_phase!r}"
            )
        n_constraints = {1: 0, 2: 1, 3: 3}[constraint_phase]

        super().__init__(
            n_var=DISCRETIZED_DIM,
            n_obj=1,
            n_ieq_constr=n_constraints,
            xl=lower_bounds,
            xu=upper_bounds,
        )

        if target_zdata.shape != (36, 4):
            raise ValueError(
                f"target_zdata must be (36, 4), got {target_zdata.shape}"
            )

        self.surrogate = surrogate
        self.target_zdata = target_zdata
        self.sigma = sigma
        self.weights = weights
        self.anomaly_detector = anomaly_detector
        self.E_gurney = E_gurney
        self.eta_efficiency = eta_efficiency
        self.constraint_phase = constraint_phase
        self.M_max = M_max
        self.D_max = D_max
        self.L_max = L_max

    def _evaluate(self, X, out, *args, **kwargs):
        # Tier 3: Manifold Trust Region
        manifold_penalty = evaluate_manifold_penalty(X, self.anomaly_detector)

        # Tier 2: Physics Guardrails
        mass_charge = compute_explosive_mass_batch(X)
        mass_case = compute_case_mass_batch(X)

        predictions = self.surrogate.predict_batch(X)  # (N, 36, 4)

        ke_predicted = compute_ke_batch(predictions)
        gurney_penalty = evaluate_gurney_penalty(
            ke_predicted, mass_charge, self.E_gurney, self.eta_efficiency
        )

        # Tier 2: Mass conservation (fragment mass <= casing mass)
        predicted_fragment_mass = compute_predicted_fragment_mass_batch(predictions)
        mass_conservation_penalty = evaluate_mass_conservation_penalty(
            predicted_fragment_mass, mass_case
        )

        # Hybrid distance
        distances = hybrid_distance_batch(
            predictions, self.target_zdata, self.sigma, self.weights
        )

        # f(x) = distance + physics_penalties + manifold_penalty
        out["F"] = (
            distances.reshape(-1, 1)
            + gurney_penalty.reshape(-1, 1)
            + mass_conservation_penalty.reshape(-1, 1)
            + manifold_penalty.reshape(-1, 1)
        )

        # Platform constraints (inequality: g(x) <= 0)
        if self.constraint_phase >= 2:
            if self.M_max is None:
                raise ValueError(
                    "M_max must be set when constraint_phase >= 2"
                )
            mass = mass_case + mass_charge
            G = [mass - self.M_max]
            if self.constraint_phase >= 3:
                G.append(compute_diameter_batch(X) - self.D_max)
                G.append(compute_length_batch(X) - self.L_max)
            out["G"] = np.column_stack(G)
