"""3-Tiered Defense System: physics guardrails and trust region constraints.

Tier 1: Box bounds (handled by pymoo Problem xl/xu)
Tier 2: Physics guardrails (Gurney limits, mass conservation)
Tier 3: Manifold trust region filter (OOD detection via One-Class SVM)

Physics computations are delegated to gwdh_core.physics.

Reference: docs/architecture/003_optimizer.md Section 3
"""
from __future__ import annotations

import numpy as np
import scipy.special as sc

GRAIN_TO_KG = 6.479891e-5

from gwdh_core.physics import (
    compute_case_mass_batch,
    compute_diameter_batch,
    compute_explosive_mass_batch,
    compute_length_batch,
)


# ── Tier 2: Physics penalty evaluators ───────────────────────


def evaluate_gurney_penalty(
    ke_predicted: np.ndarray,
    mass_charge: np.ndarray,
    E_gurney: float,
    eta_efficiency: float,
) -> np.ndarray:
    """Tier 2 Gurney limit check.

    Returns fatal penalty (1e9) where KE exceeds thermodynamic limit.
    """
    ke_limit = mass_charge * E_gurney * eta_efficiency
    return np.where(ke_predicted > ke_limit, 1e9, 0.0)


def compute_predicted_fragment_mass_batch(predictions: np.ndarray) -> np.ndarray:
    """Compute total predicted fragment mass from zonal Stage 2 outputs.

    Args:
        predictions: (N, 36, 4) arrays with columns [V, N0, lambda, mu]

    Returns:
        (N,) total predicted fragment mass per design in kilograms
    """
    n0 = predictions[:, :, 1]
    lam = predictions[:, :, 2]
    mu = predictions[:, :, 3]

    # Match lambda stabilization used by the distance metric to avoid gamma overflow.
    lam_safe = np.where(lam > 0, lam, 1e-8)
    lam_safe = np.clip(lam_safe, 0.1, 10.0)
    expected_mass_per_fragment = mu * sc.gamma(1 + 1 / lam_safe)
    zonal_mass = n0 * expected_mass_per_fragment

    # The current hydrocode/ZDATA ingestion path fits Mott mu directly from raw
    # ZDATA mass groups, which are reported in grains. Convert here so FR-3.2 is
    # compared against casing mass, which is computed in kilograms.
    return np.sum(zonal_mass, axis=1) * GRAIN_TO_KG


def evaluate_mass_conservation_penalty(
    predicted_fragment_mass: np.ndarray,
    mass_case: np.ndarray,
) -> np.ndarray:
    """Tier 2 mass conservation check.

    Fragment mass cannot exceed casing mass.
    """
    return np.where(predicted_fragment_mass > mass_case, 1e9, 0.0)


# ── Tier 3: Manifold Trust Region ────────────────────────────


def evaluate_manifold_penalty(
    X: np.ndarray,
    anomaly_detector,
) -> np.ndarray:
    """Tier 3 manifold trust region filter.

    Uses a pre-trained One-Class SVM to detect OOD designs.
    Returns exponential penalty for outliers.

    Args:
        X: (N, 36)
        anomaly_detector: sklearn-like .predict(X) returning 1 (inlier) or -1 (outlier)

    Returns:
        (N,) penalty values
    """
    if anomaly_detector is None:
        return np.zeros(X.shape[0])

    is_inlier = anomaly_detector.predict(X)
    return np.where(is_inlier == -1, 1e9, 0.0)
