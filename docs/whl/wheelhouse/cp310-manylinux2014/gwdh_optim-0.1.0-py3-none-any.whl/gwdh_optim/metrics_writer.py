"""Append-only CSV writer for per-evaluation metrics.

Columns: eval_id, iter_id, timestamp, x_norm, pct_bounds_hit,
         obj_1, penalty, is_feasible, status, fail_type, runtime_sec
"""
from __future__ import annotations

import csv
import logging
import os

import numpy as np

from gwdh_core.types import EvalResult

logger = logging.getLogger(__name__)


COLUMNS = [
    "eval_id",
    "iter_id",
    "timestamp",
    "x_norm",
    "pct_bounds_hit",
    "obj_1",
    "penalty",
    "is_feasible",
    "status",
    "fail_type",
    "runtime_sec",
]


class MetricsCSVWriter:
    """Write per-evaluation metrics to a CSV file."""

    def __init__(
        self,
        path: str,
        lower_bounds: np.ndarray,
        upper_bounds: np.ndarray,
    ):
        self.path = path
        self.lower_bounds = lower_bounds
        self.upper_bounds = upper_bounds

        if not os.path.exists(path):
            with open(path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(COLUMNS)

    def write_batch(
        self, results: list[EvalResult], generation: int
    ) -> None:
        """Append rows for a batch of results."""
        with open(self.path, "a", newline="") as f:
            writer = csv.writer(f)
            for result in results:
                row = self._result_to_row(result, generation)
                if row is not None:
                    writer.writerow(row)

    def _result_to_row(self, result: EvalResult, generation: int) -> list | None:
        if result.design_vector is None:
            logger.warning(
                "[METRICS] Skipping row for eval_id=%s: design_vector is None",
                result.eval_id,
            )
            return None
        x = result.design_vector.data
        x_norm = float(np.linalg.norm(x))

        # Compute % of parameters hitting box bounds
        at_lower = np.sum(np.abs(x - self.lower_bounds) < 1e-10)
        at_upper = np.sum(np.abs(x - self.upper_bounds) < 1e-10)
        pct_bounds_hit = (at_lower + at_upper) / len(x) * 100

        obj_1 = ""
        penalty = 0.0
        is_feasible = True

        if result.objectives is not None:
            val = (
                result.objectives[0]
                if result.objectives.ndim > 0
                else float(result.objectives)
            )
            if val >= 1e8:
                penalty = val
                is_feasible = False
            else:
                obj_1 = f"{val:.6f}"

        return [
            result.eval_id,
            generation,
            result.timestamp or "",
            f"{x_norm:.6f}",
            f"{pct_bounds_hit:.1f}",
            obj_1,
            f"{penalty:.1f}" if penalty > 0 else "",
            is_feasible,
            result.status.value,
            result.fail_type.value if result.fail_type else "",
            f"{result.runtime_sec:.1f}",
        ]
