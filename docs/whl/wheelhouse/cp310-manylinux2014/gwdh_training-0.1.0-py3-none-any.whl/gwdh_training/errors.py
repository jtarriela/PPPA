"""Stepwise surrogate training exceptions."""


class TrainingDataError(RuntimeError):
    """Raised when required training tensors are missing or inconsistent."""


class TrainingValidationError(RuntimeError):
    """Raised when holdout validation does not meet the pilot acceptance gates."""
