"""Training configuration for the stepwise surrogate model.

Extends gwdh_core.config.TrainingConfig with sklearn-specific hyperparameters
for standalone training mode (prototyping, hyperparameter tuning, evaluation).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class StandaloneTrainingConfig:
    """Extended config for standalone training mode.

    Defaults match Lee et al. (2026) paper specifications:
    MLP 3-layer [64, 32, 16], ReLU activation, 5-fold cross-validation.
    """

    # Data splitting
    validation_split: float = 0.2
    n_cv_folds: int = 5
    random_seed: int = 42

    # Stage 1 MLP
    stage1_hidden_layers: tuple[int, ...] = (64, 32, 16)
    stage1_activation: str = "relu"
    stage1_max_iter: int = 1000
    stage1_early_stopping: bool = True
    stage1_tol: float = 1e-4

    # Stage 2 MLP
    stage2_hidden_layers: tuple[int, ...] = (64, 32, 16)
    stage2_activation: str = "relu"
    stage2_max_iter: int = 1000

    # Stage 2 GPR (exponentiated quadratic / RBF kernel)
    gpr_kernel: str = "rbf"
    gpr_n_restarts_optimizer: int = 3
    gpr_alpha: float = 1e-10
    gpr_max_train_samples: int | None = 500

    # Model selection: "per_group" trains 4 model pairs (V, N0, lambda, mu)
    model_selection_strategy: str = "per_group"

    # Validation gates (Lee et al. targets)
    gate_stage1_velocity_re: float = 0.02   # < 2%
    gate_stage1_angle_re: float = 0.03      # < 3%
    gate_stage2_velocity_re: float = 0.02   # < 2%
    gate_stage2_n0_re: float = 0.05         # < 5%
    gate_stage2_lambda_re: float = 0.05     # < 5%
    gate_stage2_mu_re: float = 0.15         # < 15%
