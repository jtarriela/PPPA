"""Stage 2 training with input augmentation from Stage 1 predictions."""
from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gwdh_training.stage2.model import OUTPUT_GROUPS, Stage2Model

if TYPE_CHECKING:
    from gwdh_training.config import StandaloneTrainingConfig


def augment_input(
    X_norm: np.ndarray,
    y1_pred_norm: np.ndarray,
) -> np.ndarray:
    """Concatenate normalized design vectors with Stage 1 predictions.

    Args:
        X_norm: (N, 36) normalized design vectors.
        y1_pred_norm: (N, 16) Stage 1 predicted outputs (normalized).

    Returns:
        (N, 52) augmented input for Stage 2.
    """
    return np.concatenate([X_norm, y1_pred_norm], axis=1)


class Stage2Trainer:
    """Trains Stage 2 models with per-group hybrid selection."""

    def train(self, *args) -> Stage2Model:
        """Train Stage 2 models for each output group.
        Accepts either ``(X_train_norm, y1_pred_train_norm, y2_train_norm, config)``
        for the legacy path or ``(X_aug_train, y2_train_norm, config)`` when the
        caller already prepared the augmented feature matrix.
        """
        if len(args) == 4:
            X_train_norm, y1_pred_train_norm, y2_train_norm, config = args
            X_aug_train = augment_input(X_train_norm, y1_pred_train_norm)
        elif len(args) == 3:
            X_aug_train, y2_train_norm, config = args
        else:
            raise TypeError("Stage2Trainer.train expects 3 or 4 positional arguments.")

        models: dict = {}
        model_types: dict = {}

        for group_name, col_slice in OUTPUT_GROUPS.items():
            y_group = y2_train_norm[:, col_slice]

            best_model, best_type, cv_rmse = Stage2Model.select_best_model(
                X_aug_train, y_group, config, group_name=group_name,
            )

            models[group_name] = best_model
            model_types[group_name] = best_type

        return Stage2Model(models=models, model_types=model_types)
