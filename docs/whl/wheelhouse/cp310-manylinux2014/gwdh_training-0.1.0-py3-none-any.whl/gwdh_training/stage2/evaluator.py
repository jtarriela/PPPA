"""Stage 2 evaluation metrics + filter ablation reporting."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from gwdh_core.types import N_ZONES, ZONE_PARAM_NAMES
from gwdh_training.stage1.evaluator import compute_re, compute_rmse
from gwdh_training.stage2.model import OUTPUT_GROUPS
from gwdh_training.stage2.trainer import augment_input

if TYPE_CHECKING:
    from gwdh_training.normalization import Normalizer
    from gwdh_training.stage2.model import Stage2Model


@dataclass
class Stage2Metrics:
    """Stage 2 validation results.

    Targets from Lee et al. (2026):
      - velocity_re < 2% (achieved 1.1%)
      - n0_re < 5% (achieved 3.7%)
      - lambda_re < 5% (achieved 2.6%)
      - mu_re < 15% (achieved 9.7%)
    """

    velocity_re: float
    n0_re: float
    lambda_re: float
    mu_re: float
    velocity_rmse: float = 0.0
    n0_rmse: float = 0.0
    lambda_rmse: float = 0.0
    mu_rmse: float = 0.0
    per_zone_re: np.ndarray = field(
        default_factory=lambda: np.zeros((N_ZONES, 4))
    )  # (36, 4)


@dataclass
class FilterAblationReport:
    """Raw vs filtered comparison per Validation Protocol section 3.4.

    Postprocessing rules (applied by caller, NOT surrogate):
      1. Mass conservation clamp: scale N0 so total mass <= case mass
      2. Mott parameter bounds: clamp lambda to [0.33, 1.0], floor mu at 0.01
      3. Velocity floor: V = max(V_pred, 300 m/s)
    """

    raw_re: dict[str, float] = field(default_factory=dict)
    filtered_re: dict[str, float] = field(default_factory=dict)
    delta: dict[str, float] = field(default_factory=dict)
    activation_rate: dict[str, float] = field(default_factory=dict)
    decision: str = "cosmetic"  # "cosmetic" | "material" | "unreliable"


def apply_filters(y2_raw: np.ndarray) -> tuple[np.ndarray, dict[str, float]]:
    """Apply postprocessing filters and compute activation rates.

    Args:
        y2_raw: (N, 144) raw predictions in original scale.

    Returns:
        (y2_filtered, activation_rates) tuple.
    """
    y2 = y2_raw.copy()
    n = y2.shape[0]
    activation_counts = {"velocity": 0, "N0": 0, "lambda": 0, "mu": 0}

    vel_slice = OUTPUT_GROUPS["velocity"]
    n0_slice = OUTPUT_GROUPS["N0"]
    lam_slice = OUTPUT_GROUPS["lambda"]
    mu_slice = OUTPUT_GROUPS["mu"]

    # Velocity floor: V >= 300 m/s
    vel = y2[:, vel_slice]
    vel_mask = vel < 300.0
    activation_counts["velocity"] = int(np.any(vel_mask, axis=1).sum())
    y2[:, vel_slice] = np.maximum(vel, 300.0)

    # N0 floor: N0 >= 1
    n0 = y2[:, n0_slice]
    n0_mask = n0 < 1.0
    activation_counts["N0"] = int(np.any(n0_mask, axis=1).sum())
    y2[:, n0_slice] = np.maximum(n0, 1.0)

    # Lambda bounds: 0.33 <= lambda <= 1.0
    lam = y2[:, lam_slice]
    lam_mask = (lam < 0.33) | (lam > 1.0)
    activation_counts["lambda"] = int(np.any(lam_mask, axis=1).sum())
    y2[:, lam_slice] = np.clip(lam, 0.33, 1.0)

    # Mu floor: mu >= 0.01
    mu = y2[:, mu_slice]
    mu_mask = mu < 0.01
    activation_counts["mu"] = int(np.any(mu_mask, axis=1).sum())
    y2[:, mu_slice] = np.maximum(mu, 0.01)

    rates = {k: v / n if n > 0 else 0.0 for k, v in activation_counts.items()}
    return y2, rates


class Stage2Evaluator:
    """Evaluate Stage 2 model on holdout data with filter ablation."""

    def evaluate(
        self,
        model: Stage2Model,
        X_val_norm: np.ndarray,
        y1_pred_val_norm: np.ndarray,
        y2_val_raw: np.ndarray,
        y2_normalizer: Normalizer,
    ) -> Stage2Metrics:
        """Compute Stage 2 metrics on holdout set.

        Args:
            model: Trained Stage2Model.
            X_val_norm: (N, 36) normalized validation inputs.
            y1_pred_val_norm: (N, 16) Stage 1 predictions on validation set.
            y2_val_raw: (N, 144) raw (un-normalized) validation targets.
            y2_normalizer: Normalizer fitted on y2 training data.

        Returns:
            Stage2Metrics with per-group RE values.
        """
        X_aug = augment_input(X_val_norm, y1_pred_val_norm)
        y2_pred_norm = model.predict(X_aug)
        y2_pred_raw = y2_normalizer.inverse_transform(y2_pred_norm)

        metrics = {}
        per_zone_re = np.zeros((N_ZONES, 4))

        for i, (group_name, col_slice) in enumerate(OUTPUT_GROUPS.items()):
            true_group = y2_val_raw[:, col_slice]
            pred_group = y2_pred_raw[:, col_slice]
            metrics[f"{group_name}_rmse"] = compute_rmse(true_group, pred_group)
            metrics[f"{group_name}_re"] = compute_re(true_group, pred_group)

            for z in range(N_ZONES):
                per_zone_re[z, i] = compute_re(true_group[:, z], pred_group[:, z])

        return Stage2Metrics(
            velocity_re=metrics["velocity_re"],
            n0_re=metrics["N0_re"],
            lambda_re=metrics["lambda_re"],
            mu_re=metrics["mu_re"],
            velocity_rmse=metrics["velocity_rmse"],
            n0_rmse=metrics["N0_rmse"],
            lambda_rmse=metrics["lambda_rmse"],
            mu_rmse=metrics["mu_rmse"],
            per_zone_re=per_zone_re,
        )

    def ablation_report(
        self,
        model: Stage2Model,
        X_val_norm: np.ndarray,
        y1_pred_val_norm: np.ndarray,
        y2_val_raw: np.ndarray,
        y2_normalizer: Normalizer,
    ) -> FilterAblationReport:
        """Compare raw vs filtered predictions per Validation Protocol section 3.4.

        Args:
            model: Trained Stage2Model.
            X_val_norm: (N, 36) normalized validation inputs.
            y1_pred_val_norm: (N, 16) Stage 1 predictions.
            y2_val_raw: (N, 144) raw validation targets.
            y2_normalizer: Normalizer fitted on y2.

        Returns:
            FilterAblationReport with delta and activation rates.
        """
        X_aug = augment_input(X_val_norm, y1_pred_val_norm)
        y2_pred_norm = model.predict(X_aug)
        y2_pred_raw = y2_normalizer.inverse_transform(y2_pred_norm)

        # Compute raw RE
        raw_re: dict[str, float] = {}
        for group_name, col_slice in OUTPUT_GROUPS.items():
            raw_re[group_name] = compute_re(
                y2_val_raw[:, col_slice], y2_pred_raw[:, col_slice]
            )

        # Apply filters
        y2_filtered, activation_rates = apply_filters(y2_pred_raw)

        # Compute filtered RE
        filtered_re: dict[str, float] = {}
        for group_name, col_slice in OUTPUT_GROUPS.items():
            filtered_re[group_name] = compute_re(
                y2_val_raw[:, col_slice], y2_filtered[:, col_slice]
            )

        # Compute delta
        delta = {k: filtered_re[k] - raw_re[k] for k in raw_re}

        # Decision rules from Validation Protocol
        max_delta = max(abs(d) for d in delta.values())
        max_activation = max(activation_rates.values())

        if max_delta > 0.10:
            decision = "unreliable"
        elif max_delta > 0.05 or max_activation > 0.20:
            decision = "material"
        else:
            decision = "cosmetic"

        return FilterAblationReport(
            raw_re=raw_re,
            filtered_re=filtered_re,
            delta=delta,
            activation_rate=activation_rates,
            decision=decision,
        )


def compute_stage2_sigma(y_train: np.ndarray) -> np.ndarray:
    """Compute per-parameter sigma across all zones for NRMSE reporting."""
    zonal = y_train.reshape(-1, 36, 4)
    sigma = np.std(zonal, axis=(0, 1))
    return np.where(sigma < 1e-8, 1.0, sigma)


def evaluate_stage2(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    sigma_by_param: np.ndarray,
) -> dict[str, float]:
    """Compute Lee-aligned Stage 2 relative error and NRMSE metrics."""
    zonal_true = y_true.reshape(-1, 36, 4)
    zonal_pred = y_pred.reshape(-1, 36, 4)
    rmse_by_param = np.sqrt(np.mean((zonal_pred - zonal_true) ** 2, axis=(0, 1)))
    nrmse_by_param = rmse_by_param / sigma_by_param
    return {
        "velocity_re_pct": compute_re(zonal_true[:, :, 0], zonal_pred[:, :, 0]) * 100.0,
        "N0_re_pct": compute_re(zonal_true[:, :, 1], zonal_pred[:, :, 1]) * 100.0,
        "lambda_re_pct": compute_re(zonal_true[:, :, 2], zonal_pred[:, :, 2]) * 100.0,
        "mu_re_pct": compute_re(zonal_true[:, :, 3], zonal_pred[:, :, 3]) * 100.0,
        "velocity_nrmse": float(nrmse_by_param[0]),
        "N0_nrmse": float(nrmse_by_param[1]),
        "lambda_nrmse": float(nrmse_by_param[2]),
        "mu_nrmse": float(nrmse_by_param[3]),
    }
