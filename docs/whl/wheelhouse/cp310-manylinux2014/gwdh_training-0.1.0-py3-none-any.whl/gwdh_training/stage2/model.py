"""Stage 2 hybrid MLP/GPR model: X_aug(52) -> y2(144) with per-group selection."""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel
from sklearn.model_selection import cross_val_score
from sklearn.neural_network import MLPRegressor

from gwdh_core.types import N_ZONES

if TYPE_CHECKING:
    from gwdh_training.config import StandaloneTrainingConfig

# Output group indices within the 144-dim flattened y2
# y2 layout: [V_zone0..V_zone35, N0_zone0..N0_zone35, lam_zone0..lam_zone35, mu_zone0..mu_zone35]
OUTPUT_GROUPS = {
    "velocity": slice(0, N_ZONES),                          # 0:36
    "N0": slice(N_ZONES, 2 * N_ZONES),                      # 36:72
    "lambda": slice(2 * N_ZONES, 3 * N_ZONES),              # 72:108
    "mu": slice(3 * N_ZONES, 4 * N_ZONES),                  # 108:144
}


class Stage2Model:
    """Hybrid MLP/GPR model for Stage 2 prediction.

    Per Lee et al.: trains both MLP and GPR for each output group (V, N0,
    lambda, mu), selects whichever has lower 5-fold cross-validation RMSE.
    """

    def __init__(
        self,
        models: dict[str, Any],
        model_types: dict[str, str],
    ) -> None:
        """Initialize with pre-trained models.

        Args:
            models: Mapping from group name -> fitted sklearn estimator.
            model_types: Mapping from group name -> "mlp" or "gpr".
        """
        self._models = models
        self._model_types = model_types

    def predict(self, X_aug: np.ndarray) -> np.ndarray:
        """Predict stage 2 outputs.

        Args:
            X_aug: (N, 52) or (52,) augmented input (normalized X + stage1 pred).

        Returns:
            (N, 144) or (144,) predicted zonal ZDATA parameters (normalized).
        """
        single = X_aug.ndim == 1
        if single:
            X_aug = X_aug.reshape(1, -1)

        n = X_aug.shape[0]
        y_pred = np.zeros((n, 4 * N_ZONES))

        for group_name, col_slice in OUTPUT_GROUPS.items():
            model = self._models[group_name]
            y_pred[:, col_slice] = model.predict(X_aug)

        if single:
            return y_pred.ravel()
        return y_pred

    @property
    def model_types(self) -> dict[str, str]:
        """Which model type was selected for each output group."""
        return dict(self._model_types)

    @property
    def models(self) -> dict[str, Any]:
        """Access underlying sklearn models (for serialization)."""
        return dict(self._models)

    @staticmethod
    def select_best_model(
        X: np.ndarray,
        y_group: np.ndarray,
        config: StandaloneTrainingConfig,
        group_name: str = "",
    ) -> tuple[Any, str, float]:
        """Train MLP and GPR on a group, return the one with lower CV RMSE.

        Args:
            X: (N, 52) augmented input.
            y_group: (N, 36) targets for one output group.
            config: Training configuration.
            group_name: For logging ("velocity", "N0", etc.).

        Returns:
            (best_model, model_type, cv_rmse) tuple.
        """
        # MLP candidate
        mlp = MLPRegressor(
            hidden_layer_sizes=config.stage2_hidden_layers,
            activation=config.stage2_activation,
            max_iter=config.stage2_max_iter,
            random_state=config.random_seed,
        )
        mlp_scores = cross_val_score(
            mlp, X, y_group,
            cv=config.n_cv_folds,
            scoring="neg_mean_squared_error",
        )
        mlp_rmse = float(np.mean(np.sqrt(-mlp_scores)))

        if (
            config.gpr_max_train_samples is not None
            and X.shape[0] > config.gpr_max_train_samples
        ):
            mlp.fit(X, y_group)
            return mlp, "mlp", mlp_rmse

        # GPR candidate
        kernel = ConstantKernel(1.0) * RBF(length_scale=1.0)
        gpr = GaussianProcessRegressor(
            kernel=kernel,
            n_restarts_optimizer=config.gpr_n_restarts_optimizer,
            alpha=config.gpr_alpha,
            random_state=config.random_seed,
        )

        # GPR doesn't natively support multi-output in cross_val_score,
        # so we wrap with MultiOutputRegressor for CV only if y has >1 col
        if y_group.ndim == 2 and y_group.shape[1] > 1:
            from sklearn.multioutput import MultiOutputRegressor
            gpr_wrapped = MultiOutputRegressor(gpr)
        else:
            gpr_wrapped = gpr

        gpr_scores = cross_val_score(
            gpr_wrapped, X, y_group,
            cv=config.n_cv_folds,
            scoring="neg_mean_squared_error",
        )
        gpr_rmse = float(np.mean(np.sqrt(-gpr_scores)))

        # Select best
        if mlp_rmse <= gpr_rmse:
            # Refit MLP on full data
            mlp.fit(X, y_group)
            return mlp, "mlp", mlp_rmse
        else:
            # Refit GPR on full data
            gpr_wrapped.fit(X, y_group)
            return gpr_wrapped, "gpr", gpr_rmse
