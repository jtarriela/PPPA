"""Model serialization and versioning via joblib."""
from __future__ import annotations

import os
import pickle
from datetime import datetime, timezone
from typing import Any

import joblib
import numpy as np

from gwdh_core.types import GeometryClass


def stage_model_id(base_model_id: str, stage: int) -> str:
    return f"{base_model_id}:stage{stage}"


def bundle_path_for_model(data_lake, geometry_class: GeometryClass, model_id: str) -> str:
    base_dir = os.path.dirname(data_lake.config.tensor_dir.rstrip("/")) or "."
    model_dir = os.path.join(base_dir, "models", geometry_class.value)
    os.makedirs(model_dir, exist_ok=True)
    return os.path.join(model_dir, f"{model_id}.pkl")


def save_model_bundle(
    path: str,
    *,
    stage1_model,
    stage2_model,
    input_normalizer,
    y1_normalizer,
    y2_normalizer,
    metadata: dict[str, Any],
) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "wb") as handle:
        pickle.dump(
            {
                "stage1_model": stage1_model,
                "stage2_model": stage2_model,
                "input_normalizer_params": input_normalizer.get_params(),
                "y1_normalizer_params": y1_normalizer.get_params(),
                "y2_normalizer_params": y2_normalizer.get_params(),
                "metadata": metadata,
            },
            handle,
        )


def load_model_bundle(path: str) -> dict[str, Any]:
    with open(path, "rb") as handle:
        return pickle.load(handle)


class SurrogateRegistry:
    """Serialize/deserialize trained StepwiseSurrogate models.

    Persists model artifacts as a single joblib bundle containing:
      - stage1_model: sklearn MLPRegressor
      - stage2_models: dict of sklearn estimators per output group
      - stage2_model_types: dict of "mlp"/"gpr" per output group
      - input_normalizer_params: {mean, std}
      - y1_normalizer_params: {mean, std}
      - y2_normalizer_params: {mean, std}
      - metadata: training report summary
    """

    @staticmethod
    def save(
        surrogate,
        model_id: str,
        geometry_class: GeometryClass,
        report=None,
        save_path: str | None = None,
    ) -> str:
        """Persist model artifacts to disk.

        Args:
            surrogate: Trained StepwiseSurrogate instance.
            model_id: Unique identifier for this model version.
            geometry_class: Which geometry class this model was trained for.
            report: Optional TrainingReport for metadata.
            save_path: File path to save to. If None, uses model_id.joblib.

        Returns:
            Path where model was saved.
        """
        bundle = {
            "model_id": model_id,
            "geometry_class": geometry_class.value,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "stage1_model": surrogate.stage1.get_sklearn_model(),
            "stage2_models": surrogate.stage2.models,
            "stage2_model_types": surrogate.stage2.model_types,
            "input_normalizer_params": surrogate.input_normalizer.get_params(),
            "y1_normalizer_params": surrogate.y1_normalizer.get_params(),
            "y2_normalizer_params": surrogate.y2_normalizer.get_params(),
        }

        if report is not None:
            bundle["metadata"] = {
                "n_training_samples": report.n_training_samples,
                "n_holdout_samples": report.n_holdout_samples,
                "passed_gates": report.passed_gates,
                "model_selection_map": report.model_selection_map,
                "stage1_velocity_re": report.stage1_metrics.velocity_re,
                "stage1_angle_re": report.stage1_metrics.angle_re,
                "stage2_velocity_re": report.stage2_metrics.velocity_re,
                "stage2_n0_re": report.stage2_metrics.n0_re,
                "stage2_lambda_re": report.stage2_metrics.lambda_re,
                "stage2_mu_re": report.stage2_metrics.mu_re,
            }

        path = save_path or f"{model_id}.joblib"
        joblib.dump(bundle, path)
        return path

    @staticmethod
    def load(model_id_or_path: str, data_lake=None):
        """Reconstruct inference-ready StepwiseSurrogate from saved bundle.

        Args:
            model_id_or_path: File path to .joblib bundle.
            data_lake: Optional (unused, reserved for future DataLake-backed storage).

        Returns:
            StepwiseSurrogate instance ready for predict/predict_batch.
        """
        from gwdh_training.normalization import Normalizer
        from gwdh_training.pipeline import StepwiseSurrogate
        from gwdh_training.stage1.model import Stage1Model
        from gwdh_training.stage2.model import Stage2Model

        bundle = joblib.load(model_id_or_path)

        stage1 = Stage1Model.from_sklearn_model(bundle["stage1_model"])
        stage2 = Stage2Model(
            models=bundle["stage2_models"],
            model_types=bundle["stage2_model_types"],
        )
        input_norm = Normalizer.from_params(bundle["input_normalizer_params"])
        y1_norm = Normalizer.from_params(bundle["y1_normalizer_params"])
        y2_norm = Normalizer.from_params(bundle["y2_normalizer_params"])

        return StepwiseSurrogate(
            stage1=stage1,
            stage2=stage2,
            input_normalizer=input_norm,
            y1_normalizer=y1_norm,
            y2_normalizer=y2_norm,
        )

    @staticmethod
    def get_metadata(model_path: str) -> dict:
        """Read metadata from a saved model bundle without loading models."""
        bundle = joblib.load(model_path)
        return {
            "model_id": bundle.get("model_id"),
            "geometry_class": bundle.get("geometry_class"),
            "created_at": bundle.get("created_at"),
            "metadata": bundle.get("metadata", {}),
        }
