"""DataLake -> structured training arrays with train/validation splits."""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from sklearn.model_selection import train_test_split

from gwdh_core.types import (
    DISCRETIZED_DIM,
    N_ZONES,
    N_ZONE_PARAMS,
    STAGE1_OUT_DIM,
    GeometryClass,
    ZonalZDATA,
)
from .errors import TrainingDataError

if TYPE_CHECKING:
    from gwdh_training.config import StandaloneTrainingConfig

# Stage 2 output dimension: 36 zones x 4 params = 144
STAGE2_OUT_DIM = N_ZONES * N_ZONE_PARAMS


@dataclass
class TrainingData:
    """Structured arrays for surrogate training.

    Attributes:
        X:  (N, 36) design vectors (Layer 2).
        y1: (N, 16) stage 1 outputs -- section velocities (8) + angles (8).
        y2: (N, 144) stage 2 outputs -- 36 zones x (V, N0, lambda, mu) flattened.
    """

    X: np.ndarray    # (N, 36)
    y1: np.ndarray   # (N, 16)
    y2: np.ndarray   # (N, 144)

    def __post_init__(self) -> None:
        n = self.X.shape[0]
        if self.X.shape != (n, DISCRETIZED_DIM):
            raise ValueError(
                f"X must be (N, {DISCRETIZED_DIM}), got {self.X.shape}"
            )
        if self.y1.shape != (n, STAGE1_OUT_DIM):
            raise ValueError(
                f"y1 must be (N, {STAGE1_OUT_DIM}), got {self.y1.shape}"
            )
        if self.y2.shape != (n, STAGE2_OUT_DIM):
            raise ValueError(
                f"y2 must be (N, {STAGE2_OUT_DIM}), got {self.y2.shape}"
            )

    @property
    def n_samples(self) -> int:
        return self.X.shape[0]


@dataclass(frozen=True)
class TrainingDataset:
    """Stage-aligned training and holdout splits for the data-lake path."""

    X_stage1_train: np.ndarray
    X_stage1_holdout: np.ndarray
    X_stage2_train: np.ndarray
    X_stage2_holdout: np.ndarray
    y_stage1_train: np.ndarray
    y_stage1_holdout: np.ndarray
    y_stage2_train: np.ndarray
    y_stage2_holdout: np.ndarray


def load_training_data(
    data_lake,
    geometry_class: GeometryClass,
) -> TrainingData:
    """Pull simulation records from DataLake, return structured arrays.

    Args:
        data_lake: A gwdh_datalake.DataLake instance.
        geometry_class: Which geometry class to load data for.

    Returns:
        TrainingData with X (N,36), y1 (N,16), y2 (N,144).

    Raises:
        ValueError: If no complete rows remain after filtering NaN stage1 outputs.
    """
    X, y1, zdata = data_lake.load_training_data(geometry_class=geometry_class)
    if X.shape[0] == 0:
        raise ValueError(
            f"No complete simulation records found for {geometry_class.value}. "
            "Records must have design_vector, stage1_output, and zdata."
        )
    complete_mask = ~np.isnan(y1).any(axis=1)
    if not np.any(complete_mask):
        raise ValueError(
            f"No complete simulation records found for {geometry_class.value}. "
            "Records must have design_vector, stage1_output, and zdata."
        )

    X_complete = X[complete_mask]
    y1_complete = y1[complete_mask]
    zdata_complete = zdata[complete_mask]
    y2 = np.stack([ZonalZDATA(data=row).to_flat() for row in zdata_complete])

    return TrainingData(X=X_complete, y1=y1_complete, y2=y2)


def split_data(
    data: TrainingData,
    config: StandaloneTrainingConfig,
) -> tuple[TrainingData, TrainingData]:
    """Split into train/holdout sets.

    Args:
        data: Full training dataset.
        config: Config with validation_split and random_seed.

    Returns:
        (train_data, holdout_data) tuple.
    """
    idx = np.arange(data.n_samples)
    train_idx, val_idx = train_test_split(
        idx,
        test_size=config.validation_split,
        random_state=config.random_seed,
    )

    train = TrainingData(
        X=data.X[train_idx],
        y1=data.y1[train_idx],
        y2=data.y2[train_idx],
    )
    holdout = TrainingData(
        X=data.X[val_idx],
        y1=data.y1[val_idx],
        y2=data.y2[val_idx],
    )
    return train, holdout


def load_training_dataset(
    data_lake,
    geometry_class: GeometryClass,
    validation_split: float,
    random_seed: int,
) -> TrainingDataset:
    """Load aligned Stage 1/Stage 2 matrices from the data lake."""
    X_stage1, y_stage1 = data_lake.get_training_set(geometry_class, stage=1)
    X_stage2, y_stage2 = data_lake.get_training_set(geometry_class, stage=2)

    n_samples = X_stage1.shape[0]
    if n_samples < 2:
        raise TrainingDataError("At least two samples are required to create a train/holdout split.")
    if X_stage2.shape[0] != n_samples or y_stage1.shape[0] != n_samples or y_stage2.shape[0] != n_samples:
        raise TrainingDataError("Stage 1 and Stage 2 datasets must contain the same number of samples.")
    if not np.allclose(X_stage1, X_stage2[:, 16:]):
        raise TrainingDataError("Stage 1 and Stage 2 design vectors are misaligned.")

    indices = np.arange(n_samples)
    train_idx, holdout_idx = train_test_split(
        indices,
        test_size=validation_split,
        random_state=random_seed,
        shuffle=True,
    )
    if train_idx.size == 0 or holdout_idx.size == 0:
        raise TrainingDataError("Train/holdout split produced an empty partition.")

    return TrainingDataset(
        X_stage1_train=X_stage1[train_idx],
        X_stage1_holdout=X_stage1[holdout_idx],
        X_stage2_train=X_stage2[train_idx],
        X_stage2_holdout=X_stage2[holdout_idx],
        y_stage1_train=y_stage1[train_idx],
        y_stage1_holdout=y_stage1[holdout_idx],
        y_stage2_train=y_stage2[train_idx],
        y_stage2_holdout=y_stage2[holdout_idx],
    )
