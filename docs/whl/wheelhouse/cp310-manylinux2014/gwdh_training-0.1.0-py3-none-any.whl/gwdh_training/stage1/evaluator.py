"""Stage 1 evaluation metrics: per-section RE for velocity and angle."""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from gwdh_core.types import N_SECTIONS

if TYPE_CHECKING:
    from gwdh_training.normalization import Normalizer
    from gwdh_training.stage1.model import Stage1Model


@dataclass
class Stage1Metrics:
    """Stage 1 validation results.

    Targets from Lee et al. (2026):
      - velocity_re < 2% (achieved 1.1%)
      - angle_re < 3% (achieved ~2%)
    """

    velocity_rmse: float
    velocity_re: float
    angle_rmse: float
    angle_re: float
    per_section_re: np.ndarray  # (16,) individual RE values


def compute_rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Root mean squared error."""
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def compute_re(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Relative error: RMSE / mean(|y_true|) x 100.

    Per Lee et al. Eq. (3): RE(%) = RMSE / (1/n * sum|yi|) * 100
    Returns as fraction (0.011 = 1.1%), not percentage.
    """
    rmse = compute_rmse(y_true, y_pred)
    mean_abs = np.mean(np.abs(y_true))
    if mean_abs == 0.0:
        return 0.0
    return rmse / mean_abs


class Stage1Evaluator:
    """Evaluate Stage 1 model on holdout data."""

    def evaluate(
        self,
        model: Stage1Model,
        X_val_norm: np.ndarray,
        y1_val_raw: np.ndarray,
        y1_normalizer: Normalizer,
    ) -> Stage1Metrics:
        """Compute Stage 1 metrics on holdout set.

        Args:
            model: Trained Stage1Model.
            X_val_norm: (N, 36) normalized validation inputs.
            y1_val_raw: (N, 16) raw (un-normalized) validation targets.
            y1_normalizer: Normalizer fitted on y1 training data.

        Returns:
            Stage1Metrics with velocity and angle RE values.
        """
        y1_pred_norm = model.predict(X_val_norm)
        y1_pred_raw = y1_normalizer.inverse_transform(y1_pred_norm)

        # Split into velocities (0:8) and angles (8:16)
        vel_true = y1_val_raw[:, :N_SECTIONS]
        vel_pred = y1_pred_raw[:, :N_SECTIONS]
        ang_true = y1_val_raw[:, N_SECTIONS:]
        ang_pred = y1_pred_raw[:, N_SECTIONS:]

        vel_rmse = compute_rmse(vel_true, vel_pred)
        vel_re = compute_re(vel_true, vel_pred)
        ang_rmse = compute_rmse(ang_true, ang_pred)
        ang_re = compute_re(ang_true, ang_pred)

        # Per-section RE (16 values)
        per_section = np.zeros(2 * N_SECTIONS)
        for i in range(N_SECTIONS):
            per_section[i] = compute_re(vel_true[:, i], vel_pred[:, i])
        for i in range(N_SECTIONS):
            per_section[N_SECTIONS + i] = compute_re(
                ang_true[:, i], ang_pred[:, i]
            )

        return Stage1Metrics(
            velocity_rmse=vel_rmse,
            velocity_re=vel_re,
            angle_rmse=ang_rmse,
            angle_re=ang_re,
            per_section_re=per_section,
        )


def evaluate_stage1(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    """Compute Lee-aligned Stage 1 holdout metrics in percent."""
    return {
        "velocity_re_pct": compute_re(y_true[:, :8], y_pred[:, :8]) * 100.0,
        "angle_re_pct": compute_re(y_true[:, 8:], y_pred[:, 8:]) * 100.0,
    }
