"""Stage 1 MLP model: X(36) -> y1(16) [section velocities + angles]."""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from sklearn.neural_network import MLPRegressor

if TYPE_CHECKING:
    from gwdh_training.config import StandaloneTrainingConfig


class Stage1Model:
    """Wrapper around sklearn MLPRegressor for Stage 1 prediction.

    Predicts 16 outputs (8 section velocities + 8 ejection angles)
    from 36-dimensional normalized design vectors.
    """

    def __init__(self, config: Any | None = None) -> None:
        if isinstance(config, MLPRegressor):
            self._model = config
            self._fitted = True
            return

        if config is None:
            from gwdh_training.config import StandaloneTrainingConfig
            config = StandaloneTrainingConfig()

        activation = getattr(config, "stage1_activation", "relu")
        max_iter = getattr(config, "stage1_max_iter", getattr(config, "stage1_epochs", 500))
        early_stopping = getattr(config, "stage1_early_stopping", False)
        tol = getattr(config, "stage1_tol", 1e-4)
        random_seed = getattr(config, "random_seed", 0)
        self._model = MLPRegressor(
            hidden_layer_sizes=config.stage1_hidden_layers,
            activation=activation,
            max_iter=max_iter,
            early_stopping=early_stopping,
            tol=tol,
            random_state=random_seed,
            validation_fraction=0.1 if early_stopping else 0.0,
        )
        self._fitted = False

    def fit(self, X: np.ndarray, y: np.ndarray) -> Stage1Model:
        """Train the MLP on normalized data.

        Args:
            X: (N, 36) normalized design vectors.
            y: (N, 16) normalized stage 1 targets.

        Returns:
            self for method chaining.
        """
        self._model.fit(X, y)
        self._fitted = True
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict stage 1 outputs.

        Args:
            X: (N, 36) or (36,) normalized design vectors.

        Returns:
            (N, 16) or (16,) predicted section velocities + angles.
        """
        if not self._fitted:
            raise RuntimeError("Stage1Model must be fit before predict.")
        return self._model.predict(X)

    def get_sklearn_model(self) -> MLPRegressor:
        """Access underlying sklearn model (for serialization, inspection)."""
        return self._model

    @classmethod
    def from_sklearn_model(cls, model: MLPRegressor) -> Stage1Model:
        """Reconstruct from a deserialized sklearn MLPRegressor."""
        instance = cls.__new__(cls)
        instance._model = model
        instance._fitted = True
        return instance
