"""Stage 1 training loop with cross-validation."""
from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from sklearn.model_selection import cross_val_score

from gwdh_training.stage1.model import Stage1Model

if TYPE_CHECKING:
    from gwdh_training.config import StandaloneTrainingConfig


class Stage1Trainer:
    """Trains a Stage1Model and provides cross-validation metrics."""

    def train(self, *args) -> Stage1Model:
        """Train a Stage 1 MLP model.
        Accepts either ``(X_train, y_train, X_val, y_val, config)`` for the
        legacy standalone path or ``(X_train, y_train, config)`` for the
        data-lake-integrated path.
        """
        if len(args) == 5:
            X_train, y1_train, _X_val, _y1_val, config = args
        elif len(args) == 3:
            X_train, y1_train, config = args
        else:
            raise TypeError("Stage1Trainer.train expects 3 or 5 positional arguments.")
        model = Stage1Model(config)
        model.fit(X_train, y1_train)
        return model

    def cross_validate(
        self,
        X: np.ndarray,
        y: np.ndarray,
        config: StandaloneTrainingConfig,
    ) -> dict[str, float]:
        """Run k-fold cross-validation and report metrics.

        Args:
            X: (N, 36) normalized design vectors.
            y: (N, 16) normalized stage 1 targets.
            config: Training configuration with n_cv_folds.

        Returns:
            Dict with keys: rmse_mean, rmse_std, per_fold_scores.
        """
        from sklearn.neural_network import MLPRegressor

        estimator = MLPRegressor(
            hidden_layer_sizes=config.stage1_hidden_layers,
            activation=config.stage1_activation,
            max_iter=config.stage1_max_iter,
            early_stopping=config.stage1_early_stopping,
            tol=config.stage1_tol,
            random_state=config.random_seed,
            validation_fraction=0.1 if config.stage1_early_stopping else 0.0,
        )

        # neg_mean_squared_error is sklearn convention (higher = better)
        scores = cross_val_score(
            estimator,
            X,
            y,
            cv=config.n_cv_folds,
            scoring="neg_mean_squared_error",
        )
        rmse_per_fold = np.sqrt(-scores)

        return {
            "rmse_mean": float(np.mean(rmse_per_fold)),
            "rmse_std": float(np.std(rmse_per_fold)),
            "per_fold_scores": rmse_per_fold.tolist(),
        }
