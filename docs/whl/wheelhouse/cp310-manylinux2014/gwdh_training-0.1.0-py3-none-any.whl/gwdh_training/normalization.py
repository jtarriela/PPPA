"""Z-score normalization with save/load for model deployment."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


class Normalizer:
    """Z-score (StandardScaler-style) normalization with serializable params.

    Stores mean and std as numpy arrays for persistence alongside trained
    models (via joblib or dict serialization).
    """

    def __init__(self) -> None:
        self._mean: np.ndarray | None = None
        self._std: np.ndarray | None = None
        self._fitted = False

    def fit(self, X: np.ndarray) -> Normalizer:
        """Compute mean and std from training data.

        Args:
            X: (N, D) array of training samples.

        Returns:
            self for method chaining.
        """
        self._mean = np.mean(X, axis=0)
        self._std = np.std(X, axis=0)
        # Guard against zero-variance columns (constant features)
        self._std[self._std == 0.0] = 1.0
        self._fitted = True
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        """Apply Z-score normalization: (X - mean) / std.

        Args:
            X: (N, D) or (D,) array.

        Returns:
            Normalized array with same shape.
        """
        if not self._fitted:
            raise RuntimeError("Normalizer must be fit before transform.")
        return (X - self._mean) / self._std

    def inverse_transform(self, X_norm: np.ndarray) -> np.ndarray:
        """Reverse Z-score normalization: X_norm * std + mean.

        Args:
            X_norm: Normalized (N, D) or (D,) array.

        Returns:
            Original-scale array with same shape.
        """
        if not self._fitted:
            raise RuntimeError("Normalizer must be fit before inverse_transform.")
        return X_norm * self._std + self._mean

    def get_params(self) -> dict[str, np.ndarray]:
        """Export parameters for serialization."""
        if not self._fitted:
            raise RuntimeError("Normalizer must be fit before get_params.")
        return {"mean": self._mean.copy(), "std": self._std.copy()}

    @classmethod
    def from_params(cls, params: dict[str, np.ndarray]) -> Normalizer:
        """Reconstruct a fitted Normalizer from saved parameters."""
        norm = cls()
        norm._mean = np.asarray(params["mean"])
        norm._std = np.asarray(params["std"])
        norm._fitted = True
        return norm


def _safe_std(values: np.ndarray) -> np.ndarray:
    std = np.std(values, axis=0)
    return np.where(std < 1e-8, 1.0, std)


@dataclass(frozen=True)
class FeatureNormalizer:
    """Deterministic normalization stats for the data-lake training path."""

    input_mean: np.ndarray
    input_std: np.ndarray
    stage1_mean: np.ndarray
    stage1_std: np.ndarray
    stage2_mean: np.ndarray
    stage2_std: np.ndarray

    @classmethod
    def fit(
        cls,
        design_vectors: np.ndarray,
        stage1_outputs: np.ndarray,
        stage2_targets: np.ndarray,
    ) -> "FeatureNormalizer":
        return cls(
            input_mean=np.mean(design_vectors, axis=0),
            input_std=_safe_std(design_vectors),
            stage1_mean=np.mean(stage1_outputs, axis=0),
            stage1_std=_safe_std(stage1_outputs),
            stage2_mean=np.mean(stage2_targets, axis=0),
            stage2_std=_safe_std(stage2_targets),
        )

    @staticmethod
    def build_stage2_features(stage1_outputs: np.ndarray, design_vectors: np.ndarray) -> np.ndarray:
        return np.concatenate([stage1_outputs, design_vectors], axis=-1)

    def transform_input(self, design_vectors: np.ndarray) -> np.ndarray:
        return (np.asarray(design_vectors, dtype=float) - self.input_mean) / self.input_std

    def inverse_input(self, design_vectors: np.ndarray) -> np.ndarray:
        return np.asarray(design_vectors, dtype=float) * self.input_std + self.input_mean

    def transform_stage1(self, stage1_outputs: np.ndarray) -> np.ndarray:
        return (np.asarray(stage1_outputs, dtype=float) - self.stage1_mean) / self.stage1_std

    def inverse_stage1(self, stage1_outputs: np.ndarray) -> np.ndarray:
        return np.asarray(stage1_outputs, dtype=float) * self.stage1_std + self.stage1_mean

    def transform_stage2(self, stage2_targets: np.ndarray) -> np.ndarray:
        return (np.asarray(stage2_targets, dtype=float) - self.stage2_mean) / self.stage2_std

    def inverse_stage2(self, stage2_targets: np.ndarray) -> np.ndarray:
        return np.asarray(stage2_targets, dtype=float) * self.stage2_std + self.stage2_mean

    def transform_stage2_features(self, features: np.ndarray) -> np.ndarray:
        features = np.asarray(features, dtype=float)
        stage1 = self.transform_stage1(features[..., :16])
        design = self.transform_input(features[..., 16:])
        return self.build_stage2_features(stage1, design)
