"""StepwiseSurrogate inference wrapper + SurrogateTrainingPipeline orchestrator."""
from __future__ import annotations

from dataclasses import dataclass
import uuid

import numpy as np

from gwdh_core.config import TrainingConfig
from gwdh_core.types import (
    N_ZONES,
    N_ZONE_PARAMS,
    GeometryClass,
)
from gwdh_training.config import StandaloneTrainingConfig
from gwdh_training.data_loader import load_training_data, load_training_dataset, split_data
from gwdh_training.normalization import FeatureNormalizer, Normalizer
from gwdh_training.stage1.evaluator import Stage1Evaluator, Stage1Metrics, evaluate_stage1
from gwdh_training.stage1.model import Stage1Model
from gwdh_training.stage1.trainer import Stage1Trainer
from gwdh_training.stage2.evaluator import (
    FilterAblationReport,
    Stage2Evaluator,
    Stage2Metrics,
    compute_stage2_sigma,
    evaluate_stage2,
)
from gwdh_training.stage2.model import Stage2Model
from gwdh_training.stage2.trainer import Stage2Trainer
from .registry import (
    bundle_path_for_model,
    load_model_bundle,
    save_model_bundle,
    stage_model_id,
)


@dataclass
class TrainingReport:
    """Full training report for standalone mode."""

    stage1_metrics: Stage1Metrics
    stage2_metrics: Stage2Metrics
    filter_ablation: FilterAblationReport
    model_selection_map: dict[str, str]
    n_training_samples: int
    n_holdout_samples: int
    geometry_class: str
    passed_gates: bool


class StepwiseSurrogate:
    """Inference wrapper combining Stage 1 + Stage 2 into single prediction.

    Satisfies gwdh_core.types.SurrogateProtocol (predict_batch).
    Returns RAW model outputs -- no postprocessing filters.
    """

    def __init__(
        self,
        stage1: Stage1Model,
        stage2: Stage2Model,
        input_normalizer: Normalizer | FeatureNormalizer,
        y1_normalizer: Normalizer | None = None,
        y2_normalizer: Normalizer | None = None,
        *,
        model_id: str | None = None,
        training_report: TrainingReport | None = None,
    ) -> None:
        self.stage1 = stage1
        self.stage2 = stage2
        self.model_id = model_id
        self.training_report = training_report
        if isinstance(input_normalizer, FeatureNormalizer):
            self.normalizer = input_normalizer
            self.input_normalizer = Normalizer.from_params(
                {"mean": input_normalizer.input_mean, "std": input_normalizer.input_std}
            )
            self.y1_normalizer = Normalizer.from_params(
                {"mean": input_normalizer.stage1_mean, "std": input_normalizer.stage1_std}
            )
            self.y2_normalizer = Normalizer.from_params(
                {"mean": input_normalizer.stage2_mean, "std": input_normalizer.stage2_std}
            )
        else:
            if y1_normalizer is None or y2_normalizer is None:
                raise ValueError("Separate Stage 1/Stage 2 normalizers are required in legacy mode.")
            self.input_normalizer = input_normalizer
            self.y1_normalizer = y1_normalizer
            self.y2_normalizer = y2_normalizer
            self.normalizer = FeatureNormalizer(
                input_mean=self.input_normalizer.get_params()["mean"],
                input_std=self.input_normalizer.get_params()["std"],
                stage1_mean=self.y1_normalizer.get_params()["mean"],
                stage1_std=self.y1_normalizer.get_params()["std"],
                stage2_mean=self.y2_normalizer.get_params()["mean"],
                stage2_std=self.y2_normalizer.get_params()["std"],
            )

    def __iter__(self):
        yield self
        yield self.training_report

    def predict(self, design_vector: np.ndarray) -> np.ndarray:
        """Layer 2 (36,) -> Layer 3 (36, 4) -- single sample, RAW outputs.

        Returns raw model outputs. Postprocessing filters (mass conservation
        clamp, Mott parameter bounds, velocity floor) are the caller's
        responsibility (typically in ZDATAProblem._evaluate()).
        """
        x_norm = self.input_normalizer.transform(design_vector.reshape(1, -1))
        s1_pred_norm = self.stage1.predict(x_norm)               # (1, 16)
        x_aug = np.concatenate([x_norm, s1_pred_norm], axis=1)   # (1, 52)
        y2_pred_norm = self.stage2.predict(x_aug)                # (1, 144)
        y2_pred_raw = self.y2_normalizer.inverse_transform(y2_pred_norm)
        return y2_pred_raw.reshape(N_ZONE_PARAMS, N_ZONES).T     # (36, 4)

    def predict_batch(self, design_matrix: np.ndarray) -> np.ndarray:
        """(N, 36) -> (N, 36, 4) -- vectorized for CMA-ES populations.

        Returns raw model outputs. No postprocessing applied.
        """
        n = design_matrix.shape[0]
        x_norm = self.input_normalizer.transform(design_matrix)
        s1_pred_norm = self.stage1.predict(x_norm)               # (N, 16)
        x_aug = np.concatenate([x_norm, s1_pred_norm], axis=1)   # (N, 52)
        y2_pred_norm = self.stage2.predict(x_aug)                # (N, 144)
        y2_pred_raw = self.y2_normalizer.inverse_transform(y2_pred_norm)
        return y2_pred_raw.reshape(n, N_ZONE_PARAMS, N_ZONES).transpose(0, 2, 1)

    @classmethod
    def load(cls, model_id: str, data_lake) -> StepwiseSurrogate:
        """Load a registered model from the data lake."""
        from gwdh_training.normalization import Normalizer

        if data_lake is None:
            from gwdh_training.registry import SurrogateRegistry
            return SurrogateRegistry.load(model_id, data_lake)

        stage1_record = data_lake.get_surrogate_record(model_id, stage=1)
        stage2_record = data_lake.get_surrogate_record(model_id, stage=2)
        if stage1_record["model_artifact_path"] != stage2_record["model_artifact_path"]:
            raise RuntimeError("Stage 1 and Stage 2 bundle paths do not match for this model_id.")
        bundle = load_model_bundle(stage1_record["model_artifact_path"])
        return cls(
            stage1=bundle["stage1_model"],
            stage2=bundle["stage2_model"],
            input_normalizer=Normalizer.from_params(bundle["input_normalizer_params"]),
            y1_normalizer=Normalizer.from_params(bundle["y1_normalizer_params"]),
            y2_normalizer=Normalizer.from_params(bundle["y2_normalizer_params"]),
            model_id=model_id,
        )


class SurrogateTrainingPipeline:
    """Standalone mode: full train -> validate -> register workflow."""

    def run(
        self,
        geometry_class: GeometryClass,
        data_lake,
        config: StandaloneTrainingConfig | TrainingConfig | None = None,
    ) -> StepwiseSurrogate:
        if isinstance(config, TrainingConfig):
            return self._run_registered(geometry_class, data_lake, config)
        return self._run_standalone(
            geometry_class,
            data_lake,
            config or StandaloneTrainingConfig(),
        )

    def _run_standalone(
        self,
        geometry_class: GeometryClass,
        data_lake,
        config: StandaloneTrainingConfig,
    ) -> StepwiseSurrogate:
        data = load_training_data(data_lake, geometry_class)
        train_data, holdout_data = split_data(data, config)

        input_norm = Normalizer().fit(train_data.X)
        y1_norm = Normalizer().fit(train_data.y1)
        y2_norm = Normalizer().fit(train_data.y2)

        X_train_n = input_norm.transform(train_data.X)
        y1_train_n = y1_norm.transform(train_data.y1)
        y2_train_n = y2_norm.transform(train_data.y2)
        X_hold_n = input_norm.transform(holdout_data.X)

        s1_model = Stage1Trainer().train(
            X_train_n,
            y1_train_n,
            X_hold_n,
            y1_norm.transform(holdout_data.y1),
            config,
        )
        y1_pred_train_n = s1_model.predict(X_train_n)
        y1_pred_hold_n = s1_model.predict(X_hold_n)

        s2_model = Stage2Trainer().train(X_train_n, y1_pred_train_n, y2_train_n, config)

        s1_evaluator = Stage1Evaluator()
        s1_metrics = s1_evaluator.evaluate(s1_model, X_hold_n, holdout_data.y1, y1_norm)
        s2_evaluator = Stage2Evaluator()
        s2_metrics = s2_evaluator.evaluate(
            s2_model,
            X_hold_n,
            y1_pred_hold_n,
            holdout_data.y2,
            y2_norm,
        )
        ablation = s2_evaluator.ablation_report(
            s2_model,
            X_hold_n,
            y1_pred_hold_n,
            holdout_data.y2,
            y2_norm,
        )
        passed = (
            s1_metrics.velocity_re <= config.gate_stage1_velocity_re
            and s1_metrics.angle_re <= config.gate_stage1_angle_re
            and s2_metrics.velocity_re <= config.gate_stage2_velocity_re
            and s2_metrics.n0_re <= config.gate_stage2_n0_re
            and s2_metrics.lambda_re <= config.gate_stage2_lambda_re
            and s2_metrics.mu_re <= config.gate_stage2_mu_re
            and ablation.decision != "unreliable"
        )
        report = TrainingReport(
            stage1_metrics=s1_metrics,
            stage2_metrics=s2_metrics,
            filter_ablation=ablation,
            model_selection_map=s2_model.model_types,
            n_training_samples=train_data.n_samples,
            n_holdout_samples=holdout_data.n_samples,
            geometry_class=geometry_class.value,
            passed_gates=passed,
        )
        return StepwiseSurrogate(
            stage1=s1_model,
            stage2=s2_model,
            input_normalizer=input_norm,
            y1_normalizer=y1_norm,
            y2_normalizer=y2_norm,
            training_report=report,
        )

    def _run_registered(
        self,
        geometry_class: GeometryClass,
        data_lake,
        config: TrainingConfig,
    ) -> StepwiseSurrogate:
        dataset = load_training_dataset(
            data_lake=data_lake,
            geometry_class=geometry_class,
            validation_split=config.validation_split,
            random_seed=config.random_seed,
        )

        input_norm = Normalizer().fit(dataset.X_stage1_train)
        y1_norm = Normalizer().fit(dataset.y_stage1_train)
        y2_norm = Normalizer().fit(dataset.y_stage2_train)

        X_stage1_train_n = input_norm.transform(dataset.X_stage1_train)
        X_stage1_hold_n = input_norm.transform(dataset.X_stage1_holdout)
        y_stage1_train_n = y1_norm.transform(dataset.y_stage1_train)
        y_stage2_train_n = y2_norm.transform(dataset.y_stage2_train)

        stage1_model = Stage1Trainer().train(X_stage1_train_n, y_stage1_train_n, config)
        y1_pred_train_n = stage1_model.predict(X_stage1_train_n)
        y1_pred_hold_n = stage1_model.predict(X_stage1_hold_n)

        X_stage2_train_n = np.concatenate([X_stage1_train_n, y1_pred_train_n], axis=1)
        X_stage2_hold_n = np.concatenate([X_stage1_hold_n, y1_pred_hold_n], axis=1)
        stage2_model = Stage2Trainer().train(X_stage2_train_n, y_stage2_train_n, config)

        stage1_holdout_pred = y1_norm.inverse_transform(y1_pred_hold_n)
        stage2_holdout_pred = y2_norm.inverse_transform(stage2_model.predict(X_stage2_hold_n))

        stage1_metrics_pct = evaluate_stage1(dataset.y_stage1_holdout, stage1_holdout_pred)
        stage2_metrics_pct = evaluate_stage2(
            dataset.y_stage2_holdout,
            stage2_holdout_pred,
            sigma_by_param=compute_stage2_sigma(dataset.y_stage2_train),
        )

        model_id = f"{geometry_class.value.lower()}-{uuid.uuid4().hex[:12]}"
        bundle_path = bundle_path_for_model(data_lake, geometry_class, model_id)
        save_model_bundle(
            bundle_path,
            stage1_model=stage1_model,
            stage2_model=stage2_model,
            input_normalizer=input_norm,
            y1_normalizer=y1_norm,
            y2_normalizer=y2_norm,
            metadata={
                "geometry_class": geometry_class.value,
                "stage1_metrics": stage1_metrics_pct,
                "stage2_metrics": stage2_metrics_pct,
            },
        )

        sample_count = int(dataset.X_stage1_train.shape[0])
        data_lake.register_surrogate(
            model_id=stage_model_id(model_id, 1),
            geometry_class=geometry_class,
            stage=1,
            training_sample_count=sample_count,
            holdout_metrics=stage1_metrics_pct,
            model_artifact_path=bundle_path,
        )
        data_lake.register_surrogate(
            model_id=stage_model_id(model_id, 2),
            geometry_class=geometry_class,
            stage=2,
            training_sample_count=sample_count,
            holdout_metrics=stage2_metrics_pct,
            model_artifact_path=bundle_path,
        )

        dummy_stage1_metrics = Stage1Metrics(
            velocity_rmse=0.0,
            velocity_re=stage1_metrics_pct["velocity_re_pct"] / 100.0,
            angle_rmse=0.0,
            angle_re=stage1_metrics_pct["angle_re_pct"] / 100.0,
            per_section_re=np.zeros(16),
        )
        dummy_stage2_metrics = Stage2Metrics(
            velocity_re=stage2_metrics_pct["velocity_re_pct"] / 100.0,
            n0_re=stage2_metrics_pct["N0_re_pct"] / 100.0,
            lambda_re=stage2_metrics_pct["lambda_re_pct"] / 100.0,
            mu_re=stage2_metrics_pct["mu_re_pct"] / 100.0,
        )
        report = TrainingReport(
            stage1_metrics=dummy_stage1_metrics,
            stage2_metrics=dummy_stage2_metrics,
            filter_ablation=FilterAblationReport(),
            model_selection_map=stage2_model.model_types,
            n_training_samples=sample_count,
            n_holdout_samples=int(dataset.X_stage1_holdout.shape[0]),
            geometry_class=geometry_class.value,
            passed_gates=True,
        )
        return StepwiseSurrogate(
            stage1=stage1_model,
            stage2=stage2_model,
            input_normalizer=input_norm,
            y1_normalizer=y1_norm,
            y2_normalizer=y2_norm,
            model_id=model_id,
            training_report=report,
        )
