"""HPC dispatch: submit, monitor, and collect CTH evaluations.

Orchestrates slurm_client, cth_adapter, and observer_status.yaml polling
to manage the full lifecycle of hydrocode evaluations. One fresh Slurm
job per evaluation for fault isolation.
"""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Optional

import numpy as np
import yaml  # type: ignore[import-untyped]

from gwdh_core.config import HPCConfig, ObservationRunnerConfig
from gwdh_core.types import (
    DISCRETIZED_DIM,
    DesignVector,
    EvalResult,
    EvalStatus,
    FailType,
    GeometryClass,
    JobHandle,
)

from .cth_adapter import CTHAdapter
from .slurm_client import SlurmClient
from .zdata_extractor import ZDATAExtractor

logger = logging.getLogger(__name__)


class HPCDispatch:
    """Thin orchestration layer over the active GWDH HPC stack.

    Each evaluation gets its own working directory and Slurm job.
    The host node polls observer_status.yaml to track progress.
    """

    def __init__(
        self,
        hpc_config: HPCConfig,
        obs_config: ObservationRunnerConfig,
        apre_template_path: str | None,
        geometry_class: GeometryClass,
        base_dir: str,
    ):
        self.hpc_config = hpc_config
        self.obs_config = obs_config
        self.base_dir = base_dir
        self.slurm = SlurmClient(hpc_config)
        self.cth_adapter = CTHAdapter(
            hpc_config,
            apre_template_path or hpc_config.apre_template_path,
            geometry_class,
        )
        self.zdata_extractor = ZDATAExtractor()

    def submit_cth(
        self,
        design: DesignVector,
        primitive_params: dict,
        campaign_id: str,
    ) -> JobHandle:
        """Submit a single CTH evaluation as a Slurm job.

        Steps:
        1. Create per-eval working directory
        2. Prepare APRE via CTHAdapter (includes tracer placement)
        3. Write worker config YAML
        4. Prepare Slurm submission script
        5. sbatch submit
        """
        eval_id = str(uuid.uuid4())[:12]
        working_dir = os.path.join(
            self.base_dir, campaign_id, f"eval_{eval_id}"
        )
        os.makedirs(working_dir, exist_ok=True)

        # Prepare APRE with deformed geometry and tracers
        self.cth_adapter.prepare_evaluation_dir(
            design_vector=design,
            primitive_params=primitive_params,
            working_dir=working_dir,
        )

        # Write worker config YAML for the Slurm job
        config_path = os.path.join(working_dir, "worker_config.yaml")
        worker_config = {
            "eval_id": eval_id,
            "campaign_id": campaign_id,
            "hpc": {
                "ntasks": self.hpc_config.ntasks,
                "walltime": self.hpc_config.walltime,
                "kill_grace_period_s": self.hpc_config.kill_grace_period_s,
                "launch_command": self.hpc_config.launch_command,
            },
            "observation_runner": {
                "poll_interval_s": self.obs_config.poll_interval_s,
                "velocity_window_size": self.obs_config.velocity_window_size,
                "velocity_slope_threshold": self.obs_config.velocity_slope_threshold,
                "steady_state_patience": self.obs_config.steady_state_patience,
                "tracer_majority_fraction": self.obs_config.tracer_majority_fraction,
                "max_observation_time_s": self.obs_config.max_observation_time_s,
                "process_verify_retries": self.obs_config.process_verify_retries,
                "process_verify_interval_s": self.obs_config.process_verify_interval_s,
            },
            "postprocess": {
                # Stub hook for simulation-specific postprocessing
                "command": "",
                "timeout_s": 600,
            },
        }
        with open(config_path, "w") as f:
            yaml.safe_dump(worker_config, f)

        # Save design vector for provenance
        np.save(os.path.join(working_dir, "design_vector.npy"), design.data)

        # Prepare and submit Slurm job
        job_name = f"gdwh_{eval_id}"
        script_path = self.slurm.prepare_submission_script(
            working_dir=working_dir,
            job_name=job_name,
            config_path=config_path,
        )
        slurm_job_id = self.slurm.submit(script_path, working_dir)

        submit_time = datetime.now(timezone.utc).isoformat()

        logger.info(
            "[HPC] Submitted eval %s as Slurm job %s in %s",
            eval_id, slurm_job_id, working_dir,
        )

        return JobHandle(
            job_id=slurm_job_id,
            eval_id=eval_id,
            working_dir=working_dir,
            submit_time=submit_time,
        )

    def wait_and_extract(
        self, job: JobHandle, timeout_s: Optional[int] = None
    ) -> EvalResult:
        """Block until job completes, extract ZDATA, classify outcome.

        Polls observer_status.yaml for real-time state, falls back to
        Slurm status via scontrol.
        """
        timeout = timeout_s or self.hpc_config.execution_timeout_s
        start_time = time.monotonic()
        poll_interval = self.hpc_config.observer_poll_interval_s

        while time.monotonic() - start_time < timeout:
            elapsed = time.monotonic() - start_time
            # Check observer_status.yaml first (more informative)
            obs_status = self._read_observer_status(job.working_dir)
            if obs_status:
                state = obs_status.get("state", "")
                if state == "completed":
                    return self._collect_result(job)
                if state == "failed":
                    return self._collect_failed_result(job, obs_status)

            # Fall back to Slurm status
            slurm_status = self.slurm.get_job_status(job.job_id)
            if (
                slurm_status == "PENDING"
                and elapsed > self.hpc_config.queue_timeout_s
            ):
                logger.warning(
                    "Job %s exceeded queue timeout after %ds",
                    job.job_id,
                    self.hpc_config.queue_timeout_s,
                )
                self.slurm.cancel(job.job_id)
                return EvalResult(
                    eval_id=job.eval_id,
                    design_vector=self._load_design_vector(job.working_dir)
                    or DesignVector(data=np.zeros(36)),
                    status=EvalStatus.FAILED,
                    fail_type=FailType.SLURM_QUEUE_TIMEOUT,
                    runtime_sec=elapsed,
                    slurm_job_id=job.job_id,
                    timestamp=datetime.now(timezone.utc).isoformat(),
                )
            if slurm_status == "COMPLETED":
                return self._collect_result(job)
            if slurm_status in (
                "FAILED",
                "CANCELLED",
                "TIMEOUT",
                "NODE_FAIL",
                "PREEMPTED",
            ):
                design_vector = self._load_design_vector(job.working_dir)
                return EvalResult(
                    eval_id=job.eval_id,
                    design_vector=design_vector,
                    status=EvalStatus.FAILED,
                    fail_type=self._slurm_status_to_fail_type(slurm_status),
                    runtime_sec=time.monotonic() - start_time,
                    slurm_job_id=job.job_id,
                    timestamp=datetime.now(timezone.utc).isoformat(),
                )

            time.sleep(poll_interval)

        # Timeout — cancel the job
        logger.warning("Job %s timed out after %ds", job.job_id, timeout)
        self.slurm.cancel(job.job_id)
        design_vector = self._load_design_vector(job.working_dir)
        return EvalResult(
            eval_id=job.eval_id,
            design_vector=design_vector,
            status=EvalStatus.FAILED,
            fail_type=FailType.CTH_TIMEOUT,
            runtime_sec=time.monotonic() - start_time,
            slurm_job_id=job.job_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def submit_batch(
        self,
        designs: list[tuple[DesignVector, dict]],
        campaign_id: str,
    ) -> list[JobHandle]:
        """Submit multiple CTH jobs (one per design)."""
        handles = []
        for design, primitives in designs:
            handle = self.submit_cth(design, primitives, campaign_id)
            handles.append(handle)
        return handles

    def _collect_result(self, job: JobHandle) -> EvalResult:
        """Read result.json and extract ZDATA from completed job."""
        result_path = os.path.join(job.working_dir, "result.json")

        if os.path.exists(result_path):
            with open(result_path) as f:
                result_dict = json.load(f)
        else:
            result_dict = {"status": "completed"}

        design = self._load_design_vector(job.working_dir)
        safe_design = design if design is not None else DesignVector(data=np.zeros(36))

        # Try to extract ZDATA
        stage1_output = None
        zdata = None
        mott_fit_r2 = None
        try:
            if design is not None:
                stage1_output, zdata, mott_fit_r2 = (
                    self.zdata_extractor.extract_stagewise_targets(
                        job.working_dir,
                        design,
                    )
                )
            else:
                zdata = self.zdata_extractor.extract_from_cth_output(job.working_dir)
        except Exception as e:
            logger.warning("ZDATA extraction failed for %s: %s", job.eval_id, e)
            try:
                zdata = self.zdata_extractor.extract_from_cth_output(job.working_dir)
                stage1_output = None
                mott_fit_r2 = None
            except Exception:
                pass

        return EvalResult(
            eval_id=job.eval_id,
            design_vector=safe_design,
            status=EvalStatus.COMPLETED if zdata else EvalStatus.FAILED,
            fail_type=FailType.POSTPROCESS_PARSE_ERROR if not zdata else None,
            stage1_output=stage1_output,
            zdata=zdata,
            mott_fit_r2=mott_fit_r2,
            runtime_sec=result_dict.get("runtime_sec", 0.0),
            slurm_job_id=job.job_id,
            timestamp=result_dict.get("timestamp"),
        )

    def _collect_failed_result(
        self, job: JobHandle, obs_status: dict
    ) -> EvalResult:
        """Build EvalResult from a failed observer status."""
        fail_type_str = obs_status.get("fail_type", "unknown")
        try:
            fail_type = FailType(fail_type_str)
        except ValueError:
            fail_type = FailType.UNKNOWN

        return EvalResult(
            eval_id=job.eval_id,
            design_vector=self._load_design_vector(job.working_dir)
            or DesignVector(data=np.zeros(36)),
            status=EvalStatus.FAILED,
            fail_type=fail_type,
            runtime_sec=obs_status.get("elapsed_sec", 0.0),
            slurm_job_id=job.job_id,
            timestamp=obs_status.get("timestamp"),
        )

    def _read_observer_status(self, working_dir: str) -> Optional[dict]:
        """Read observer_status.yaml if it exists."""
        path = os.path.join(working_dir, "observer_status.yaml")
        if not os.path.exists(path):
            return None
        try:
            with open(path) as f:
                return yaml.safe_load(f)
        except Exception:
            return None

    def _load_design_vector(self, working_dir: str) -> DesignVector:
        """Load the saved design vector from the eval directory.

        EvalResult requires a DesignVector. If the file is missing, return a sentinel vector.
        """
        path = os.path.join(working_dir, "design_vector.npy")
        if os.path.exists(path):
            return DesignVector(data=np.load(path))
        logger.warning("[HPC] design_vector.npy missing in %s", working_dir)
        return DesignVector(data=np.zeros(DISCRETIZED_DIM))

    @staticmethod
    def _slurm_status_to_fail_type(status: str) -> FailType:
        return {
            "FAILED": FailType.CTH_CRASH,
            "CANCELLED": FailType.SLURM_PREEMPTED,
            "TIMEOUT": FailType.CTH_TIMEOUT,
            "NODE_FAIL": FailType.SLURM_NODE_FAIL,
            "PREEMPTED": FailType.SLURM_PREEMPTED,
        }.get(status, FailType.UNKNOWN)
