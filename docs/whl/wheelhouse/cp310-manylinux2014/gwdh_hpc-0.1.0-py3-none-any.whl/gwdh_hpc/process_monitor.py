"""Safe process management for HPC compute nodes.

CRITICAL: Must not bring down the compute node. Only kills the specific
CTH process tree (parent + MPI children) using process groups.
"""
from __future__ import annotations

import logging
import os
import signal
import subprocess
import time

logger = logging.getLogger(__name__)


class ProcessMonitor:
    """Monitor and manage CTH processes on HPC nodes."""

    def is_alive(self, pid: int) -> bool:
        """Check if process with given PID is still running."""
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            # Process exists but we don't have permission (shouldn't happen
            # since we own the CTH process, but treat as alive to be safe)
            return True

    def safe_kill(self, pid: int, grace_period_s: int = 30) -> bool:
        """Send SIGTERM, wait grace_period, check if dead.

        Returns True if process is confirmed dead.
        """
        if not self.is_alive(pid):
            logger.info("Process %d already dead before SIGTERM", pid)
            return True

        try:
            pgid = os.getpgid(pid)
            logger.info(
                "Sending SIGTERM to process group %d (pid=%d)", pgid, pid
            )
            os.killpg(pgid, signal.SIGTERM)
        except ProcessLookupError:
            return True
        except PermissionError:
            logger.warning("Permission denied sending SIGTERM to pid=%d", pid)
            return False

        deadline = time.monotonic() + grace_period_s
        while time.monotonic() < deadline:
            if self._try_reap(pid) or not self.is_alive(pid):
                logger.info("Process %d terminated gracefully after SIGTERM", pid)
                return True
            time.sleep(1.0)

        logger.warning(
            "Process %d still alive after %ds grace period", pid, grace_period_s
        )
        return self._try_reap(pid) or (not self.is_alive(pid))

    def force_kill(self, pid: int) -> bool:
        """Send SIGKILL to process and all children via process group.

        Uses os.killpg to catch MPI child processes.
        """
        if not self.is_alive(pid):
            return True

        try:
            pgid = os.getpgid(pid)
            logger.warning(
                "Sending SIGKILL to process group %d (pid=%d)", pgid, pid
            )
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            return True
        except PermissionError:
            logger.error("Permission denied sending SIGKILL to pid=%d", pid)
            return False

        time.sleep(2.0)
        return self._try_reap(pid) or (not self.is_alive(pid))

    def verify_dead(
        self, pid: int, retries: int = 5, interval_s: float = 2.0
    ) -> bool:
        """Poll to confirm process is truly dead.

        Uses both os.kill probe and ps as cross-check.
        """
        for attempt in range(retries):
            if self._try_reap(pid):
                logger.info(
                    "Process %d confirmed dead (attempt %d/%d)",
                    pid, attempt + 1, retries,
                )
                return True
            if not self.is_alive(pid):
                logger.info(
                    "Process %d confirmed dead (attempt %d/%d)",
                    pid, attempt + 1, retries,
                )
                return True
            time.sleep(interval_s)

        logger.error(
            "Process %d still alive after %d verification attempts", pid, retries
        )
        return False

    def get_children(self, pid: int) -> list[int]:
        """Get all child PIDs (MPI workers, etc.)."""
        try:
            result = subprocess.run(
                ["pgrep", "-P", str(pid)],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                return [int(p) for p in result.stdout.strip().split("\n") if p]
            return []
        except FileNotFoundError:
            logger.warning("pgrep not found, cannot enumerate children of %d", pid)
            return []

    @staticmethod
    def _try_reap(pid: int) -> bool:
        """Attempt to reap pid if it's our child and has exited.

        This is the only reliable way to clear zombies without shelling out
        to `ps` (which may be restricted in some execution environments).
        """
        try:
            waited_pid, _ = os.waitpid(pid, os.WNOHANG)
            return waited_pid == pid
        except ChildProcessError:
            # Not our child process (or already reaped)
            return False
