"""Typed Slurm client for native GDWH dispatch/runtime flow."""
from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
from pathlib import Path

from gwdh_core.config import HPCConfig

logger = logging.getLogger(__name__)
DEFAULT_SLURM_TEMPLATE = (
    Path(__file__).resolve().parent / "templates" / "run_eval.sh.slurm"
)


class SlurmClient:
    """Submit, monitor, and manage Slurm jobs for CTH evaluations."""

    def __init__(self, config: HPCConfig):
        self.config = config

    @staticmethod
    def _render_template(
        *,
        template_path: str,
        target_script: str,
        replacements: dict[str, str],
        strip_empty_account: bool,
    ) -> None:
        """Copy a Slurm template and apply placeholder substitutions."""
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Slurm template not found: {template_path}")

        shutil.copy(template_path, target_script)

        content = Path(target_script).read_text()
        for placeholder, val in replacements.items():
            content = content.replace(placeholder, str(val))

        # Remove empty account lines to avoid `sbatch` validation errors.
        if strip_empty_account:
            content = re.sub(
                r"^#SBATCH --account=\s*$\n", "", content, flags=re.MULTILINE
            )
            content = re.sub(
                r"^#SBATCH -A\s*$\n", "", content, flags=re.MULTILINE
            )

        Path(target_script).write_text(content)
        os.chmod(target_script, 0o755)

    def prepare_submission_script(
        self,
        working_dir: str,
        job_name: str,
        config_path: str,
    ) -> str:
        """Prepare a Slurm submission script that launches the worker lifecycle.

        Copies the template, patches placeholders, and injects the
        python -m gwdh_hpc.worker_lifecycle command.

        Returns path to the prepared script.
        """
        template_path = self._resolve_template_path()
        script_name = "run_eval.sh.slurm"
        target_script = os.path.join(working_dir, script_name)

        replacements = {
            "@@JOB_NAME@@": job_name,
            "@@TIME@@": self.config.walltime,
            "@@NTASKS@@": str(self.config.ntasks),
            "@@PARTITION@@": self.config.partition,
            "@@ACCOUNT@@": self.config.account,
            "@@WORKING_DIR@@": working_dir,
            "@@CONFIG_PATH@@": config_path,
        }

        self._render_template(
            template_path=template_path,
            target_script=target_script,
            replacements=replacements,
            strip_empty_account=not bool(self.config.account),
        )

        logger.info("Prepared Slurm script at: %s", target_script)
        return target_script

    def prepare_command_script(
        self,
        *,
        working_dir: str,
        job_name: str,
        command: str,
        template_path: str,
        ntasks: int,
        walltime: str,
        partition: str,
        account: str,
    ) -> str:
        """Prepare a Slurm script that executes an arbitrary shell command.

        Intended for the outer optimizer job, which runs on Slurm but
        submits per-evaluation jobs itself.

        Template placeholders:
            @@JOB_NAME@@, @@TIME@@, @@NTASKS@@, @@PARTITION@@, @@ACCOUNT@@,
            @@WORKING_DIR@@, @@COMMAND@@
        """
        script_name = "run_command.sh.slurm"
        target_script = os.path.join(working_dir, script_name)

        replacements = {
            "@@JOB_NAME@@": job_name,
            "@@TIME@@": walltime,
            "@@NTASKS@@": str(ntasks),
            "@@PARTITION@@": partition,
            "@@ACCOUNT@@": account,
            "@@WORKING_DIR@@": working_dir,
            "@@COMMAND@@": command,
        }

        self._render_template(
            template_path=template_path,
            target_script=target_script,
            replacements=replacements,
            strip_empty_account=not bool(account),
        )

        logger.info("Prepared command Slurm script at: %s", target_script)
        return target_script

    def submit(self, script_path: str, working_dir: str) -> str:
        """Submit a Slurm job via sbatch.

        Returns the Slurm job ID string.
        Raises RuntimeError on submission failure.
        """
        logger.info("Submitting Slurm job: %s", script_path)
        process = subprocess.run(
            ["sbatch", script_path],
            capture_output=True,
            text=True,
            check=False,
            cwd=working_dir,
        )

        if process.returncode != 0:
            raise RuntimeError(
                f"sbatch failed (rc={process.returncode}): {process.stderr}"
            )

        match = re.search(r"Submitted batch job (\d+)", process.stdout)
        if not match:
            raise RuntimeError(
                f"Could not parse job ID from sbatch output: {process.stdout}"
            )

        job_id = match.group(1)
        logger.info("Job submitted successfully. Job ID: %s", job_id)
        return job_id

    def get_job_status(self, job_id: str) -> str:
        """Get current Slurm job status via scontrol.

        Returns one of: PENDING, RUNNING, COMPLETED, FAILED, CANCELLED,
        TIMEOUT, NODE_FAIL, PREEMPTED, UNKNOWN.
        """
        try:
            result = subprocess.run(
                ["scontrol", "show", "job", job_id],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode != 0:
                return "UNKNOWN"

            match = re.search(r"JobState=([A-Z_]+)", result.stdout)
            if not match:
                return "UNKNOWN"

            status = match.group(1)
            terminal = {
                "COMPLETED", "FAILED", "CANCELLED", "TIMEOUT",
                "NODE_FAIL", "PREEMPTED",
            }
            if status in terminal:
                return status
            if status == "PENDING":
                return "PENDING"

            return "RUNNING"  # all non-terminal states
        except Exception as e:
            logger.warning("Error checking job %s status: %s", job_id, e)
            return "UNKNOWN"

    def cancel(self, job_id: str) -> bool:
        """Cancel a Slurm job. Returns True if scancel succeeded."""
        try:
            result = subprocess.run(
                ["scancel", job_id],
                capture_output=True,
                text=True,
                check=False,
            )
            return result.returncode == 0
        except Exception as e:
            logger.error("Error cancelling job %s: %s", job_id, e)
            return False

    def _resolve_template_path(self) -> str:
        configured = (self.config.slurm_template_path or "").strip()
        if configured:
            if not os.path.exists(configured):
                raise FileNotFoundError(f"Slurm template not found: {configured}")
            return configured
        if not DEFAULT_SLURM_TEMPLATE.exists():
            raise FileNotFoundError(
                f"Bundled Slurm template not found: {DEFAULT_SLURM_TEMPLATE}"
            )
        return str(DEFAULT_SLURM_TEMPLATE)
