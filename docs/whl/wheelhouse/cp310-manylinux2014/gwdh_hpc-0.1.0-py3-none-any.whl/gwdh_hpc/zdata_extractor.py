"""ZDATA file parser and CTH output extractor.

Thin wrapper over gwdh_core.zdata_io and gwdh_core.mott for
CTH-output-specific file discovery. All parsing and Mott fitting
logic is delegated to gwdh-core.

Reference: docs/supplementary/Reading_Writing_and_Analyzing_ZDATA_Files_Using_C++.md
"""
from __future__ import annotations

import csv
import logging
import os
import re
from typing import Optional

import numpy as np

from gwdh_core.mott import fit_mott
from gwdh_core.types import (
    DesignVector,
    N_SECTIONS,
    RawZDATA,
    SectionOutput,
    ZDATAStats,
    ZonalZDATA,
)
from gwdh_core.zdata_io import (
    analyze_zdata as _analyze_zdata,
    parse_zdata_string as _parse_zdata_string,
    raw_to_zonal as _raw_to_zonal,
    read_zdata as _read_zdata,
)

logger = logging.getLogger(__name__)


class ZDATAExtractor:
    """Parse ZDATA files and extract ZonalZDATA from CTH output.

    Delegates all parsing/fitting to gwdh_core.zdata_io and gwdh_core.mott.
    This class adds CTH-output-specific file discovery logic.
    """

    def parse_zdata_file(self, path: str) -> RawZDATA:
        """Parse a standard ZDATA file per ARL-TN-541 spec."""
        return _read_zdata(path)

    def parse_zdata_string(self, text: str) -> RawZDATA:
        """Parse ZDATA from a string (mirrors C++ StringToZdata)."""
        return _parse_zdata_string(text)

    def analyze_zdata(self, raw: RawZDATA) -> ZDATAStats:
        """Compute summary statistics (mirrors C++ AnalyzeZdata)."""
        return _analyze_zdata(raw)

    def raw_to_zonal(self, raw: RawZDATA) -> tuple[ZonalZDATA, np.ndarray]:
        """Convert RawZDATA to the internal (36, 4) representation.

        Returns:
            (ZonalZDATA, mott_fit_r2) where mott_fit_r2 is (n_zones,)
            per-zone R^2 of the Mott fit.
        """
        return _raw_to_zonal(raw)

    def extract_from_cth_output(self, cth_output_dir: str) -> ZonalZDATA:
        """Extract ZonalZDATA from raw CTH simulation output.

        Looks for ZDATA files produced by CTH postprocessing.
        """
        stage1_dummy = DesignVector(data=np.zeros(36, dtype=float))
        _, zonal, _ = self.extract_stagewise_targets(cth_output_dir, stage1_dummy)
        return zonal

    def _find_zdata_file(self, directory: str) -> Optional[str]:
        """Locate a ZDATA file in the output directory."""
        for fname in os.listdir(directory):
            lower = fname.lower()
            if "zdata" in lower and not lower.endswith((".py", ".pyc")):
                return os.path.join(directory, fname)
        return None

    def _find_hscth_file(self, directory: str) -> Optional[str]:
        """Locate an hscth history CSV in the output directory."""
        for fname in os.listdir(directory):
            lower = fname.lower()
            if lower.startswith("hscth"):
                return os.path.join(directory, fname)
        return None

    def extract_stagewise_targets(
        self,
        cth_output_dir: str,
        design_vector: DesignVector,
    ) -> tuple[Optional[SectionOutput], ZonalZDATA, np.ndarray]:
        """Extract Stage 1 section outputs plus Stage 2 zonal targets."""
        zdata_path = self._find_zdata_file(cth_output_dir)
        if zdata_path is None:
            raise FileNotFoundError(f"No ZDATA file found in {cth_output_dir}")

        raw = self.parse_zdata_file(zdata_path)
        zonal, mott_fit_r2 = self.raw_to_zonal(raw)
        stage1_output = self._extract_stage1_output(cth_output_dir, design_vector)
        return stage1_output, zonal, mott_fit_r2

    def _extract_stage1_output(
        self,
        cth_output_dir: str,
        design_vector: DesignVector,
    ) -> Optional[SectionOutput]:
        hscth_path = self._find_hscth_file(cth_output_dir)
        if hscth_path is None:
            return None

        with open(hscth_path, newline="") as handle:
            reader = csv.reader(handle)
            try:
                next(reader)
                headers = [h.strip() for h in next(reader)]
            except StopIteration:
                return None
            rows = list(reader)

        if not rows:
            return None

        velocity_cols = self._resolve_tracer_columns(headers, {"velocity", "speed", "v"})
        radial_velocity_cols = self._resolve_tracer_columns(headers, {"radialvelocity", "velocityr", "vr"})
        axial_velocity_cols = self._resolve_tracer_columns(headers, {"axialvelocity", "velocityz", "vz"})
        radial_position_cols = self._resolve_tracer_columns(headers, {"positionx", "posx", "x", "radius", "r"})
        axial_position_cols = self._resolve_tracer_columns(headers, {"positionz", "posz", "z", "axialposition"})

        last_velocity = self._collect_last_numeric_values(rows, velocity_cols)
        last_vr = self._collect_last_numeric_values(rows, radial_velocity_cols)
        last_vz = self._collect_last_numeric_values(rows, axial_velocity_cols)
        displacement_by_tracer = self._collect_recent_displacements(
            rows,
            radial_position_cols,
            axial_position_cols,
        )

        tracer_ids = (
            set(last_velocity.keys())
            | (set(last_vr.keys()) & set(last_vz.keys()))
            | set(displacement_by_tracer.keys())
        )
        ordered_tracer_ids = self._ordered_tracer_ids(tracer_ids)
        if not ordered_tracer_ids:
            return None

        n_tracers = len(ordered_tracer_ids)
        z_start = float(design_vector.axial_coords[0])
        z_end = float(design_vector.axial_coords[-1])
        tracer_z = np.linspace(z_start, z_end, n_tracers)
        span = max(z_end - z_start, 1e-12)
        section_ids = np.clip(
            np.floor(((tracer_z - z_start) / span) * N_SECTIONS).astype(int),
            0,
            N_SECTIONS - 1,
        )

        section_velocities = [[] for _ in range(N_SECTIONS)]
        section_angles = [[] for _ in range(N_SECTIONS)]

        for tracer_idx, tracer_id in enumerate(ordered_tracer_ids):
            v_mag = last_velocity.get(tracer_id)
            vr = last_vr.get(tracer_id)
            vz = last_vz.get(tracer_id)
            if v_mag is None and vr is not None and vz is not None:
                v_mag = float(np.hypot(vr, vz))
            if v_mag is None or not np.isfinite(v_mag):
                continue

            theta = self._angle_from_components(vr, vz)
            if theta is None:
                dx_dz = displacement_by_tracer.get(tracer_id)
                if dx_dz is not None:
                    theta = self._angle_from_components(dx_dz[0], dx_dz[1])
            if theta is None:
                continue

            section_id = int(section_ids[tracer_idx])
            section_velocities[section_id].append(float(v_mag))
            section_angles[section_id].append(float(theta))

        if not all(section_velocities) or not all(section_angles):
            logger.warning(
                "Incomplete Stage 1 tracer coverage in %s; omitting stage1_output",
                hscth_path,
            )
            return None

        velocity_sections = np.array(
            [float(np.mean(values)) for values in section_velocities],
            dtype=float,
        )
        angle_sections = np.array(
            [float(np.mean(values)) for values in section_angles],
            dtype=float,
        )
        return SectionOutput(data=np.concatenate([velocity_sections, angle_sections], axis=0))

    def _resolve_tracer_columns(self, headers: list[str], base_names: set[str]) -> dict[int, int]:
        mapping: dict[int, int] = {}
        normalized_bases = sorted(
            {self._normalize_header(name) for name in base_names},
            key=len,
            reverse=True,
        )
        for idx, header in enumerate(headers):
            tracer_id = self._match_tracer_header(header, normalized_bases)
            if tracer_id is not None:
                mapping[tracer_id] = idx
        return mapping

    def _ordered_tracer_ids(self, tracer_ids: set[int]) -> Optional[list[int]]:
        if not tracer_ids:
            return None
        ordered = sorted(tracer_ids)
        if ordered[0] not in {0, 1}:
            logger.warning("Unsupported tracer numbering: starts at %s", ordered[0])
            return None
        if len(ordered) > 1 and any(current - prev != 1 for prev, current in zip(ordered, ordered[1:])):
            logger.warning("Non-contiguous tracer numbering detected: %s", ordered)
            return None
        return ordered

    def _collect_last_numeric_values(
        self,
        rows: list[list[str]],
        tracer_columns: dict[int, int],
    ) -> dict[int, float]:
        values: dict[int, float] = {}
        for tracer_id, col_idx in tracer_columns.items():
            for row in reversed(rows):
                if col_idx >= len(row):
                    continue
                cell = row[col_idx].strip()
                if not cell:
                    continue
                try:
                    val = float(cell)
                except ValueError:
                    continue
                if np.isfinite(val):
                    values[tracer_id] = val
                    break
        return values

    def _collect_recent_displacements(
        self,
        rows: list[list[str]],
        radial_position_cols: dict[int, int],
        axial_position_cols: dict[int, int],
    ) -> dict[int, tuple[float, float]]:
        displacement: dict[int, tuple[float, float]] = {}
        tracer_ids = set(radial_position_cols.keys()) & set(axial_position_cols.keys())
        for tracer_id in tracer_ids:
            r_vals = self._collect_numeric_series(rows, radial_position_cols[tracer_id])
            z_vals = self._collect_numeric_series(rows, axial_position_cols[tracer_id])
            n = min(len(r_vals), len(z_vals))
            if n < 2:
                continue
            displacement[tracer_id] = (
                float(r_vals[-1] - r_vals[-2]),
                float(z_vals[-1] - z_vals[-2]),
            )
        return displacement

    def _collect_numeric_series(self, rows: list[list[str]], col_idx: int) -> list[float]:
        values: list[float] = []
        for row in rows:
            if col_idx >= len(row):
                continue
            cell = row[col_idx].strip()
            if not cell:
                continue
            try:
                value = float(cell)
            except ValueError:
                continue
            if np.isfinite(value):
                values.append(value)
        return values

    def _angle_from_components(
        self,
        radial_component: Optional[float],
        axial_component: Optional[float],
    ) -> Optional[float]:
        if radial_component is None or axial_component is None:
            return None
        if not np.isfinite(radial_component) or not np.isfinite(axial_component):
            return None
        radial_abs = abs(float(radial_component))
        axial = float(axial_component)
        if axial > 0:
            return float(np.degrees(np.arctan2(radial_abs, axial)))
        if axial < 0:
            return float(180.0 - np.degrees(np.arctan2(radial_abs, abs(axial))))
        return 90.0

    def _match_tracer_header(self, header: str, normalized_bases: list[str]) -> Optional[int]:
        normalized_header = self._normalize_header(header)
        for base in normalized_bases:
            match = re.fullmatch(rf"{re.escape(base)}(?:0*(\d+))?", normalized_header)
            if match:
                return int(match.group(1)) if match.group(1) is not None else 0
        return None

    def _normalize_header(self, header: str) -> str:
        without_units = re.sub(r"\([^)]*\)|\[[^\]]*\]", "", header)
        return re.sub(r"[^a-z0-9]", "", without_units.lower())

    @staticmethod
    def _fit_mott(
        masses: np.ndarray, counts: np.ndarray
    ) -> tuple[float, float, float, float]:
        """Fit Mott distribution parameters. Delegates to gwdh_core.mott."""
        return fit_mott(masses, counts)
