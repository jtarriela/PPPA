"""CTH adapter using typed Layer 1 primitives and APRE templating."""
from __future__ import annotations

import logging
from importlib.resources import files
from pathlib import Path

import numpy as np

from gwdh_core.config import HPCConfig
from gwdh_core.geometry import CTHTemplater, Reconstructor
from gwdh_core.geometry.primitives import (
    CylinderConeOgivePrimitives,
    CylinderConePrimitives,
    CylinderPrimitives,
)
from gwdh_core.types import DesignVector, GeometryClass

logger = logging.getLogger(__name__)

TRACER_MARKER = "@@GWDH_TRACERS@@"


class CTHAdapter:
    """Prepare evaluation directories for a single CTH evaluation."""

    def __init__(
        self,
        hpc_config: HPCConfig,
        apre_template_path: str,
        geometry_class: GeometryClass,
    ):
        self.hpc_config = hpc_config
        self.apre_template_path = str(
            self._resolve_template_path(apre_template_path or hpc_config.apre_template_path)
        )
        self.geometry_class = geometry_class
        self._templater = CTHTemplater()
        self._reconstructor = Reconstructor()

    def prepare_evaluation_dir(
        self,
        design_vector: DesignVector,
        primitive_params: dict,
        working_dir: str,
        n_tracers: int = 36,
    ) -> str:
        """Set up and render a working APRE file for one evaluation."""
        workdir = Path(working_dir)
        workdir.mkdir(parents=True, exist_ok=True)
        template_path = Path(self.apre_template_path)
        target_apre = workdir / template_path.name

        primitives = self._resolve_primitives(design_vector, primitive_params)
        self._templater.render_file(template_path, target_apre, primitives)
        self._insert_tracers(target_apre, primitives, n_tracers)

        logger.info(
            "[HPC] Prepared evaluation dir: %s (%d tracers)",
            working_dir,
            n_tracers,
        )
        return str(target_apre)

    def _resolve_primitives(
        self,
        design_vector: DesignVector,
        primitive_params: dict,
    ) -> CylinderPrimitives | CylinderConePrimitives | CylinderConeOgivePrimitives:
        if primitive_params:
            return self._templater.primitives_from_mapping(primitive_params)
        return self._reconstructor.from_vector(design_vector, self.geometry_class)

    def _insert_tracers(self, apre_path, geometry_or_vector, n_tracers: int) -> None:
        """Insert tracer definitions.

        New rendered templates require the explicit tracer marker and get the
        deterministic ``TRACER`` block. The legacy direct-call test path still
        supports appending the older ``tracer { ... }`` block before ``end``.
        """
        apre_path = Path(apre_path)
        if hasattr(geometry_or_vector, "profile_arrays"):
            primitives = geometry_or_vector
            axial, case_r, expl_r = primitives.profile_arrays()
            mid_r = (case_r + expl_r) / 2.0
            tracer_z = np.linspace(axial[0], axial[-1], n_tracers)
            tracer_r = np.interp(tracer_z, axial, mid_r)

            tracer_lines = ["TRACER"]
            for i in range(n_tracers):
                tracer_lines.append(
                    f"    ADD {tracer_r[i] * 100.0:.5f}, {tracer_z[i] * 100.0:.5f}    * GDWH tracer {i + 1}"
                )
                tracer_lines.append("        fixed = XY")
            tracer_lines.append("ENDTRACER")

            content = apre_path.read_text()
            if TRACER_MARKER not in content:
                raise ValueError(
                    f"APRE template is missing required tracer marker {TRACER_MARKER!r}."
                )
            content = content.replace(TRACER_MARKER, "\n".join(tracer_lines), 1)
            apre_path.write_text(content)
            logger.info("Inserted %d Lagrangian tracers into %s", n_tracers, apre_path)
            return

        design_vector: DesignVector = geometry_or_vector
        case_r = design_vector.case_radii * 100.0
        expl_r = design_vector.explosive_radii * 100.0
        axial = design_vector.axial_coords * 100.0
        mid_r = (case_r + expl_r) / 2.0
        tracer_y = np.linspace(axial[0], axial[-1], n_tracers)
        tracer_x = np.interp(tracer_y, axial, mid_r)

        tracer_lines = []
        for i in range(n_tracers):
            tracer_lines.append(
                f"  tracer {{ id = {i+1}; x = {tracer_x[i]:.5f}; y = {tracer_y[i]:.5f}; z = 0.0; }}"
            )
        tracer_block = "\n".join(tracer_lines)

        content = apre_path.read_text()
        if "\nend\n" in content:
            content = content.replace(
                "\nend\n",
                f"\n  ! GWDH Lagrangian tracers\n{tracer_block}\nend\n",
                1,
            )
        else:
            content += f"\n! GWDH Lagrangian tracers\n{tracer_block}\n"
        apre_path.write_text(content)
        logger.info("Inserted %d legacy tracers into %s", n_tracers, apre_path)

    def _resolve_template_path(self, apre_template_path: str) -> Path:
        if apre_template_path:
            return Path(apre_template_path)
        return Path(str(files("gwdh_hpc").joinpath("templates/penetrator_.apre")))
