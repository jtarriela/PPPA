"""Full Slurm job lifecycle coordinator.

This is the entry point called by the Slurm job script. It coordinates:
1. Environment setup
2. CTH launch as subprocess (in its own process group)
3. Observation runner monitoring tracer velocities
4. CTH kill at steady state
5. Postprocessing on still-allocated node
6. Writing results for host node pickup

Usage (from Slurm script):
    python -m gwdh_hpc.worker_lifecycle \\
        --working-dir=/path/to/eval_dir \\
        --config=/path/to/worker_config.yaml
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import yaml  # type: ignore[import-untyped]

from gwdh_core.config import HPCConfig, ObservationRunnerConfig
from gwdh_core.types import (
    DISCRETIZED_DIM,
    DesignVector,
    EvalResult,
    EvalStatus,
    FailType,
    ObserverState,
)

from .observation_runner import ObservationRunner
from .zdata_extractor import ZDATAExtractor

logger = logging.getLogger(__name__)


class WorkerLifecycle:
    """Full lifecycle for a single CTH evaluation within a Slurm job."""

    def __init__(self, working_dir: str, config_path: str):
        self.working_dir = working_dir

        with open(config_path) as f:
            raw = yaml.safe_load(f) or {}
        if not isinstance(raw, dict):
            raw = {}

        postprocess = raw.get("postprocess", {})

        self.hpc_config = HPCConfig(**raw.get("hpc", {}))
        self.obs_config = ObservationRunnerConfig(
            **raw.get("observation_runner", {})
        )
        self.eval_id = raw.get("eval_id", "unknown")
        self.campaign_id = raw.get("campaign_id", "unknown")
        self.slurm_job_id = os.environ.get("SLURM_JOB_ID", "unknown")
        self.ntasks = int(os.environ.get("SLURM_NTASKS", self.hpc_config.ntasks))
        self.postprocess_command = str(postprocess.get("command", "") or "")
        self.postprocess_timeout_s = int(postprocess.get("timeout_s", 600) or 600)

    def run(self) -> int:
        """Main entry point. Returns exit code (0=success, 1=failure)."""
        try:
            self._write_initial_status()

            design_vector = self._load_design_vector()

            # Launch CTH in its own process group
            cth_process = self._launch_cth()

            # Run observation loop
            observer = ObservationRunner(
                config=self.obs_config,
                working_dir=self.working_dir,
                cth_pid=cth_process.pid,
                design_vector=design_vector,
                eval_id=self.eval_id,
                campaign_id=self.campaign_id,
                slurm_job_id=self.slurm_job_id,
            )
            obs_result = observer.run()

            # If observation succeeded, run postprocessing
            if obs_result.status == EvalStatus.COMPLETED:
                result = self._run_postprocessing(obs_result)
            else:
                result = obs_result

            self._write_result(result)
            self._write_terminal_status(result)
            return 0 if result.status == EvalStatus.COMPLETED else 1

        except Exception as e:
            logger.exception("Worker lifecycle crashed: %s", e)
            self._write_error_result(str(e))
            self._write_status(
                ObserverState.FAILED,
                "Worker lifecycle crashed",
                fail_type=FailType.OBS_RUNNER_CRASH,
            )
            return 1

    def _launch_cth(self) -> subprocess.Popen:
        """Launch CTH via mpirun as a subprocess in its own process group."""
        # Find the APRE file
        apre_files = list(Path(self.working_dir).glob("*.apre"))
        if not apre_files:
            raise FileNotFoundError(
                f"No .apre files found in {self.working_dir}"
            )
        apre_file = str(apre_files[0])

        launch_command = self.hpc_config.launch_command.format(
            ntasks=self.ntasks,
            apre_path=apre_file,
        )
        cmd = shlex.split(launch_command)

        logger.info("Launching CTH: %s", " ".join(cmd))

        stdout_path = os.path.join(self.working_dir, "cth.stdout")
        stderr_path = os.path.join(self.working_dir, "cth.stderr")

        # Open log files and keep references so we can close them after CTH finishes.
        # Not using context managers here because Popen must outlive this method;
        # _close_cth_log_handles() is called after cth_process.wait().
        self._cth_stdout_fh = open(stdout_path, "w")
        self._cth_stderr_fh = open(stderr_path, "w")

        process = subprocess.Popen(
            cmd,
            cwd=self.working_dir,
            preexec_fn=os.setsid,  # new process group for clean kill
            stdout=self._cth_stdout_fh,
            stderr=self._cth_stderr_fh,
        )

        logger.info("CTH launched with PID %d (PGID %d)", process.pid, os.getpgid(process.pid))
        return process

    def _load_design_vector(self) -> DesignVector:
        """Load design_vector.npy saved by the host for provenance.

        WorkerLifecycle always returns an EvalResult, and EvalResult requires a DesignVector.
        If the file is missing (e.g., shared FS issue), we fall back to a sentinel.
        """
        path = os.path.join(self.working_dir, "design_vector.npy")
        if os.path.exists(path):
            return DesignVector(data=np.load(path))
        logger.warning("design_vector.npy missing in %s", self.working_dir)
        return DesignVector(data=np.zeros(DISCRETIZED_DIM))

    def _close_cth_log_handles(self) -> None:
        """Close stdout/stderr file handles opened for the CTH subprocess."""
        for attr in ("_cth_stdout_fh", "_cth_stderr_fh"):
            fh = getattr(self, attr, None)
            if fh is not None and not fh.closed:
                try:
                    fh.close()
                except OSError:
                    pass

    def _run_postprocessing(self, obs_result: EvalResult) -> EvalResult:
        """Extract fragment data on the still-allocated node.

        NOTE: This method intentionally mutates obs_result in-place.
        EvalResult is not frozen, and mutation here is the deliberate design:
        the observer returns a partial result that postprocessing completes.
        Callers must not hold a reference expecting the original partial state.
        """
        logger.info("Starting postprocessing in %s", self.working_dir)

        # Close CTH log file handles now that the process has finished.
        self._close_cth_log_handles()

        try:
            command = self.postprocess_command.strip()
            if command:
                env = os.environ.copy()
                env.update(
                    {
                        "GWDH_WORKING_DIR": self.working_dir,
                        "GWDH_EVAL_ID": self.eval_id,
                        "GWDH_CAMPAIGN_ID": self.campaign_id,
                    }
                )
                logger.info("Running postprocess command: %s", command)
                proc = subprocess.run(
                    ["bash", "-lc", command],
                    cwd=self.working_dir,
                    env=env,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=self.postprocess_timeout_s,
                )
                if proc.returncode != 0:
                    logger.error(
                        "Postprocess command failed (rc=%d): %s",
                        proc.returncode,
                        proc.stderr.strip(),
                    )
                    obs_result.status = EvalStatus.FAILED
                    obs_result.fail_type = FailType.POSTPROCESS_PARSE_ERROR
                    return obs_result

            extractor = ZDATAExtractor()
            zdata = extractor.extract_from_cth_output(self.working_dir)

            obs_result.zdata = zdata
            obs_result.status = EvalStatus.COMPLETED
            logger.info("Postprocessing complete")
            return obs_result

        except Exception as e:
            logger.error("Postprocessing failed: %s", e)
            obs_result.status = EvalStatus.FAILED
            obs_result.fail_type = FailType.POSTPROCESS_PARSE_ERROR
            return obs_result

    def _write_result(self, result: EvalResult) -> None:
        """Write result.json for host node to pick up."""
        result_dict = {
            "eval_id": result.eval_id,
            "status": result.status.value,
            "fail_type": result.fail_type.value if result.fail_type else None,
            "runtime_sec": result.runtime_sec,
            "slurm_job_id": result.slurm_job_id,
            "timestamp": result.timestamp or datetime.now(timezone.utc).isoformat(),
            "has_zdata": result.zdata is not None,
        }

        if result.objectives is not None:
            result_dict["objectives"] = result.objectives.tolist()

        result_path = os.path.join(self.working_dir, "result.json")
        tmp_path = result_path + ".tmp"
        with open(tmp_path, "w") as f:
            json.dump(result_dict, f, indent=2)
        os.replace(tmp_path, result_path)

        logger.info("Result written to %s (status=%s)", result_path, result.status.value)

    def _write_error_result(self, error_msg: str) -> None:
        """Write a failure result.json when the lifecycle itself crashes."""
        result_dict = {
            "eval_id": self.eval_id,
            "status": EvalStatus.FAILED.value,
            "fail_type": FailType.OBS_RUNNER_CRASH.value,
            "runtime_sec": 0.0,
            "slurm_job_id": self.slurm_job_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "error": error_msg,
            "has_zdata": False,
        }

        result_path = os.path.join(self.working_dir, "result.json")
        with open(result_path, "w") as f:
            json.dump(result_dict, f, indent=2)

    def _write_initial_status(self) -> None:
        """Write initial observer_status.yaml."""
        self._write_status(
            ObserverState.INITIALIZING,
            "Worker lifecycle starting",
        )

    def _write_terminal_status(self, result: EvalResult) -> None:
        """Write a terminal observer_status.yaml state for host node pickup."""
        if result.status == EvalStatus.COMPLETED:
            self._write_status(ObserverState.COMPLETED, "Worker lifecycle completed")
            return

        fail_type = result.fail_type or FailType.UNKNOWN
        self._write_status(
            ObserverState.FAILED,
            "Worker lifecycle failed",
            fail_type=fail_type,
        )

    def _write_status(
        self,
        state: ObserverState,
        message: str,
        fail_type: FailType | None = None,
    ) -> None:
        """Write observer_status.yaml (atomic write)."""
        status = {
            "slurm_job_id": self.slurm_job_id,
            "eval_id": self.eval_id,
            "campaign_id": self.campaign_id,
            "state": state.value,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "message": message,
        }
        if fail_type is not None:
            status["fail_type"] = fail_type.value

        status_path = os.path.join(self.working_dir, "observer_status.yaml")
        tmp_path = status_path + ".tmp"
        with open(tmp_path, "w") as f:
            yaml.safe_dump(status, f, default_flow_style=False)
        os.replace(tmp_path, status_path)


def main() -> None:
    """CLI entry point for Slurm job scripts."""
    parser = argparse.ArgumentParser(description="GWDH Worker Lifecycle")
    parser.add_argument("--working-dir", required=True, help="Evaluation working directory")
    parser.add_argument("--config", required=True, help="Path to worker_config.yaml")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(
                os.path.join(args.working_dir, "worker.log")
            ),
        ],
    )

    worker = WorkerLifecycle(args.working_dir, args.config)
    sys.exit(worker.run())


if __name__ == "__main__":
    main()
