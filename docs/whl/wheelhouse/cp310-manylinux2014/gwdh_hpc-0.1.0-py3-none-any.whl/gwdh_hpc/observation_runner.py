"""Observation runner: monitors CTH tracer velocities for steady-state convergence.

Runs within a Slurm job, co-located with CTH on the compute node.
Monitors ALL Lagrangian tracers and uses majority-vote to determine
when fragment velocities have leveled off. Kills CTH at steady state
to avoid wasting compute time, then runs postprocessing on the
still-allocated node.
"""
from __future__ import annotations

import csv
import logging
import os
import time
from datetime import datetime, timezone
from typing import Optional

import numpy as np
import yaml  # type: ignore[import-untyped]

from gwdh_core.config import ObservationRunnerConfig
from gwdh_core.types import (
    DesignVector,
    EvalResult,
    EvalStatus,
    FailType,
    ObserverState,
    ObserverStatus,
)

from .process_monitor import ProcessMonitor

logger = logging.getLogger(__name__)


class ObservationRunner:
    """Monitor CTH execution and kill at steady state.

    Steady-state detection:
    - Track ALL Lagrangian tracers (placed at fragment layer midpoint)
    - Per-tracer rolling window slope check
    - Majority vote: >= tracer_majority_fraction of tracers must show
      |slope/mean_v| < velocity_slope_threshold for steady_state_patience
      consecutive windows
    """

    def __init__(
        self,
        config: ObservationRunnerConfig,
        working_dir: str,
        cth_pid: int,
        design_vector: DesignVector,
        eval_id: str,
        campaign_id: str,
        slurm_job_id: str,
    ):
        self.config = config
        self.working_dir = working_dir
        self.cth_pid = cth_pid
        self.design_vector = design_vector
        self.eval_id = eval_id
        self.campaign_id = campaign_id
        self.slurm_job_id = slurm_job_id
        self.process_monitor = ProcessMonitor()

        # Per-tracer velocity histories: tracer_id -> list of velocities
        self._velocity_histories: dict[int, list[float]] = {}
        self._consecutive_steady_counts: int = 0
        self._last_hscth_mtime: float = 0.0
        self._start_time: float = 0.0

    def run(self) -> EvalResult:
        """Main observation loop."""
        self._start_time = time.monotonic()
        self._write_status(ObserverState.MONITORING_CTH, "Starting tracer monitoring")

        while self._elapsed_sec() < self.config.max_observation_time_s:
            # Check if CTH is still alive
            if not self.process_monitor.is_alive(self.cth_pid):
                return self._handle_cth_exit()

            # Read latest tracer data from hscth file
            new_data = self._read_latest_tracer_velocities()
            if new_data:
                self._update_velocity_histories(new_data)

                # Check for steady state across all tracers
                if self._is_global_steady_state():
                    logger.info(
                        "Global steady state reached after %.1fs",
                        self._elapsed_sec(),
                    )
                    return self._kill_and_postprocess()

            time.sleep(self.config.poll_interval_s)

        # Timeout
        logger.warning(
            "Observation timed out after %ds", self.config.max_observation_time_s
        )
        return self._kill_and_classify(FailType.OBS_STEADY_STATE_TIMEOUT)

    def _read_latest_tracer_velocities(self) -> Optional[dict[int, float]]:
        """Parse the growing hscth file to get latest tracer velocities.

        Uses os.stat() mtime check to avoid re-reading unchanged files
        (important for Lustre metadata caching).

        Returns dict of tracer_id -> velocity, or None if no new data.
        Uses csv.reader instead of pandas to keep the hot poll loop lightweight.
        """
        hscth_path = self._find_hscth_file()
        if hscth_path is None:
            return None

        try:
            current_mtime = os.stat(hscth_path).st_mtime
            if current_mtime <= self._last_hscth_mtime:
                return None
            self._last_hscth_mtime = current_mtime
        except OSError:
            return None

        try:
            with open(hscth_path, newline="") as fh:
                reader = csv.reader(fh)
                # Skip CTH header rows
                try:
                    next(reader)  # row 0
                    header_row = next(reader)  # row 1 — column names
                except StopIteration:
                    return None

                headers = [h.strip() for h in header_row]
                vel_col_indices = [
                    i for i, h in enumerate(headers) if h.startswith("Velocity")
                ]

                if not vel_col_indices:
                    return None

                # Accumulate all valid velocity readings per tracer, take last
                # Use a dict of lists to find the last non-empty value per column
                latest: dict[int, float] = {}
                for row in reader:
                    for tracer_idx, col_idx in enumerate(vel_col_indices):
                        if col_idx >= len(row):
                            continue
                        cell = row[col_idx].strip()
                        if not cell:
                            continue
                        try:
                            latest[tracer_idx] = float(cell)
                        except ValueError:
                            continue

            return latest if latest else None

        except Exception as e:
            logger.warning("Error reading hscth file: %s", e)
            return None

    def _update_velocity_histories(self, new_data: dict[int, float]) -> None:
        """Update per-tracer velocity histories with new readings."""
        for tracer_id, velocity in new_data.items():
            if tracer_id not in self._velocity_histories:
                self._velocity_histories[tracer_id] = []
            self._velocity_histories[tracer_id].append(velocity)

    def _is_tracer_steady(self, tracer_id: int) -> bool:
        """Check if a single tracer has reached steady state."""
        history = self._velocity_histories.get(tracer_id, [])
        w = self.config.velocity_window_size

        if len(history) < w:
            return False

        window = history[-w:]
        x = np.arange(w, dtype=float)
        slope = np.polyfit(x, window, 1)[0]

        mean_v = np.mean(window)
        if mean_v <= 0:
            return False

        relative_slope = abs(slope) / mean_v
        return relative_slope < self.config.velocity_slope_threshold

    def _is_global_steady_state(self) -> bool:
        """Majority-vote across all tracers for global steady state."""
        if not self._velocity_histories:
            return False

        n_total = len(self._velocity_histories)
        n_steady = sum(
            1 for tid in self._velocity_histories if self._is_tracer_steady(tid)
        )
        fraction_steady = n_steady / n_total

        self._write_status(
            ObserverState.MONITORING_CTH,
            f"{n_steady}/{n_total} tracers at steady state",
            tracers_steady=n_steady,
            tracers_total=n_total,
        )

        if fraction_steady >= self.config.tracer_majority_fraction:
            self._consecutive_steady_counts += 1
        else:
            self._consecutive_steady_counts = 0

        return self._consecutive_steady_counts >= self.config.steady_state_patience

    def _kill_and_postprocess(self) -> EvalResult:
        """Kill CTH safely, verify death, signal ready for postprocessing."""
        self._write_status(ObserverState.KILLING_CTH, "Sending SIGTERM to CTH")

        killed = self.process_monitor.safe_kill(
            self.cth_pid, grace_period_s=30
        )
        if not killed:
            killed = self.process_monitor.force_kill(self.cth_pid)

        self._write_status(
            ObserverState.VERIFYING_CTH_DEAD, "Verifying CTH process terminated"
        )

        verified = self.process_monitor.verify_dead(
            self.cth_pid,
            retries=self.config.process_verify_retries,
            interval_s=self.config.process_verify_interval_s,
        )

        if not verified:
            self._write_status(
                ObserverState.FAILED,
                "CTH process could not be verified dead",
                fail_type=FailType.OBS_PROCESS_VERIFY_FAILED,
            )
            return EvalResult(
                eval_id=self.eval_id,
                design_vector=self.design_vector,
                status=EvalStatus.FAILED,
                fail_type=FailType.OBS_PROCESS_VERIFY_FAILED,
                runtime_sec=self._elapsed_sec(),
                slurm_job_id=self.slurm_job_id,
                timestamp=self._now_iso(),
            )

        # Postprocessing happens in worker_lifecycle after this returns
        self._write_status(
            ObserverState.POSTPROCESSING, "CTH killed, ready for postprocessing"
        )
        return EvalResult(
            eval_id=self.eval_id,
            design_vector=self.design_vector,
            status=EvalStatus.COMPLETED,
            runtime_sec=self._elapsed_sec(),
            slurm_job_id=self.slurm_job_id,
            timestamp=self._now_iso(),
        )

    def _kill_and_classify(self, fail_type: FailType) -> EvalResult:
        """Kill CTH and return a failure result."""
        self._write_status(
            ObserverState.KILLING_CTH,
            f"Killing CTH due to {fail_type.value}",
        )
        self.process_monitor.safe_kill(self.cth_pid, grace_period_s=15)
        if self.process_monitor.is_alive(self.cth_pid):
            self.process_monitor.force_kill(self.cth_pid)

        self._write_status(
            ObserverState.FAILED,
            f"Evaluation failed: {fail_type.value}",
            fail_type=fail_type,
        )
        return EvalResult(
            eval_id=self.eval_id,
            design_vector=self.design_vector,
            status=EvalStatus.FAILED,
            fail_type=fail_type,
            runtime_sec=self._elapsed_sec(),
            slurm_job_id=self.slurm_job_id,
            timestamp=self._now_iso(),
        )

    def _handle_cth_exit(self) -> EvalResult:
        """CTH exited on its own. Check for output completeness."""
        logger.info("CTH process %d exited on its own", self.cth_pid)

        # Check if ZDATA output files exist
        spcth_files = list(
            f
            for f in os.listdir(self.working_dir)
            if f.endswith(".spcth")
        )
        if spcth_files:
            self._write_status(
                ObserverState.POSTPROCESSING,
                "CTH exited normally, found output files",
            )
            return EvalResult(
                eval_id=self.eval_id,
                design_vector=self.design_vector,
                status=EvalStatus.COMPLETED,
                runtime_sec=self._elapsed_sec(),
                slurm_job_id=self.slurm_job_id,
                timestamp=self._now_iso(),
            )

        self._write_status(
            ObserverState.FAILED,
            "CTH exited without producing output files",
            fail_type=FailType.CTH_INCOMPLETE_OUTPUT,
        )
        return EvalResult(
            eval_id=self.eval_id,
            design_vector=self.design_vector,
            status=EvalStatus.FAILED,
            fail_type=FailType.CTH_INCOMPLETE_OUTPUT,
            runtime_sec=self._elapsed_sec(),
            slurm_job_id=self.slurm_job_id,
            timestamp=self._now_iso(),
        )

    def _find_hscth_file(self) -> Optional[str]:
        """Locate the hscth history file in the working directory."""
        for fname in os.listdir(self.working_dir):
            if fname.startswith("hscth") or fname == "hscth":
                return os.path.join(self.working_dir, fname)
        return None

    def _elapsed_sec(self) -> float:
        return time.monotonic() - self._start_time

    def _write_status(
        self,
        state: ObserverState,
        message: str,
        tracers_steady: int = 0,
        tracers_total: int = 0,
        fail_type: Optional[FailType] = None,
    ) -> None:
        """Write observer_status.yaml to working directory."""
        # Compute velocity snapshot from latest readings
        vel_mean = vel_min = vel_max = None
        if self._velocity_histories:
            latest_vels = [
                h[-1] for h in self._velocity_histories.values() if h
            ]
            if latest_vels:
                vel_mean = float(np.mean(latest_vels))
                vel_min = float(np.min(latest_vels))
                vel_max = float(np.max(latest_vels))

        status = ObserverStatus(
            slurm_job_id=self.slurm_job_id,
            eval_id=self.eval_id,
            campaign_id=self.campaign_id,
            state=state,
            timestamp=self._now_iso(),
            cth_pid=self.cth_pid,
            n_tracers=len(self._velocity_histories),
            tracers_steady=tracers_steady,
            tracers_total=tracers_total or len(self._velocity_histories),
            velocity_mean=vel_mean,
            velocity_min=vel_min,
            velocity_max=vel_max,
            elapsed_sec=self._elapsed_sec(),
            message=message,
            fail_type=fail_type,
        )

        status_dict = {
            "slurm_job_id": status.slurm_job_id,
            "eval_id": status.eval_id,
            "campaign_id": status.campaign_id,
            "state": status.state.value,
            "timestamp": status.timestamp,
            "cth_pid": status.cth_pid,
            "n_tracers": status.n_tracers,
            "tracers_steady": status.tracers_steady,
            "tracers_total": status.tracers_total,
            "velocity_snapshot": {
                "mean": status.velocity_mean,
                "min": status.velocity_min,
                "max": status.velocity_max,
            },
            "elapsed_sec": round(status.elapsed_sec, 1),
            "message": status.message,
        }
        if status.fail_type:
            status_dict["fail_type"] = status.fail_type.value

        status_path = os.path.join(self.working_dir, "observer_status.yaml")
        # Write atomically: write to temp file then rename
        tmp_path = status_path + ".tmp"
        with open(tmp_path, "w") as f:
            yaml.safe_dump(status_dict, f, default_flow_style=False)
        os.replace(tmp_path, status_path)

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(timezone.utc).isoformat()
