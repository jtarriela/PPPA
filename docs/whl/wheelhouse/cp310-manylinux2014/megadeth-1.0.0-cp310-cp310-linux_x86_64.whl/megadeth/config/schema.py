from __future__ import annotations

from pathlib import Path
from typing import List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# Default centroid heights pulled from Architecture_Specification.md (Section 3.1)
DEFAULT_CENTROID_HEIGHTS_FT = {
    8421: 6.35,
    8422: 1.93,
    8423: 3.41,
    4901: 2.89,
    4902: 6.49,
    4903: 7.14,
    4904: 4.48,
    5221: 7.78,
    5222: 6.44,
    5223: 5.69,
    5224: 5.69,
    5231: 21.91,
    5232: 21.41,
    5233: 19.51,
    5234: 20.35,
    7131: 2.3,
    7132: 10.96,
    7151: 3.2,
    7152: 16.0,
    7153: 15.7,
    7173: 14.968,
    1001: 7.3,
    1002: 23.87,
    1003: 5.515,
    1004: 5.92,
    1005: 6.5,
    1006: 9.06,
    503: 6.5,
    1: 2.3,
}


def _generate_axis(min_val: float, max_val: float, step: float) -> List[float]:
    """Generate an inclusive axis using step increments."""
    axis: List[float] = []
    current = float(min_val)
    max_val = float(max_val)
    step = float(step)

    # Guard against invalid steps to avoid infinite loops.
    if step <= 0:
        raise ValueError("step must be positive when generating an axis")

    # Add a small epsilon to include the endpoint when floating point error
    # would otherwise drop the final value.
    epsilon = step * 1e-6
    while current <= max_val + epsilon:
        axis.append(round(current, 6))
        current += step
    return axis


class AxisSpec(BaseModel):
    """Specifies either an explicit axis or a min/max/step definition."""
    model_config = ConfigDict(extra="forbid")

    min: Optional[float] = None
    max: Optional[float] = None
    step: Optional[float] = None
    axis: Optional[List[float]] = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def _compute_axis(self) -> "AxisSpec":
        if self.axis is None:
            if None in (self.min, self.max, self.step):
                raise ValueError("Provide either axis or min/max/step")
            self.axis = _generate_axis(self.min, self.max, self.step)
        return self

    @property
    def values(self) -> List[float]:
        return list(self.axis or [])


class TerminalConditionConfig(BaseModel):
    """Axes for the HOB/velocity/AOF grid."""
    model_config = ConfigDict(extra="forbid")

    hob: AxisSpec
    velocity: AxisSpec
    aof: AxisSpec


class GridConfig(BaseModel):
    """
    Miss distance grid definition.
    
    DEPRECATED: This config is no longer used. The miss distance grid is now
    extracted directly from the LAM2.DAT output (native 80×40 grid mirrored
    to ~160×40). This ensures Python uses the exact same grid as MATLAB.
    
    Kept for backwards compatibility but ignored by analyzers.
    """
    model_config = ConfigDict(extra="forbid")

    miss_x_axis: Optional[List[float]] = Field(default=None, min_length=1)
    miss_y_axis: Optional[List[float]] = Field(default=None, min_length=1)


class WarheadConfigModel(BaseModel):
    """Warhead configuration for campaign generation."""
    model_config = ConfigDict(extra="forbid")

    zdata_number: int
    zdata_path: Path


class TargetConfigModel(BaseModel):
    """Target configuration including centroid height lookup."""
    model_config = ConfigDict(extra="forbid")

    rcas_number: int
    rcas_path: Path
    intrvc_path: Path
    centroid_height_ft: Optional[float] = None

    @model_validator(mode="after")
    def _fill_centroid_height(self) -> "TargetConfigModel":
        if self.centroid_height_ft is None:
            self.centroid_height_ft = DEFAULT_CENTROID_HEIGHTS_FT.get(self.rcas_number)
        return self


class SolverConfig(BaseModel):
    """Paths to the solver executable and static data."""
    model_config = ConfigDict(extra="forbid")

    backend: Optional[str] = Field(
        default=None,
        description=(
            "Optional solver backend selector (e.g., 'python'). Present for"
            " backwards compatibility with earlier configs; ignored by the"
            " current orchestrator."
        ),
    )
    fsm_exe_path: Optional[Path] = Field(
        default=None,
        description="Path to FSM executable. Auto-detected from megadeth/executables/ if not specified."
    )
    cdrag_path: Optional[Path] = Field(
        default=None,
        description="Path to CDRAG1.DAT. Auto-detected from executables directory if not specified."
    )


class OutputConfig(BaseModel):
    """Output directory for generated artifacts."""
    model_config = ConfigDict(extra="forbid")

    directory: Path = Field(default=Path("output"))


class DebugConfig(BaseModel):
    """Optional debug artifacts."""
    model_config = ConfigDict(extra="forbid")

    save_ipdat_sample: bool = Field(
        default=False,
        description="If true, save the first generated IP.DAT to output/lam2_debug for inspection.",
    )


class MatrixConfig(BaseModel):
    """Override grid dimensions or cell size for IP.DAT generation."""

    model_config = ConfigDict(extra="forbid")

    nx: Optional[int] = Field(default=None, gt=0, description="Matrix x-dimension (nx).")
    ny: Optional[int] = Field(default=None, gt=0, description="Matrix y-dimension (ny).")
    cell_size_m: Optional[float] = Field(
        default=None, ge=0.1, description="Cell size in meters (applies to both axes)."
    )
    range_offset_m: Optional[float] = Field(
        default=None, description="Range axis offset in meters."
    )


class ExecutionConfig(BaseModel):
    """Execution tuning knobs surfaced to users."""
    model_config = ConfigDict(extra="forbid")

    max_parallel_workers: Optional[int] = None
    batch_size: Optional[Union[int, str]] = None
    staging_buffer_mb: Optional[Union[int, str]] = None
    skip_io_benchmark: bool = False
    postprocess_threads: Optional[int] = Field(
        default=None,
        gt=0,
        description="Number of threads for LAM2 post-processing per worker (defaults to cpu_count)",
    )
    staging_strategy: Literal["batched", "per_job"] = Field(
        default="batched",
        description=(
            "Staging approach: 'batched' uses one IP/LAM2 per shard, 'per_job' creates a fresh "
            "directory and IP.DAT for each work item (legacy isolation)."
        ),
    )


class MonteCarloAnalysisConfig(BaseModel):
    """Monte Carlo analysis feature toggles for MATLAB parity."""
    model_config = ConfigDict(extra="forbid")

    matlab_parity_sampling: bool = False
    parity_plot_style: bool = False
    save_terminal_condition_results: bool = False


# =============================================================================
# Discrete Grid Analysis Configuration (v3.0 Spec)
# =============================================================================

class ErrorModelConfig(BaseModel):
    """
    4-source error model configuration for discrete analysis.
    
    MATLAB Parity (2025-12-02): Coordinate convention matches MEGADETH SalvoAnalysis03x3.m:
        - X-axis = Deflection (crossrange) - MATLAB Precision column 5
        - Y-axis = Range (downrange) - MATLAB Precision column 6
    
    MATLAB Reference: Precision input matrix (8 columns)
        [TLE_r, TLE_f, CEP_r, CEP_f, FixedBias_defl, FixedBias_range, VarBias_r, VarBias_f]
    
    Reference: docs/DISCRETE_ANALYSIS.md Section 1.1-1.4
    """
    
    # Target Location Error (per-salvo)
    tle_radius_m: float = Field(default=30.0, ge=0.0, description="TLE containment radius in meters")
    tle_fraction: float = Field(default=0.90, gt=0.0, lt=1.0, description="TLE containment probability (e.g., 0.90 for TLE90)")
    
    # Circular Error Probable (per-shot)
    cep_radius_m: float = Field(default=5.0, ge=0.0, description="CEP containment radius in meters")
    cep_fraction: float = Field(default=0.50, gt=0.0, lt=1.0, description="CEP containment probability (e.g., 0.50 for CEP50)")
    
    # Fixed Bias (constant offset) - MATLAB Parity: X=Deflection, Y=Range
    fixed_bias_x_m: float = Field(default=0.0, description="Fixed bias in X (deflection/crossrange) direction, meters - MATLAB col 5")
    fixed_bias_y_m: float = Field(default=0.0, description="Fixed bias in Y (range/downrange) direction, meters - MATLAB col 6")
    
    # Variable Bias (per-salvo) - set radius=0 and fraction=0 to disable
    variable_bias_radius_m: float = Field(default=0.0, ge=0.0, description="Variable bias containment radius in meters")
    variable_bias_fraction: float = Field(default=0.50, ge=0.0, le=1.0, description="Variable bias containment probability (0 to disable)")
    model_config = ConfigDict(extra="forbid")


class SalvoAnalysisConfig(BaseModel):
    """
    Salvo analysis configuration for multi-shot engagement.
    
    Reference: docs/DISCRETE_ANALYSIS.md Section 4
    """
    
    max_shots: int = Field(default=10, gt=0, le=100, description="Maximum shots per salvo (K)")
    pk_thresholds: List[float] = Field(
        default=[0.30, 0.50, 0.70, 0.90],
        description="Pk thresholds for rounds-to-kill computation"
    )
    model_config = ConfigDict(extra="forbid")

    @field_validator('pk_thresholds')
    @classmethod
    def validate_thresholds(cls, v: List[float]) -> List[float]:
        for t in v:
            if not 0.0 < t < 1.0:
                raise ValueError(f"Pk threshold must be in (0, 1), got {t}")
        return sorted(v)


class IntegrationMethodConfig(BaseModel):
    """
    Integration method configuration for discrete analysis.
    
    Reference: docs/DISCRETE_ANALYSIS.md Section 6
    """
    
    method: str = Field(
        default="hybrid_mc",
        description="Integration method: 'nested_grid', 'hybrid_mc', or 'single_shot_only'"
    )
    
    # For nested_grid mode
    n_salvo_centers: int = Field(
        default=31, ge=11, le=101,
        description="Grid resolution for salvo centers (odd number recommended)"
    )
    
    # For hybrid_mc mode
    n_salvos: int = Field(default=2001, gt=0, description="Number of MC salvo samples")
    random_seed: int = Field(default=314159, description="RNG seed for reproducibility")
    
    # Convolution optimization (v3.1)
    use_convolution: bool = Field(
        default=True,
        description="Use FFT convolution for salvo center precomputation (faster, ~0.1% vs einsum)"
    )
    model_config = ConfigDict(extra="forbid")

    @field_validator('method')
    @classmethod
    def validate_method(cls, v: str) -> str:
        valid_methods = {'nested_grid', 'hybrid_mc', 'single_shot_only'}
        if v not in valid_methods:
            raise ValueError(f"method must be one of {valid_methods}, got '{v}'")
        return v


class DeliveryErrorConfig(BaseModel):
    """
    Delivery error model for flight parameter uncertainty.
    
    Reference: docs/DISCRETE_ANALYSIS.md Section 7
    """
    
    sigma_hob_m: float = Field(default=0.0, ge=0.0, description="HOB (fuse timing) error sigma in meters")
    sigma_velocity_mps: float = Field(default=0.0, ge=0.0, description="Velocity error sigma in m/s")
    sigma_aof_deg: float = Field(default=0.0, ge=0.0, description="Angle of fall error sigma in degrees")
    kernel_width_sigma: float = Field(default=3.0, gt=0.0, description="Convolution kernel extends ±N sigma")
    model_config = ConfigDict(extra="forbid")


class DiscreteGridConfig(BaseModel):
    """
    Discrete grid analysis configuration (v3.0 specification).
    
    Enables 4-source error model with nested integration for
    MATLAB MEGADETH parity.
    
    Reference: docs/DISCRETE_ANALYSIS.md Part 3
    """
    
    enabled: bool = Field(default=False, description="Enable discrete grid analysis")
    
    # 4-source error model
    error_model: ErrorModelConfig = Field(default_factory=ErrorModelConfig)
    
    # Salvo analysis parameters
    salvo: SalvoAnalysisConfig = Field(default_factory=SalvoAnalysisConfig)
    
    # Integration method
    integration: IntegrationMethodConfig = Field(default_factory=IntegrationMethodConfig)
    
    # Delivery error model (Stage 4)
    delivery_error: Optional[DeliveryErrorConfig] = None
    
    # Metrics thresholds
    pk_threshold: float = Field(default=0.5, gt=0.0, lt=1.0, description="Minimum Pk for envelope computation")
    gradient_threshold: float = Field(default=0.05, gt=0.0, description="Maximum sensitivity for robustness")
    
    # Output options
    save_pk_sys_grid: bool = Field(default=True, description="Export precomputed Pk_sys_grid to NPZ")
    save_mean_pk: bool = Field(default=True, description="Export mean_Pk[k,h,v,α] to NPZ")
    save_rounds_to_kill: bool = Field(default=True, description="Export r2k[h,v,α,T] to NPZ")
    model_config = ConfigDict(extra="forbid")


# =============================================================================
# Monte Carlo Analysis Configuration (v2.0 full spec)
# =============================================================================

class PrecisionConfig(BaseModel):
    """
    Precision configuration for a single error model scenario.
    
    MATLAB Parity (2025-12-02): Coordinate convention matches MEGADETH SalvoAnalysis03x3.m:
        - fixed_bias_deflection_m = X-axis = crossrange - MATLAB Precision column 5
        - fixed_bias_range_m = Y-axis = downrange - MATLAB Precision column 6
    
    MATLAB Reference: SalvoAnalysis03x3.m precision input rows
        [TLE_r, TLE_f, CEP_r, CEP_f, FixedBias_defl, FixedBias_range, VarBias_r, VarBias_f]
    """
    
    label: str = Field(default="default", description="Human-readable label for this precision config")
    
    # TLE (Target Location Error)
    tle_radius_m: float = Field(default=30.0, ge=0.0)
    tle_fraction: float = Field(default=0.90, gt=0.0, lt=1.0)
    
    # CEP (Circular Error Probable)
    cep_radius_m: float = Field(default=5.0, ge=0.0)
    cep_fraction: float = Field(default=0.50, gt=0.0, lt=1.0)
    
    # Fixed Bias - MATLAB Parity: Deflection=X, Range=Y
    fixed_bias_deflection_m: float = Field(default=0.0, description="X-axis (crossrange) bias - MATLAB col 5")
    fixed_bias_range_m: float = Field(default=0.0, description="Y-axis (downrange) bias - MATLAB col 6")
    
    # Variable Bias - set radius=0 and fraction=0 to disable
    variable_bias_radius_m: float = Field(default=0.0, ge=0.0)
    variable_bias_fraction: float = Field(default=0.50, ge=0.0, le=1.0)
    
    # Z-axis components (optional, for 3D analysis - behind enable_z_axis flag)
    tle_z_sigma_m: float = Field(default=0.0, ge=0.0)
    cep_z_sigma_m: float = Field(default=0.0, ge=0.0)
    model_config = ConfigDict(extra="forbid")


class MCSamplingConfig(BaseModel):
    """Monte Carlo sampling parameters."""
    model_config = ConfigDict(extra="forbid")
    
    n_salvos: int = Field(default=2001, gt=0, description="Number of salvos to simulate")
    n_shots: int = Field(default=10, gt=0, le=100, description="Shots per salvo")
    random_seed: int = Field(default=314159, description="RNG seed for reproducibility")
    store_detailed_results: bool = Field(default=False, description="Store per-shot Pk values")


class MCLethalityConfig(BaseModel):
    """Lethality thresholds for Monte Carlo analysis."""
    model_config = ConfigDict(extra="forbid")
    
    pk_thresholds: List[float] = Field(
        default=[0.30, 0.50, 0.70, 0.90],
        description="Pk thresholds for rounds-to-kill"
    )


class MonteCarloConfig(BaseModel):
    """
    Full Monte Carlo analysis configuration.
    
    MATLAB Reference: SalvoAnalysis03x3.m
    """
    model_config = ConfigDict(extra="forbid")
    
    enabled: bool = Field(default=False, description="Enable Monte Carlo analysis")
    precisions: List[PrecisionConfig] = Field(default_factory=list, description="List of precision configurations")
    sampling: MCSamplingConfig = Field(default_factory=MCSamplingConfig)
    lethality: MCLethalityConfig = Field(default_factory=MCLethalityConfig)


class CampaignConfig(BaseModel):
    """Top-level campaign configuration validated via Pydantic."""
    model_config = ConfigDict(extra="forbid")

    name: str = "megadeth_campaign"
    description: Optional[str] = None
    terminal_conditions: TerminalConditionConfig
    grid: Optional[GridConfig] = Field(
        default=None,
        description="DEPRECATED: Miss grid is now extracted from LAM2.DAT native output"
    )
    warheads: List[WarheadConfigModel] = Field(..., min_length=1)
    targets: List[TargetConfigModel] = Field(..., min_length=1)
    solver: SolverConfig
    output: OutputConfig = Field(default_factory=OutputConfig)
    debug: DebugConfig = Field(default_factory=DebugConfig)
    matrix: Optional[MatrixConfig] = Field(
        default=None,
        description="Optional overrides for IP.DAT matrix dimensions and cell size",
    )
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    analysis: Optional[MonteCarloAnalysisConfig] = None
    
    # v3.0 Analysis Configurations
    monte_carlo: MonteCarloConfig = Field(default_factory=MonteCarloConfig)
    discrete_analysis: DiscreteGridConfig = Field(default_factory=DiscreteGridConfig)

    @field_validator("warheads", "targets")
    @classmethod
    def _require_items(cls, value: List) -> List:
        if not value:
            raise ValueError("At least one entry required")
        return value
