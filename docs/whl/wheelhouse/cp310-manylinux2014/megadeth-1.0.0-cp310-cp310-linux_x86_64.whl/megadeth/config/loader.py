from __future__ import annotations

import os
import re
from collections.abc import Mapping, MutableMapping, MutableSequence
from pathlib import Path
from typing import Any

import yaml

from .schema import CampaignConfig

_DEFAULT_ENV_PATTERN = re.compile(r"\$\{([^}:]+):-([^}]+)\}")


def _expand_env_vars(obj: Any) -> Any:
    """Recursively expand environment variables and user paths.

    Supports shell-style defaults of the form ``${VAR:-fallback}``.
    """

    if isinstance(obj, str):
        # Handle ${VAR:-fallback} manually before deferring to expandvars
        def _replace(match: re.Match[str]) -> str:
            var = match.group(1)
            default = match.group(2)
            val = os.getenv(var)
            return val if val is not None else default

        expanded = _DEFAULT_ENV_PATTERN.sub(_replace, obj)
        return os.path.expandvars(os.path.expanduser(expanded))

    if isinstance(obj, MutableMapping):
        return {k: _expand_env_vars(v) for k, v in obj.items()}

    if isinstance(obj, MutableSequence):
        return [
            _expand_env_vars(v)  # type: ignore[list-item]
            for v in obj
        ]

    return obj


def _validate(model_cls, data: Mapping[str, Any]) -> CampaignConfig:
    """Compatibility helper for Pydantic v1/v2 validation."""
    if hasattr(model_cls, "model_validate"):
        return model_cls.model_validate(data)  # type: ignore[attr-defined]
    return model_cls.parse_obj(data)  # type: ignore[call-arg]


def load_config(path: str | Path) -> CampaignConfig:
    """Load and validate a YAML campaign config file."""
    path = Path(path)
    raw = yaml.safe_load(path.read_text())
    if raw is None:
        raise ValueError(f"Config file {path} is empty")
    return _validate(CampaignConfig, _expand_env_vars(raw))


def load_config_string(data: str) -> CampaignConfig:
    """Validate a YAML string representation of the config."""
    raw = yaml.safe_load(data)
    if raw is None:
        raise ValueError("Config string is empty")
    return _validate(CampaignConfig, _expand_env_vars(raw))


def config_to_dict(config: CampaignConfig | Mapping[str, Any]) -> Mapping[str, Any]:
    """Convert a CampaignConfig to a plain dict for downstream consumers."""
    if isinstance(config, CampaignConfig):
        if hasattr(config, "model_dump"):
            return config.model_dump()
        return config.dict()
    return dict(config)
