
C                                                                       
      PROGRAM MATERIEL                                                  
C                                                                       
C--------------------------------------------------------------------   
C                                                                       
C DESCRIPTIN:  This is the General Full Spray Materiel MAE              
C              (Lethal Area) Program.  Significant revisions            
C              include options for burial, terrain, strips,             
C              revetments, and mounds.  See the User and Analyst        
C              Manual for detailed descriptions.                        
C                                                                       
C--------------------------------------------------------------------   
C Subroutines Called                                                    
C                                                                       
C MAIN                                                                  
C                                                                       
C--------------------------------------------------------------------   
                                                                        
      CALL MAIN                                                         
      STOP                                                              
      END                                                               
C-----------------------------------------------------------------------
C                                                                       
      SUBROUTINE BEGIN                                                  
C                                                                       
C-----------------------------------------------------------------------
C DESCRIPTION:  The purpose of this subroutine is to read the input,    
C               one case at a time, and set the necessary indicators    
C               for the selected options.  A complete description of    
C               record formats is contained in Volume 1, Users Manual.  
C                                                                       
C NOTE:  When referencing revetments, the terms uprange and downrange   
C        are as shown below.  Direction of weapon trajectory is from    
C        uprange to downrange.                                          
C         _____                   _____                                 
C        /     \                 /     \                                
C       /       \_______________/       \                               
C        uprange                downrange                               
C                                                                       
C VARIABLES:                                                            
C     Name          Units                  Definition                   
C ---------------  -------  --------------------------------------------
C A1(I)            ft/sec   I=1, JC1.  Initial velocity of the fragments
C                           at the lower boundary of the ith static     
C                           zone.                                       
C                                                                       
C A2(I)            ft/sec   I=1, JC1. Initial velocity of the fragments 
C                           at the middle of the ith static zone.       
C                                                                       
C A3(I)            ft/sec   I=1, JC1.  Initial velocity of the fragments
C                           at the upper boundary of the ith static     
C                           zone.                                       
C                                                                       
C ACTR               ft     Distance in the ground plane from the impact
C                           point to a perpendicular line drawn from the
C                           uprange interior top corner of the revetment
C                           to the ground plane.  This distance is used 
C                           to calculate the cutoff angle in subroutine 
C                           MAIN.                                       
C                                                                       
C AHPR               deg    Angle formed by the weapon trajectory       
C                           extended to the ground and the revetment    
C                           side impacted.  Used when the weapon impacts
C                           the downrange revetment wall.               
C                                                                       
C AMAN               --     Number of fragment masses in target         
C                           vulnerability table.                        
C                                                                       
C AMASS(I)         grains   I=1, IVAL.  Fragment masses in the cutoff   
C                           velocity vs fragment weight table.          
C                                                                       
C ANAM               --     Used to read input record name.             
C                                                                       
C ANELA              --     Number of elevation angles in target        
C                           vulnerability table.                        
C                                                                       
C ANVLE              --     Number of velocities in target vulnerability
C                           table.                                      
C                                                                       
C AUR                ft     The distance along the revetment wall from  
C                           the weapon impact point to the ground.  Used
C                           for revetted targets when the weapon impacts
C                           the downrange revetment wall.               
C                                                                       
C AVNZRO             --     Indicator:                                  
C                             0.0 - Vulnerable areas averaged over all  
C                                   computed azimuths.                  
C                             1.0 - Vulnerable areas averaged over only 
C                                   nonzero computed azimuths.          
C                                                                       
C B1(I)             deg     I=1, JC1.  Angle defining the lower boundary
C                           of the ith static zone.                     
C                                                                       
C B2(I)             deg     I=1, JC1.  Angle defining the middle        
C                           boundary of the ith static zone.            
C                                                                       
C B3(I)             deg     I=1, JC1.  Angle defining the upper boundary
C                           of the ith static zone.                     
C                                                                       
C C2               ft/sec   Velocity of munition at detonation.         
C                                                                       
C C3               ft/sec   Constant cutoff velocity.                   
C                                                                       
C CFD(I,J)           --     J=1, NCDP; I=1, NHDT.  Drag coefficient for 
C                           fragments, jth velocity, ith altitude.      
C                                                                       
C CGRAV              ft     Centroid of partially buried weapon.        
C                                                                       
C CIC(I)             --     I=1, JC1.  Number of weight groups in the   
C                           ith static fragment zone.                   
C                                                                       
C CKQ                --     Shape factor for the fragments.             
C                           Units are:  ft^(2)gr^(1/3)/lb               
C                                                                       
C CNDG               --     Number of matrix cells in deflection.       
C                                                                       
C CNHD               --     Total number of altitudes used in the drag  
C                           table.                                      
C                                                                       
C CNRG               --     Number of matrix cells in range.            
C                                                                       
C CNTR               ft     Range grid coordinate of the center of the  
C                           matrix.                                     
C                                                                       
C CNVD               --     Total number of velocities used in the drag 
C                           table.                                      
C                                                                       
C COOPTN             --     Cutoff velocity option name.                
C                                                                       
C COTM             grains   The fragment cutoff mass. The smallest      
C                           fragment size that will contribute to a     
C                           target kill.                                
C                                                                       
C COV(I)           ft/sec   I=1, IVAL.  Fragment velocities below which 
C                           no damage will occur for the ith fragment   
C                           weight.                                     
C                                                                       
C CWR                --     Cosine of the weapon impact angle.          
C                                                                       
C D0K                ft     Distance beyond which a fire kill will not  
C                           occur.                                      
C                                                                       
C D1(I,J)            --     I=1, IC2(J); J=1, JC1.  Number of fragments,
C                           ith weight group, jth  static zone.         
C                                                                       
C D1I(I)             --     I=1, JC1.  Temporary storage for D1(1,J),   
C                           number of static zones for 1st weight group.
C                                                                       
C D1K                ft     Maximum distance at which a fire kill will  
C                           occur with a probability of 1.0, given      
C                           sufficient fuel leakage.                    
C                                                                       
C D2(I,J)          grains   I=1, IC2(J); J=1, JC1.  Fragment weight,    
C                           ith weight group, jth  static zone.         
C                                                                       
C DA                 ft     If NRAD = 1 or 3, DA= Matrix cell size in   
C                                  deflection.                          
C                                                                       
C DAR(I)             ft     I=1, NDGP.  Ith deflection grid             
C                           coordinate.                                 
C                                                                       
C DEAD               ft     Dead zone - area inside of the revetment    
C                           that the weapon cannot physically impact.   
C                           If DEAD = 0, there is no dead zone inside of
C                           the revetment.                              
C                                                                       
C DEG2RAD            --     Constant.  PI/180.  Degrees to radians      
C                           conversion.                                 
C                                                                       
C DOTEND             --     Filename extension for RCAS and INTRVC disk 
C                           files (read as unit 12):                    
C                                .ROB - Red-on-Blue files               
C                                .DAT - NOT Red-on-Blue files           
C                                                                       
C DRAG               --     Drag data file code.                        
C                                                                       
C DRAGTYP            --     Drag option name.                           
C                                                                       
C DTD                ft     Distance from target to dead zone for       
C                           revetted targets.  DTD is negative if the   
C                           target is included in the dead zone.        
C                                                                       
C FELE(I)           deg     I=1, FNELA.  Elevation angles in fire       
C                           effects table.                              
C                                                                       
C FMAN               --     Number of fragment masses in fire effects   
C                           table.                                      
C                                                                       
C FNELA              --     Number of elevation angles in fire effects  
C                           table.                                      
C                                                                       
C FNVLE              --     Number of fragment velocities in fire       
C                           effects table.                              
C                                                                       
C FPPA(I,J,K)        --     I=1,KNELA ; J=1,KMAN ; K=1,KNVLE.           
C                           Probability of exposure for fire effects,   
C                           ith elevation, jth weight group, kth        
C                           velocity.                                   
C                                                                       
C FRACT              --     Temporary variable used in the calculation  
C                           of computed cutoff velocity, WZ4.           
C                                                                       
C FRAGOPT            --     Indicator:                                  
C                             0 - Frags considered in direct hit area.  
C                             1 - Frags NOT considered in direct hit    
C                                 area.                                 
C                                                                       
C FVLE(I)          ft/sec   I=1,KNVLE.  Fragment velocities in fire     
C                           effects tables.                             
C                                                                       
C FXMA(I)          grains   I=1,KMAN.  Fire effects tables for fragment 
C                           weights.                                    
C                                                                       
C FZA(I,J,K)       sq ft    I=1,KNELA ; J=1,KMAN ; K=1,KNVLE.           
C                           Average-vulnerable-area data for fire       
C                           effects, ith elevation, jth weight group,   
C                           kth velocity.                               
C                                                                       
C HDT(I)             ft     I=1, NHD.  The lower altitude limit for the 
C                           ith layer of medium.                        
C                                                                       
C HPR                ft     The ground distance from the inside edge of 
C                           the revetment base to the projected impact  
C                           point on the ground assuming a straight     
C                           trajectory. Used for revetted targets when  
C                           the weapon impacts the downrange revetment  
C                           wall.                                       
C                                                                       
C IC2(I)             --     I=1, JC1.  Number of weight groups in the   
C                           ith static zone.                            
C                                                                       
C IDEAD              ft     Indicator :                                 
C                             TRUE  - A dead zone exists.               
C                             FALSE - A dead zone does NOT exist.       
C                           Dead zone is the area of the mound that the 
C                           weapon cannot physically reach.             
C                                                                       
C IDHT               --     Indicator :                                 
C                             TRUE  - Direct-hit option used.           
C                             FALSE - Direct-hit option NOT used.       
C                                                                       
C IFIRE              --     Indicator :                                 
C                             TRUE - fire option used.                  
C                             FALSE - fire option NOT used.             
C                                                                       
C INDC               --     Indicator :                                 
C                              0 - NOT single centroid target           
C                              1 - Single centroid target               
C                                                                       
C INELA              --     Array index.  Number of elevation angles in 
C                           RCAS file multiplied by the number of       
C                           centers of vulnerability for fragments for  
C                           strips (maximum is 132).                    
C                                                                       
C INTRVC             --     Code for cutoff velocity file.              
C IOUT               --     Indicator:                                  
C                             TRUE  - Warhead fragmentation data will be
C                                     printed (option OUTP).            
C                             FALSE - Warhead fragmentation data will   
C                                     NOT be printed.                   
C                                                                       
C IP                 --     Indicator in record set 1:                  
C                             Blank - Short output option.              
C                             Non-blank - Long output option.           
C                                                                       
C IPQF               --     Indicator used with fire option:            
C                             0 - Compute fire effective distances,     
C                                 D1K and D0K, in program.              
C                             1 - Read D1K and D0K as input.            
C                                                                       
C IPRWT              --     Indicator:                                  
C                             0 - COTM or ZDATA options NOT selected.   
C                             1 - COTM or ZDATA options selected.       
C                                                                       
C IRV                --     Indicator :                                 
C                             TRUE  - revetment has a dead zone.        
C                             FALSE - NO dead zone in revetment.        
C                                                                       
C ITAR               --     Target Code : used to construct the disk    
C                           filename for RCAS, FIRE and INTRVC options. 
C                                                                       
C TERAIN             --     Indicator :                                 
C                             TRUE - Terrain shielding option is used.  
C                             FALSE - Terrain shielding option is NOT   
C                                     used.                             
C                                                                       
C ITRAP              --     Indicator :                                 
C                             0 - Simpson's integration is used.        
C                             1 - Trapezoidal integration is used.      
C                                                                       
C IVAL               --     Number of fragment weights read from second 
C                           record of INTRVC file.  Array index for     
C                           fragment masses array, AMASS, and fragment  
C                           velocity array, COV.                        
C                                                                       
C IW                 --     Weapon code read from ZDATA and WPNDRAG     
C                           files.  Verifies correct file is opened.    
C                                                                       
C JC1                --     Total number of static fragmentation zones. 
C                                                                       
C JCX                --     Number of warhead segments for buried run.  
C                                                                       
C JR                 --     Indicator used to attach correct ZDATA file:
C                             JR = A for A/S run; S for S/S run.  This  
C                                  is for JTCG/ME production runs.      
C                             JR = blank.  This is for the general user 
C                                  whose data files will be named:      
C                                  ZDATA(weapon code).DAT               
C                                  RCAS(target code).DAT                
C                                  (drag name)(drag code).DAT           
C                                  INTRVC(target code).DAT              
C                                  FIRE(target code).DAT                
C                                                                       
C KKCT               --     Upper bound array indicator for variable    
C                           TEMPVAL.  Used to construct filenames when  
C                           JR is blank.                                
C                                                                       
C KLBUR              --     Indicator :                                 
C                             TRUE  - Weapon buried.                    
C                             FALSE - Weapon NOT buried.                
C                                                                       
C KMAN               --     Array index, KMAN = FMAN.                   
C                                                                       
C KNELA              --     Array index, KNELA = FNELA.                 
C                                                                       
C KNVLE              --     Array index, KNVLE = FNVLE.                 
C                                                                       
C MAN                --     Array index, MAN = AMAN.                    
C                                                                       
C MATZ               --     Indicator :                                 
C                             TRUE - Compute lethal areas and output    
C                                 matrix.                               
C                             FALSE - Compute only lethal areas.        
C                                                                       
C MCUT               --     Number of integration radii desired to cut  
C                           through each cell of the matrix (set to 2   
C                           if input as 0).                             
C                                                                       
C MOSK               --     Indicator :                                 
C                             1 - Matrix is NOT output to file.         
C                             2 - Matrix is output to file.             
C                                                                       
C MOUNDOPT           --     Indicator :                                 
C                             TRUE  - Target is on a mound.             
C                             FALSE - Target is NOT on a mound.         
C                                                                       
C MT7                --     Indicator :                                 
C                             TRUE - Use cutoff velocity computed or    
C                                    input.                             
C                             FALSE - Use constant cutoff velocity.     
C                                                                       
C NAME               --       Title for each case of the job.           
C                             (1:30)  : identification of run           
C                             (61:65) : R/B for Red on Blue - or -      
C                                       BM/AS for Basic Manual - or -   
C                                       LAR for Lethal Area Report      
C                                                                       
C NCDP               --     Number of velocity values in the drag curve.
C                                                                       
C ND                 --     Indicator :                                 
C                             1 - Store PK for an arc increment versus  
C                                 ground range r in the ZZ array.       
C                             2 - Do NOT store PK for an arc increment  
C                                 versus ground range r.                
C                                                                       
C NDCLS              --     Indicator :                                 
C                             TRUE  - ARCS option was selected.         
C                             FALSE - ARCS option was NOT selected.     
C                                                                       
C NDG                --     Number of cells in deflection.              
C                                                                       
C NDGP               --     Total number of deflection grid coordinates.
C                                                                       
C NDON               --     Indicator :                                 
C                             0 - Cell size is to be computed given the 
C                                 number of cells.                      
C                             1 - Number of cells is to be computed     
C                                 given the cell size.                  
C                                                                       
C NELA               --     Array index, NELA = ANELA.  Number of       
C                           elevation angles in target vulnerability    
C                           table.                                      
C                                                                       
C NEWLFN             --     Stores the filenames of the data files for  
C                           the following options: ZDATA, RCAS, WPNDRAG,
C                           INTRVC, and TGTFIRE.                        
C                                                                       
C NHD                --     Array index, NHD = NHDT = CNHD (total number
C                           of altitudes in drag tables) when NOT CDRAG 
C                           option.                                     
C                                                                       
C NHDT               --     Number of heights associated with the drag  
C                           table.  Set to 1 for CDRAG option.          
C                                                                       
C NMAZ               --     Indicator :                                 
C                             0 - One integration pass through the      
C                                 program is needed (no matrix to be    
C                                 computed).                            
C                             1 - Two integration passes through the    
C                                 program are required (matrix to       
C                                 be computed).                         
C                                                                       
C NNNN               --     Indicator :                                 
C                             TRUE  - COTM option has been selected.    
C                             FALSE - COTM option has NOT been selected.
C                                                                       
C NQ                 --     Indicator :                                 
C                             1 - Multiple centroid target.             
C                             2 - Single centroid target.               
C                                                                       
C NRAD               --     Indicates the option selected in option     
C                           MATRIX :                                    
C                             1 - Read in cell dimensions and center of 
C                                 matrix.                               
C                             2 - Compute cell dimensions and center of 
C                                 matrix given number of cells.         
C                             3 - Compute the number of cells necessary 
C                                 to cover the effective area of the    
C                                 munition given the cell dimensions.   
C                             4 - Read in the coordinates of the cells. 
C                                                                       
C NRG                --     Number of matrix cells in range.            
C                                                                       
C NRGP               --     Total number of range grid coordinates.     
C                                                                       
C NT7                --     Indicator :                                 
C                             TRUE  - Store PK for each ground range r. 
C                             FALSE - Do NOT store PK for each ground   
C                                   range r.                            
C                                                                       
C NT9                --     Indicator :                                 
C                             TRUE  - Drag curve has been input for this
C                                     case.                             
C                             FALSE - Drag curve has NOT been input for 
C                                     this case.                        
C                                                                       
C NTPX               --     Number of target fragment centroids.        
C                           When NTPX > 1, Q41(NTPX+1) contains the     
C                           overall target centroid.                    
C                                                                       
C NTRE               --     Indicator to select a particular exposure   
C                           function for the TRES option :              
C                             0 - Environmental shielding NOT desired.  
C                             1 - Temperate forest.                     
C                             2 - Tropical rain forest.                 
C                                                                       
C NUMOUT             --     Index to control number of columns per line 
C                           when writing vulnerable areas to output.    
C                                                                       
C NVLE               --     Array index, NVLE = ANVLE.                  
C                                                                       
C NWC1               --     Indicator :                                 
C                             TRUE - New velocity data have been input. 
C                             FALSE - New velocity data have NOT been   
C                                    input.                             
C                                                                       
C NWC2               --     Indicator :                                 
C                             TRUE - New fragmentation data have been   
C                                    input.                             
C                             FALSE - New fragmentation data have NOT   
C                                    been input.                        
C                                                                       
C NYN                --     Indicator :                                 
C                             TRUE - Blast effects to be calculated.    
C                             FALSE - Blast NOT effective (no           
C                                    calculation).                      
C                                                                       
C NYN1               --     Indicator used to reset NYN in subroutine   
C                           MAIN :                                      
C                             0 - When NO BLT option is encountered.    
C                             1 - When BLT option is first encountered  
C                                 (remains 1 throughout entire run      
C                                 regardless of whether another BLT     
C                                 record is encountered).               
C                                 Blast effects are to be considered.   
C                                                                       
C PBH                ft     Weapon burst height.                        
C                                                                       
C PF(I)              ft     I=1, JCX.  Location of each segment on a    
C                           buried warhead.  PF(1) is the location of   
C                           the nose.                                   
C                                                                       
C PKH                --     Probability of kill, given a hit, for the   
C                           direct-hit option                           
C                                                                       
C Q41(I)             ft     I=1,NTPX.  Target heights representing      
C                           centers of vulnerability to fragments.      
C                                                                       
C Q41R(I)            ft     I=1,NTPX.  Fragment centroid for target     
C                           on a mound.  Used to adjust Q41(I) to       
C                           include mound height.                       
C                                                                       
C Q43                ft     Burst height of the munition.               
C                                                                       
C Q43R               ft     Same as Q43.  Used to restore Q43 for the   
C                           next interation pass in subroutine MAIN.    
C                                                                       
C Q6                deg     Weapon impact angle.                        
C                                                                       
C QAV                ft     Height of target centroid for blast.        
C                                                                       
C QAVR               ft     Height of target centroid for a target on   
C                           a mound.  QAVR  is used to adjust QAV to    
C                           include mound height.                       
C                                                                       
C R1                 --     Correction factor in option CORR used to    
C                           increase or decrease the total warhead      
C                           weight.                                     
C                                                                       
C R2                deg     Cutoff angle for fragments.                 
C                                                                       
C RA                 ft     If NRAD = 1 or 3, RA =  Matrix cell size    
C                           in range.                                   
C                                                                       
C RAD2DEG            --     Constant.  180/PI. Radians to degrees       
C                           conversion.                                 
C                                                                       
C RAR(I)             ft     I=1,NRGP.  Ith range grid coordinate.       
C                                                                       
C RB1                ft     Maximum distance from burst that PKB = 1.0  
C                           (PKB is probability of kill due to blast).  
C                                                                       
C RB11               ft     Set equal to RB1 but used as a testing      
C                           variable.                                   
C                                                                       
C RB2                ft     Minimum distance from burst that PKB = 0.0  
C                           (PKB is probability of kill due to blast).  
C                                                                       
C RCAS               --     Code for target vulnerable area file.       
C                                                                       
C RBIND              --     Indicator for proper ZDATA file selection   
C                           (set based upon columns 61-65 in the title  
C                           record):  'R' - Red-on-Blue files selected; 
C                                     'Z' - non ROB files selected.     
C                                                                       
C RD1                ft     Direct hit radius for direct hit weapons.   
C                           For revetted targets, RD1 is the equivalent 
C                           target size in the ground plane or presented
C                           area at 90 degrees converted to a radius.   
C                                                                       
C REC1               --     Contains the indicator code name from the   
C                           first line of the data files accessed for   
C                           the RCAS, ZDATA, WPNDRAG, INTRVC, and FIRE  
C                           options.                                    
C                                                                       
C REC2               --     Contains the indicator code name from the   
C                           second line of the data files accessed for  
C                           the RCAS, ZDATA, WPNDRAG, INTRVC, and FIRE  
C                           options.                                    
C                                                                       
C REVA              deg     Interior angle formed by the sloped face and
C                           base of the revetment or mound.             
C                                                                       
C REVBAS             ft     Width of revetment base or radius of mound  
C                           base.                                       
C                                                                       
C REVDIS             ft     Distance from inside edge of revetment      
C                           bottom to target center.                    
C                                                                       
C REVHT              ft     Height of revetment or mound.               
C                                                                       
C REVSLP             ft     Distance on the ground from the base edge to
C                           the top edge of the revetment or mound.     
C                                                                       
C REVTOP             ft     Width of revetment top or radius of mound   
C                           top.                                        
C                                                                       
C REVTOT             ft     Distance on the ground from the target to   
C                           the top edge of the revetment.              
C                                                                       
C RF(I)              ft     I=1,JCX.  Radius of each warhead segment for
C                           buried run.                                 
C                                                                       
C RHO(I)           lb/ft3   I=1,NHD.  Density of medium for the ith     
C                           altitude                                    
C                                                                       
C ROP                --     Indicator :                                 
C                             TRUE  - Target is revetted.               
C                             FALSE - Target is NOT revetted.           
C                                                                       
C RTRAJ             deg     Impact angle read from revetment card.      
C                                                                       
C SKT(I)             --     I=1,NHD.  SKT(I)=CKQ.  Fragment shape factor
C                           for the ith altitude obtained from the ZDATA
C                           records.                                    
C                                                                       
C SWR                --     Sine of the weapon impact angle.            
C                                                                       
C S1D                ft     Length of mound shadow in the ground        
C                           plane. Measured from the target location    
C                           to the end of the mound shadow.             
C                                                                       
C TELE(I)           deg     I=1,NELA.  Elevation angles in fragment kill
C                           table.                                      
C                                                                       
C TEMPVAL            --     Part of data file name.                     
C                                                                       
C TERAIN             --     Indicator:                                  
C                             TRUE - Terrain shielding option.          
C                             FALSE - NOT terrain shielding option.     
C                                                                       
C TGTHT              ft     Target height for direct-hit option.        
C                                                                       
C TGTNO              --     Target code read from RCAS, INTRVC, and     
C                           TGTFIRE files.  Verifies correct file       
C                           is opened.                                  
C                                                                       
C THE(I)            deg     I=1,JCX.  The angle of departure for the    
C                           fragments in each warhead segment for buried
C                           run.                                        
C                                                                       
C TPPA(I,J,K)        --     I=1,NELA; J=1,MAN; K=1,NVLE.  Probability   
C                           of exposure for fragment kill, ith          
C                           elevation, jth weight group, kth velocity.  
C                                                                       
C TVLE(I)          ft/sec   I=1,NVLE.  Fragment kill table, fragment    
C                           velocities.                                 
C                                                                       
C TXMA(I)          grains   I=1,MAN.  Fragment kill table, fragment     
C                           weights.                                    
C                                                                       
C TZA(I,J,K)       sq ft    I=1,132 (Max of 11 elevation angles/strip.  
C                           Max of 12 strips/target) ; J=1,14; K=1,18.  
C                           Average vulnerable area data for fragment   
C                           kill, ith elevation, jth weight group, kth  
C                           velocity.                                   
C                                                                       
C VALUE              --     Used to read value when a code name is      
C                           input.                                      
C                                                                       
C VCF(I)           ft/sec   I=1,NCDP.  Velocities found in the drag     
C                           table.                                      
C                                                                       
C WPENT             lbs     Equivalent Pentolite bare charge weight.    
C                           Used with fire kill option.                 
C                                                                       
C WZ4(I,J)         ft/sec   I=1,IC2(J); J=1,JC1.  Computed cutoff       
C                           velocity, ith weight group, jth static      
C                           fragment zone. Interpolated from given      
C                           fragment weight array, D2(), in the         
C                           vulnerability table.                        
C                                                                       
C XX                 ft     Used in revetted targets when the weapon    
C                           impacts the downrange revetment wall.  The  
C                           distance on the ground from the revetment   
C                           base to the weapon impact point on the      
C                           revetment.                                  
C                                                                       
C ZDATAID            --     Weapon code.                                
C-----------------------------------------------------------------------
C Subroutines called:                                                   
C                                                                       
C    BURINT                                                             
C-----------------------------------------------------------------------
C Functions called:                                                     
C                                                                       
C    None                                                               
C-----------------------------------------------------------------------
C Calling routine:                                                      
C                                                                       
C    MAIN                                                               
C-----------------------------------------------------------------------
C NOTE:  The units are read/written as follows:                         
C        Unit 6 - Output                                                
C        Unit 9 - Input stream                                          
C        Unit 12 - Disk                                                 
C                                                                       
C Set up dimension, character variable definition, and common statements
C for communication with other subroutines.                             
C                                                                       
      DIMENSION AMASS(25),COV(25),HOL(3),CIC(50)                        
      DIMENSION RF(50),PF(50),THE(50)                                   
      DIMENSION TH(50),BX(3),Q41R(13)                                   
C                                                                       
      CHARACTER*37 NEWLFN                                               
      CHARACTER*6 ANAM,REC1,REC2                                        
      CHARACTER*1 JR,RBIND                                              
      CHARACTER*5 ITAR,TEMPVAL,TGTNO,RCAS,INTRVC                        
      CHARACTER*4 DOTEND                                                
      CHARACTER*6 COOPTN,DRAGTYP                                        
C                                                                       
      LOGICAL IOUT,TERAIN,NDCLS,NT9,NWC1,NWC2                           
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
C                                                                       
      COMMON  / ALT1 /  COTM,D1I(50),IOUT,ND,NTRE,NT9,RATF(13)          
      COMMON  / ARCPT /  NDCLS                                          
      COMMON  / BBUR /  RPF1(50),RPF2(50),RPF3(50),PLF1(50),PLF2(50),   
     &       PLF3(50)                                                   
      COMMON  / BVNZRO /  AVNZRO                                        
      COMMON  / CBUR /  GMID                                            
      COMMON  / COSINE /  CWR,SWR                                       
      COMMON  / DIRHIT /  PKH,RD1,TGTHT,Q43R,FRAGOPT                    
      COMMON  / ICOTM /  IPRWT,IROB                                     
      COMMON  / MSIZE /  MCUT,ITRAP                                     
      COMMON  / NWC /  NWC1,NWC2                                        
      COMMON  / OUT1 /  PBH,RCAS,DRAG,INTRVC,ZDATAID                    
      COMMON  / OUT2 /  DRAGTYP,COOPTN                                  
      COMMON  / REV /  REVHT,REVSLP,REVTOT,ACTR,DTD,REVBAS,REVDIS,DEAD, 
     &       REVA,COFF,GONG,REVTOP,RTRAJ,LOSFRG,LOSBLT                  
      COMMON  / TER /  TERAIN                                           
                                                                        
C Initialize IPRWT to 0 (IPRWT indicates if option COTM or ZDATA is to  
C be selected.  Initialize NAME(46:46) to blank to indicate MAEF run.   
                                                                        
      IPRWT = 0                                                         
      NAME(46:46) = ' '                                                 
                                                                        
C If long output start a new page.                                      
                                                                        
      IF (IP .EQ. ' ') THEN                                             
         WRITE(6,5000)                                                  
      ELSE                                                              
         WRITE(6,5010)                                                  
      ENDIF                                                             
                                                                        
C Read record set 1, TITLE CARD.  If the code name RATS (record set 44) 
C is on this record, all data cases have been read and the program is   
C terminated.                                                           
                                                                        
      READ(9,5020)NAME,MCUT,ITRAP,IP,JR                                 
      IF (NAME(1:4) .EQ. 'RATS') THEN                                   
         CALL EXIT                                                      
      ENDIF                                                             
                                                                        
C Set indicators for the number of cuts through each cell, MCUT.        
                                                                        
      IF (MCUT .EQ. 0) MCUT = 2                                         
      IF (MCUT .GT. 1 .AND. IP .NE. ' ') WRITE(6,5030)MCUT              
                                                                        
C Read the next data record and check for record set 2, NTP.  If this   
C record is  present then set NTPX, the number of target centers of     
C vulnerability for fragments.  Read NTPX number of target centers of   
C vulnerability for fragments, Q41, from record set 3. Set Q41R and     
C read the next data record.                                            
                                                                        
      READ(9,5040)ANAM,VALUE,ITAR                                       
      IF (ANAM .EQ. 'NTP') THEN                                         
         NTPX = INT(VALUE)                                              
         READ(9,5050)(Q41(J),J=1,NTPX)                                  
         DO 10 J=1,NTPX                                                 
            Q41R(J) = Q41(J)                                            
 10      CONTINUE                                                       
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 4, option 1, STRIPS, or option 2, SPTM.          
C Read the single point target centroid for strip targets,              
C option 1, from record set 5.  Set indicator NQ and read the next      
C data record.                                                          
                                                                        
      IF (ANAM .EQ. 'STRIPS') THEN                                      
         READ(9,5050)Q41(NTPX + 1)                                      
         WRITE(6,5060)(Q41(J),J=1,NTPX + 1)                             
         NQ = 1                                                         
         READ(9,5040)ANAM,VALUE,ITAR                                    
                                                                        
      ELSEIF (ANAM .EQ. 'SPTM') THEN                                    
         NQ = 2                                                         
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C **** PKT is the total probability of kill. ****                       
                                                                        
C Check for record set 6, options 1, 2, or 3.   If option 1, DNP, is    
C chosen, set indicator ND so PKT for an arc increment versus ground    
C range, r, will not be stored.  Set indicator NDCLS to show ARCS was   
C not selected, and set indicator NT7 so PKT for each r will not be     
C stored.  Read the next data record.                                   
                                                                        
      IF (ANAM .EQ. 'DNP') THEN                                         
         ND = 2                                                         
         NDCLS = .FALSE.                                                
         NT7 = .FALSE.                                                  
         READ(9,5040)ANAM,VALUE,ITAR                                    
                                                                        
C If option 2, ARCS, is chosen, set indicator ND to store PKT for an    
C arc increment versus ground range, r, in the ZZ array.  Set indicator 
C NDCLS to show ARCS was selected, and set indicator NT7 so that PKT for
C each r will not be stored.  Read the next data record.                
                                                                        
      ELSEIF (ANAM .EQ. 'ARCS') THEN                                    
         ND = 1                                                         
         NDCLS = .TRUE.                                                 
         NT7 = .FALSE.                                                  
         READ(9,5040)ANAM,VALUE,ITAR                                    
                                                                        
C If option 3, PKVSR, is chosen, set indicator ND so PKT for an arc     
C increment versus ground range, r, will not be stored, set NDCLS to    
C show ARCS was not selected and set NT7 so PKT for each r will be      
C stored.  Read the next data record.                                   
                                                                        
      ELSEIF (ANAM .EQ. 'PKVSR') THEN                                   
         ND = 2                                                         
         NDCLS = .FALSE.                                                
         NT7 = .TRUE.                                                   
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 7, PBH.  If this record is present, set the burst
C height, Q43.  Set Q43R so Q43 can be restored for the next iteration  
C pass in subroutine MAIN.  Set the burst height, PBH, which is         
C written in OUTZ.  Read the next data record.                          
                                                                        
      IF (ANAM .EQ. 'PBH') THEN                                         
         Q43 = VALUE                                                    
         Q43R = Q43                                                     
         PBH = VALUE                                                    
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 8, OMEGA.  If this record set is present, set    
C impact angle, Q6, compute the sine and cosine of the impact angle,    
C CWR and SWR.  Read the next data record.                              
                                                                        
      IF (ANAM .EQ. 'OMEGA') THEN                                       
         Q6 = VALUE                                                     
         CWR = COS(DEG2RAD * Q6)                                        
         SWR = SIN(DEG2RAD * Q6)                                        
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 9, VELM.    If this record set is present, set   
C the weapon velocity, C2, and indicator NWC1 to show a new velocity    
C was input.  Read the next data record.                                
                                                                        
      IF (ANAM .EQ. 'VELM') THEN                                        
         C2 = VALUE                                                     
         NWC1 = .TRUE.                                                  
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ELSE                                                              
                                                                        
C If this record set is not present, set indicator NWC1 to show no new  
C velocity was input.                                                   
                                                                        
         NWC1 = .FALSE.                                                 
      ENDIF                                                             
                                                                        
C Check for record set 10, CORR.  This option is used to increase or    
C decrease the total warhead case weight by scaling the number of       
C fragments.  If this record set is present, set the correction         
C factor, R1, and read the next data record.                            
                                                                        
      IF (ANAM .EQ. 'CORR') THEN                                        
         R1 = VALUE                                                     
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 11, BETA.  This option allows the input of a     
C cutoff angle to compute the maximum effective range for fragments in  
C subroutine DRRR.  If this record set is present, set the cutoff angle,
C R2, and read the next data record.                                    
                                                                        
      IF (ANAM .EQ. 'BETA') THEN                                        
         R2 = VALUE                                                     
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 12, ZDATA. If this record is present, set the    
C weapon code ZDATAID.                                                  
                                                                        
      IF (ANAM .EQ. 'ZDATA') THEN                                       
         ZDATAID = VALUE                                                
                                                                        
C If the BURIED option was previously turned on, it will be turned off  
C for a new weapon and a warning message will be written to output.     
                                                                        
         IF (KLBUR) THEN                                                
            WRITE(6,5460)'BURIED OPTION TURNED OFF'                     
            KLBUR = .FALSE.                                             
         ENDIF                                                          
                                                                        
C Define parameters to open the ZDATA file.  Variable NEWLFN defines    
C the filename to use.                                                  
                                                                        
         WRITE(TEMPVAL,5070)INT(ZDATAID)                                
         KKCT = 1                                                       
         DO 20 KK=1,5                                                   
            IF (TEMPVAL(KK:KK) .EQ. ' ') THEN                           
               TEMPVAL(KK:KK) = '0'                                     
               KKCT = KKCT + 1                                          
            ENDIF                                                       
 20      CONTINUE                                                       
         IF (NAME(61:61) .EQ. 'R') THEN                                 
            RBIND = 'R'                                                 
         ELSE                                                           
            RBIND = 'Z'                                                 
         ENDIF                                                          
         NEWLFN = ' users:[OSULIB.DATA.ZDATA]' // RBIND // JR //        
     &            TEMPVAL(2:5) // '.DAT'                                
         IF (JR .EQ. ' ') NEWLFN = 'ZDATA' // TEMPVAL(KKCT:5) // '.DAT' 
         OPEN(12,FILE=NEWLFN,STATUS='OLD',READONLY)                     
                                                                        
C Test to verify the opened ZDATA file contains the correct data. Read  
C the first two records from ZDATA file.                                
                                                                        
         READ(12,5080)REC1,IW,TGTNO                                     
         READ(12,5090)REC2,VALUE                                        
         IF ((REC1 .NE. ANAM) .OR. (IW .NE. INT(ZDATAID))) THEN         
            WRITE(6,5100)'ZDATA'                                        
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
         IF (IP .NE. ' ') WRITE(6,5260)NAME,ANAM,IW,INT(VALUE)          
         IF (IP .NE. ' ') WRITE(6,5290)                                 
                                                                        
C Set the number of static zones, JC1. Set NWC2 to show that a new      
C set of fragmentation data was input. Set IPRWT to indicate            
C option ZDATA was selected.                                            
                                                                        
         JC1 = INT(VALUE)                                               
         IF (JC1 .GT. 50) THEN                                          
            WRITE(6,5110)'NUMBER OF FRAG ZONES TOO LARGE'               
            CALL EXIT                                                   
         ENDIF                                                          
         NWC2 = .TRUE.                                                  
         IPRWT = 1                                                      
                                                                        
C Read the records composing record set 12.  Arrays A1, A3, and A2      
C are static zone velocities and the IC2 array is set to the number     
C of weight groups in the jth static zone. Arrays D1, the number of     
C fragments, and D2, the fragment weights, are sorted from largest      
C to smallest as they are input.  Store the number of fragments for     
C the first weight group in each zone in array D1I.                     
                                                                        
         DO 40 J=1,JC1                                                  
            READ(12,5120)B1(J),B3(J),B2(J),A1(J),A3(J),A2(J),CIC(J)     
            IC2(J) = INT(CIC(J))                                        
            IF (IC2(J) .GT. 180) THEN                                   
               WRITE(6,5110)'NUMBER OF FRAG WEIGHT CLASSES TOO LARGE'   
               CALL EXIT                                                
            ENDIF                                                       
            READ(12,5120)(D2(N,J),N=IC2(J),1, - 1)                      
            READ(12,5120)(D1(N,J),N=IC2(J),1, - 1)                      
                                                                        
            IF (IP .NE. ' ') WRITE(6,5300)B1(J),B3(J),B2(J),A1(J),A3(J),
     &                                       A2(J),CIC(J),D2(IC2(J),J), 
     &                                       D1(IC2(J),J)               
            IF (IP .NE. ' ') THEN                                       
               DO 30 N=2,IC2(J)                                         
                  WRITE(6,5310)D2(IC2(J) - N + 1,J),D1(IC2(J) - N + 1,  
     &                         J)                                       
 30            CONTINUE                                                 
            ENDIF                                                       
            IF (IP .NE. ' ') WRITE(6,'('' '')')                         
            D1I(J) = D1(1,J)                                            
 40      CONTINUE                                                       
         IF (IP .NE. ' ') WRITE(6,'(''1'')')                            
                                                                        
C Read the shape factor, CKQ, and the equivalent Pentolite bare         
C charge weight, WPENT.                                                 
                                                                        
         READ(12,5120)CKQ                                               
         READ(12,5120)WPENT                                             
                                                                        
C ** NOTE -- The maximum index size for array SKT is the same as NHD.   
C NDH is set past the following loop and cannot be used as a loop       
C control.  Change loop control index if NHD value changes. **          
                                                                        
         DO 50 I=1,10                                                   
                                                                        
C Set array SKT equal to the shape factor, CKQ, for each altitude in the
C drag table.                                                           
                                                                        
            SKT(I) = CKQ                                                
 50      CONTINUE                                                       
                                                                        
C If the fragment velocities within a  zone are 0.0, then set them equal
C to 1.0. Close ZDATA file.  Read the  next data record.                
                                                                        
         DO 60 J=1,JC1                                                  
            IF (A1(J) .EQ. 0.0) A1(J) = 1.0                             
            IF (A2(J) .EQ. 0.0) A2(J) = 1.0                             
            IF (A3(J) .EQ. 0.0) A3(J) = 1.0                             
 60      CONTINUE                                                       
         CLOSE(12)                                                      
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ELSE                                                              
                                                                        
C Set indicator NWC2 to show no new fragmentation data was input.       
                                                                        
         NWC2 = .FALSE.                                                 
      ENDIF                                                             
                                                                        
C Check for record set 13, RCAS.  If it is present, set the target      
C vulnerable area code, RCAS, which is written in OUTZ.                 
                                                                        
      IF (ANAM .EQ. 'RCAS') THEN                                        
         RCAS = ITAR                                                    
                                                                        
C If the FIRE, REVET, MOUND, TRES, or TER options were previously       
C turned on, they will be turned off for a new target and a warning     
C message will be written to output.                                    
                                                                        
         IF (IFIRE) THEN                                                
            WRITE(6,5460)'FIRE OPTION TURNED OFF'                       
            IFIRE = .FALSE.                                             
         ENDIF                                                          
         IF (ROP) THEN                                                  
            WRITE(6,5460)'REVET OPTION TURNED OFF'                      
            ROP = .FALSE.                                               
         ENDIF                                                          
         IF (MOUNDOPT) THEN                                             
            WRITE(6,5460)'MOUND OPTION TURNED OFF'                      
            MOUNDOPT = .FALSE.                                          
         ENDIF                                                          
         IF (NTRE .NE. 0) THEN                                          
            WRITE(6,5460)'ENVIRONMENTAL SHIELDING OPTION TURNED OFF'    
            NTRE = 0                                                    
         ENDIF                                                          
         IF (TERAIN) THEN                                               
            WRITE(6,5460)'TERRAIN SHIELDING OPTION TURNED OFF'          
            TERAIN = .FALSE.                                            
         ENDIF                                                          
                                                                        
C Parameters defined to open the RCAS file.                             
                                                                        
         TEMPVAL = ITAR                                                 
         KKCT = 1                                                       
         DO 80 KK=1,5                                                   
            IF (TEMPVAL(KK:KK) .EQ. ' ') THEN                           
               TEMPVAL(KK:KK) = '0'                                     
               KKCT = KKCT + 1                                          
            ENDIF                                                       
 80      CONTINUE                                                       
                                                                        
         DOTEND = '.DAT'                                                
         IF (NAME(61:61) .EQ. 'R') DOTEND = '.ROB'                      
                                                                        
         NEWLFN = ' users:[OSULIB.DATA.RCAS]RCS' // TEMPVAL(3:5) //     
     &            DOTEND                                                
         IF (JR .EQ. ' ') NEWLFN = 'RCAS' // TEMPVAL(KKCT:5) // '.DAT'  
         OPEN(12,FILE=NEWLFN,STATUS='OLD',READONLY)                     
                                                                        
C Test to verify the opened RCAS file contains the correct data. Read   
C the first two records from RCAS file.                                 
                                                                        
         READ(12,5080)REC1,IW,TGTNO                                     
         READ(12,5090)REC2,VALUE                                        
         IF ((REC1 .NE. ANAM) .OR. (TGTNO .NE. ITAR)) THEN              
            WRITE(6,5100)'RCAS'                                         
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C Read the number of elevation angles, ANELA, the number of fragment    
C weights, AMAN, the number of fragment velocities, ANVLE, and whether  
C the vulnerable areas are averaged over all azimuths or over only      
C nonzero computed azimuths, AVNZRO.  Write averaging method and test   
C to guarantee the array sizes are not exceeded.                        
                                                                        
         READ(12,5120)ANELA,AMAN,ANVLE,AVNZRO                           
                                                                        
         NELA = INT(ANELA)                                              
         MAN = INT(AMAN)                                                
         NVLE = INT(ANVLE)                                              
         IF (IP .NE. ' ') THEN                                          
            WRITE(6,5350)ANAM,ITAR                                      
            IF (INT(AVNZRO) .EQ. 1) WRITE(6,5370)                       
            IF (INT(AVNZRO) .EQ. 0) WRITE(6,5380)                       
            WRITE(6,5360)NELA,MAN,NVLE                                  
         ENDIF                                                          
         IF (ANELA .GT. 11.0 .OR. AMAN .GT. 15.0 .OR. ANVLE .GT. 18.0)  
     &       THEN                                                       
            WRITE(6,5110)'TARGET VA TABLE EXCEEDS PROGRAM DIMENSIONS'   
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C Read the records composing record set 13.  Read the elevation         
C angles, TELE, fragment weights, TXMA, fragment velocities, TVLE,      
C average vulnerable areas, TZA, and probabilities of exposure, TPPA.   
                                                                        
         READ(12,5050)(TELE(J),J=1,NELA)                                
         READ(12,5050)(TXMA(J),J=1,MAN)                                 
         READ(12,5050)(TVLE(J),J=1,NVLE)                                
                                                                        
         IF (NVLE .LT. 10) THEN                                         
            NUMOUT = NVLE                                               
         ELSE                                                           
            NUMOUT = NVLE / 2                                           
         ENDIF                                                          
                                                                        
C Read TZA and TPPA for strips.                                         
                                                                        
         IF (NQ .EQ. 1) THEN                                            
            INELA = NTPX * NELA                                         
            IF (INELA .GT. 132) THEN                                    
               WRITE(6,5110)'TARGET VA TABLE EXCEEDS DIMENSIONS'        
               CALL EXIT                                                
            ENDIF                                                       
            DO 100 J=1,INELA                                            
               DO 90 K=1,MAN                                            
                  READ(12,5050)(TZA(J,K,L),L=1,NVLE)                    
 90            CONTINUE                                                 
 100        CONTINUE                                                    
                                                                        
            DO 160 M=1,NTPX                                             
               DO 120 J=1,NELA                                          
                  DO 110 K=1,MAN                                        
                     READ(12,5050)(TPPA(J,K,L),L=1,NVLE)                
 110              CONTINUE                                              
 120           CONTINUE                                                 
                                                                        
C TZA is recalculated for strips to include the probability of exposure.
                                                                        
               DO 150 J=1,NELA                                          
                  IJ = J + (M - 1) * NELA                               
                  DO 140 K=1,MAN                                        
                     DO 130 L=1,NVLE                                    
                        TZA(IJ,K,L) = TZA(IJ,K,L) * TPPA(J,K,L)         
 130                 CONTINUE                                           
 140              CONTINUE                                              
 150           CONTINUE                                                 
 160        CONTINUE                                                    
                                                                        
C Write TZA and TPPA arrays for strips to output.                       
                                                                        
            DO 200 JJ=1,NTPX                                            
               DO 190 J=1,NELA                                          
                  WRITE(6,5160)JJ                                       
                  WRITE(6,5190)TELE(J)                                  
                  WRITE(6,5200)(TVLE(M),M=1,NUMOUT)                     
                  WRITE(6,5180)                                         
                  DO 170 K=1,MAN                                        
                     WRITE(6,5170)TXMA(K),(TZA(J,K,L),TPPA(J,K,L),L=1,  
     &                            NUMOUT)                               
 170              CONTINUE                                              
                  IF (NVLE .GT. 9) THEN                                 
                     WRITE(6,5200)(TVLE(M),M=NUMOUT + 1,NVLE)           
                     DO 180 K=1,MAN                                     
                        WRITE(6,5170)TXMA(K),(TZA(J,K,L),TPPA(J,K,L),   
     &                               L=NUMOUT + 1,NVLE)                 
 180                 CONTINUE                                           
                  ENDIF                                                 
 190           CONTINUE                                                 
 200        CONTINUE                                                    
         ELSE                                                           
                                                                        
C Read and write TZA and TPPA for non-strip targets.                    
                                                                        
            DO 220 J=1,NELA                                             
               DO 210 K=1,MAN                                           
                  READ(12,5050)(TZA(J,K,L),L=1,NVLE)                    
 210           CONTINUE                                                 
 220        CONTINUE                                                    
            DO 250 J=1,NELA                                             
               IF (IP .NE. ' ') WRITE(6,5190)TELE(J)                    
               IF (IP .NE. ' ') WRITE(6,5200)(TVLE(M),M=1,NUMOUT)       
               IF (IP .NE. ' ') WRITE(6,5180)                           
               DO 230 K=1,MAN                                           
                  READ(12,5050)(TPPA(J,K,L),L=1,NVLE)                   
                  IF (IP .NE. ' ') WRITE(6,5170)TXMA(K),(TZA(J,K,L),    
     &                                        TPPA(J,K,L),L=1,NUMOUT)   
 230           CONTINUE                                                 
               IF (NVLE .GT. 9) THEN                                    
                  IF (IP .NE. ' ') WRITE(6,5200)(TVLE(M),M=NUMOUT + 1,  
     &                                        NVLE)                     
                  DO 240 K=1,MAN                                        
                     IF (IP .NE. ' ') WRITE(6,5170)TXMA(K),(TZA(J,K,L), 
     &                                        TPPA(J,K,L),L=NUMOUT + 1, 
     &                                        NVLE)                     
 240              CONTINUE                                              
               ENDIF                                                    
 250        CONTINUE                                                    
         ENDIF                                                          
                                                                        
C Read the next data record.                                            
                                                                        
         CLOSE(12)                                                      
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 14, WPNDRAG options. Option 1 is for CDRAG and   
C option 2 is for the remaining drag options.  If it is present, set the
C drag option type, DRAGTYP, and the drag file code, DRAG.  DRAGTYP and 
C DRAG are written in OUTZ.                                             
                                                                        
      IF (ANAM(2:5) .EQ. 'DRAG') THEN                                   
         DRAGTYP = ANAM                                                 
         DRAG = VALUE                                                   
                                                                        
C Parameters defined to open the WPNDRAG file.                          
                                                                        
         WRITE(TEMPVAL,5070)INT(DRAG)                                   
         KKCT = 1                                                       
         DO 260 KK=1,5                                                  
            IF (TEMPVAL(KK:KK) .EQ. ' ') KKCT = KKCT + 1                
 260     CONTINUE                                                       
         IF (JR .NE. ' ') TEMPVAL(4:4) = ANAM(1:1)                      
         NEWLFN = ' users:[OSULIB.DATA.WPNDRAG]' // TEMPVAL(4:5) //     
     &            '.DAT'                                                
         IF (JR .EQ. ' ') NEWLFN = ANAM(1:5) // TEMPVAL(KKCT:5) //      
     &                                '.DAT'                            
         OPEN(12,FILE=NEWLFN,STATUS='OLD',READONLY)                     
                                                                        
C Test to verify the opened WPNDRAG file contains the correct data. Read
C the first two records from WPNDRAG file.                              
                                                                        
         READ(12,5080)REC1,IW,TGTNO                                     
         READ(12,5090)REC2,VALUE                                        
         IF ((REC1 .NE. ANAM) .OR. (IW .NE. INT(DRAG))) THEN            
            WRITE(6,5100)'WPNDRAG'                                      
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C If drag type is NOT CDRAG, then read number of altitudes in drag      
C table, CNHD, and the number of velocities in each layer, CNVD.        
                                                                        
         IF (ANAM .EQ. 'CDRAG') THEN                                    
            IF (IP .NE. ' ') THEN                                       
               WRITE(6,5280)DRAGTYP                                     
               WRITE(6,5320)CKQ                                         
            ENDIF                                                       
         ELSE                                                           
            READ(12,5120)CNHD,CNVD                                      
            IF (IP .NE. ' ') THEN                                       
               WRITE(6,5280)DRAGTYP                                     
               WRITE(6,5390)INT(CNHD),INT(CNVD)                         
            ENDIF                                                       
         ENDIF                                                          
                                                                        
C If CDRAG option is chosen, set the number of velocity values, NCDP,   
C set indicator NT9 to show that a drag curve has been input for this   
C case, and set the number of altitudes, NHDT, to 1.                    
                                                                        
         IF (ANAM .EQ. 'CDRAG') THEN                                    
            NCDP = INT(VALUE)                                           
            NT9 = .TRUE.                                                
            NHDT = 1                                                    
            NHD = 1                                                     
         ELSE                                                           
                                                                        
C Option is NOT CDRAG.  Set number of velocity values, NCDP, and number 
C of heights, NHD.                                                      
                                                                        
            NHDT = INT(CNHD)                                            
            NCDP = INT(CNVD)                                            
            NHD = NHDT                                                  
         ENDIF                                                          
                                                                        
C Test for NCDP and NHD exceeding maximum size.                         
                                                                        
         IF (NCDP .GT. 11) THEN                                         
            WRITE(6,5110)'NUMBER OF DRAG CURVE VELOCITY VALUES EXCEEDED'
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
         IF (NHD .GT. 10) THEN                                          
            WRITE(6,5110)'NUMBER OF DRAG TABLE HEIGHTS EXCEEDED '       
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C Read the velocity values of the drag curve, VCF, and the drag         
C coefficients, CFD. If the option is NOT CDRAG, read the altitude      
C limits, HDT, and densities, RHO.  Write drag tables to output.        
                                                                        
         IF (ANAM .EQ. 'CDRAG') THEN                                    
            READ(12,5120)(VCF(I),I=1,NCDP)                              
            READ(12,5120)(CFD(1,I),I=1,NCDP)                            
            IF (IP .NE. ' ') THEN                                       
               WRITE(6,5330)(INT(VCF(I)),I=1,NCDP)                      
               WRITE(6,5340)(CFD(1,I),I=1,NCDP)                         
            ENDIF                                                       
         ELSE                                                           
            READ(12,5120)(HDT(I),I=1,NHD)                               
            READ(12,5120)(RHO(I),I=1,NHD)                               
            READ(12,5120)(VCF(I),I=1,NCDP)                              
            IF (IP .NE. ' ') THEN                                       
               WRITE(6,5400)(HDT(I),I=1,NHD)                            
               WRITE(6,5410)(RHO(I),I=1,NHD)                            
               WRITE(6,5320)CKQ                                         
               WRITE(6,5330)(INT(VCF(I)),I=1,NCDP)                      
            ENDIF                                                       
            DO 270 I=1,NHD                                              
               READ(12,5120)(CFD(I,J),J=1,NCDP)                         
               IF (IP .NE. ' ') WRITE(6,5340)(CFD(I,J),J=1,NCDP)        
 270        CONTINUE                                                    
         ENDIF                                                          
                                                                        
C If the option is CDRAG, set RHO, SKT, AND HDT.  If option is not      
C CDRAG, set the shape factor, CKQ, and indicator, NT9, so no drag curve
C will be input.                                                        
                                                                        
         IF (ANAM .EQ. 'CDRAG') THEN                                    
            RHO(1) = 0.076474                                           
            SKT(1) = CKQ                                                
            HDT(1) = 0.0                                                
            HDT(2) = 1000.0                                             
         ELSE                                                           
            CKQ = SKT(NHDT)                                             
            NT9 = .TRUE.                                                
         ENDIF                                                          
                                                                        
C Set the first velocity to .1 if it is less than 0.1.  Read the next   
C data record.                                                          
                                                                        
         IF (VCF(1) .LT. 0.1) VCF(1) = .1                               
                                                                        
         CLOSE(12)                                                      
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ELSE                                                              
                                                                        
C If record set 14 is not present, set indicator NT9=FALSE to show no   
C drag curve was input.                                                 
                                                                        
         NT9 = .FALSE.                                                  
      ENDIF                                                             
                                                                        
C Check for record set 15, option 1, CONCV.  If this option is chosen,  
C set the cutoff velocity option type, COOPTN, the cutoff velocity, C3, 
C and indicator to show the use of a constant cutoff velocity, MT7. Read
C the next data record.                                                 
                                                                        
      IF (ANAM .EQ. 'CONCV') THEN                                       
         COOPTN = ANAM                                                  
         C3 = VALUE                                                     
         DO 290 J=1,JC1                                                 
            DO 280 N=IC2(J),1, - 1                                      
               WZ4(N,J) = C3                                            
 280        CONTINUE                                                    
 290     CONTINUE                                                       
         MT7 = .FALSE.                                                  
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 15, option 2, INTRVC.  This option produces the  
C target dependent table of cutoff velocities per each fragment weight. 
C If this option is chosen, set the cutoff velocity option type, COOPTN,
C and cutoff velocity code, INTRVC.                                     
                                                                        
      IF (ANAM .EQ. 'INTRVC') THEN                                      
         COOPTN = ANAM                                                  
         INTRVC = ITAR                                                  
                                                                        
C Parameters defined to open the INTRVC file.                           
                                                                        
         TEMPVAL = ITAR                                                 
         KKCT = 1                                                       
         DO 300 KK=1,5                                                  
            IF (TEMPVAL(KK:KK) .EQ. ' ') THEN                           
               TEMPVAL(KK:KK) = '0'                                     
               KKCT = KKCT + 1                                          
            ENDIF                                                       
 300     CONTINUE                                                       
                                                                        
         DOTEND = '.DAT'                                                
         IF (NAME(61:61) .EQ. 'R') DOTEND = '.ROB'                      
                                                                        
         NEWLFN = ' users:[OSULIB.DATA.INTRVC]IVC' // TEMPVAL(3:5) //   
     &            DOTEND                                                
         IF (JR .EQ. ' ') NEWLFN = 'INTRVC' // TEMPVAL(KKCT:5) // '.DAT'
         OPEN(12,FILE=NEWLFN,STATUS='OLD',READONLY)                     
                                                                        
C Test to verify the opened INTRVC file contains the correct data. Read 
C the first two records from INTRVC file.                               
                                                                        
         READ(12,5080)REC1,IW,TGTNO                                     
         READ(12,5090)REC2,VALUE                                        
         IF ((REC1 .NE. ANAM) .OR. (TGTNO .NE. ITAR)) THEN              
            WRITE(6,5100)'INTRVC'                                       
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C Guarantee the size of IVAL is not exceeded.  Read and write the       
C fragment weights, AMASS, and velocities, COV.                         
                                                                        
         IVAL = INT(VALUE)                                              
         IF (IVAL .GT. 25) THEN                                         
            WRITE(6,5110)'AMASS() AND COV() INDEX EXCEEDED'             
            CALL EXIT                                                   
         ENDIF                                                          
         READ(12,5220)(AMASS(I),I=1,IVAL)                               
         READ(12,5220)(COV(I),I=1,IVAL)                                 
         IF (IP .NE. ' ') THEN                                          
            WRITE(6,5420)                                               
            WRITE(6,5430)ANAM,TGTNO                                     
            WRITE(6,5230)(AMASS(I),I=1,IVAL)                            
            WRITE(6,5240)(COV(I),I=1,IVAL)                              
         ENDIF                                                          
                                                                        
C Produce the cutoff velocities array, WZ4, using interpolation of      
C masses and cutoff velocities arrays, AMASS and COV.  The cutoff       
C velocity located in each element of WZ4 corresponds to the same       
C element in the weapon fragmentation weights array, D2.                
                                                                        
         DO 350 J=1,JC1                                                 
            DO 340 N=1,IC2(J)                                           
               DO 310 I=1,IVAL                                          
                  IF (AMASS(I) .GT. D2(N,J)) THEN                       
                     GOTO 320                                           
                  ELSEIF (AMASS(I) .EQ. D2(N,J)) THEN                   
                     WZ4(N,J) = COV(I)                                  
                     GOTO 330                                           
                  ENDIF                                                 
 310           CONTINUE                                                 
 320           I = I - 1                                                
               IF (I .EQ. 0) THEN                                       
                  WZ4(N,J) = COV(1)                                     
               ELSE                                                     
                  IF (AMASS(IVAL) .LE. D2(N,J)) THEN                    
                     WZ4(N,J) = COV(IVAL)                               
                  ELSE                                                  
                     FRACT = (D2(N,J) - AMASS(I)) / (AMASS(I + 1) -     
     &                       AMASS(I))                                  
                     WZ4(N,J) = FRACT * (COV(I + 1) - COV(I)) + COV(I)  
                  ENDIF                                                 
               ENDIF                                                    
 330           CONTINUE                                                 
 340        CONTINUE                                                    
 350     CONTINUE                                                       
                                                                        
C Set indicator MT7 to show the cutoff velocity array was calculated.   
C Read the next data record.                                            
                                                                        
         MT7 = .TRUE.                                                   
         CLOSE(12)                                                      
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 15, option 3, READVC.  If this option is chosen, 
C read the cutoff velocity, WZ4(N,J), for each weight group in each     
C zone from record set 16.  Set indicator MT7 to show cutoff velocity   
C was input.  Read the next data record.                                
                                                                        
      IF (ANAM .EQ. 'READVC') THEN                                      
         COOPTN = ANAM                                                  
         DO 360 J=1,JC1                                                 
            READ(9,5120)(WZ4(N,J),N=IC2(J),1, - 1)                      
 360     CONTINUE                                                       
         MT7 = .TRUE.                                                   
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 17, MATRIX.  If this record set is present, read 
C the number of cells in deflection, CNDX, and the number in range,     
C CNRG, from record set 18.  Verify the sizes of CNDG and CNRG          
C are not exceeded.  Read the indicator record, INDC, indicator         
C to read or compute cell dimensions and center of matrix, NRAD, and    
C indicator to output the matrix, MOSK, from record set 19.  Compute the
C number of deflection and range grid coordinates, NDGP and NRGP.       
                                                                        
      IF (ANAM .EQ. 'MATRIX') THEN                                      
         READ(9,5120)CNDG,CNRG                                          
         IF (CNDG .GT. 80.0 .OR. CNRG .GT. 40.0) THEN                   
            WRITE(6,5110)'MATRIX SIZE EXCEEDS 80 X 40'                  
            CALL EXIT                                                   
         ENDIF                                                          
         READ(9,5210)INDC,NRAD,MOSK                                     
         NRG = INT(CNRG)                                                
         NDG = INT(CNDG)                                                
         NDGP = NDG / 2 + 1                                             
         NRGP = NRG + 1                                                 
                                                                        
C Record set 20 will be read depending on the value of NRAD. If NRAD =  
C 1, read the deflection, DA, and range, RA, of each cell and the range 
C coordinate of the center of the matrix, CNTR. Compute the range and   
C deflection coordinates, RAR(I) and DAR(I).  Set indicator MATZ to     
C show that lethal areas and matrix should be computed.  Set indicator  
C NMAZ to show that one integration pass is required.                   
                                                                        
         IF (NRAD .EQ. 1) THEN                                          
            READ(9,5120)DA,RA,CNTR                                      
            RAR(1) = CNTR - RA * FLOAT(NRG / 2)                         
            DO 370 I=2,NRGP                                             
               RAR(I) = RAR(I - 1) + RA                                 
               IF (ABS(RAR(I)) .LE. 0.001) RAR(I) = 0.0                 
 370        CONTINUE                                                    
            DO 380 I=1,NDGP                                             
               DAR(I) = (I - 1) * DA                                    
 380        CONTINUE                                                    
            MATZ = .TRUE.                                               
            NMAZ = 0                                                    
                                                                        
C **** PKT is the total probability of kill. ****                       
                                                                        
C If NRAD = 2, cell size and center of matrix will be computed.  Set    
C indicators NDON to show cell size should be computed, ND to show PKT  
C for an arc increment versus ground range, r, should be stored, MATZ to
C show only lethal areas will be computed, NMAZ to show two integration 
C passes are required, and MOSK to generate a matrix file.              
                                                                        
         ELSEIF (NRAD .EQ. 2) THEN                                      
            NDON = 0                                                    
            ND = 1                                                      
            MATZ = .FALSE.                                              
            NMAZ = 1                                                    
            MOSK = 1                                                    
                                                                        
C If NRAD = 3, read the length of each cell in deflection, DA, and      
C range, RA from record set 20.  Set indicators ND to show PKT for an   
C arc increment versus ground range, r, is to be stored, NMAZ to show   
C two integration passes are required, MATZ to show only lethal areas   
C are computed, NDON to show the number of cells in deflection and range
C must be computed, and MOSK to generate a matrix file.                 
                                                                        
         ELSEIF (NRAD .EQ. 3) THEN                                      
            READ(9,5120)DA,RA                                           
            ND = 1                                                      
            NMAZ = 1                                                    
            MATZ = .FALSE.                                              
            NDON = 1                                                    
            MOSK = 1                                                    
                                                                        
C If NRAD = 4, read the deflection, DAR(I), and range, RAR(I),          
C coordinates from record sets 21 and 22 respectively.  Set NMAZ to show
C one integration pass is required. Set indicator MATZ to show lethal   
C area and a matrix should be computed.                                 
                                                                        
         ELSEIF (NRAD .EQ. 4) THEN                                      
            READ(9,5120)(DAR(I),I=1,NDGP)                               
            READ(9,5120)(RAR(I),I=1,NRGP)                               
            NMAZ = 0                                                    
            MATZ = .TRUE.                                               
                                                                        
C If NRAD is not 1 through 4, an error message is printed, and program  
C exits.                                                                
                                                                        
         ELSE                                                           
            WRITE(6,5110)'NRAD  .NE.  1-4'                              
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C If indicator MOSK equals 0, set indicator to show the matrix is not   
C output to a file.  If MOSK does NOT equal 0, set indicator to show    
C that the matrix is output to a file.                                  
                                                                        
         IF (NRAD .EQ. 1 .OR. NRAD .EQ. 4) THEN                         
            IF (MOSK .EQ. 0) THEN                                       
               MOSK = 1                                                 
            ELSE                                                        
               MOSK = 2                                                 
            ENDIF                                                       
         ENDIF                                                          
                                                                        
C Read the next data record.                                            
                                                                        
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ELSE                                                              
                                                                        
C The MATRIX option is not selected for this case. Set  indicator       
C MOSK so the PK matrix will not be  output.  Set indicator NMAZ        
C to show one integration pass is required.                             
                                                                        
         IF (.NOT.MATZ) THEN                                            
            MOSK = 1                                                    
            NMAZ = 0                                                    
         ENDIF                                                          
                                                                        
      ENDIF                                                             
                                                                        
C Check for record set 23, BLT.  If it is present, read record set 24   
C to obtain the distances where blast has an effect, RB1 and RB2, and   
C height of target centroid for blast, QAV.  Check to determine if the  
C burst height to target centroid is greater than the blast distance;   
C if so set test variable for blast to 0 for use in integration region  
C boundary.  Set IDHT for no direct hit and QAVR, mound target centroid.
C Set indicators NYN1 and NYN to show blast effect should be considered.
C Set NAME(46:46) to MAEB for  blast only weapons or targets with no    
C RCAS.  Read the next data record.                                     
                                                                        
                                                                        
      IF (ANAM .EQ. 'BLT') THEN                                         
         READ(9,5120)RB1,RB2,QAV                                        
         RB11 = RB1                                                     
         IF (((QAV-Q43)**2) .GT. (RB1**2)) RB11 = 0                     
         IDHT = .FALSE.                                                 
         QAVR = QAV                                                     
         NYN1 = 1                                                       
         NYN = .TRUE.                                                   
         IF (RCAS .EQ. '  999' .OR. INT(ZDATAID) .EQ. 9999) NAME(46:46) 
     &       = '3'                                                      
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ELSE                                                              
                                                                        
C If the BLT record is not present, check indicator NYN1 to see if blast
C option has been turned on and blast effects should be considered.  Set
C indicator NYN accordingly.                                            
                                                                        
         RB11 = RB1                                                     
         IF (NYN1 .EQ. 0) THEN                                          
            NYN = .FALSE.                                               
         ELSE                                                           
            NYN = .TRUE.                                                
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C Check for record set 25, FIRE, fire effects option.  If it is present,
C set indicator IPQF to read or compute fire effects distances.         
                                                                        
      IF (ANAM .EQ. 'FIRE') THEN                                        
                                                                        
         IPQF = INT(VALUE)                                              
                                                                        
         TEMPVAL = ITAR                                                 
         KKCT = 1                                                       
         DO 390 KK=1,5                                                  
            IF (TEMPVAL(KK:KK) .EQ. ' ') THEN                           
               TEMPVAL(KK:KK) = '0'                                     
               KKCT = KKCT + 1                                          
            ENDIF                                                       
 390     CONTINUE                                                       
                                                                        
C Open the fire effects vulnerability data file, TGTFIRE.DAT.           
                                                                        
         NEWLFN = ' users:[OSULIB.DATA]TGTFIRE.DAT'                     
         IF (JR .EQ. ' ') NEWLFN = 'FIRE' // TEMPVAL(KKCT:5) // '.DAT'  
         OPEN(12,FILE=NEWLFN,STATUS='OLD',READONLY)                     
                                                                        
C Test to verify the opened TGTFIRE file contains the correct data. Read
C the first two records from TGTFIRE file.                              
                                                                        
         READ(12,5080)REC1,IW,TGTNO                                     
         READ(12,5090)REC2,VALUE                                        
         IF ((REC1 .NE. ANAM) .OR. (TGTNO .NE. ITAR)) THEN              
            WRITE(6,5100)'TGTFIRE'                                      
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C Read the number of elevation angles in the fire effects vulnerability 
C data FNELA, the number of fragment weights, FMAN, and the number of   
C fragment velocities, FNVLE.                                           
                                                                        
         IF (IP .NE. ' ') THEN                                          
            IF (IPQF .EQ. 0) WRITE(6,5130)                              
            IF (IPQF .EQ. 1) WRITE(6,5140)                              
         ENDIF                                                          
                                                                        
         READ(12,5120)FNELA,FMAN,FNVLE                                  
         IF (FNELA .GT. 9.0 .OR. FMAN .GT. 13.0 .OR. FNVLE .GT. 8.0)    
     &       THEN                                                       
            WRITE(6,5110)'FIRE TARGET VA TABLE DIMENSIONS EXCEEDED'     
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C Set array index variables.                                            
                                                                        
         KNELA = INT(FNELA)                                             
         KMAN = INT(FMAN)                                               
         KNVLE = INT(FNVLE)                                             
                                                                        
C Read and write the elevation angles in the fire effects               
C vulnerability data, FELE, the fragment weights, FXMA, the fragment    
C velocities, FVLE, the average vulnerable areas for fire effects, FZA, 
C and the probabilities of exposure, FPPA.                              
                                                                        
         READ(12,5050)(FELE(J),J=1,KNELA)                               
         READ(12,5050)(FXMA(J),J=1,KMAN)                                
         READ(12,5050)(FVLE(J),J=1,KNVLE)                               
         IF (KNVLE .LT. 10) THEN                                        
            NUMOUT = KNVLE                                              
         ELSE                                                           
            NUMOUT = KNVLE / 2                                          
         ENDIF                                                          
         IF (IP .NE. ' ') THEN                                          
            WRITE(6,5150)                                               
            WRITE(6,5360)KNELA,KMAN,KNVLE                               
         ENDIF                                                          
         DO 410 J=1,KNELA                                               
            DO 400 K=1,KMAN                                             
               READ(12,5050)(FZA(J,K,L),L=1,KNVLE)                      
 400        CONTINUE                                                    
 410     CONTINUE                                                       
         DO 440 J=1,KNELA                                               
            IF (IP .NE. ' ') WRITE(6,5190)FELE(J)                       
            IF (IP .NE. ' ') WRITE(6,5200)(FVLE(M),M=1,NUMOUT)          
                                                                        
            DO 420 K=1,KMAN                                             
               READ(12,5050)(FPPA(J,K,L),L=1,KNVLE)                     
               IF (IP .NE. ' ') WRITE(6,5170)FXMA(K),(FZA(J,K,L),FPPA(J,
     &                                        K,L),L=1,NUMOUT)          
 420        CONTINUE                                                    
            IF (KNVLE .GT. 9 .AND. IP .NE. ' ') THEN                    
               WRITE(6,5200)(FVLE(M),M=NUMOUT + 1,KNVLE)                
               DO 430 K=1,KMAN                                          
                  IF (IP .NE. ' ') WRITE(6,5170)FXMA(K),(FZA(J,K,L),    
     &                                        FPPA(J,K,L),L=NUMOUT + 1, 
     &                                        KNVLE)                    
 430           CONTINUE                                                 
            ENDIF                                                       
 440     CONTINUE                                                       
                                                                        
C Set fire option indicator, IFIRE.                                     
                                                                        
         IFIRE = .TRUE.                                                 
                                                                        
C Compute fire distances D1K or D0K or read record set 26 depending on  
C indicator IPQF. Read the next data record.                            
                                                                        
         IF (IPQF .EQ. 0) THEN                                          
            D1K = 12.76 * WPENT *  * .333 - 2.898                       
            D0K = 13.03 * WPENT *  * .333 - 1.304                       
         ELSE                                                           
            READ(9,5120)D1K,D0K                                         
         ENDIF                                                          
         CLOSE(12)                                                      
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 27, TRES, environmental shielding option.        
C If this card is present, set NTRE to the control number to select     
C a particular exposure function.  Read the next data record.           
                                                                        
      IF (ANAM .EQ. 'TRES') THEN                                        
         NTRE = INT(VALUE)                                              
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 28, TER, terrain shielding option.  If this      
C card is present, set TERAIN.  Read the next data record.              
                                                                        
      IF (ANAM .EQ. 'TER') THEN                                         
         TERAIN = .TRUE.                                                
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 29, REVET.  If it is present, read record set 30 
C to obtain the revetment base,  REVBAS, the revetment top, REVTOP,     
C revetment height, REVHT, the distance from revetment base to target   
C center, REVDIS, and the impact  angle, RTRAJ.  Read record set 31 to  
C obtain the probability of kill given a hit, PKH, equivalent target    
C radius, RD1, target height for direct hit, TGTHT, and fragments       
C considered indicator, FRAGOPT.  If the impact angle is zero, set it   
C to 1 to prevent a divide by zero error in subsequent calculations.    
C Calculate the distance on the ground from the base edge to the        
C top edge of the revetment, REVSLP. Calculate the revetment angle in   
C degrees, REVA.  Set indicator for a  revetment run, ROP.  Calculate   
C the distance on the ground from the top edge of the revetment to the  
C target center, REVTOT.                                                
                                                                        
      IF (ANAM .EQ. 'REVET') THEN                                       
         READ(9,5120)REVBAS,REVTOP,REVHT,REVDIS,RTRAJ                   
         READ(9,5120)PKH,RD1,TGTHT,FRAGOPT                              
         IF (RTRAJ .EQ. 0.) RTRAJ = 1.                                  
         REVSLP = (REVBAS - REVTOP) / 2.                                
         REVA = ATAN(REVHT / REVSLP) * RAD2DEG                          
         ROP = .TRUE.                                                   
         REVTOT = REVDIS + REVSLP                                       
                                                                        
C Test for dead zone.  If there is none, set indicators IRV = FALSE and 
C DEAD equal to zero.                                                   
                                                                        
         IF (Q43 .GT. REVHT .OR. REVA .LE. RTRAJ) THEN                  
            IRV = .FALSE.                                               
            DEAD = 0.                                                   
         ELSE                                                           
                                                                        
C A dead zone exists.  Set indicator IRV and calculate the dead zone,   
C DEAD.                                                                 
                                                                        
            IRV = .TRUE.                                                
            DEAD = REVHT / TAN(RTRAJ * DEG2RAD) - REVSLP                
                                                                        
C Dead zone intersects downrange revetment wall.  Recalculate dead zone 
C to include the added distance in the ground plane from the revetment  
C base to the weapon impact point on the revetment, XX.                 
                                                                        
            IF (DEAD .GT. 2. * REVDIS) THEN                             
               HPR = DEAD - 2. * REVDIS                                 
               AHPR = 180. - REVA - RTRAJ                               
               AUR = HPR * SIN(RTRAJ * DEG2RAD) / SIN(AHPR * DEG2RAD)   
               XX = AUR * COS(REVA * DEG2RAD)                           
               DEAD = 2. * REVDIS + XX                                  
            ENDIF                                                       
                                                                        
C Calculate the distance from the dead zone to the target, DTD, and the 
C distance inside of the revetment which is impossible for a weapon to  
C impact (dead zone distance), ACTR.                                    
                                                                        
            DTD = REVDIS - DEAD                                         
            ACTR = REVSLP + DEAD                                        
         ENDIF                                                          
                                                                        
C  Read the next data record.                                           
                                                                        
         WRITE(6,5440)REVA,DTD,ACTR                                     
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 32, MOUND.  If it is present, read record set 33 
C to obtain the mound base  radius, REVBAS, the mound top radius,       
C REVTOP, mound height, REVHT, and the impact angle, RTRAJ.  If the     
C impact angle is zero, set it to 1.  Adjust the  target blast          
C centroid, QAV,  and fragment centroid, Q41, to be located above the   
C mound height.  Set the indicator for a mound run, MOUNDOPT.  Calculate
C the distance on the ground from the base edge to the top edge of the  
C mound, REVSLP. Calculate REVA, the interior angle formed by the wall  
C and the base of the mound.                                            
                                                                        
      IF (ANAM .EQ. 'MOUND') THEN                                       
         READ(9,5120)REVBAS,REVTOP,REVHT,RTRAJ                          
         IF (RTRAJ .EQ. 0.) RTRAJ = 1.                                  
         QAV = QAVR + REVHT                                             
         DO 450 J=1,NTPX                                                
            IF (Q41(J) .NE. 0.0) Q41(J) = Q41R(J) + REVHT               
 450     CONTINUE                                                       
         MOUNDOPT = .TRUE.                                              
         REVSLP = REVBAS - REVTOP                                       
         REVA = ATAN(REVHT / REVSLP) * RAD2DEG                          
                                                                        
C Test for no dead zone.  If there is none, set indicator IDEAD = FALSE 
C else set idead =TRUE.                                                 
                                                                        
         IF (REVA .LE. RTRAJ .OR. Q43R .GE. REVHT) THEN                 
            IDEAD = .FALSE.                                             
         ELSE                                                           
                                                                        
C If there is a dead zone set indicator IDEAD = TRUE.                   
                                                                        
            IDEAD = .TRUE.                                              
         ENDIF                                                          
                                                                        
C Compute the length of the mound shadow in the ground plane, S1D.      
C Read the next data record set.                                        
                                                                        
         S1D = REVHT / TAN(RTRAJ * DEG2RAD) + REVTOP                    
         WRITE(6,5450)REVA,S1D                                          
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 34, OUTP.  If it is present, set indicator IOUT  
C to write warhead fragmentation data.  Read the next data record.  If  
C OUTP is not present, set indicator IOUT so that warhead fragmentation 
C data will not be printed.                                             
                                                                        
      IF (ANAM .EQ. 'OUTP') THEN                                        
         IOUT = .TRUE.                                                  
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ELSE                                                              
         IOUT = .FALSE.                                                 
      ENDIF                                                             
                                                                        
C Check for record set 35, COTM.  If it is present, set COTM to cutoff  
C weight.  Set indicators IPRWT and NNNN to show COTM was selected.     
C Read the next data record.                                            
                                                                        
      IF (ANAM .EQ. 'COTM') THEN                                        
         COTM = VALUE                                                   
         IPRWT = 1                                                      
         NNNN = .TRUE.                                                  
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 36, BURIED.  If this record is present, set the  
C number of warhead segments, JCX.  Test to guarantee the size of JCX   
C is not exceeded.  Read record set 37 to obtain the angle of departure 
C for the fragments in each segment, THE.  Read record set 38 to obtain 
C the radius of each segment, RF.  Read record set 39 to obtain the     
C location of the warhead segment, PF.  Read record set 40 to obtain    
C the buried centroid, CGRAV.  The segment location array, PF, is       
C adjusted so the centroid is location 0.0.  Set indicator KLBUR for a  
C buried run.  Call subroutine BURINT to obtain the warhead segment     
C radii and location for the boundary angles for each static            
C fragmentation zone.  Read the next record.                            
                                                                        
      IF (ANAM .EQ. 'BURIED') THEN                                      
         JCX = INT(VALUE)                                               
         IF (JCX .GT. 50) THEN                                          
            WRITE(6,5110)'NUMBER OF BURIED WARHEAD SEGMENTS EXCEEDED'   
            CALL EXIT                                                   
         ENDIF                                                          
         READ(9,5120)(THE(I),I=1,JCX)                                   
         READ(9,5120)(RF(I),I=1,JCX)                                    
         READ(9,5120)(PF(I),I=1,JCX)                                    
         READ(9,5120)CGRAV                                              
         DO 460 I=1,JCX                                                 
            PF(I) = CGRAV - PF(I)                                       
 460     CONTINUE                                                       
         KLBUR = .TRUE.                                                 
         CALL BURINT(B1,B2,B3,JC1,RF,PF,THE,JCX)                        
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 41, DIRHIT.  If it is present, read record set   
C 42 to obtain the probability of kill given a hit, PKH, the direct hit 
C radius, RD1, the target height, TGTHT, and indicator to consider      
C frags in the direct hit area, FRAGOPT.  Set indicator IDHT to show    
C DIRHIT option was selected.  Set NAME(46:46) to VAN for direct hit    
C weapon with NO fragmentation data or target with no RCAS.  Read the   
C next data  record.                                                    
                                                                        
      IF (ANAM .EQ. 'DIRHIT') THEN                                      
         READ(9,5120)PKH,RD1,TGTHT,FRAGOPT                              
         IDHT = .TRUE.                                                  
         IF (RCAS .EQ. '  999' .OR. INT(ZDATAID) .EQ. 9999) NAME(46:46) 
     &       = '2'                                                      
         READ(9,5040)ANAM,VALUE,ITAR                                    
      ENDIF                                                             
                                                                        
C Check for record set 43, (blank).  If the last record in the case is  
C not blank, an error message is printed out and program execution is   
C stopped.                                                              
                                                                        
      IF (ANAM .EQ. '      ') THEN                                      
         WRITE(6,5270)NAME(1:72)                                        
      ELSE                                                              
         WRITE(6,5250)ANAM                                              
         CALL EXIT                                                      
      ENDIF                                                             
                                                                        
      RETURN                                                            
                                                                        
C The following format statements are used in this subroutine.          
                                                                        
 5000 FORMAT ('0')                                                      
 5010 FORMAT ('1')                                                      
 5020 FORMAT (A72,2X,2I1,2X,2A1)                                        
 5030 FORMAT (/,10X,'EACH CELL IS CUT AT LEAST ',I1,' TIMES',/)         
 5040 FORMAT (A6,4X,F10.3,6X,A5)                                        
 5050 FORMAT (6F10.0)                                                   
 5060 FORMAT ('0',12F10.4/F10.4)                                        
 5070 FORMAT (I5)                                                       
 5080 FORMAT (A6,I4,A5)                                                 
 5090 FORMAT (A6,4X,F10.3)                                              
 5100 FORMAT (' %-ERROR- WRONG ',A,' FILE')                             
 5110 FORMAT (' %-ERROR- ',A)                                           
 5120 FORMAT (7F10.4)                                                   
 5130 FORMAT ('0 FIRE EFFECTS COMPUTED',/)                              
 5140 FORMAT ('0 FIRE EFFECTS READ',/)                                  
 5150 FORMAT (50X,'>>> FIRE EFFECTS VULNERBILITY TABLE <<<',//)         
 5160 FORMAT (/,40X,'STRIP',I2)                                         
 5170 FORMAT (1X,F8.0,2X,9(F7.2,1X,F4.2,'|'))                           
 5180 FORMAT (' FRAG MASS ',4X,'AV',3X,'PE  ')                          
 5190 FORMAT ('0',35X,' ELEVATION ANGLE = ',F5.0,' DEGREES')            
 5200 FORMAT (/,' FRAG VEL = ',10(F7.0,'FT/S',2X))                      
 5210 FORMAT (6X,I1,1X,2I1)                                             
 5220 FORMAT (7F10.0)                                                   
 5230 FORMAT ('      FRAGMENT  MASS  ',12F8.0)                          
 5240 FORMAT ('      CUTOFF VELOCITY ',12F8.0)                          
 5250 FORMAT (' %-ERROR- THIS IS AN INVALID RECORD',/1X,A6)             
 5260 FORMAT ('0',A72//1X,A6,2X,'IDENTIFIER NUMBER = 'I4,               
     &        '   NUMBER OF ZONES = ',I5//)                             
 5270 FORMAT ('0   CASE TITLE =   'A72,/)                               
 5280 FORMAT ('1',50X,'>>> ',A6,' <<<',/)                               
 5290 FORMAT (1X,37X,'FRAGMENTATION DATA'//1X,6X,'POLAR ZONES (DEG)',   
     &        10X,'INITIAL ZONE VELOCITY (FPS)',6X,'NO. OF',4X,'FRAG WT'
     &       ,4X,'NO. OF'/1X,3X,'LOWER',5X,'UPPER',6X,'MID',8X,'LOWER', 
     &        5X,'UPPER',6X,'MID',7X,'WT GPS',5X,'(GR)',6X,'FRAGS'/2X,  
     &        3('--------  '),2X,3('--------  '),2X,3('--------  '))    
 5300 FORMAT (2X,F8.2,2X,F8.2,2X,F8.2,4X,F8.2,2X,F8.2,2X,F8.2,4X,F8.2,  
     &        2X,F8.2,2X,F8.2)                                          
 5310 FORMAT (1X,75X,F8.2,2X,F8.2)                                      
 5320 FORMAT (1X,'SHAPE FACTOR (ft^(2) gr^(1/3) / lb) = ',F10.4)        
 5330 FORMAT (/,1X,'VELOCITY (FPS):  ',11I8,1X,/)                       
 5340 FORMAT (1X,'COEFFICIENT   =  ',11F8.2)                            
 5350 FORMAT ('0',50X,'>>> TARGET VULNERABILITY DATA <<<',//35X,A6,     
     &        '  IDENTIFIER NUMBER = ',A5,/)                            
 5360 FORMAT ('0 NUMBER OF ELEVATION ANGLES = ',I2,5X,                  
     &        '  NUMBER OF FRAGMENT MASS ZONES = ',I2,5X,               
     &        '  NUMBER OF VELOCITIES = ',I2)                           
 5370 FORMAT (35X,                                                      
     &        ' VULNERABLE AREAS AVERAGED OVER ONLY NONZERO AZIMUTHS')  
 5380 FORMAT (35X,' VULNERABLE AREAS AVERAGED OVER ALL AZIMUTHS')       
 5390 FORMAT (' NUMBER OF LAYERS  = ',I5,10X,'NUMBER OF VELOCITIES = ', 
     &        I5,/)                                                     
 5400 FORMAT (' LAYER BOUNDARIES  =    ',11F8.2)                        
 5410 FORMAT (' DENSITIES  =           ',11F8.2)                        
 5420 FORMAT (//,38X,'>>> CUT OFF VELOCITY VS. FRAGMENT WEIGHT <<<')    
 5430 FORMAT (/,1X,A6,'  IDENTIFIER NUMBER = ',A5,/)                    
 5440 FORMAT ('0',50X,'>>> REVETMENT DATA <<<',//,                      
     &        ' REVETMENT ANGLE(deg) = ',F10.2,5X,                      
     &        'DEAD ZONE DISTANCE TO TARGET(ft)= ',F10.2,5X,            
     &        'DEAD ZONE DISTANCE(ft) = ',F10.2)                        
 5450 FORMAT ('0',50X,'>>> MOUND DATA <<<',//,30X,' MOUND ANGLE(deg) = '
     &       ,F10.2,5X,'LENGTH OF DEAD ZONE(ft) = 'F10.2)               
 5460 FORMAT (' %-WARNING- ',A)                                         
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE BLT(S1X,P)                                             
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Compute the probability of kill due to blast effects for a given   
C slant range.  When the slant range from the burst point to the        
C target is greater than the effects of blast, an indicator is set      
C to prevent this routine from being called.                            
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   -------        -------  -------------------------------------       
C MOUNDOPT           --     Indicator:                                  
C                           TRUE  - Target is on a mound.               
C                           FALSE - Target is Not on a mound.           
C                                                                       
C NYN                --     Indicator:                                  
C                           TRUE - Weapon has blast effects             
C                           FALSE - Weapon does not have blast effects  
C                                                                       
C P                  --     Probability of kill due to blast for a given
C                           slant range.                                
C                                                                       
C RB1                ft     Maximum distance from burst point where     
C                           Pk=1.0                                      
C                                                                       
C RB2                ft     Minimum distance from burst point where     
C                           Pk=0.0                                      
C                                                                       
C REVTOP             ft     Radius of the top of a mound.               
C                                                                       
C REVTOT             ft     Distance on the ground from the target to   
C                           the top edge of the revetment.              
C                                                                       
C ROP                --     Indicator:                                  
C                           TRUE  - Target is revetted.                 
C                           FALSE - Target is Not revetted.             
C                                                                       
C S1                 ft     Straight line distance from weapon to       
C                           target.                                     
C                                                                       
C S1X                ft     Slant Range from burst point to target      
C                           centroid.                                   
C                                                                       
C TEMP               ft     Temporary variable to hold slant range when 
C                           weapon hits the top of the mound.           
C                                                                       
C---------------------------------------------------------------------- 
C SUBROUTINES REFERENCED                                                
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C FUNCTIONS REFERENCED                                                  
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C CALLING ROUTINE                                                       
C                                                                       
C CALC                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      COMMON  / REV /  REVHT,REVSLP,REVTOT,ACTR,DTD,REVBAS,REVDIS,DEAD, 
     &       REVA,COFF,GONG,REVTOP,RTRAJ,LOSFRG,LOSBLT                  
                                                                        
C If target is revetted and the blast radius is smaller than the ground 
C distance from the center of the revetment to the top, inside edge of  
C the revetment wall, then the blast centroid is equal to the burst     
C height of the weapon (the target is treated as if it is in the        
C open).                                                                
                                                                        
      IF (ROP .AND. (RB1 .LT. REVTOT)) QAV = Q43                        
                                                                        
C If the target is on a mound and the weapon hits on top of the mound,  
C then treat the target as if it is in the open (i.e., the blast is     
C treated as a straight line distance from the weapon to the target).   
                                                                        
      IF (MOUNDOPT .AND. (S1 .LE. REVTOP)) THEN                         
         TEMP = S1X                                                     
         S1X = S1                                                       
      ENDIF                                                             
                                                                        
C Check to see if still within blast radius.                            
C If equal to or less than RB1 then the Pk = 1.                         
C If between RB1 and RB2 the Pk is between 0 & 1 according to slope     
C of the blast curve.                                                   
C If outside of RB2, then the Pk = 0.                                   
                                                                        
      IF (S1X .LE. RB1) THEN                                            
         P = 1.                                                         
      ELSEIF (S1X .LT. RB2) THEN                                        
         P = 1. - (S1X - RB1) / (RB2 - RB1)                             
      ELSE                                                              
         P = 0.                                                         
         NYN = .FALSE.                                                  
      ENDIF                                                             
                                                                        
C Reset the slant range for weapons hitting on top of a mound           
C to be used in later calculations.                                     
                                                                        
      IF (MOUNDOPT .AND. (S1 .LE. REVTOP)) S1X = TEMP                   
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE BURINT(B1,B2,B3,JC1,RF,PF,THE,JCX)                     
C                                                                       
C---------------------------------------------------------------------- 
C DESCRIPTION:  This subroutine interpolates the warhead segment radius 
C               and location arrays for the static fragmentation zone   
C               boundary angles.   Produced are 3 segment radii arrays  
C               and segment location arrays for the lower, middle, and  
C               upper boundary angles for each static fragmentation     
C               zone.                                                   
C                                                                       
C NOTE:         Buried warheads are divided into segments defined by    
C               segment location (measured from the centroid), PF,      
C               segment radius, RF, and the fragment angle of           
C               departure in each segment, THE.  These parameters are   
C               used to reposition the fragments from the centroid of   
C               the warhead to the external surface.                    
C                                                                       
C               The following figure shows an example of the segment    
C               locations, PF, segment radii, RF, and fragment angle    
C               of departure, THE.                                      
C                                                                       
C               6 WARHEAD SEGMENTS                                      
C                                                                       
C THE(1)-THE(6)-->                                                      
C               55    85       100     121     127     160              
C                                                                       
C                          |       | 0.0   |      |                     
C                    |---------------x------------------|               
C                          |       |       |      |                     
C                                                                       
C RF(1) - RF(6) --> .2    .4      .55     .5     .45   .4               
C                                                                       
C                    |-----|-------|-------|------|-----|               
C                  4.0  2.75      .5    -1.5   -3.25  -4.75             
C                                                                       
C                PF(1)  PF(2)    PF(3)  PF(4)   PF(5)  PF(6)            
C            Segment locations (measured from centroid, noted by x)     
C                                                                       
C               The following table is a simplified example showing the 
C               array values produced in this subroutine.  The example  
C               uses the data from the above warhead figure.            
C                                                                       
C|----|--------------------|---------------------|---------------------|
C|    |  STATIC FRAG ZONE  |                     |                     |
C|ZONE|   BOUNDARY ANGLES  |    SEGMENT RADII    |   SEGMENT LOCATION  |
C|----|--------------------|---------------------|---------------------|
C|    | B1( )  B2( )  B3( )| RPF1() RFP2() RFP3()| PLF1() PLF2() PLF3()|
C|----|--------------------|---------------------|---------------------|
C|  1 |   0.0   25.0   50.0|   .20    .20    .20 |  4.00   4.00   4.00 |
C|  2 |  50.0   75.0  100.0|   .20    .38    .55 |  4.00   2.25    .50 |
C|  3 | 100.0  140.0  180.0|   .55    .48    .40 |   .50  -2.13  -4.75 |
C|----|--------------------|---------------------|---------------------|
C                                                                       
C VARIABLES:                                                            
C     Name          Units                  Definition                   
C ---------------  -------  --------------------------------------------
C B1(I)             deg     I=1, JC1.  Angle defining the lower boundary
C                           of the ith static zone.                     
C                                                                       
C B2(I)             deg     I=1, JC1.  Angle defining the middle        
C                           boundary of the ith static zone.            
C                                                                       
C B3(I)             deg     I=1, JC1.  Angle defining the upper boundary
C                           of the ith static zone.                     
C                                                                       
C BX(I)             deg     I=1, 3.  Temporary variable to hold the     
C                           angles defining the lower, middle, and upper
C                           boundaries of the static zones.             
C                                                                       
C DN                deg     Interpolation variable.  Difference between 
C                           the current static boundary zone and the    
C                           nearest value of THE that is smaller than   
C                           the static zone boundary angle, BX.         
C                                                                       
C JC1                --     Total number of static fragmentation zones  
C                           (maximum of 50).                            
C                                                                       
C JC1X               --     Initial loop parameter.  Indicates the      
C                           element of the THE array containing the     
C                           value that is larger than the static zone   
C                           boundary angle, BX.                         
C                                                                       
C JCX                --     Number of warhead segments.                 
C                                                                       
C PF(I)              ft     I=1, JCX.  Location of each segment on a    
C                           buried warhead.  PF(1) is the location of   
C                           the nose.                                   
C                                                                       
C PLF1(I)            ft     I=1, JC1.  Weapon segment location (measured
C                           from the centroid) associated with the angle
C                           defining the lower boundary of the ith      
C                           static zone.                                
C                                                                       
C PLF2(I)            ft     I=1, JC1.  Weapon segment location (measured
C                           from the centroid) associated with the angle
C                           defining the middle boundary of the ith     
C                           static zone.                                
C                                                                       
C PLF3(I)            ft     I=1, JC1.  Weapon segment location (measured
C                           from the centroid) associated with the angle
C                           defining the upper boundary of the ith      
C                           static zone.                                
C                                                                       
C RF(I)              ft     I=1,JCX.  Radius of each warhead segment.   
C                                                                       
C RPF1(I)            ft     I=1, JC1.  Weapon segment radius for the    
C                           angle defining the lower boundary of the ith
C                           static zone.                                
C                                                                       
C RPF2(I)            ft     I=1, JC1.  Weapon segment radius for the    
C                           angle defining the middle boundary of the   
C                           ith static zone.                            
C                                                                       
C RPF3(I)            ft     I=1, JC1.  Weapon segment radius for the    
C                           angle defining the upper boundary of the ith
C                           static zone.                                
C                                                                       
C SLP              ft/deg   Interpolation variable.  Difference between 
C                           2 consecutive radii in the RF array divided 
C                           by the difference between 2 consecutive     
C                           angles in the THE array.  The radii and     
C                           angles bracket the static zone boundary     
C                           angle, BX.                                  
C                                                                       
C SLR              ft/deg   Interpolation variable.  Difference between 
C                           2 consecutive locations in the PF array     
C                           divided by the difference between 2         
C                           consecutive angles in the THE array.  The   
C                           locations and angles bracket the static zone
C                           boundary angle, BX.                         
C                                                                       
C THE (I)           deg     I=1,JCX.  The angle of departure for the    
C                           fragments in each warhead segment.          
C---------------------------------------------------------------------- 
C Subroutines called:                                                   
C                                                                       
C  NONE                                                                 
C---------------------------------------------------------------------- 
C Functions called:                                                     
C                                                                       
C  NONE                                                                 
C---------------------------------------------------------------------- 
C Calling routine:                                                      
C                                                                       
C  BEGIN                                                                
C---------------------------------------------------------------------- 
C                                                                       
      DIMENSION B1(50),B2(50),B3(50),RF(50),PF(50),THE(50),BX(3)        
C                                                                       
      COMMON  / BBUR /  RPF1(50),RPF2(50),RPF3(50),PLF1(50),PLF2(50),   
     &          PLF3(50)                                                
                                                                        
C Initialize J to 1 to begin loop 10 at THE(1).                         
                                                                        
      J = 1                                                             
      WRITE(6,5000)                                                     
      DO 50 I=1,JC1                                                     
                                                                        
C Assign temporary variable BX to the lower, middle, and upper          
C boundaries of the ith static fragmentation zone.  Execute loop 40 for 
C all 3 static zone angles.                                             
                                                                        
         BX(1) = B1(I)                                                  
         BX(2) = B2(I)                                                  
         BX(3) = B3(I)                                                  
                                                                        
         DO 40 K=1,3                                                    
                                                                        
C Assign JC1X to begin loop 10 at the element of the THE array          
C containing the value that is larger than BX(K).  When J equals 1,     
C JC1X is assigned to the first element of the THE array.               
                                                                        
C NOTE:   The THE array angles and the static fragmentation             
C boundary angles are in ascending order.  This is the premise that     
C dictates the use of the initial loop parameter control, JC1X, for     
C loop 10.                                                              
                                                                        
            JC1X = J                                                    
            DO 10 J=JC1X,JCX                                            
               IF (BX(K) .LT. THE(J)) THEN                              
                                                                        
C The static zone boundary angle, BX, is less than the segment          
C fragment departure angle, THE(J).  If J equals 1, BX is less than the 
C smallest value of THE(J), and control is transfered to statement 20   
C to assign warhead segment radii and location array values.            
                                                                        
                  IF (J .EQ. 1) GOTO 20                                 
                                                                        
C Store the interpolated segment radii and locations for the lower      
C (K=1), middle (K=2), and upper (K=3) static zone boundary angles.     
                                                                        
                  DN = BX(K) - THE(J - 1)                               
                  SLR = (RF(J) - RF(J - 1)) / (THE(J) - THE(J - 1))     
                  SLP = (PF(J) - PF(J - 1)) / (THE(J) - THE(J - 1))     
                  IF (K .EQ. 1) THEN                                    
                     RPF1(I) = SLR * DN + RF(J - 1)                     
                     PLF1(I) = SLP * DN + PF(J - 1)                     
                  ELSEIF (K .EQ. 2) THEN                                
                     RPF2(I) = SLR * DN + RF(J - 1)                     
                     PLF2(I) = SLP * DN + PF(J - 1)                     
                  ELSEIF (K .EQ. 3) THEN                                
                     RPF3(I) = SLR * DN + RF(J - 1)                     
                     PLF3(I) = SLP * DN + PF(J - 1)                     
                  ENDIF                                                 
                  GOTO 30                                               
               ELSEIF (BX(K) .EQ. THE(J)) THEN                          
                                                                        
C The static zone boundary angle, BX, is equal to the segment fragment  
C departure angle, THE(J).  Transfer control to statement 20 as no      
C interpolation will be needed.                                         
                                                                        
                  GOTO 20                                               
               ENDIF                                                    
 10         CONTINUE                                                    
                                                                        
C Angle BX(K) is greater than the largest angle (last element) of the   
C THE array.  J is set so the largest segment radii and location values 
C of RF and PF will be stored in the segment radii and location arrays  
C for each static fragmentation zone.                                   
                                                                        
            J = JCX                                                     
                                                                        
C No interpolation is needed.  Assign the values of RF and PF to the    
C segment radii and location arrays for the lower (RPF1, PLF1),         
C middle (RPF2, PLF2), and upper (RPF3, PLF3) static fragmentation      
C zones.  Conditions for reaching this code are:                        
C    (1) BX(K) > largest value in the THE array.  Use RF and PF values  
C                which correspond to the last element of array THE.     
C    (2) BX(K) < smallest value in the THE array.  Use RF and PF values 
C                which correspond to the first element of array THE.    
C    (3) BX(K) = a value in the THE array.  Use corresponding RF and PF 
C                values.                                                
                                                                        
 20         IF (K .EQ. 1) THEN                                          
               RPF1(I) = RF(J)                                          
               PLF1(I) = PF(J)                                          
            ELSEIF (K .EQ. 2) THEN                                      
               RPF2(I) = RF(J)                                          
               PLF2(I) = PF(J)                                          
            ELSEIF (K .EQ. 3) THEN                                      
               RPF3(I) = RF(J)                                          
               PLF3(I) = PF(J)                                          
            ENDIF                                                       
                                                                        
C Set the J indicator to start loop 10 at the element corresponding to  
C the value of the THE array which was just tested.                     
                                                                        
 30         CONTINUE                                                    
 40      CONTINUE                                                       
                                                                        
C Write the lower, middle, and upper boundary angles for the ith static 
C fragmentation zones.  Write the corresponding warhead segment radii   
C and locations.                                                        
                                                                        
         WRITE(6,5010)B1(I),B2(I),B3(I),RPF1(I),RPF2(I),RPF3(I),PLF1(I),
     &                PLF2(I),PLF3(I)                                   
 50   CONTINUE                                                          
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (//,T50,'>>> BURIED WARHEAD DATA <<<',/,63('--'),/,T15,    
     &        'POLAR ZONES',T53,'WARHEAD SEGMENT RADII(FT)',T90,        
     &        'WARHEAD SEGMENT ','LOCATION(FT)',/,T95,                  
     &        'RELATIVE TO CENTROID',/,63('--'),/,1X,3(4X,              
     &        '  LOWER       MIDDLE        UPPER   '),/,63('--'))       
 5010 FORMAT (1X,'|',3(3(F10.2,3X),'|'))                                
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE CALC                                                   
C                                                                       
C---------------------------------------------------------------------- 
C Description:                                                          
C    For each radius and angle of integration, this routine calculates  
C the probability of killing the target by the weapon.  The target is   
C represented as a single or variable number of centroids.              
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   -------        -------  -------------------------------------       
C BB                 --     Probability of kill for fragments, blast    
C                           and fire effects for a target given that    
C                           the weapon has LOS to the target.           
C                                                                       
C BBS                --     Probability of kill from blast or direct    
C                           hit given that the weapon has LOS to the    
C                           target.                                     
C                                                                       
C BB7                --     Probability of kill for fragments given     
C                           that the weapon has LOS to the target.      
C                                                                       
C BFIRE              --     Probability of kill for fire.               
C                                                                       
C CC                 --     Probability of kill for fragments not       
C                           considering LOS.                            
C                                                                       
C CINT2             deg     Difference between upper and lower angle in 
C                           the ground plane where the target passes    
C                           from one dynamic zone to the next.          
C                                                                       
C COFF              deg     For a particular ground range, COFF is the  
C                           arc angle where the ground range arc        
C                           intersects the dead zone.                   
C                                                                       
C D0K                ft     Distance from the weapon where Pk = 0 for   
C                           fire effects.                               
C                                                                       
C D1K                ft     Maximum distance where fire will cause a    
C                           Pk = 1 given sufficient fuel leakage.       
C                                                                       
C DTD                ft     Distance from target to dead zone for       
C                           revetted targets.  DTD is negative if the   
C                           target is included in the dead zone.        
C                                                                       
C GM                deg     Angle in the ground plane where the target  
C                           passes into the next dynamic zone.          
C                                                                       
C GMID              deg     Angle used in burial routine to determine   
C                           if weapon's current zone is buried.         
C                                                                       
C GMLO               deg    Angle formed by the deflection axis and the 
C                           vector to the point where the next dynamic  
C                           fragment zone is encountered.               
C                                                                       
C GML02             deg     Angle in the ground plane where the target  
C                           passes into the next dynamic zone.          
C                                                                       
C GMUP2             deg     Upper angle in the ground plane of the      
C                           present dynamic zone.                       
C                                                                       
C IDEAD              --     Indicator:                                  
C                           TRUE  - A dead zone exists.                 
C                           FALSE - A dead zone does NOT exist.         
C                                                                       
C IDHT               --     Indicator :                                 
C                           TRUE  - Direct-hit option used.             
C                           FALSE - Direct-hit option NOT used.         
C                                                                       
C IFIRE              --     Indicator :                                 
C                           TRUE  - fire option used.                   
C                           FALSE - fire option NOT used.               
C                                                                       
C IRV                --     Indicator :                                 
C                           TRUE  - revetment has a dead zone.          
C                           FALSE - NO dead zone in revetment.          
C                                                                       
C JP                 --     Counter used in the ZZ array.               
C                                                                       
C KLBUR              --     Indicator:                                  
C                           TRUE  - Weapon is buried.                   
C                           FALSE - Weapon is NOT buried.               
C                                                                       
C LOSBLT             --     Indicator for line of sight of blast:       
C                              0 - NO line-of-sight                     
C                              1 - Line-of-sight exists                 
C                                                                       
C LOSFRG             --     Indicator for line of sight of fragments:   
C                              0 - NO line-of-sight                     
C                              1 - Line-of-sight exists                 
C                                                                       
C MATX               --     Indicator :                                 
C                           TRUE  - Compute matrix for Ith target       
C                                   type.                               
C                           FALSE - Do NOT compute matrix.              
C                                                                       
C MATZ               --     Indicator:                                  
C                           TRUE -  Compute lethal areas and output     
C                                   a matrix.                           
C                           FALSE - Compute only lethal areas.          
C                                                                       
C MOUNDOPT           --     Indicator:                                  
C                           TRUE  - Target is on a mound.               
C                           FALSE - Target is Not on a mound.           
C                                                                       
C MTX                --     Indicator:                                  
C                             FALSE - Arc with radius S1 does not enter 
C                                     matrix.                           
C                             TRUE - Arc with radius S1 DOES enter      
C                                    matrix.                            
C                                                                       
C M2                 --     Subscript of range grid coordinate.         
C                                                                       
C ND                        Indicator:                                  
C                             1 - Store Pk vs R values in ZZ array.     
C                             2 - Do NOT store Pk vs R values in ZZ     
C                                 array.                                
C                                                                       
C NMAZ               --     Indicator:                                  
C                             0 - Do NOT compute maximum matrix         
C                                 dimension.                            
C                             1 - Compute maximum matrix dimension.     
C                                                                       
C NQ                 --     Indicator:                                  
C                             1 - Multiple centroid target.             
C                             2 - Single centroid target.               
C                                                                       
C NRG                --     Number of matrix cells in range.            
C                                                                       
C NTPX               --     Number of Fragment centroids in target.     
C                                                                       
C NT7                --     Indicator:                                  
C                           TRUE  - Store Pk for each ground range (S1) 
C                                   and print.                          
C                           FALSE - Do NOT store Pk for each S1.        
C                                                                       
C NYN                --     Indicator:                                  
C                              TRUE - Weapon has blast effects.         
C                              FALSE - Weapon does NOT have blast effect
C                                                                       
C PIF                --     Probability of fire kill, give sufficient   
C                           fuel leakage, for a single arc increment.   
C                                                                       
C PKFIRE             --     Average probability of kill for fire over   
C                           an arc of radius S1.                        
C                                                                       
C PKH                --     Probability of kill given a direct hit.     
C                                                                       
C PSL                --     Probability of achieving sufficient fuel    
C                           leakage.                                    
C                                                                       
C QAV                ft     Blast centroid (height above ground).       
C                                                                       
C QQ                 --     Indicator:                                  
C                           TRUE  - Target is within a fragmentation    
C                                   zone.                               
C                           FALSE - Target is NOT located within a      
C                                   fragmentation zone.                 
C                                                                       
C Q1(I)              --     Average probability of kill over an arc for 
C                           blast, fragments, and fire at radius S1.    
C                                                                       
C Q41(I)             ft      Height of target fragmentation centroid(s).
C                                                                       
C Q43                ft      Weapon burst height.                       
C                                                                       
C Q6                deg      Impact angle of weapon.                    
C                                                                       
C RAR(I)             ft      Range grid coordinate of the Pk matrix.    
C                                                                       
C RD1                ft     Direct hit radius for direct hit weapons.   
C                           For revetted targets, RD1 is the equivalent 
C                           target size in the ground plane or presented
C                           area at 90 degrees converted to a radius.   
C                                                                       
C RDH                --     Indicator:                                  
C                           TRUE  - Weapon trajectory intersects target.
C                                   Use direct hit calculations.        
C                           FALSE - Weapon trajectory does NOT intersect
C                                   target.                             
C                                                                       
C ROP                --     Indicator:                                  
C                           TRUE  - Target is revetted.                 
C                           FALSE - Target is Not revetted.             
C                                                                       
C RXMAX              ft     Maximum effective distance in the range     
C                           direction (usually positive).               
C                                                                       
C RXMIN              ft     Maximum effective distance in the range     
C                           direction opposite RXMAX.                   
C                                                                       
C RYMAX              ft     Maximum effective distance in the deflection
C                           direction.                                  
C                                                                       
C SR1                ft     Slant range from weapon burst point to      
C                           target blast centroid.                      
C                                                                       
C SR2                ft     Slant range from weapon burst point to      
C                           target fragmentation centroid.              
C                                                                       
C SUMF               --     Accumulator for weighted Pk times arc length
C                           summed over 180 degree arc for fire kill.   
C                                                                       
C SUMP               --     Accumulator for weighted Pk times arc length
C                           summed over 180 degree arc for entire       
C                           target kill.                                
C                                                                       
C S1                 ft     Ground range. Distance from target to       
C                           weapon in the ground plane.                 
C                                                                       
C ZZ(J)              --     Used to store Pk for an arc increment.      
C                           ZZ(1) = ground range.                       
C                           For J even; ZZ(J) are angles in the         
C                           ground plane defining dynamic fragmentation 
C                           zones, measured from the deflection (Y)     
C                           axis at a ground range S1.                  
C                           For J odd; ZZ(J) are Pk associated with J   
C                           even.                                       
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C   BLT, INCEL, GRID, GAMS, THLS, MTXLIM, CELL, and SEKS                
C                                                                       
C---------------------------------------------------------------------- 
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      LOGICAL IOUT,NT9                                                  
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      COMMON  / ABUR /  GMUP,GMLO,RF1(50),RF2(50),PLT1(50),PLT2(50)     
      COMMON  / ALT1 /  COTM,D1I(50),IOUT,ND,NTRE,NT9,RATF(13)          
      COMMON  / ARTXX /  ABOX(40,40),RDR                                
      COMMON  / BVNZRO /  AVNZRO                                        
      COMMON  / CBUR /  GMID                                            
      COMMON  / COSINE /  CWR,SWR                                       
      COMMON  / DIRHIT /  PKH,RD1,TGTHT,Q43R,FRAGOPT                    
      COMMON  / PKR /  PKVSR(2000,2),KNT                                
      COMMON  / REV /  REVHT,REVSLP,REVTOT,ACTR,DTD,REVBAS,REVDIS,DEAD, 
     &       REVA,COFF,GONG,REVTOP,RTRAJ,LOSFRG,LOSBLT                  
                                                                        
C Initialize variables.                                                 
                                                                        
      ICOFF = 0                                                         
      IGM = 0                                                           
      PIF = 0.0                                                         
      GMUP2 = 90.0                                                      
      LBUR = 0                                                          
      SUMP = 0.0                                                        
      SUMF = 0.0                                                        
      ZZ(1) = S1                                                        
      ZZ(2) = 90.0                                                      
                                                                        
C If direct hit is considered or the target is revetted, then determine 
C if the weapon hits the target.  If the weapon does hit the target,    
C then the Pk is set to the PkH.                                        
                                                                        
      IF (IDHT .OR. ROP) THEN                                           
         BBS = 0.0                                                      
         IF (S1 .LE. RD1 .AND. RDH) BBS = PKH                           
                                                                        
C If direct hit is considered or the weapon is within the direct hit    
C radius of a revetted target then check to see if there are any        
C fire effects on the target.                                           
                                                                        
         IF (IDHT .OR. S1 .LE. RD1) GOTO 10                             
      ENDIF                                                             
                                                                        
C If blast effects are considered and the weapon has line-of-sight to   
C the target, then calculate the PkBlast.                               
                                                                        
      IF (NYN) THEN                                                     
         SR1 = SQRT(S1 *  * 2 + (Q43 - QAV) *  * 2)                     
         CALL BLT(SR1,BBS)                                              
         IF (LOSBLT .NE. 1) BBS = 0.0                                   
      ELSE                                                              
         BBS = 0.0                                                      
      ENDIF                                                             
                                                                        
C If fire effects are to be considered against the target, then         
C calculate the PkFire (PIF) at distance S1.  If the weapon is          
C within the lethal fire radius (D1K), Pk is set to one.  If the weapon 
C is between D1K and the maximum distance that fire will still have an  
C effect (D0K), then determine where on the fire curve the distance     
C S1 will fall and calculate the PkFire at that point.  If S1 is        
C greater that D0K, fire does not effect the total Pk.                  
                                                                        
 10   IF (IFIRE) THEN                                                   
         SR2 = SQRT(S1 *  * 2 + (Q43 - Q41(1)) *  * 2)                  
         IF (SR2 .LE. D1K) THEN                                         
            PIF = 1.0                                                   
         ELSEIF (SR2 .LE. D0K) THEN                                     
            PIF = 1.0 - (SR2 - D1K) / (D0K - D1K)                       
            IF (PIF .GT. 1.0 .OR. PIF .LT. 0.0) WRITE(6,5000)SR2,D1K,   
     &                                        D0K                       
         ELSE                                                           
            PIF = 0.0                                                   
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C If a matrix is to be computed in the run, then determine how the arc  
C enters the matrix (INCEL) and which side the arc enters the next      
C cell (GRID).                                                          
                                                                        
      IF (MATZ) THEN                                                    
         IF (S1 .GT. RAR(1)) THEN                                       
            IF ((RAR(NRG + 1) .GE. 0.0) .OR. (S1 .GT. ABS(RAR(NRG +     
     &          1)))) THEN                                              
               CALL INCEL                                               
               IF (M2 .EQ. 1) THEN                                      
                  MTX = .FALSE.                                         
               ELSE                                                     
                  CALL GRID(IYNX)                                       
               ENDIF                                                    
            ENDIF                                                       
         ELSE                                                           
                                                                        
C If arc does not enter the matrix, set appropriate indicators.         
                                                                        
            MATX = .FALSE.                                              
            MTX = .TRUE.                                                
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C Assign CENT the value of the single point fragment centroid.          
                                                                        
      CENT = Q41(1)                                                     
      IF (NQ .EQ. 1) CENT = Q41(NTPX + 1)                               
                                                                        
C Calculate the angle between the warhead axis and the fragment path    
C to the target.                                                        
                                                                        
      CALL THLS                                                         
                                                                        
C Determine which dynamic fragment zone the target lies in.             
                                                                        
      CALL GAMS(0)                                                      
                                                                        
C If the target is on a mound and a dead zone exists, set the indicator 
C IGM.                                                                  
                                                                        
      IF (MOUNDOPT .AND. IDEAD .AND. (COFF .NE. 90.) .AND. (GM .LT.     
     &    COFF)) IGM = 1                                                
                                                                        
C If the target is revetted, a dead zone exists, and the weapon         
C is inside the revetment, and the weapon does not physically hit the   
C target then...                                                        
                                                                        
      IF (ROP .AND. IRV .AND. (S1 .LT. REVTOT) .AND. (S1 .GT. RD1 .OR.  
     &    .NOT.RDH)) THEN                                               
                                                                        
C If the weapon is within the dead zone, set the Pk=0.0 and set the     
C angle to the next dynamic zone.                                       
                                                                        
         IF (S1 .GT. ABS(DTD)) THEN                                     
            GM = COFF                                                   
            ICOFF = 1                                                   
            BB = 0.0                                                    
            BFIRE = 0.0                                                 
            GOTO 20                                                     
         ENDIF                                                          
                                                                        
C If the target is within the dead zone, set the Pk=0.0 and the next    
C dynamic angle is set to -90.                                          
                                                                        
         IF (DTD .LE. 0.0) THEN                                         
            BB = 0.0                                                    
            BFIRE = 0.0                                                 
            GM =  - 90.0                                                
            GOTO 20                                                     
         ENDIF                                                          
                                                                        
      ENDIF                                                             
                                                                        
C If fragments cannot reach the target, then the set the probability    
C of kill due to frags and fuel leakage = 0.0.                          
                                                                        
      IF (.NOT.QQ) THEN                                                 
         CC = 0.0                                                       
         PSL = 0.0                                                      
                                                                        
      ELSE                                                              
                                                                        
C Calculate Pk due to fragmentation.                                    
C Set up angles to use in burial routine.                               
                                                                        
         IF (KLBUR) THEN                                                
            GMID = 100.0                                                
            GMUP = GMUP2                                                
            GMLO = GM                                                   
         ENDIF                                                          
                                                                        
         CALL SEKS                                                      
                                                                        
C If buried, store all your angles and calculated Pks.                  
                                                                        
         IF (KLBUR) THEN                                                
            IF ((GMID .NE. 100.0) .AND. (GMID .LT. GMUP2)) THEN         
                                                                        
C If zone is partially buried, save the angle where the zone becomes    
C unburied.  Save buried zone Pk.  Set partially buried indicator.      
                                                                        
               IF (GMID .GT. GM) THEN                                   
                  TGM = GM                                              
                  TCC = CC                                              
                  GM = GMID                                             
                  LBUR = 1                                              
               ENDIF                                                    
                                                                        
C Zone completely buried.  Set Pk=0                                     
                                                                        
               CC = 0.0                                                 
                                                                        
            ENDIF                                                       
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C Compute PkFrag with LINE-OF-SIGHT factored in.                        
                                                                        
      BB7 = CC * LOSFRG                                                 
                                                                        
C If revetted or direct hit and frags not considered, then frag Pk=0.   
                                                                        
      IF ((ROP .OR. IDHT) .AND. (S1 .LE. RD1) .AND. (FRAGOPT .EQ. 1.0)) 
     &    BB7 = 0.0                                                     
                                                                        
C Calculate PkFire.                                                     
                                                                        
      BFIRE = PIF * PSL * LOSFRG                                        
                                                                        
C Calculate the total Pk.                                               
                                                                        
      BB = 1.0 - (1.0 - BBS) * (1.0 - BB7) * (1.0 - BFIRE)              
                                                                        
C If the target is revetted or on a mound and frags are considered      
C then assign the last angle of integration.                            
                                                                        
 20   IF ((ROP .OR. MOUNDOPT) .AND. (LOSFRG .EQ. 0)) THEN               
         IF (COFF .NE. 90) THEN                                         
            GM = COFF                                                   
         ELSE                                                           
            GM =  - 90.                                                 
         ENDIF                                                          
      ENDIF                                                             
                                                                        
      IF (ND .EQ. 1) JP = 3                                             
                                                                        
C Set the integration angle.                                            
                                                                        
 30   GMLO2 = GM                                                        
      IF (IGM .EQ. 1) GMLO2 = COFF                                      
                                                                        
C If calculating Pk vs R then store the Pk for each radius in the       
C ZZ array.                                                             
                                                                        
      IF (ND .EQ. 1) THEN                                               
         ZZ(JP) = BB                                                    
         ZZ(JP + 1) = GMLO2                                             
         JP = JP + 2                                                    
      ENDIF                                                             
                                                                        
C If matrix is desired then write out the Pks and get information       
C necessary for calculating the Pk over a cell.                         
                                                                        
      IF (MATX) THEN                                                    
         IF (BB .LT. 0.) WRITE(6,5000)BB,BBS,BB7,BFIRE                  
         CALL CELL(GMLO2,BB)                                            
      ENDIF                                                             
                                                                        
C Sum Pk over a given arc length.                                       
                                                                        
      CINT2 = GMUP2 - GMLO2                                             
      SUMP = SUMP + BB * CINT2                                          
      SUMF = SUMF + BFIRE * CINT2                                       
                                                                        
C If the target is on a mound then initialize values.                   
                                                                        
      IF (MOUNDOPT) THEN                                                
         IF (IGM .EQ. 0) GOTO 40                                        
         BB = 0                                                         
         BFIRE = 0                                                      
         IGM = 0                                                        
         GM =  - 90                                                     
         GOTO 80                                                        
      ENDIF                                                             
                                                                        
C If weapon is buried, then adjust parameters for burial subroutines.   
                                                                        
 40   IF (LBUR .NE. 0) THEN                                             
         GM = TGM                                                       
         CC = TCC                                                       
         LBUR = 0                                                       
         GOTO 70                                                        
      ENDIF                                                             
                                                                        
C If the impact angle is 90 or the distance from the target to the      
C weapon is 0 then the entire arc has a single Pk.                      
                                                                        
      IF ((Q6 .EQ. 90.0) .OR. (S1 .EQ. 0.0)) THEN                       
         Q1(7) = BB                                                     
         GOTO 50                                                        
      ENDIF                                                             
                                                                        
C If the increments over the entire arc are complete then calculate the 
C average Pk for the arc for all options.                               
                                                                        
      IF (GMLO2 .LE.  - 90.0) THEN                                      
         Q1(7) = SUMP / 180.0                                           
         PKFIRE = SUMF / 180.0                                          
                                                                        
 50      IF (NT7) THEN                                                  
            KNT = KNT + 1                                               
            PKVSR(KNT,1) = S1                                           
            PKVSR(KNT,2) = Q1(7)                                        
         ENDIF                                                          
                                                                        
         IF (ND .EQ. 1) THEN                                            
            ZZ(JP) = Q1(7)                                              
         ENDIF                                                          
      ELSE                                                              
                                                                        
C Calculate the next integration angle.                                 
                                                                        
 60      CALL GAMS(1)                                                   
                                                                        
C If the angle is not in the dead zone then set the indicator.          
                                                                        
         IF (MOUNDOPT .AND. IDEAD .AND. (COFF .NE. 90.0) .AND. (GM .LT. 
     &       COFF)) IGM = 1                                             
                                                                        
C If the angle is within the dead zone then calculate the next angle.   
                                                                        
         IF (ROP .AND. (ICOFF .NE. 0) .AND. (GM .GE. COFF)) GOTO 60     
                                                                        
C If target is not in a fragmentation zone then set Pk for frags=0.     
                                                                        
         IF (.NOT.QQ) THEN                                              
            CC = 0.0                                                    
            PSL = 0.0                                                   
         ELSE                                                           
                                                                        
C Calculate the Pk for a specific zone and then set necessary variables 
C for a buried weapon.                                                  
                                                                        
            GMID = 100.0                                                
            GMUP = GMUP2                                                
            GMLO = GM                                                   
            CALL SEKS                                                   
            IF ((GMID .NE. 100.0) .AND. (GMID .LT. GMUP2)) THEN         
               IF (GMID .GT. GM) THEN                                   
                  TGM = GM                                              
                  TCC = CC                                              
                  GM = GMID                                             
                  LBUR = 1                                              
               ENDIF                                                    
               CC = 0.0                                                 
            ENDIF                                                       
         ENDIF                                                          
                                                                        
C Calculate Pk for frags considering Line-of-Sight.                     
                                                                        
 70      BB7 = CC * LOSFRG                                              
                                                                        
C If revetted or direct hit and frags not considered then frag pk=0.    
                                                                        
         IF ((ROP .OR. IDHT) .AND. (S1 .LE. RD1) .AND. (FRAGOPT .EQ.    
     &       1.0)) BB7 = 0.0                                            
                                                                        
C Calculate the Pk for fire effects considering Line-of-Sight.          
                                                                        
         BFIRE = PIF * PSL * LOSFRG                                     
                                                                        
C Calculate total Pk for region.                                        
                                                                        
         BB = 1.0 - (1.0 - BBS) * (1.0 - BB7) * (1.0 - BFIRE)           
                                                                        
C Increment to next angle and repeat loop.                              
                                                                        
 80      GMUP2 = GMLO2                                                  
         GOTO 30                                                        
      ENDIF                                                             
                                                                        
C Place the overall Pk of the region in the first element of Q1.        
                                                                        
      Q1(1) = Q1(7)                                                     
      Q1(2) = Q1(8)                                                     
                                                                        
C If a matrix is desired, calculate the maximum matrix dimensions.      
                                                                        
      IF (NMAZ .EQ. 1) THEN                                             
                                                                        
C If the weapon impacts at 90 degrees, then set the maximum matrix      
C coordinates to the current S1 value.                                  
                                                                        
         IF (ZERO(Q6,90.0) .EQ. 0.0) THEN                               
            IF (ZZ(3) .GT. 0.0) THEN                                    
               RXMAX = S1                                               
               RXMIN =  - S1                                            
               RYMAX = S1                                               
            ENDIF                                                       
         ELSE                                                           
                                                                        
C If the weapon impacts at an angle other than 90 degrees, call MTXLIM  
C to compute the maximum matrix dimensions based on the current S1.     
                                                                        
            CALL MTXLIM(JP,ZZ,RXMAX,RXMIN,RYMAX)                        
         ENDIF                                                          
      ENDIF                                                             
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (4F10.4)                                                   
      END                                                               
C                                                                       
      SUBROUTINE CELL(GMLO,BB)                                          
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Calculates the values (BOX & ABOX) needed to compute the           
C average PK over a cell.  PK = BOX / ABOX                              
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C ABOX(I,J)        sq ft    Area of a cell or portion of a cell.        
C                           Note: ABOX is the accumulation of DANG.     
C                                                                       
C ALOB               deg    Angle formed by the deflection axis and     
C                           the vector to the point on the arc which    
C                           exits the cell.                             
C                                                                       
C AUPB               deg    Angle formed by the deflection axis         
C                           and the line to the point on the arc        
C                           which enters the cell.                      
C                           Note: Angle is incremented through the      
C                                 cell until the cell is transversed.   
C                                                                       
C BB                 --     PK in the given dynamic frag zone.          
C                                                                       
C BOX(I,J)         sq ft    Lethal area of a cell or portion of a cell. 
C                           Note: BOX is the accumulation of (DANG X PK)
C                                                                       
C DANG             sq ft    Area in a cell or defined portion of a cell.
C                                                                       
C DEG2RAD            --     Conversion factor for degrees to radians.   
C                                                                       
C GMLO               deg    Angle formed by the deflection axis and the 
C                           vector to the point where the next dynamic  
C                           fragment zone is encountered.               
C                                                                       
C IN                        Indicator for cell side where arc entered:  
C                                1 - Arc entered bottom of cell         
C                                2 - Arc entered top of cell            
C                                3 - Arc entered side of cell           
C                                                                       
C IYN                 --    Indicator:                                  
C                                1 - portion of cell still needs to be  
C                                    evaluated.                         
C                                2 - Reset MATX and MTX to 1 and exit.  
C                                3 - Determine if any portion of cell   
C                                    still needs to be evaluated.       
C                                                                       
C MATX                --    Indicator:                                  
C                           TRUE  - Compute matrix for target.          
C                           FALSE - Do NOT compute matrix.              
C                                                                       
C MTX                 --    Indicator:                                  
C                                0 - Arc does not enter the matrix.     
C                                1 - Arc enters the matrix.             
C                                                                       
C M1                  --    Subscript of the largest deflection grid    
C                           coordinate of the current cell.             
C                                                                       
C M2                  --    Subscript of the largest range grid         
C                           coordinate of the current cell.             
C                                                                       
C RDR               sq ft   Ground plane distance from the burst point  
C                           to the target (S1) times the integration    
C                           step size.                                  
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C GRID                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C CALC                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      INCLUDE 'stdparameter_clean.inc'                                        
C                                                                       
      COMMON  / ARTXX /  ABOX(40,40),RDR                                
                                                                        
C If the Pk for the dynamic zone arc is negative, write an error message
C and exit.                                                             
                                                                        
      IF (BB .LT. 0.0) THEN                                             
         WRITE(6,5000)'PK'                                              
         CALL EXIT                                                      
      ENDIF                                                             
                                                                        
C Determine if the arc is within the matrix.  If not, then exit routine.
                                                                        
 10   IF (AUPB .GT. GMLO) THEN                                          
                                                                        
C If the dynamic zone is completely contained in the cell, find the     
C lethal area of this portion of the cell and increment the angle of    
C entry to the end of the dynamic zone.  Exit the routine.              
                                                                        
 20      IF (ALOB .LT. GMLO) THEN                                       
            DANG = (AUPB - GMLO) * DEG2RAD * RDR                        
            BOX(M1 - 1,M2 - 1) = BOX(M1 - 1,M2 - 1) + BB * DANG         
            ABOX(M1 - 1,M2 - 1) = ABOX(M1 - 1,M2 - 1) + DANG            
            AUPB = GMLO                                                 
                                                                        
C The cell is contained in the remainder of the dynamic zone. Compute   
C values for the lethal area of the cell. Increment the angle of        
C cell entry to the angle of exit to check next cell.  Exit routine.    
                                                                        
         ELSE                                                           
                                                                        
C If the arc length is negative, write an error message and exit.       
                                                                        
            IF (AUPB .LT. ALOB) THEN                                    
               WRITE(6,5000)'ARC'                                       
               CALL EXIT                                                
            ENDIF                                                       
                                                                        
            DANG = (AUPB - ALOB) * DEG2RAD * RDR                        
            BOX(M1 - 1,M2 - 1) = BOX(M1 - 1,M2 - 1) + BB * DANG         
            ABOX(M1 - 1,M2 - 1) = ABOX(M1 - 1,M2 - 1) + DANG            
            AUPB = ALOB                                                 
                                                                        
C Arc will enter the bottom of the next cell, therefore increment the   
C deflection index.                                                     
                                                                        
            IF (IN .EQ. 1) THEN                                         
               M1 = M1 + 1                                              
                                                                        
C Determine which side of the cell the arc will exit.                   
                                                                        
               IYN = 1                                                  
               CALL GRID(IYN)                                           
                                                                        
C Determine where arc is located in cell.                               
                                                                        
               IF (IYN .EQ. 1) GOTO 20                                  
               IF (IYN .EQ. 3) GOTO 10                                  
            ELSE                                                        
                                                                        
C Arc will enter the top of the next cell, so decrement the             
C deflection index.                                                     
                                                                        
               IF (IN .EQ. 2) THEN                                      
                  M1 = M1 - 1                                           
                  IF (M1 .GT. 1) THEN                                   
                                                                        
C Determine which side of the cell the arc will exit.                   
                                                                        
                     IYN = 1                                            
                     CALL GRID(IYN)                                     
                                                                        
C Determine where arc is located in the cell.                           
                                                                        
                     IF (IYN .EQ. 1) GOTO 20                            
                     IF (IYN .EQ. 3) GOTO 10                            
                  ENDIF                                                 
                                                                        
C Arc will enter the side of the next cell, so decrement the range      
C index.                                                                
                                                                        
               ELSE                                                     
                  M2 = M2 - 1                                           
                  IF (M2 .GT. 1) THEN                                   
                                                                        
C Call GRID to determine which side of the cell the arc will exit.      
                                                                        
                     IYN = 1                                            
                     CALL GRID(IYN)                                     
                                                                        
C Determine where arc is located in matrix.                             
                                                                        
                     IF (IYN .EQ. 1) GOTO 20                            
                     IF (IYN .EQ. 3) GOTO 10                            
                  ENDIF                                                 
               ENDIF                                                    
            ENDIF                                                       
                                                                        
C If arc does not continue in matrix, set flags so that this            
C routine will not be called again.                                     
                                                                        
            MATX = .FALSE.                                              
            MTX = .TRUE.                                                
         ENDIF                                                          
      ENDIF                                                             
      RETURN                                                            
                                                                        
 5000 FORMAT (' %-ERROR- SUBR=CELL ',A,' IS NEGATIVE IN MATRIX')        
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE CUTMOUND(TLOG,QAV,Q43,RB1)                             
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C This subroutine will calculate where on the mound the blast radius    
C will fall. If the blast radius hits on the slope of the mound then    
C it will calculate a ground distance to the edge of the blast          
C radius and set the boundary between the second and third              
C integration regions to this distance.                                 
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C                                                                       
C A                  --     Intermediate variable used to calculate     
C                           the intersection of the blast radius and    
C                           the mound slope.                            
C                                                                       
C B                  --     Intermediate variable used to calculate     
C                           the intersection of the blast radius and    
C                           the mound slope.                            
C                                                                       
C C                  --     Intermediate variable used to calculate     
C                           the intersection of the blast radius and    
C                           the mound slope.                            
C                                                                       
C D                  --     Intermediate variable used to calculate     
C                           the intersection of the blast radius and    
C                           the mound slope.                            
C                                                                       
C QAV                ft     Height of target centroid for blast.        
C                           Includes mound height.                      
C                                                                       
C Q43                ft     Weapon burst height.                        
C                                                                       
C RB1                ft     Maximum distance from burst that PKB = 1.0  
C                           (PKB is probability of kill due to blast).  
C                                                                       
C REVBAS             ft     Width of revetment base or radius of mound  
C                           base.                                       
C                                                                       
C REVHT              ft     Height of revetment or mound.               
C                                                                       
C REVTOP             ft     Width of revetment top or radius of mound   
C                           top.                                        
C                                                                       
C SLOPE                     Slope of mound face.                        
C                                                                       
C TLOG               ft     Boundary between 2nd and third integration  
C                           regions. If only 2 regions, TLOG=RMAXX.     
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Referenced                                                
C    None                                                               
C---------------------------------------------------------------------- 
C Calling Routine                                                       
C    Main                                                               
C---------------------------------------------------------------------- 
C                                                                       
      COMMON  / REV /  REVHT,REVSLP,REVTOT,ACTR,DTD,REVBAS,REVDIS,DEAD, 
     &REVA,COFF,GONG,REVTOP,RTRAJ,LOSFRG,LOSBLT                         
                                                                        
C If the blast radius is less than the mound top radius, then set       
C ground distance to the blast radius. Exit routine.                    
                                                                        
      IF (RB1 .LE. REVTOP) THEN                                         
         TLOG = RB1                                                     
      ELSEIF (RB1 .GT. QAV) THEN                                        
                                                                        
C Blast radius will reach the ground plane. Calculate ground range      
C distance of blast radius. Exit routine.                               
                                                                        
         TLOG = SQRT(RB1 *  * 2 - (QAV - Q43) *  * 2)                   
      ELSE                                                              
                                                                        
C Blast radius does not reach ground plane, but extends past top of     
C mound. Calculate where on mound face the blast radius falls.          
                                                                        
         SLOPE = REVHT / (REVTOP - REVBAS)                              
         D =  - SLOPE * REVBAS - QAV                                    
         A = 1 + SLOPE *  * 2                                           
         B = 2 * (SLOPE * D)                                            
         C = D *  * 2 - RB1 *  * 2                                      
         TLOG = ( - B + SQRT(B *  * 2 - 4 * A * C)) / (2. * A)          
      ENDIF                                                             
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE DINTT(AA,CMQQ,J1,VPA,VPP)                              
C                                                                       
C---------------------------------------------------------------------- 
C DESCRIPTION: The purpose of this subroutine is to use the fragment    
C              striking velocity, AA, and weight, CMQQ, from fragment   
C              spray data (provided by subroutine SEKS) to determine the
C              resulting vulnerable area and probability of exposure by 
C              interpolating the appropriate fragment kill or fire kill 
C              data table.  If a strip target is selected, a vulnerable 
C              area and probability of exposure value will be determined
C              for each strip.                                          
C                                                                       
C VARIABLES:                                                            
C     Name          Units                  Definition                   
C ---------------  -------  --------------------------------------------
C AA               ft/sec   Fragment striking velocity.                 
C                                                                       
C CMQQ             grains   Fragment weight.                            
C                                                                       
C FAMV(I,J)        sq ft    I=1,J1*MAN ; J=1,KNVLE.  Fire vulnerable    
C                           areas for ith weight and jth velocity for   
C                           the fragment elevation angle.               
C                                                                       
C FPMV(I,J)          --     I=1,J1*MAN ; J=1,KNVLE.  Fire probability of
C                           exposure for the ith weight and jth velocity
C                           for the fragment elevation angle.           
C                                                                       
C FVLE(I)          ft/sec   I=1,KNVLE.  Fragment velocities in fire     
C                           vulnerable area table.                      
C                                                                       
C FXMA(I)          grains   I=1,KMAN.  Fragment weights in fire         
C                           vulnerable area table.                      
C                                                                       
C IFT                --     Indicator:                                  
C                             TRUE  - FIRE does contribute to kill      
C                             FALSE - FIRE does not contribute to kill  
C                                                                       
C J1                 --     Target strip being considered.              
C                                                                       
C KI                 --     Array index for the nearest fragment weight 
C                           in array TXMA that is larger than CMQQ.     
C                                                                       
C KI1                --     Array index for the nearest fragment weight 
C                           in array TXMA that is smaller than CMQQ.    
C                                                                       
C KJ                 --     Array index for the nearest fragment        
C                           velocity in array TVLE that is smaller than 
C                           AA.                                         
C                                                                       
C KJ1                --     Array index for the nearest fragment        
C                           velocity in array TVLE that is larger than  
C                           AA.                                         
C                                                                       
C KMAN               --     Number of fragment weights in fire          
C                           vulnerable area table.                      
C                                                                       
C KNVLE              --     Number of fragment velocities in fire       
C                           vulnerable area table.                      
C                                                                       
C LZF                --     Adjusts array indices KI and KI1 to select  
C                           the J1th target strip in the fire vulnerable
C                           area table.                                 
C                                                                       
C LZM                --     Adjusts array indices KI and KI1 to select  
C                           the J1th target strip in the fragment kill  
C                           table.                                      
C                                                                       
C MAN                --     Number of fragment weights in target        
C                           vulnerability table.                        
C                                                                       
C NVLE               --     Number of velocities in target vulnerability
C                           table.                                      
C                                                                       
C TP1A             sq ft    Vulnerable area obtained by interpolating   
C                           the vulnerable areas table, XAMV, for weight
C                           CMQQ and the closest velocity which is      
C                           smaller than the fragment striking velocity,
C                           AA.                                         
C                                                                       
C TP1P               --     Probability of exposure obtained by         
C                           interpolating the probability of exposure   
C                           table, XPMV, for weight CMQQ and the closest
C                           velocity which is larger than the fragment  
C                           striking velocity, AA.                      
C                                                                       
C TP2A             sq ft    Vulnerable area obtained by interpolating   
C                           the vulnerable areas table, XAMV, for weight
C                           CMQQ and the closest velocity which is      
C                           smaller than the fragment striking velocity,
C                           AA.                                         
C                                                                       
C TP2P               --     Probability of exposure obtained by         
C                           interpolating the probability of exposure   
C                           table, XPMV, for weight CMQQ and the closest
C                           velocity which is larger                    
C                           than the fragment striking velocity, AA.    
C                                                                       
C TPM                --     Fragment weight interpolation factor        
C                           produced when NUM is divided by DEN, where: 
C                             NUM is the difference between the fragment
C                                 striking weight, CMQQ, and the smaller
C                                 weight in TXMA which is closest to    
C                                 CMQQ, and,                            
C                             DEN is the difference between the two     
C                                 weights in TXMA which bracket CMQQ.   
C                                                                       
C TPV                --     Fragment velocity interpolation factor      
C                           produced when NUM is divided by DEN, where: 
C                             NUM is the difference between the fragment
C                                 striking velocity, AA, and the smaller
C                                 velocity in TVLE which is closest to  
C                                 AA, and,                              
C                             DEN is the difference between the two     
C                                 velocities in TVLE which bracket AA.  
C                                                                       
C TVLE(I)          ft/sec   I=1,NVLE.  Fragment kill table, fragment    
C                           velocities.                                 
C                                                                       
C TXMA(I)          grains   I=1,MAN.  Fragment kill table, fragment     
C                           weights.                                    
C                                                                       
C VPA               sq ft   Target vulnerable areas for velocity, AA,   
C                           and weight, CMQQ.                           
C                                                                       
C VPP                --     Probability of exposure of vulnerable       
C                           area for velocity, AA, and weight, CMQQ.    
C                                                                       
C XAMV(I,J)        sq ft    I=1,J1*MAN ; J=1,KVLE.  Fragment vulnerable 
C                           area table for the ith weight and jth       
C                           velocity for the fragment elevation angle.  
C                                                                       
C XPMV(I,J)          --     I=1,J1*MAN ; J=1,KVLE.  Fragment            
C                           probability of exposure table for ith weight
C                           and jth velocity for the fragment elevation 
C                           angle.                                      
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines called:                                                   
C                                                                       
C   NONE                                                                
C---------------------------------------------------------------------- 
C Functions called:                                                     
C                                                                       
C  NONE                                                                 
C---------------------------------------------------------------------- 
C Calling routine:                                                      
C                                                                       
C  SEKS                                                                 
C---------------------------------------------------------------------- 
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
                                                                        
      IF (.NOT.IFT) THEN                                                
                                                                        
C Fragment kill data (FIRE does NOT contribute to kill).  Set the array 
C index LZM to a value representing the target strip of interest.       
                                                                        
         LZM = (J1 - 1) * MAN                                           
                                                                        
         DO 10 I=1,MAN                                                  
            IF (CMQQ .LT. TXMA(I)) THEN                                 
               IF (I .EQ. 1) THEN                                       
                                                                        
C Fragment weight, CMQQ, is less than the first (smallest) weight in the
C fragment weight table, TXMA.  No interpolation will be done and the   
C vulnerable areas for the smallest weight in the table will be used.   
C Set array  index values KI and KI1 to indicate the first element of   
C table XAMV.                                                           
                                                                        
                  TPM = 0.0                                             
                  KI = LZM + 1                                          
                  KI1 = KI                                              
               ELSE                                                     
                                                                        
C Fragment weight, CMQQ, is located between two weights in the fragment 
C weight table, TXMA.  Interpolation will be done for weight CMQQ.  Set 
C array index values KI and KI1 to indicate the elements to interpolate 
C between.                                                              
                                                                        
                  TPM = (CMQQ - TXMA(I - 1)) / (TXMA(I) - TXMA(I - 1))  
                  KI = LZM + I - 1                                      
                  KI1 = KI + 1                                          
               ENDIF                                                    
               GOTO 20                                                  
            ELSEIF (CMQQ .EQ. TXMA(I)) THEN                             
                                                                        
C Fragment weight, CMQQ, is equal to a weight in the fragment weight    
C table, TXMA, and no interpolation will be done. Set array index values
C KI and KI1 to indicate the element of table XAMV.                     
                                                                        
               TPM = 0.0                                                
               KI = LZM + I                                             
               KI1 = KI                                                 
               GOTO 20                                                  
            ENDIF                                                       
                                                                        
 10      CONTINUE                                                       
                                                                        
C Fragment weight, CMQQ, is larger than the last (largest) weight in the
C fragment velocity table, TXMA.  No interpolation will be done and the 
C vulnerable areas for the largest weight in the array will be used. Set
C array index values KI and KI1 to indicate the last element of table   
C XAMV.                                                                 
                                                                        
         TPM = 0.0                                                      
         KI = LZM + MAN                                                 
         KI1 = KI                                                       
                                                                        
 20      DO 30 JLR=1,NVLE                                               
            IF (AA .LT. TVLE(JLR)) THEN                                 
               IF (JLR .EQ. 1) THEN                                     
                                                                        
C Fragment velocity, AA, is less than the first (smallest) velocity in  
C fragment velocity table, TVLE.  No interpolation will be done and the 
C vulnerable areas for the smallest velocity in the table  will be used.
C Set array index values KJ and KJ1 to indicate the first element of    
C table XAMV.                                                           
                                                                        
                  TPV = 0.0                                             
                  KJ = 1                                                
                  KJ1 = KJ                                              
               ELSE                                                     
                                                                        
C Fragment velocity, AA, is located between two velocities in the       
C fragment velocity table, TVLE.  Interpolation will be done for        
C velocity AA.  Set array index values KJ and KJ1 to indicate the       
C elements to interpolate between.                                      
                                                                        
                  KJ1 = JLR                                             
                  KJ = JLR - 1                                          
                  TPV = (AA - TVLE(KJ)) / (TVLE(KJ1) - TVLE(KJ))        
               ENDIF                                                    
               GOTO 40                                                  
            ELSEIF (AA .EQ. TVLE(JLR)) THEN                             
                                                                        
C Fragment velocity, AA, is equal to a velocity in the fragment         
C velocity table, TVLE, and no interpolation will be done.   Set array  
C index values KJ and KJ1 to indicate the element of table XAMV.        
                                                                        
               TPV = 0.0                                                
               KJ = JLR                                                 
               KJ1 = KJ                                                 
               GOTO 40                                                  
            ENDIF                                                       
 30      CONTINUE                                                       
                                                                        
C Fragment velocity, AA, is greater than the last (largest) velocity    
C in the fragment velocity table, TVLE.  No interpolation will be done  
C and the vulnerable areas for the largest velocity in the table  will  
C be used. Set array index values KJ and KJ1 to indicate the last       
C element of table XAMV.                                                
                                                                        
         TPV = 0.0                                                      
         KJ = NVLE                                                      
         KJ1 = KJ                                                       
                                                                        
C Interpolate the vulnerable area and probability of exposure tables    
C for weight CMQQ to obtain TP1A, TP2A, TP1P, and TP2P. Interpolate TP1A
C and TP2A for velocity AA to obtain the vulnerable area VPA.           
C Interpolate TP1P and TP2P for velocity AA to obtain the probability of
C exposure, VPP.  If a strip target is selected, set VPP to 1.0         
C (probabilities of exposure for strip targets are included in the      
C vulnerable areas).  Return VPA and VPP to subroutine SEKS.            
                                                                        
 40      TP1A = XAMV(KI,KJ) + TPM * (XAMV(KI1,KJ) - XAMV(KI,KJ))        
         TP2A = XAMV(KI,KJ1) + TPM * (XAMV(KI1,KJ1) - XAMV(KI,KJ1))     
         VPA = TP1A + TPV * (TP2A - TP1A)                               
         TP1P = XPMV(KI,KJ) + TPM * (XPMV(KI1,KJ) - XPMV(KI,KJ))        
         TP2P = XPMV(KI,KJ1) + TPM * (XPMV(KI1,KJ1) - XPMV(KI,KJ1))     
         VPP = TP1P + TPV * (TP2P - TP1P)                               
         IF (NQ .EQ. 1) VPP = 1                                         
                                                                        
      ELSE                                                              
                                                                        
C Interpolate fire kill data.  The remaining code interpolates in the   
C same manner as the above code for fragmentation kill data.  Set the   
C array index LZF to a value representing the target strip of interest. 
                                                                        
         LZF = (J1 - 1) * KMAN                                          
                                                                        
         DO 50 I=1,KMAN                                                 
            IF (CMQQ .LT. FXMA(I)) THEN                                 
               IF (I .EQ. 1) THEN                                       
                                                                        
C Fragment weight, CMQQ, is less than the first (smallest) weight in the
C fragment weight table, FXMA.  No interpolation will be done and the   
C vulnerable areas for the smallest weight in table will be used. Set   
C array  index values KI and KI1 to indicate the first element of table 
C FAMV.                                                                 
                                                                        
                  TPM = 0.                                              
                  KI = LZF + 1                                          
                  KI1 = KI                                              
               ELSE                                                     
                                                                        
C Fragment weight, CMQQ, is located between two weights in the fragment 
C weight table, FXMA.  Interpolation will be done for weight CMQQ.  Set 
C array index values KI and KI1 to indicate the elements to interpolate 
C between.                                                              
                                                                        
                  TPM = (CMQQ - FXMA(I - 1)) / (FXMA(I) - FXMA(I - 1))  
                  KI = LZF + I - 1                                      
                  KI1 = KI + 1                                          
               ENDIF                                                    
               GOTO 60                                                  
            ELSEIF (CMQQ .EQ. FXMA(I)) THEN                             
                                                                        
C Fragment weight, CMQQ, is equal to a weight in the fragment weight    
C table, FXMA, and no interpolation will be done. Set array index values
C KI  and KI1 to indicate the element of table FAMV.                    
                                                                        
               TPM = 0.                                                 
               KI = LZF + I                                             
               KI1 = KI                                                 
               GOTO 60                                                  
            ENDIF                                                       
 50      CONTINUE                                                       
                                                                        
C Fragment weight,CMQQ, is greater than the last (largest) weight in the
C fragment velocity table, FXMA.  No interpolation will be done and the 
C vulnerable areas for the largest weight in the array will be used. Set
C array index values KI and KI1 to indicate the last element of table   
C FAMV.                                                                 
                                                                        
         TPM = 0.0                                                      
         KI = LZF + KMAN                                                
         KI1 = KI                                                       
                                                                        
 60      DO 70 JLR=1,KNVLE                                              
            IF (AA .LT. FVLE(JLR)) THEN                                 
               IF (JLR .EQ. 1) THEN                                     
                                                                        
C Fragment velocity, AA, is less than the first (smallest) velocity in  
C fragment velocity table, FVLE.  No interpolation will be done and the 
C vulnerable areas for the smallest velocity in the table will be used. 
C Set array index values KJ and KJ1 to indicate the first element of    
C table FAMV.                                                           
                                                                        
                  TPV = 0.0                                             
                  KJ = 1                                                
                  KJ1 = KJ                                              
               ELSE                                                     
                                                                        
C Fragment velocity, AA, is located between two velocities in the       
C fragment velocity table, FVLE.  Interpolation will be done for        
C velocity AA.  Set array index values KJ and KJ1 to indicate the       
C elements to interpolate between.                                      
                                                                        
                  KJ1 = JLR                                             
                  KJ = JLR - 1                                          
                  TPV = (AA - FVLE(KJ)) / (FVLE(KJ1) - FVLE(KJ))        
               ENDIF                                                    
               GOTO 80                                                  
            ELSEIF (AA .EQ. FVLE(JLR)) THEN                             
                                                                        
C Fragment velocity, AA, is equal to a velocity in the fragment         
C velocity table, FVLE, and no interpolation will be done.   Set array  
C index values KJ and KJ1 to indicate the element of table XAMV.        
                                                                        
               TPV = 0.0                                                
               KJ = JLR                                                 
               KJ1 = KJ                                                 
               GOTO 80                                                  
            ENDIF                                                       
 70      CONTINUE                                                       
                                                                        
C Fragment velocity, AA, is greater than the last (largest) velocity    
C in the fragment velocity table, FVLE.  No interpolation will be done  
C and the vulnerable areas for the largest velocity in the table  will  
C be used. Set array index values KJ and KJ1 to indicate the last       
C element of table FAMV.                                                
                                                                        
         TPV = 0.0                                                      
         KJ = KNVLE                                                     
         KJ1 = KJ                                                       
                                                                        
C Interpolate the vulnerable area and probability of exposure tables    
C for weight CMQQ to obtain TP1A, TP2A, TP1P, and TP2P. Interpolate TP1A
C and TP2A for velocity AA to obtain the vulnerable area VPA.           
C Interpolate TP1P and TP2P for velocity AA to obtain the probability of
C exposure, VPP.  Return VPA and VPP to subroutine SEKS.                
                                                                        
 80      TP1A = FAMV(KI,KJ) + TPM * (FAMV(KI1,KJ) - FAMV(KI,KJ))        
         TP2A = FAMV(KI,KJ1) + TPM * (FAMV(KI1,KJ1) - FAMV(KI,KJ1))     
         VPA = TP1A + TPV * (TP2A - TP1A)                               
         TP1P = FPMV(KI,KJ) + TPM * (FPMV(KI1,KJ) - FPMV(KI,KJ))        
         TP2P = FPMV(KI,KJ1) + TPM * (FPMV(KI1,KJ1) - FPMV(KI,KJ1))     
         VPP = TP1P + TPV * (TP2P - TP1P)                               
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE DRRR(J,RM,ICX)                                         
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Computes the maximum effective range for each fragment weight      
C group in a dynamic fragmentation zone.                                
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C C1(J)             ft/sec  Average initial vectored fragment velocity, 
C                           Jth zone.                                   
C                                                                       
C C3                ft/sec  Constant cutoff velocity.                   
C                                                                       
C D2(I,J)           grains  Weight of Ith group in Jth static zone.     
C                                                                       
C F5                 --     Cosine of cutoff angle.                     
C                                                                       
C ICX                --     Number of weight groups in zone.            
C                                                                       
C J                  --     Number of static zone.                      
C                                                                       
C MT7                --     Indicator:                                  
C                             FALSE - Use constant cutoff velocity.     
C                             TRUE - Use computed or input cutoff       
C                                    velocity.                          
C                                                                       
C DEG2RAD            --     Conversion from degrees to radians.         
C                                                                       
C Q43                ft     Burst height of the weapon.                 
C                                                                       
C RM(I)              ft     Maximum effective range for Ith group.      
C                                                                       
C RM1                ft     Distance the fragment travels corresponding 
C                           to the cutoff angle.                        
C                                                                       
C RM2                ft     Distance the fragment travels before the    
C                           velocity becomes less than or equal to the  
C                           cutoff velocity.                            
C                                                                       
C R2               degree   Cutoff Angle.                               
C                                                                       
C TEMP             radian   Cutoff Angle converted to radians.          
C                                                                       
C VTQ              ft/sec   Cutoff velocity when the probability        
C                           of kill equals 0.                           
C                                                                       
C WZ4(I,J)         ft/sec   Computed cutoff velocity for Ith group.     
C                                                                       
C-----------------------------------------------------------------------
C SUBROUTINES REFERENCED                                                
C                                                                       
C XDRG                                                                  
C                                                                       
C-----------------------------------------------------------------------
C FUNCTIONS REFERENCED                                                  
C                                                                       
C ROUND                                                                 
C                                                                       
C-----------------------------------------------------------------------
C CALLING ROUTINE                                                       
C                                                                       
C ZONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      DIMENSION RM(25)                                                  
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
                                                                        
      TEMP = R2 * DEG2RAD                                               
      F5 = COS(TEMP)                                                    
                                                                        
C Compute the maximum effective range for each weight group.            
                                                                        
      DO 10 I=1,ICX                                                     
                                                                        
C Determine whether the cutoff velocity needs to be assigned or is      
C constant.                                                             
                                                                        
         IF (MT7) THEN                                                  
            VTQ = WZ4(I,J)                                              
         ELSE                                                           
            VTQ = C3                                                    
         ENDIF                                                          
                                                                        
C Cutoff velocity must have a minimum value of 1.0.                     
                                                                        
         IF (ROUND(VTQ,1) .LE. 0.0) VTQ = 1.0                           
                                                                        
C If cutoff velocity at 0 Pk is larger than the average velocity in the 
C zone, set the maximum effective range to zero.                        
                                                                        
         IF (VTQ .GE. C1(J)) THEN                                       
            RM(I) = 0.0                                                 
                                                                        
         ELSE                                                           
                                                                        
C Find distance fragment will travel between the initial and cutoff     
C velocities.                                                           
                                                                        
            CALL XDRG(C1(J),D2(I,J),VTQ,RM2)                            
                                                                        
C Set maximum effective range to above computed distance.               
                                                                        
            RM(I) = RM2                                                 
                                                                        
C If the cutoff angle is not equal to 90, then compute the maximum      
C effective range using the cutoff angle.  Set the maximum effective    
C range for this zone equal to the cutoff velocity maximum range or     
C cutoff angle maximum range, whichever is smallest.                    
                                                                        
            IF (ROUND(R2,1) .NE. 90.0) THEN                             
               RM1 = Q43 / F5                                           
               RM(I) = MIN(RM1,RM(I))                                   
            ENDIF                                                       
         ENDIF                                                          
 10   CONTINUE                                                          
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE EXANG                                                  
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    This subroutine computes the angle of exit (ALOB) of the arc with  
C radius S1 from the current cell.                                      
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C ALOB               deg    Exit angle from the current cell formed     
C                           by the deflection axis and the radius of    
C                           the arc where the arc exits the cell.       
C                                                                       
C DAR(I)             ft     Ith deflection grid coordinate.             
C                                                                       
C DENO               ft     Distance measured in the deflection         
C                           direction from the weapon burst point to the
C                           point on the current cell where the arc     
C                           exits the cell.                             
C                                                                       
C DIF                ft     Distance measured in the range direction    
C                           from the weapon burst point to the point    
C                           on the current cell where the arc exits     
C                           the cell.                                   
C                                                                       
C IN                        Indicator for cell side where arc entered:  
C                                1 - Arc entered bottom of cell         
C                                2 - Arc entered top of cell            
C                                3 - Arc entered side of cell           
C                                                                       
C M1                  --    Subscript of the largest deflection grid    
C                           coordinate of the current cell.             
C                                                                       
C M2                  --    Subscript of the largest range grid         
C                           coordinate of the current cell.             
C                                                                       
C RAD2DEG             --    Conversion factor for radians to degrees.   
C                                                                       
C RAR(I)              ft    Ith range grid coordinate.                  
C                                                                       
C S1S               sq ft   Squared distance from the burst point of    
C                           the weapon to the target measured in the    
C                           ground plane.                               
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C ZERO1                                                                 
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C GRID                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
                                                                        
C Print an error message if the range coordinate subscript is not       
C greater than 1.                                                       
                                                                        
      IF (M2 .LE. 1) THEN                                               
         WRITE(6,5000)'M2',M2                                           
         CALL EXIT                                                      
      ENDIF                                                             
                                                                        
C If the next cell will be entered from the bottom, then calculate      
C the distance in range using the largest deflection coordinate of the  
C current cell.                                                         
                                                                        
      IF (IN .EQ. 1) THEN                                               
         DENO = DAR(M1)                                                 
         DIF = SQRT(S1S - DENO *  * 2)                                  
                                                                        
C If the next cell will be entered from the top, then calculate         
C the distance in range using the smallest deflection coordinate of the 
C current cell.                                                         
                                                                        
      ELSEIF (IN .EQ. 2) THEN                                           
         DENO = DAR(M1 - 1)                                             
         DIF =  - SQRT(S1S - DENO *  * 2)                               
                                                                        
C If the next cell will be entered from the side, then calculate        
C the distance in range using the smallest range coordinate of the      
C current cell.                                                         
                                                                        
      ELSEIF (IN .EQ. 3) THEN                                           
         DIF = RAR(M2 - 1)                                              
                                                                        
C If the deflection distance (in this case, S1S) equals 0 then the      
C exit angle is -90.                                                    
                                                                        
         IF (S1S .EQ. 0.0) THEN                                         
            ALOB =  - 90.0                                              
            RETURN                                                      
         ELSE                                                           
            DENO = SQRT(S1S - DIF *  * 2)                               
         ENDIF                                                          
                                                                        
C Write an error message if the cell was entered incorrectly.           
                                                                        
      ELSE                                                              
         WRITE(6,5000)'IN',IN                                           
         CALL EXIT                                                      
      ENDIF                                                             
                                                                        
C If the deflection distance (in this case, DENO) equals 0 then the     
C exit angle is -90.                                                    
                                                                        
      IF (DENO .EQ. 0) THEN                                             
         ALOB =  - 90.0                                                 
                                                                        
C If the range distance equals 0 then the exit angle is 0.              
                                                                        
      ELSEIF (ZERO1(DIF) .EQ. 0.0) THEN                                 
         ALOB = 0.0                                                     
                                                                        
C Compute the exit angle.                                               
                                                                        
      ELSE                                                              
         ALOB = ATAN(DIF / DENO) / DEG2RAD                              
      ENDIF                                                             
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (' %-ERROR- SUBR=EXANG, VARIABLE ',A,' = ',I2)             
      END                                                               
C-----------------------------------------------------------------------
C                                                                       
      SUBROUTINE GAMS(LLL)                                              
C                                                                       
C-----------------------------------------------------------------------
C DESCRIPTION: This subroutine:                                         
C                1) finds the dynamic fragmentation zone in which the   
C                   target point lies, using angle theta, S2, computed  
C                   in subroutine THLS, and                             
C                2) computes the angle gamma, GM, in the ground plane at
C                   which the target passes into the next dynamic       
C                   fragmentation zone.  GM is measured from the        
C                   deflection axis in a counter clockwise direction.   
C                                                                       
C VARIABLES:                                                            
C     Name          Units               Definition                      
C ---------------  -------  --------------------------------------------
C CENT               ft     Single-point target fragmentation centroid  
C                           height.                                     
C                                                                       
C CNUM               --     Factor used in computation of GM.           
C                                                                       
C CWR                --     Cosine of the impact angle.                 
C                                                                       
C DEG2RAD            --     Constant.  PI/180.  Degrees to radians      
C                           conversion.                                 
C                                                                       
C G5(I)             deg     I=1, KMAX.  Lower boundary angle of ith     
C                           dynamic fragmentation zone.                 
C                                                                       
C GM                deg     Angle in the ground plane where the         
C                           arc with radius S1 enters the dynamic       
C                           zone containing the target, measured from   
C                           the deflection axis.                        
C                                                                       
C KMAX               --     Number of dynamic zones.                    
C                                                                       
C KS3                --     Lower boundary subscript of the             
C                           dynamic zone containing the target.         
C                                                                       
C KZP                --     Upper boundary subscript of the dynamic     
C                           zone containing the target.                 
C                                                                       
C LLL                --     Indicator: (Passed in as 0 the 1st time GAMS
C                           is called from CALC; passed in as 1 the 2nd 
C                           time GAMS is called from CALC.)             
C                             0 - Find the dynamic zone in which the    
C                                 target point lies, given the angle    
C                                 S2.  Then compute the angle in the    
C                                 ground plane at which the target      
C                                 passes into the next dynamic zone.    
C                             1 - Compute the angle in the ground plane 
C                                 at which the target passes into the   
C                                 next dynamic zone.                    
C                                                                       
C Q43                ft     Burst height of the weapon.                 
C                                                                       
C Q6                deg     Weapon impact angle measured from the       
C                           horizontal.                                 
C                                                                       
C QQ                 --     Indicator:                                  
C                             TRUE  - Target is in a dynamic zone.      
C                             FALSE - Target is NOT in a dynamic zone.  
C                                                                       
C S1                 ft     Ground range. Distance from target to       
C                           weapon in the ground plane.                 
C                                                                       
C S2                deg     Angle between the warhead axis and the      
C                           line connecting the weapon burst            
C                           point and the target centroid.              
C                                                                       
C SWR                --     Sine of the weapon impact angle.            
C                                                                       
C Z                  --     Sine of the angle GM.                       
C                                                                       
C-----------------------------------------------------------------------
C Subroutines called:                                                   
C                                                                       
C  NONE                                                                 
C-----------------------------------------------------------------------
C Functions called:                                                     
C                                                                       
C  NONE                                                                 
C-----------------------------------------------------------------------
C Calling routine:                                                      
C                                                                       
C  CALC                                                                 
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
C                                                                       
      COMMON  / COSINE /  CWR,SWR                                       
                                                                        
C Subroutine CALC sets LLL for each arc with radius S1.  If LLL is      
C zero, find the subscript , KS3, for the lower boundary of the first   
C dynamic zone entered by the current arc.  If LLL is 1, use the        
C subscript, KS3, which was computed the first time GAMS was called.    
                                                                        
      IF (LLL .EQ. 0) THEN                                              
         KS3 = KMAX                                                     
         DO 10 K=1,KMAX                                                 
            IF (S2 .LE. G5(K)) THEN                                     
               KS3 = K - 1                                              
               GOTO 20                                                  
            ENDIF                                                       
 10      CONTINUE                                                       
      ENDIF                                                             
                                                                        
 20   IF (KS3 .LT. KMAX) THEN                                           
                                                                        
C Compute the upper boundary subscript of the dynamic zone containing   
C the target.                                                           
                                                                        
         KZP = KS3 + 1                                                  
                                                                        
C If the impact angle, Q6, is 90.0 degrees or the radius of the arc,    
C S1, is 0.0, there is only 1 dynamic zone per arc.  Set gamma,         
C GM, = -90.0 and transfer to statement 30.                             
                                                                        
         IF (Q6 .EQ. 90.0 .OR. S1 .EQ. 0.0) THEN                        
            GM =  - 90.0                                                
            GOTO 30                                                     
         ENDIF                                                          
                                                                        
C Compute Z, sin(GM).    ****  equation and figure here  ****           
                                                                        
         CNUM = ((S1 * S1 + (Q43 - CENT) * (Q43 - CENT)) *  * .5) *     
     &          COS(G5(KZP) * DEG2RAD) - (Q43 - CENT) * SWR             
         Z = CNUM / (S1 * CWR)                                          
                                                                        
C Assign values to GM depending on the value of Z, sin(GM).             
                                                                        
         IF (Z .LT. 1.0) THEN                                           
                                                                        
            IF (Z .LE.  - 1.0) THEN                                     
                                                                        
C Z, sin(GM), is <= -1.0, then set GM = -90.0 degrees.                  
                                                                        
               GM =  - 90.0                                             
            ELSE                                                        
                                                                        
C Z is greater than -1.0 and less than 1.0, compute GM.                 
                                                                        
               GM = (ATAN(Z / ((1.0 - Z * Z) *  * .5))) / DEG2RAD       
            ENDIF                                                       
         ELSE                                                           
                                                                        
C Z is greater or equal to 1.0, set GM = 90.0.                          
                                                                        
            GM = 90.0                                                   
         ENDIF                                                          
                                                                        
C Set the indicator QQ to show if the target is in a dynamic zone.      
                                                                        
 30      IF (KS3 .EQ. 0) THEN                                           
            QQ = .FALSE.                                                
         ELSE                                                           
            QQ = .TRUE.                                                 
         ENDIF                                                          
      ELSE                                                              
                                                                        
C At the completion of the 180. degree rotation, set the angle, GM      
C to -90.0 degrees to indicate that the last dynamic zone has been      
C found.  Set indicator QQ to show that the target is not in a          
C dynamic zone.                                                         
                                                                        
         GM =  - 90.0                                                   
         QQ = .FALSE.                                                   
      ENDIF                                                             
                                                                        
C Set the subscript to indicate the lower boundary of the next dynamic  
C zone for the current arc.                                             
                                                                        
      KS3 = KZP                                                         
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE GRID(IYN)                                              
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    This subroutine calculates the side on which the arc with radius   
C S1 will enter the next cell.                                          
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C AUPB               deg    Angle formed by the deflection axis and     
C                           the vector to the point on the arc which    
C                           exits the cell.                             
C                                                                       
C DAR(J)             ft     Jth deflection grid coordinate.             
C                                                                       
C DEG2RAD            --     Conversion factor for degrees to radians.   
C                                                                       
C IN                        Indicator for cell side where arc entered:  
C                                1 - Arc entered bottom of cell         
C                                2 - Arc entered top of cell            
C                                3 - Arc entered side of cell           
C                                                                       
C IYN                 --    Indicator:                                  
C                                2 - Arc will not reenter the matrix.   
C                                3 - Arc will reenter the matrix.       
C                                                                       
C M1                  --    Subscript of the largest deflection grid    
C                           coordinate of the current cell.             
C                                                                       
C M2                  --    Subscript of the largest range grid         
C                           coordinate of the current cell.             
C                                                                       
C NDG                 --    Total number of cells in deflection.        
C                                                                       
C NRG                 --    Total number of cells in range.             
C                                                                       
C RAR(J)              ft    Jth range grid coordinate.                  
C                                                                       
C S1                  ft    Distance from the burst point of the        
C                           weapon to the target.                       
C                                                                       
C TEMANG             rad    Exit angle from the current cell.           
C                                                                       
C TEMP1               ft    Range distance when the arc goes beyond     
C                           the grid.                                   
C                                                                       
C V1                  ft     Distance from the burst point of the       
C                            weapon to lower left corner of the current 
C                            cell.                                      
C                                                                       
C V2                  ft     Distance from the burst point of the weapon
C                            to upper left corner of the current        
C                            cell.                                      
C---------------------------------------------------------------------- 
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
                                                                        
C If the arc goes beyond largest deflection coordinate, then compute    
C the exit angle from the current cell.                                 
                                                                        
      IF ((M1 - (NDG / 2)) .GT. 1) THEN                                 
         TEMANG = AUPB * DEG2RAD                                        
                                                                        
C Compute the range distance of the arc.                                
                                                                        
         IF (TEMANG .LT. 0.0) THEN                                      
            TEMP1 = S1 * SIN(TEMANG)                                    
                                                                        
C If the exit angle is positive, change it to negative to indicate      
C that the arc will reenter the matrix in the negative range            
C sector.  Set indicators to state that arc will reenter the matrix     
C in the top of the next cell.                                          
                                                                        
         ELSE                                                           
            IN = 2                                                      
            AUPB =  - AUPB                                              
            TEMP1 =  - S1 * SIN(TEMANG)                                 
            IYN = 3                                                     
         ENDIF                                                          
                                                                        
C Determine if the arc is outside the matrix.  If so, set the indicator 
C to state that the arc will not reenter the matrix and exit routine.   
                                                                        
         IF (TEMP1 .LE. RAR(1)) THEN                                    
            IYN = 2                                                     
                                                                        
C If the radius of the arc is less than max range, determine which cell 
C the arc will reenter.                                                 
                                                                        
         ELSE                                                           
            DO 10 I=2,NRG + 1                                           
               IF (TEMP1 .LE. RAR(I)) GOTO 20                           
 10         CONTINUE                                                    
 20         M2 = I                                                      
            M1 = (NDG / 2) + 1                                          
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C If arc is within the matrix then determine exact coordinates and      
C side of the next cell that the arc will enter.                        
                                                                        
      IF (IYN .NE. 2) THEN                                              
                                                                        
C Calculate the distance from the burst point to the bottom left and top
C left corner of the current cell.                                      
                                                                        
         V1 = SQRT(DAR(M1 - 1) *  * 2 + RAR(M2 - 1) *  * 2)             
         V2 = SQRT(DAR(M1) *  * 2 + RAR(M2 - 1) *  * 2)                 
                                                                        
C If the current cell was entered from the top, or from the side and    
C the exit angle was negative, then...                                  
                                                                        
         IF ((IN .EQ. 2) .OR. ((IN .EQ. 3) .AND. (ROUND(AUPB,1) .LE.    
     &       0.0))) THEN                                                
                                                                        
C If the ground range is less than the distance to the current cells    
C furthest deflection coordinate, the next cell will be entered from    
C the top.                                                              
                                                                        
            IF (S1 .LE. V1) THEN                                        
               IN = 2                                                   
                                                                        
C Otherwise the next cell will be entered from the side.                
                                                                        
            ELSE                                                        
               IN = 3                                                   
            ENDIF                                                       
                                                                        
C If the current cell was entered from the bottom or side, then...      
                                                                        
         ELSEIF ((IN .EQ. 1) .OR. (IN .EQ. 3)) THEN                     
                                                                        
C If the ground range is less than the distance to the current cells    
C closest deflection coordinate, the next cell will be entered from     
C the side.                                                             
                                                                        
            IF (S1 .LE. V2) THEN                                        
               IN = 3                                                   
                                                                        
C Otherwise the next cell will be entered from the bottom.              
                                                                        
            ELSE                                                        
               IN = 1                                                   
            ENDIF                                                       
                                                                        
C Invalid value for the current cell's entry point.  Write error.       
                                                                        
         ELSE                                                           
            WRITE(6,5000)IN                                             
            CALL EXIT                                                   
         ENDIF                                                          
                                                                        
C Compute the next cell's angle of entry.                               
                                                                        
         CALL EXANG                                                     
                                                                        
      ENDIF                                                             
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (' %-ERROR- SUBR=GRID CONTAINS INVALID VALUE: IN = ',I2)   
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE INCEL                                                  
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    This subroutine describes how the arc with radius S1 enters the    
C matrix.  The three steps necessary to accomplish this task are:       
C  1) Determine which cell of the matrix the arc must enter when        
C     initially entering the matrix.                                    
C  2) Determine which side of the cell the arc entered.                 
C  3) Determine the angle formed by the deflection axis and the vector  
C     to the point where the arc enters the cell.                       
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C AUPB               deg    Angle formed by the deflection axis and     
C                           the vector to the point where the arc       
C                           first enters the cell.                      
C                                                                       
C DAR(I)             ft     Ith deflection grid coordinate.             
C                                                                       
C DEG2RAD            --     Conversion factor for degrees to radians.   
C                                                                       
C DIAG(I)            ft     Diagonal from the weapon to the upper left  
C                           corner of each cell on the top row of the   
C                           matrix.                                     
C                                                                       
C IN                        Indicator for cell side where arc entered:  
C                                1 - Arc entered bottom of cell         
C                                2 - Arc entered top of cell            
C                                3 - Arc entered side of cell           
C                                                                       
C INDX3               --    Total number of range grid coordinates.     
C                                                                       
C INDX5               --    Total number of positive deflection grid    
C                           coordinates.                                
C                                                                       
C MATX               --     Indicator :                                 
C                           TRUE  - Compute matrix for Ith target       
C                                   type.                               
C                           FALSE - Do NOT compute matrix.              
C                                                                       
C M1                  --    Subscript of the deflection grid            
C                           coordinate of the cell which the arc enters.
C                                                                       
C M2                  --    Subscript of the range grid                 
C                           coordinate of the cell which the arc enters.
C                                                                       
C NDG                 --    Total number of cells in deflection.        
C                                                                       
C NRG                 --    Total number of cells in range.             
C                                                                       
C RAD2DEG             --    Conversion factor for radians to degrees.   
C                                                                       
C RAR(I)              ft    Ith range grid coordinate.                  
C                                                                       
C S1                  ft    Distance from the burst point of the        
C                           weapon to the target. Arc's radius.         
C                                                                       
C ZL                  ft    Distance in deflection measured from ground 
C                           zero to the point where the arc enters the  
C                           matrix.                                     
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C CALC                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
                                                                        
C Calculate total number of range and deflection grid coordinates       
C to consider.                                                          
                                                                        
      INDX5 = (NDG / 2) + 1                                             
      INDX3 = NRG + 1                                                   
                                                                        
C If the largest range coordinate is a positive number then determine   
C if the arc's radius is within the matrix.                             
                                                                        
      IF (RAR(INDX3) .GE. 0.0) THEN                                     
         DO 10 I=1,INDX3                                                
                                                                        
C If the arc's radius is smaller than max range coordinate, then the    
C arc will enter the bottom of the matrix with an entrance angle (AUPB) 
C of 90 degrees.  Assign cell indexes and exit routine.                 
                                                                        
            IF (S1 .LE. RAR(I)) THEN                                    
               M1 = 2                                                   
               M2 = I                                                   
               IN = 1                                                   
               AUPB = 90.0                                              
               RETURN                                                   
            ENDIF                                                       
 10      CONTINUE                                                       
      ENDIF                                                             
                                                                        
C If the arc radius is greater than the largest range coordinate, use   
C Pythagorean theorem to determine distance to point where the arc      
C enters the matrix.                                                    
                                                                        
      ZL = SQRT(S1 *  * 2 - RAR(INDX3) *  * 2)                          
                                                                        
C Determine if the arc enters the matrix from the side or top.          
                                                                        
      IF (ZERO1(ZL) .GE. 0.0) THEN                                      
                                                                        
C Check all deflection coordinates to determine if the arc enters       
C the matrix from the side.  If it does, then the cell coordinates      
C are assigned and the angle of entry is computed. Exit subroutine.     
                                                                        
         DO 20 I=2,INDX5                                                
            IF (ZL .LE. DAR(I)) THEN                                    
               M1 = I                                                   
               M2 = INDX3                                               
               IN = 3                                                   
               AUPB = (ATAN(RAR(INDX3) / ZL)) * RAD2DEG                 
               RETURN                                                   
            ENDIF                                                       
 20      CONTINUE                                                       
                                                                        
C Determine if the arc will enter the matrix from the                   
C top of the matrix.  Calculate the coordinate and the angle of entry   
C (which will be negative) for the cell of entry.                       
                                                                        
         IF ((RAR(1) .LT. 0.0) .AND. (S1 .LT. DIAG(1))) THEN            
            DO 30 I=2,INDX3                                             
               IF (S1 .GE. DIAG(I)) THEN                                
                  M2 = I                                                
                  M1 = INDX5                                            
                  IN = 2                                                
                  AUPB =  - (ACOS(DAR(INDX5) / S1) * RAD2DEG)           
                  RETURN                                                
               ENDIF                                                    
 30         CONTINUE                                                    
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C If none of the above criteria were met, the arc will not enter the    
C matrix so set flags so this routine will not be called for larger     
C increments of S1.                                                     
                                                                        
      MATX = .FALSE.                                                    
                                                                        
      M2 = 1                                                            
      M1 = 1                                                            
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE LDCO                                                   
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C   This subroutine calculates the interpolation factors, ALH (alpha) & 
C BTA (beta), that are used in the equation to calculate the drag       
C coefficient, Cd.  The factors are used in XDRG and RESULT to calculate
C the drag coefficients.                                                
C                            Cd = ALH*V + BTA                           
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C ALH(I,J)           --     Slope of drag curve for the Ith layer of    
C                           medium and the Jth velocity.                
C                                                                       
C BTA(I,J)           --     Y Intercept of drag curve for Ith layer of  
C                           medium and Jth velocity.                    
C                                                                       
C CFD(I,J)           --     Drag factor for fragments for Ith layer of  
C                           medium and Jth velocity.                    
C                                                                       
C DNUM             ft/sec   Difference between two consecutive          
C                           velocities in the drag table.               
C                                                                       
C I                  --     Subscript denoting layer of medium.         
C                                                                       
C J                  --     Subscript denoting velocity of fragment.    
C                                                                       
C NCDP               --     Number of velocities used to describe the   
C                           drag curve (same for all media layers).     
C                                                                       
C NHDT               --     Number of medium layers to be considered.   
C                                                                       
C ULN(I,J)           --     Integration factor which will be used       
C                           in Subroutines XDRG and RESULT.  See        
C                           Appendix B of analyst manual to explain how 
C                           this factor was derived.                    
C                                                                       
C UTEP               --     Intermediate variable used to derive ULN.   
C                                                                       
C VCF(J)           ft/sec   Jth velocity in drag table.                 
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
                                                                        
C Loop through all of the velocities and mediums so that the factors    
C A & B and the integration factor ULN can be calculated for each       
C given condition.                                                      
                                                                        
      DO 20 J=1,NCDP - 1                                                
                                                                        
C Calculate the difference between two consecutive velocities.          
                                                                        
         DNUM = VCF(J + 1) - VCF(J)                                     
                                                                        
         DO 10 I=1,NHDT                                                 
                                                                        
C Factor ALH =  Slope of drag                                           
                                                                        
            ALH(I,J) = (CFD(I,J + 1) - CFD(I,J)) / DNUM                 
                                                                        
C Calculate factor BTA (beta).  Y-Intercept of the drag curve.          
                                                                        
            BTA(I,J) = (VCF(J + 1) * CFD(I,J) - VCF(J) * CFD(I,J + 1)) /
     &                  DNUM                                            
                                                                        
C Calculate the distance a fragment will travel given an initial        
C velocity and a terminal velocity.  If the intermediate                
C variable UTEP = 0 (no distance traveled), then write out an error.    
                                                                        
            UTEP = (VCF(J) * (ALH(I,J) * VCF(J + 1) + BTA(I,J))) /      
     &             (VCF(J + 1) * (ALH(I,J) * VCF(J) + BTA(I,J)))        
                                                                        
            IF (UTEP .EQ. 0.0) THEN                                     
               WRITE(6,5000)I,J                                         
               CALL EXIT                                                
            ENDIF                                                       
                                                                        
            ULN(I,J) = LOG(UTEP)                                        
                                                                        
 10      CONTINUE                                                       
 20   CONTINUE                                                          
                                                                        
C Set the slope to 0 and assign the intercept for the last velocity     
C interval of the drag curve.                                           
                                                                        
      DO 30 I=1,NHDT                                                    
         ALH(I,NCDP) = 0.0                                              
         BTA(I,NCDP) = CFD(I,NCDP)                                      
 30   CONTINUE                                                          
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (' %-ERROR- SUBR=LDCO, LAYER=',I2,', DRAG INTERVAL=',I2,   
     &        ', DRAG CURVE PRODUCES SLOPE=0., INTERCEPT=0.')           
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE MAIN                                                   
C                                                                       
C---------------------------------------------------------------------- 
C This subroutine is the driver routine for the calculation of lethal   
C areas.                                                                
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C A1(K)            ft/sec   K = 1,50                                    
C                           Initial fragment velocity at lower boundary 
C                           of Kth static zone.                         
C                                                                       
C A2(K)            ft/sec   K = 1,50                                    
C                           Initial fragment velocity at middle boundary
C                           of Kth static zone.                         
C                                                                       
C A3(K)            ft/sec   K = 1,50                                    
C                           Initial fragment velocity at upper boundary 
C                           of Kth static zone.                         
C                                                                       
C ABOX(I,J)        sq ft    I = 1,40; J = 1,40                          
C                           Area of a cell or portion of a cell.        
C                                                                       
C AMG                --     Number of weight groups to be considered    
C                           after COTM option has been applied.         
C                                                                       
C AX                 --     Store PK * ground range. Used in the        
C                           integration process. This coefficient is    
C                           the first term in the series expansion for  
C                           trapeziodal and Simpson's Rule integration. 
C                                                                       
C AXF                --     Store cumulative fire effects for use in    
C                           final integration. This coefficient is      
C                           the first term in the series expansion for  
C                           trapeziodal and Simpson's Rule integration. 
C                                                                       
C B1(K)             deg     K = 1,50                                    
C                           Lower boundary angle of Kth static zone.    
C                                                                       
C B2(K)             deg     K = 1,50                                    
C                           Middle boundary angle of Kth static zone.   
C                                                                       
C B3(K)             deg     K = 1,50                                    
C                           Upper boundary angle of Kth static zone.    
C                                                                       
C BOX(I,J)         sq ft    I = 1,40; J = 1,40                          
C                           Lethal area of a cell or portion of a cell. 
C                                                                       
C BRAD(I)            --     I = 1,24                                    
C                           Array containing environmental shielding    
C                           data retrieved from function SHADE.         
C                                                                       
C BX                 --     Store PK * ground range. Used in the        
C                           integration process. This coefficient is    
C                           the sum of the odd terms in the series      
C                           expansion for trapeziodal and Simpson's     
C                           Rule integration.                           
C                                                                       
C BXF                --     Store cumulative fire effects for use in    
C                           final integration. This coefficient is      
C                           the sum of the odd terms in the series      
C                           expansion for trapeziodal and Simpson's     
C                           Rule integration.                           
C                                                                       
C C2               ft/sec   Weapon impact velocity.                     
C                                                                       
C C3               ft/sec   Constant fragment cutoff velocity.          
C                                                                       
C CM                 --     The largest integration increment that will 
C                           insure the desired number of radii will cut 
C                           each cell.                                  
C                                                                       
C COTM             grains   The fragment cutoff mass. The smallest      
C                           fragment size that will contribute to a     
C                           target kill.                                
C                                                                       
C COVR(I)            --     I = 1,24                                    
C                           Array containing environmental shielding    
C                           data retrieved from function SHADE.         
C                                                                       
C CX                 --     Store PK * ground range. Used in the        
C                           integration process. This coefficient is    
C                           the sum of the even terms in the series     
C                           expansion for trapeziodal and Simpson's     
C                           Rule integration.                           
C                                                                       
C CXF                --     Store cumulative fire effects for use in    
C                           final integration. This coefficient is      
C                           the sum of the even terms in the series     
C                           expansion for trapeziodal and Simpson's     
C                           Rule integration.                           
C                                                                       
C D1(I,J)            --     I=1,25 J=1,50                               
C                           Number of fragments in the Ith weight       
C                           group, Jth static zone.                     
C                                                                       
C D1I(I)             --     I=1,50                                      
C                           Number of weight groups in the Ith static   
C                           zone.                                       
C                                                                       
C D2(I,J)          grains   I=1,25; J=1,50                              
C                           Fragment weight, Ith weight group, Jth      
C                           static zone.                                
C                                                                       
C DA                 ft     Matrix cell size in deflection for NRAD=1   
C                           or 3; Number of cells in deflection for     
C                           NRAD=2.                                     
C                                                                       
C DAR(I)             ft     I = 1,41                                    
C                           Ith deflection grid coordinate.             
C                                                                       
C DARSQ            sq ft    Maximum deflection grid coordinate squared. 
C                           Used to compute matrix diagonals.           
C                                                                       
C DEG2RAD            --     Constant. Degrees to radians conversion.    
C                                                                       
C DIAG(I)            ft     I = 1,41                                    
C                           Diagonals from ground zero to the corners   
C                           of the each cell on the top row of the      
C                           matrix.                                     
C                                                                       
C DIVIS              --     Interpolation factor for environmental      
C                           shielding.                                  
C                                                                       
C DNOMI              --     Integration constant.                       
C                           2.0 - Trapezoidal integration               
C                           3.0 - Simpson's Rule.                       
C                                                                       
C DR                 ft     Size of an integration increment.           
C                                                                       
C G5(I)             deg     I = 1,100                                   
C                           Dynamic fragmentation zone angles in        
C                           ascending order.                            
C                                                                       
C H1(I)              ft     K = 1,50                                    
C                           The maximum effective range of the fragments
C                           in the Ith dynamic zone.                    
C                                                                       
C H3                 ft     Largest maximum effective range for all     
C                           dynamic zones.                              
C                                                                       
C HOLDZZ(I,J)        --     I = 1,300; J = 1,300                        
C                           Holding array for the ARCS option.          
C                                                                       
C IC10               --     Number of weight groups in a particular     
C                           static fragmentation zone.                  
C                                                                       
C IC2(I)             --     I = 1,180                                   
C                           Number of weight groups in the Ith static   
C                           zone.                                       
C                                                                       
C IDHT               --     Indicator for direct hit option:            
C                              FALSE - Direct hit option NOT selected.  
C                              TRUE - Direct hit option selected.       
C                                                                       
C IFIRE              --     Indicator for FIRE option:                  
C                              FALSE - FIRE option NOT selected.        
C                              TRUE - FIRE option selected.             
C                                                                       
C IIS1               --     Indicator for integration region boundary:  
C                           0 - Boundary between regions has NOT been   
C                               reached.                                
C                           1 - Boundary between 2nd and 3rd region     
C                               reached.                                
C                                                                       
C INDC               --     Indicator :                                 
C                              0 - Not single point target              
C                              1 - Single point target                  
C                                                                       
C IP                 --     Indicator (Located in record 1, title card):
C                           Blank - short output option.                
C                           Non-blank - long output option.             
C                                                                       
C ITRAP              --     Indicator for integration type:             
C                           0 - Simpson's Rule.                         
C                           1 - Trapezoidal integration.                
C                                                                       
C JAY1               --     Indicates if a boundary between two         
C                           integration regions has been reached.       
C                                                                       
C JC1                --     Number of static fragmentation zones.       
C                                                                       
C JPC                --     Number of dynamic zones passed through for  
C                           ground range S1.                            
C                                                                       
C JPCHOLD(I)         --     I=1,300                                     
C                           Number of dynamic zones passed through      
C                           for all increments.                         
C                                                                       
C KLUM               --     Index to locate correct vegetative data     
C                           from SHADE function.                        
C                                                                       
C KMAX               --     Number of distinct dynamic fragmentation    
C                           zones.                                      
C                                                                       
C KTRE               --     Counter to increment distance for           
C                           vegetative shielding array.                 
C                                                                       
C LOSFRG             --     Indicator for line of sight of fragments:   
C                           0 - line of sight does NOT exist.           
C                           1 - line of sight exists for fragments for  
C                               the Ith target centroid.                
C                                                                       
C LOSBLT             --     Indicator for line of sight of blast:       
C                           0 - line of sight does NOT exist.           
C                           1 - line of sight exists.                   
C                                                                       
C LUM                --     Maximum number of values for the shielding  
C                           table COVR vs BRAD.                         
C                                                                       
C MATX                      Indicator:                                  
C                             FALSE - Do NOT compute matrix.            
C                             TRUE - Compute matrix for Ith target type.
C                                                                       
C MATZ               --     Indicator:                                  
C                           FALSE - Compute lethal areas only.          
C                           TRUE - Compute lethal areas and a selected  
C                               matrix.                                 
C                                                                       
C MCUT               --     Number of integration radii desired to cut  
C                           through each cell of the matrix (defaults to
C                           2 if input as 0).                           
C                                                                       
C MOSK               --     Indicator :                                 
C                           1 - the matrix is not output to file.       
C                           2 - the matrix is output to file.           
C                                                                       
C MOUNDOPT           --     Indicator:                                  
C                             FALSE - Target NOT on a mound.            
C                             TRUE - Target on a mound.                 
C                                                                       
C MTX                --     Indicator:                                  
C                           FALSE - Arc does not enter matrix.          
C                           TRUE - Arc does enter matrix.               
C                                                                       
C N21                --     Total number of integration regions used    
C                           for the current case.                       
C                                                                       
C N21I               --     The number of the integration region just   
C                           completed.                                  
C                                                                       
C N22                --     Indicator:                                  
C                           0 - Linear increment scheme.                
C                           1 - Logarithmic increment scheme.           
C                                                                       
C N23                --     Indicator:                                  
C                           0 - Linear integration scheme.              
C                           1 - Logarithmic integration scheme.         
C                                                                       
C N24                --     Indicator:                                  
C                           1 - Check if next to last integration       
C                               increment reached.                      
C                           2 - Continue normal integration.            
C                           3 - Integration completed for this region.  
C                                                                       
C N25                --     Indicator:                                  
C                           1 - Store Y in AX. The first term in        
C                               the integration formula.                
C                           2 - Store Y in BX. The second term in       
C                               the integration formula.                
C                           3 - Store Y in CX. The third term in        
C                               the integration formula.                
C                                                                       
C NAME               --     Title for each case.                        
C                                                                       
C NCL                --     Number of integration increments.           
C                                                                       
C ND                 --     Indicator :                                 
C                           0 - store PK for an arc increment versus    
C                               ground range in the ZZ array.           
C                           1 - do not store PK for an arc increment    
C                               versus ground range.                    
C                                                                       
C NDCLS              --     Indicator :                                 
C                              FALSE - ARCS option was NOT selected.    
C                              TRUE - ARCS option was selected.         
C                                                                       
C NDG                --     Total number of matrix cells in deflection. 
C                                                                       
C NDON               --     Indicator:                                  
C                           FALSE - Matrix cell size is computed.       
C                           TRUE - Number of cells is computed.         
C                                                                       
C NDU                --     Half the total number of matrix cells in    
C                           deflection.                                 
C                                                                       
C NMAZ               --     Indicator:                                  
C                           0 - Matrix NOT computed on this             
C                               integration pass. Call subroutine       
C                               MTXLIM.                                 
C                           1 - Matrix computed on this integration     
C                               pass. Call subroutine RNUM to set up    
C                               matrix calculations.                    
C                                                                       
C NMCTL              --     Indicator:                                  
C                           0 - Number of integration steps dependant   
C                               upon max range of weapon.               
C                           1 - Number of integration steps computed    
C                               such that MCUT integration radii will   
C                               cut through each matrix cell.           
C                                                                       
C NNNN               --     Indicator:                                  
C                              FALSE - the COTM option has NOT been sele
C                              TRUE - the COTM option has been selected.
C                                                                       
C NOWJPC             --     Number of dynamic zones for the current     
C                           ground range for the ARCS option.           
C                                                                       
C NPRT               --     Insures that Pkt for arc increment vs.      
C                           ground range is printed for the last        
C                           increment in a region.                      
C                                                                       
C NQ                 --     Indicator:                                  
C                           0 - Multiple centroid target.               
C                           1 - Single centroid target.                 
C                                                                       
C NRAD               --     Indicates the option selected in option     
C                           MATRIX :                                    
C                           1 - Read in cell dimensions and center of   
C                               matrix.                                 
C                           2 - Compute cell dimensions and center of   
C                               matrix given number of cells.           
C                           3 - Compute the number of cells necessary   
C                               to cover the effective area of the      
C                               munition given the cell dimensions.     
C                           4 - Read in the coordinates of the cells.   
C                                                                       
C NRG                --     Total number of matrix cells in range.      
C                                                                       
C NT7                --     Indicator :                                 
C                             TRUE  - Store PK for each ground range r. 
C                             FALSE - Do NOT store PK for each ground   
C                                   range r.                            
C                                                                       
C NT9                --     Indicator:                                  
C                             FALSE - No new drag table.                
C                             TRUE - New drag table. Call subroutine LDC
C                                                                       
C NTPX               --     Number of strip target centroids to         
C                           consider for fragments.                     
C                                                                       
C NTRE               --     Indicator to select a particular exposure   
C                           function for the TRES option:               
C                           0 - No environmental shielding desired      
C                           1 - temperate forest                        
C                           2 - tropical rain forest.                   
C                                                                       
C NWC1               --     Indicator :                                 
C                             TRUE - New velocity data have been input. 
C                             FALSE - New velocity data have NOT been   
C                                     input.                            
C                                                                       
C NWC2               --     Indicator :                                 
C                             TRUE - New fragmentation data have been   
C                                    input.                             
C                             FALSE - New fragmentation data have NOT   
C                                     been input.                       
C                                                                       
C NYN                --     Indicator :                                 
C                              TRUE - blast effects to be calculated    
C                              FALSE - blast not calculated             
C                                                                       
C NYN1               --     Indicator used to reset NYN in subroutine   
C                           MAIN :                                      
C                             0 - When NO BLT option is encountered.    
C                             1 - When BLT option is first encountered  
C                                 (remains 1 throughout entire run      
C                                 regardless of whether another BLT     
C                                 record is encountered).               
C                                 Blast effects are to be considered.   
C                                                                       
C PI                 --     Constant.                                   
C                                                                       
C PKFIRE             --     Probability of kill due to fire averaged    
C                           over one arc.                               
C                                                                       
C PKVSR(I,J)         --     I=1,2000;J=1,2                              
C                           Pk and Range components for PKVSR           
C                           output.                                     
C                                                                       
C Q1(I)              --     I = 1,8                                     
C                           Resultant probability of kill due to blast, 
C                           fragments, and fire.                        
C                                                                       
C Q2                sq ft   Lethal area for 1 integration region.       
C                                                                       
C Q3                sq ft   Total lethal area.                          
C                                                                       
C Q3F              sq mtrs  Total lethal area for fire kill only.       
C                                                                       
C Q3M              sq mtrs  Total lethal area.                          
C                                                                       
C Q41(I)             ft     I=1,13                                      
C                           Target heights representing centers of      
C                           vulnerability to fragments.                 
C                                                                       
C Q43                ft     Burst height of the munition.               
C                                                                       
C Q43R               ft     Used to restore Q43 for next integration    
C                           pass.                                       
C                                                                       
C Q6                deg     Weapon impact angle measured from the       
C                           horizontal.                                 
C                                                                       
C QAV                ft     Height of target centroid for blast.        
C                                                                       
C QF                sq ft   Lethal area for fire kill only, 1           
C                           integration region.                         
C                                                                       
C QFTOT             sq ft   Total lethal area for fire kill only.       
C                                                                       
C QQ43             meters   Burst height of the munition.               
C                                                                       
C R1                 --     Correction factor for total weight.         
C                                                                       
C R2                deg     Cutoff angle for fragments.                 
C                                                                       
C RA                 ft     Matrix cell size in range for NRAD=1; Number
C                           of cells in range for NRAD=2.               
C                                                                       
C RAD2DEG            --     Constant. Radians to degrees conversion.    
C                                                                       
C RAR(I)             ft     I=1,41                                      
C                           Ith range grid coordinate.                  
C                                                                       
C RATF(I)            --     I = 1,13                                    
C                           Probability of exposure times ratio of      
C                           target NOT shielded by terrain.             
C                                                                       
C RATIO              --     Percentage of target NOT shielded by        
C                           vegetative cover.                           
C                                                                       
C RATTER             --     Computed probability of exposure.           
C                                                                       
C RB1                ft     Maximum distance from burst that PKB = 1.0  
C                           (PKB is probability of kill due to blast).  
C                                                                       
C RB11               ft     Set equal to RB1 but used as a testing      
C                           variable.                                   
C                                                                       
C RB2                ft     Minimum distance from burst that PKB = 0.0  
C                           (PKB is probability of kill due to blast).  
C                                                                       
C RB3                ft     Interim variable used to calculate max      
C                           range.                                      
C                                                                       
C RD1                ft     Direct hit radius.  For revetment runs, RD1 
C                           is the equivalent target size in the ground 
C                           plane or presented area at 90 degrees       
C                           converted to a radius.                      
C                                                                       
C RDR                ft     Change in ground range * total ground       
C                           range. Used to calculate the area of an     
C                           arc.                                        
C                                                                       
C REVA              deg     Angle between the revetment or mound        
C                           slope and ground.                           
C                                                                       
C REVBAS             ft     Width of revetment base. Radius of mound    
C                           base.                                       
C                                                                       
C REVDIS             ft     Ground distance from bottom, inside edge of 
C                           revetment to target.                        
C                           (Ground dist from revet inside edges / 2).  
C                                                                       
C REVHT              ft     Height of revetment or mound.               
C                                                                       
C RMAXX              ft     The integration distance necessary to       
C                           completely cover the matrix.                
C                                                                       
C ROP                --     Indicator :                                 
C                              FALSE - Target is NOT revetted.          
C                              TRUE - Target is revetted.               
C                                                                       
C RXMAX              ft     Maximum effective distance in the range     
C                           direction (usually positive) for the damage 
C                           matrix.                                     
C                                                                       
C RXMIN              ft     Maximum effective distance in the range     
C                           direction opposite RXMAX.                   
C                                                                       
C RYMAX              ft     Maximum effective distance in the deflection
C                           direction for the damage matrix.            
C                                                                       
C S1                 ft     Ground range. Distance from target to       
C                           weapon in the ground plane.                 
C                                                                       
C S11                ft     Previous S1. Ground range for previous      
C                           integration step.                           
C                                                                       
C S1S                ft     Ground range squared.                       
C                                                                       
C SIMP1              --     Integration constant:                       
C                           2.0 Trapezoidal integration.                
C                           4.0 Simpson's rule.                         
C                                                                       
C T3                 ft     Max effective range for fragments in the    
C                           ground plane.                               
C                                                                       
C TEMP               --     Tangent of fragment striking angle.         
C                                                                       
C TERAIN             --     Indicator:                                  
C                              TRUE - Terrain effects considered.       
C                              FALSE - Terrain effects not considered.  
C                                                                       
C TGTHT              ft     Target height for direct-hit option.        
C                                                                       
C THORT              ft     Integration increment for logarithmic       
C                           integration. e**DR.                         
C                                                                       
C TLOG               ft     Boundary between 2nd and third integration  
C                           regions. If only 2 regions, TLOG=RMAXX.     
C                                                                       
C TZA(I,J,K)       sq ft    I = 1,132, J = 1,14; K = 1,18               
C                           Average vulnerable area data for fragment   
C                           kill, ith elevation, jth weight group, kth  
C                           velocity.                                   
C                                                                       
C U2                 ft     Upper integration limit for 1st region.     
C                                                                       
C U3                 ft     Lower integration limit for 2nd region.     
C                                                                       
C U4                 ft     Upper integration limit for 2nd region.     
C                                                                       
C U5                 ft     Lower integration limit for 3rd region.     
C                                                                       
C U6                 ft     Upper integration limit for 3rd region.     
C                                                                       
C U7                 ft     Next to last increment in an integration    
C                           region.                                     
C                                                                       
C U8                 ft     Lower integration limit in a region.        
C                                                                       
C WZ4(I,K)         ft/sec   I=1,25; K=1,50.                             
C                           Computed cutoff velocity, Ith weight group, 
C                           Kth static fragment zone. Interpolated from 
C                           the cutoff velocity table (INTRVC) using the
C                           weapon fragment weight data, D2().          
C                                                                       
C X                  ft     Slant range distance between target and     
C                           weapon centroids. Used in calculation of    
C                           max range.                                  
C                                                                       
C X1                 --     An intermediate variable used to find TLOG  
C                           on the first pass, when the program         
C                           requires 2 integration passes.              
C                                                                       
C XMAX               ft     Maximum range (RXMAX).                      
C                           Used in subroutine MTXCEL.                  
C                                                                       
C XMIN               ft     Minimum range (RXMIN).                      
C                           Used in subroutine MTXCEL.                  
C                                                                       
C XN                 --     Number of integration steps taken in a      
C                           linear region.                              
C                                                                       
C XNX                --     Number of integration steps taken in a      
C                           logarithmic region.                         
C                                                                       
C Y                  --     PK * ground range. Used in final            
C                           integration calculations.                   
C                                                                       
C Y6                 --     Integration factor in Simpson's Rule and    
C                           trapezoidal integration.                    
C                                                                       
C YF                 --     Fire effects for a particular ground range. 
C                           Used in final integration.                  
C                                                                       
C YMAX               ft     Maximum deflection (RYMAX).                 
C                           Used in subroutine MTXCEL.                  
C                                                                       
C ZEA                deg    Fragment impact elevation angle, measured   
C                           from the horizontal.                        
C                                                                       
C ZZ(I)              --     I=1,300                                     
C                           Used to store Pk's over arc increments      
C                           for a ground range r.                       
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C PRINT                                                                 
C BEGIN                                                                 
C LDCO                                                                  
C YAC1                                                                  
C YAC2                                                                  
C ZONE                                                                  
C RNUM                                                                  
C CUTMOUND                                                              
C TABLE                                                                 
C MOUND                                                                 
C REVETLOS                                                              
C TEV                                                                   
C CALC                                                                  
C OUTM                                                                  
C OUTZ                                                                  
C MTXCEL                                                                
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C SHADE                                                                 
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      DIMENSION BRAD(24),COVR(24),JPCHOLD(300),HOLDZZ(300,300)          
C                                                                       
      CHARACTER*6 COOPTN,DRAGTYP                                        
      CHARACTER*5 RCAS,INTRVC                                           
C                                                                       
      LOGICAL IOUT,NDCLS,TERAIN,NT9,NWC1,NWC2                           
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
C                                                                       
      COMMON  / ABUR /  GMUP,GMLO,RF1(50),RF2(50),PLT1(50),PLT2(50)     
      COMMON  / ALT1 /  COTM,D1I(50),IOUT,ND,NTRE,NT9,RATF(13)          
      COMMON  / ARCPT /  NDCLS                                          
      COMMON  / ARTXX /  ABOX(40,40),RDR                                
      COMMON  / BBUR /  RPF1(50),RPF2(50),RPF3(50),PLF1(50),PLF2(50),   
     &       PLF3(50)                                                   
      COMMON  / BVNZRO /  AVNZRO                                        
      COMMON  / CBUR /  GMID                                            
      COMMON  / COSINE /  CWR,SWR                                       
      COMMON  / DIRHIT /  PKH,RD1,TGTHT,Q43R,FRAGOPT                    
      COMMON  / ICOTM /  IPRWT                                          
      COMMON  / MSIZE /  MCUT,ITRAP                                     
      COMMON  / NWC /  NWC1,NWC2                                        
      COMMON  / OUT1 /  PBH,RCAS,DRAG,INTRVC,ZDATAID                    
      COMMON  / OUT2 /  DRAGTYP,COOPTN                                  
      COMMON  / PKR /  PKVSR(2000,2),KNT                                
      COMMON  / REV /  REVHT,REVSLP,REVTOT,ACTR,DTD,REVBAS,REVDIS,DEAD, 
     &       REVA,COFF,GONG,REVTOP,RTRAJ,LOSFRG,LOSBLT                  
      COMMON  / TER /  TERAIN                                           
                                                                        
C These functions are used in the computation of integration increment  
C size.                                                                 
                                                                        
      FX(XN,TLOG,T3) = ((TLOG * (XN + 1.0) - T3) / XN) *  * (XN / (XN - 
     &                 1.0)) - TLOG                                     
      FPX(XN,TLOG,T3) = (XN + 1.0) / (XN - 1.0) * ((TLOG * (XN + 1.0) - 
     &                  T3) / XN) *  * (1.0 / (XN - 1.0)) - 1.0         
                                                                        
      OPEN(UNIT=55,FILE='LAOUT.DAT',FORM='FORMATTED',                   
     &     CARRIAGECONTROL='LIST',STATUS='unknown')                     
                                                                        
C Initialize variables.                                                 
                                                                        
      AXF = 0.                                                          
      BXF = 0.                                                          
      C2 = 0.                                                           
      C3 = 0.                                                           
      COTM = 0.0                                                        
      CXF = 0.                                                          
      IDHT = .FALSE.                                                    
      IFIRE = .FALSE.                                                   
      INDC = 0                                                          
      IIS1 = 0                                                          
      KMAN = 0                                                          
      KNT = 0                                                           
      MOSK = 0                                                          
      MOUNDOPT = .FALSE.                                                
      MT7 = .FALSE.                                                     
      N21I = 0                                                          
      NAME = ' '                                                        
      ND = 0                                                            
      NDCLS = .FALSE.                                                   
      NDON = 0                                                          
      NMAZ = 0                                                          
      NNNN = .FALSE.                                                    
      NQ = 0                                                            
      NT7 = .FALSE.                                                     
      NTRE = 0                                                          
      NYN1 = 0                                                          
      PIF = 0.0                                                         
      PSL = 0.0                                                         
      Q43 = 0.0                                                         
      Q6 = 0.0                                                          
      QFTOT = 0.0                                                       
      R1 = 0.0                                                          
      R2 = 0.0                                                          
      RB1 = 0.0                                                         
      RB11 = 0.0                                                        
      RB2 = 0.0                                                         
      RD1 = 0.0                                                         
      RDH = .TRUE.                                                      
      ROP = .FALSE.                                                     
      TERAIN = .FALSE.                                                  
      TLOG = 100.0                                                      
      JP = 1                                                            
      AX = 0.0                                                          
      BX = 0.0                                                          
      CX = 0.0                                                          
      Q3 = 0.0                                                          
      DO 10 IJ=1,300                                                    
         ZZ(IJ) = 0.0                                                   
 10   CONTINUE                                                          
      DO 20 I=1,41                                                      
         DAR(I) = 0.0                                                   
         RAR(I) = 0.0                                                   
 20   CONTINUE                                                          
      DO 50 I=1,132                                                     
         DO 40 J=1,14                                                   
            DO 30 K=1,18                                                
               TZA(I,J,K) = 0.                                          
 30         CONTINUE                                                    
 40      CONTINUE                                                       
 50   CONTINUE                                                          
                                                                        
C Print input file on output file.                                      
                                                                        
      CALL PRINT                                                        
                                                                        
C BEGIN reads input data for one case.                                  
                                                                        
 60   CALL BEGIN                                                        
                                                                        
C Initialize variables for this case.                                   
                                                                        
      LOSFRG = 1                                                        
      LOSBLT = 1                                                        
      NMCTL = 0                                                         
      NPRT = 1                                                          
      Q43R = Q43                                                        
      REVA = REVA * DEG2RAD                                             
      RXMAX =  - 1.0E + 38                                              
      RXMIN =  + 1.0E + 38                                              
      RYMAX = 0.                                                        
                                                                        
C NTRE indicates environmental shielding. If no shielding, RATIO is set 
C to 1, else constants are transferred from function SHADE to calculate 
C RATIO later. RATIO is percentage of target NOT shielded.              
                                                                        
      IF (NTRE .LE. 0) THEN                                             
         RATIO = 1.0                                                    
      ELSE                                                              
         LUM = INT(SHADE(1))                                            
         KLUM = NTRE * LUM + 1                                          
         DO 70 I=1,LUM                                                  
            J = KLUM + I                                                
            BRAD(I) = SHADE(I + 1)                                      
            COVR(I) = SHADE(J)                                          
 70      CONTINUE                                                       
         KTRE = 1                                                       
      ENDIF                                                             
                                                                        
C LDCO computes alpha and beta for the drag equation from an input drag 
C table.                                                                
                                                                        
      IF (NT9) CALL LDCO                                                
                                                                        
C If no cutoff angle for fragments is read in then set R2 (cutoff angle 
C for fragments) to 90                                                  
                                                                        
      IF (R2 .EQ. 0.) R2 = 90.0                                         
                                                                        
C R1 is scale correction factor for warhead weight. Default is 1.       
                                                                        
      IF (R1 .EQ. 0.) R1 = 1.0                                          
                                                                        
C If cutoff mass option is selected, then discard all fragmentation data
C with mass less than COTM.                                             
                                                                        
      IF (NNNN) THEN                                                    
                                                                        
C JC1 is number of zones.                                               
                                                                        
         DO 80 J=1,JC1                                                  
            D1I(J) = D1(1,J)                                            
 80      CONTINUE                                                       
                                                                        
C For all zones do -                                                    
                                                                        
         DO 110 J=1,JC1                                                 
            IC10 = IC2(J)                                               
                                                                        
C For all weight groups in the Jth zone do                              
                                                                        
            DO 90 N=1,IC10                                              
                                                                        
C If fragment weight (D2(N,J)) less than cutoff mass then               
                                                                        
               IF (D2(N,J) .LE. COTM) THEN                              
                                                                        
C Delete all remaining weight groups and exit loop.                     
                                                                        
                  IC2(J) = N - 1                                        
                  GOTO 100                                              
               ENDIF                                                    
 90         CONTINUE                                                    
                                                                        
C Set number of weight groups remaining.                                
                                                                        
 100        AMG = FLOAT(IC2(J))                                         
            IC10 = IC2(J)                                               
            IF (IC10 .LE. 0) THEN                                       
               AMG = 1.0                                                
               IC2(J) = 1                                               
               IC10 = 1                                                 
               D1(1,J) = 0.0                                            
            ENDIF                                                       
 110     CONTINUE                                                       
      ENDIF                                                             
                                                                        
C If new fragmentation data or a new velocity has been read for this    
C case, then call YAC1 and YAC2 to determine dynamic fragmentation      
C zones.                                                                
                                                                        
      IF (NWC1 .OR. NWC2) THEN                                          
         CALL YAC1                                                      
         CALL YAC2                                                      
      ENDIF                                                             
                                                                        
C Subroutine ZONE will print the warhead information if desired and     
C compute the maximum effective range for each zone.                    
                                                                        
      CALL ZONE                                                         
                                                                        
C If matrix is not to be computed on this pass, then set MATX indicator 
                                                                        
 120  IF (NMAZ .EQ. 1) THEN                                             
         MATX = .FALSE.                                                 
      ELSE                                                              
         IF (INDC .EQ. 1) THEN                                          
            MATX = .TRUE.                                               
         ELSE                                                           
            MATX = .FALSE.                                              
         ENDIF                                                          
                                                                        
C If a matrix is to be computed, initialize and compute diagonals from  
C target location to the corners of the cells on the last row of the    
C matrix. Set XMAX, XMIN, and YMAX.                                     
                                                                        
         IF (MATZ) THEN                                                 
            DO 140 I=1,40                                               
               DO 130 J=1,40                                            
                  ABOX(I,J) = 0.0                                       
                  BOX(I,J) = 0.0                                        
 130           CONTINUE                                                 
 140        CONTINUE                                                    
            DARSQ = DAR(NDG / 2 + 1) * DAR(NDG / 2 + 1)                 
            DO 150 I=1,NRG + 1                                          
               DIAG(I) = SQRT(DARSQ + RAR(I) * RAR(I))                  
 150        CONTINUE                                                    
            NMCTL = 1                                                   
            IF (NRAD .EQ. 2 .OR. NRAD .EQ. 3) GOTO 160                  
            XMAX = RAR(NRG + 1)                                         
            XMIN = RAR(1)                                               
            YMAX = DAR(NDG / 2 + 1)                                     
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C Find max effective range for warhead. H3 is the largest max range for 
C all zones.                                                            
                                                                        
 160  H3 = H1(1)                                                        
      MTX = .FALSE.                                                     
      JAY1 = 1                                                          
      DO 170 J=2,JC1                                                    
         H3 = MAX(H1(J),H3)                                             
 170  CONTINUE                                                          
                                                                        
      DO 180 LIN=1,8                                                    
         Q1(LIN) = 0.0                                                  
 180  CONTINUE                                                          
      IF (Q41(1) .LT. REVHT .AND. Q43 .LT. REVHT) H3 = REVDIS + REVBAS  
      IF (H3 .GE. RD1 .OR. .NOT.IDHT) THEN                              
         IF (RB2 .LE. H3) THEN                                          
            X = ABS(Q43 - Q41(1))                                       
         ELSE                                                           
            H3 = RB2                                                    
            X = ABS(Q43 - QAV)                                          
         ENDIF                                                          
                                                                        
C X is distance between target and weapon centroids                     
C H3 is the maximum effective distance of fragment travel (to           
C cutoff velocity) for all zones.                                       
C If Fragments can hit the centroid then                                
C   do standard fragment calculations                                   
C ELSE If no direct hit then no damage calculated                       
C T3 is maximum effective range in the ground plane. It is the greatest 
C range of frags, blast, or direct hit.                                 
                                                                        
         IF (X .LT. H3) THEN                                            
            T3 = SQRT(H3 * H3 - X * X)                                  
         ELSEIF (.NOT.IDHT) THEN                                        
            GOTO 320                                                    
         ELSE                                                           
            T3 = RD1                                                    
         ENDIF                                                          
      ELSE                                                              
         T3 = RD1                                                       
      ENDIF                                                             
                                                                        
C Set the limits and number of increments for the first region. The     
C first is linear and computed from the target to a distance of 1 foot  
C away from the target.                                                 
                                                                        
      U2 = 1.0                                                          
      XNX = 2.0                                                         
      IF (U2 .GE. T3) THEN                                              
                                                                        
C Max range less than upper integration limit. No other regions need to 
C be calculated.                                                        
                                                                        
         U2 = T3                                                        
         N21 = 1                                                        
         TLOG = T3                                                      
      ELSE                                                              
                                                                        
C Max range greater than U2. Set lower integration limit (U3) for the   
C second region and calculate the number of increments required to step 
C to the upper limit of the second region (U4).                         
                                                                        
         U3 = 1.0                                                       
         XN = 100.                                                      
                                                                        
C For the first integration, NMCTL = 0. Cell size is unknown and        
C integration limits are dependant upon the max effective range of the  
C weapon.                                                               
                                                                        
         IF (NMCTL .EQ. 1) THEN                                         
            IF (RB11 .GT. 0.) NCL = INT(XN)                             
                                                                        
C The following subroutine sets up the number of increments necessary   
C to cut the matrix cells at least twice by the polar radii.  The       
C number of increments will either be greater than or equal to the      
C increments in the previous polar integration region.                  
                                                                        
            CALL RNUM(XMAX,XMIN,YMAX,NRG,NDG,RAR,DAR,NCL,RMAXX,TLOG,N21,
     &                CM,RB1,IP)                                        
                                                                        
C RMAXX is new effective range (range at which PK < 1E-06).             
                                                                        
            T3 = RMAXX                                                  
            U3 = 1.0                                                    
            XN = FLOAT(NCL)                                             
                                                                        
C If the max increment for the first region is less than .5, then the   
C number of increments is set to smallest even integer such that        
C N >= 1/CM.                                                            
                                                                        
            IF (CM .LT. 0.5) THEN                                       
               XNX = U2 / CM                                            
               N = INT(XNX)                                             
               N = N / 2                                                
               XNX = FLOAT(2 * N + 2)                                   
            ENDIF                                                       
                                                                        
C Set the integration limits depending upon the number of regions.      
                                                                        
            IF (N21 .EQ. 3 .OR. N21 .LT. 1) THEN                        
                                                                        
C If blast is present --                                                
                                                                        
               IF (RB11 .GT. 0.) THEN                                   
                  IF (MOUNDOPT) THEN                                    
                                                                        
C Compute where on a mound the blast radius will fall. (Mounds only)    
                                                                        
                     CALL CUTMOUND(TLOG,QAV,Q43,RB1)                    
                  ELSE                                                  
                                                                        
C Compute effective blast range in the ground plane.                    
                                                                        
                     TLOG = SQRT(RB11 *  * 2 - (QAV - Q43) *  * 2)      
                  ENDIF                                                 
               ENDIF                                                    
                                                                        
C Set upper limit of second region.                                     
                                                                        
               U4 = TLOG                                                
                                                                        
C .001 added to U4 to drop off of blast curve.                          
C Set lower limit of third integration region.                          
                                                                        
               IF (RB11 .GT. 0.) THEN                                   
                  U5 = U4 + .001                                        
               ELSE                                                     
                  U5 = U4                                               
               ENDIF                                                    
                                                                        
C Set upper limit of third region.                                      
                                                                        
               U6 = T3                                                  
            ELSE                                                        
                                                                        
C Only two integration regions.                                         
                                                                        
               IF (N21 .EQ. 2) U4 = RMAXX                               
            ENDIF                                                       
         ELSE                                                           
                                                                        
C For the first polar integration--                                     
                                                                        
            IF (T3 .LE. 30.0) THEN                                      
                                                                        
C If max range is less than 30, set number of regions to 2.             
                                                                        
               N21 = 2                                                  
                                                                        
C XN is the number of divisions to make in each region.                 
                                                                        
               XN = 60.                                                 
               IF (T3 .GE. 20.0) THEN                                   
                                                                        
C 30 > Max range > 20, two regions, set lower limit of 2nd region.      
                                                                        
                  U4 = T3                                               
                  TLOG = T3                                             
               ELSE                                                     
                                                                        
C Only 1 region necessary. Set upper limit and number of cuts required. 
                                                                        
                  N21 = 1                                               
                  U2 = T3                                               
                  TLOG = T3                                             
                  XNX = 3.0 * T3                                        
                  N = INT(XNX)                                          
                  N = N / 2                                             
                  XNX = FLOAT(2 * N + 2)                                
               ENDIF                                                    
            ELSE                                                        
                                                                        
C Max range > 30.                                                       
                                                                        
               TLOG = 100.                                              
               IF (T3 .LE. 250.0) XN = 90.                              
               IF (T3 .LE. 200.0) XN = 70.                              
               IF (T3 .LE. 150.0) XN = 50.                              
               IF (T3 .LE. 100.0) XN = 30.                              
               IF (T3 .LE. 100.0) TLOG = T3 / 2.                        
                                                                        
C TLOG is the boundary between the 2nd and 3rd integration regions.     
C If there is no blast, the program runs frags only and uses            
C the above calculation of TLOG as the boundary.  If blast exists,      
C the upper limit of the 2nd region is assigned the value of RB1.       
C The area of the blast (2nd region) should equal PI x RB1**2.          
                                                                        
               IF (RB11 .GT. 0.) THEN                                   
                  IF (MOUNDOPT) THEN                                    
                                                                        
C Compute where on a mound the blast radius will fall.                  
                                                                        
                     CALL CUTMOUND(TLOG,QAV,Q43,RB1)                    
                  ELSE                                                  
                                                                        
C Compute effective blast range in the ground plane.                    
                                                                        
                     TLOG = SQRT(RB11 *  * 2 - (QAV - Q43) *  * 2)      
                  ENDIF                                                 
               ELSE                                                     
                                                                        
C No blast, frags only.                                                 
                                                                        
 190              X1 = FX(XN,TLOG,T3)                                   
                  IF (ABS(X1) .GE. 0.005) THEN                          
                     TLOG = TLOG - X1 / FPX(XN,TLOG,T3)                 
                     GOTO 190                                           
                  ENDIF                                                 
               ENDIF                                                    
                                                                        
C Set upper boundary of 2nd region.                                     
                                                                        
               U4 = TLOG                                                
                                                                        
C U5 is the beginning of the third region. .001 feet was added to U5 to 
C start the region off of the blast curve. The small amount of area     
C that is lost is insignificant to the area added if the first increment
C is made from the blast boundary.                                      
                                                                        
               IF (RB11 .GT. 0.) THEN                                   
                  U5 = U4 + .001                                        
               ELSE                                                     
                  U5 = U4                                               
               ENDIF                                                    
                                                                        
C Set upper limit of 3rd region to max range. Number of regions = 3.    
                                                                        
               U6 = T3                                                  
               N21 = 3                                                  
            ENDIF                                                       
         ENDIF                                                          
      ENDIF                                                             
                                                                        
      DR = U2 / XNX                                                     
      U7 = U2 - 1.001 * DR                                              
      U8 = 0.0                                                          
      GOTO 210                                                          
                                                                        
C The last region is computed as logarithmic for blast cases, and the   
C number of increments was set to 100. It was determined that the       
C accuracy obtained by increasing the number of increments was          
C negligible when compared to the amount of time added for the run. The 
C error between the 1st & 2nd polar regions and the matrix was found to 
C be in the vicinity of .2%.                                            
                                                                        
 200  IF (RB11 .GT. 0.0) THEN                                           
                                                                        
C If blast exists, then set up log increment step scaling and set log   
C indicators.                                                           
                                                                        
         N = 100                                                        
         XN = FLOAT(N)                                                  
         DR = (LOG(U6) - LOG(U5)) / XN                                  
         THORT = EXP(DR)                                                
         U7 = U6 / (1.001 * THORT)                                      
         U8 = U5                                                        
         N22 = 2                                                        
         N23 = 2                                                        
         GOTO 230                                                       
      ELSE                                                              
                                                                        
C No blast, compute 3rd region as linear.                               
                                                                        
         DR = (U6 - U5) / XN                                            
         U7 = U6 - 1.001 * DR                                           
         U8 = U5                                                        
      ENDIF                                                             
                                                                        
C Set integration type indicators to linear.                            
                                                                        
 210  N22 = 1                                                           
      N23 = 1                                                           
      GOTO 230                                                          
                                                                        
C Set the 2nd region to log step scaling. Set current region upper (U7) 
C and lower (U8) integration boundaries. U7 is the next to last         
C integration step.                                                     
                                                                        
 220  DR = (LOG(U4) - LOG(U3)) / XN                                     
      THORT = EXP(DR)                                                   
      U7 = U4 / (1.001 * THORT)                                         
      U8 = U3                                                           
      N22 = 2                                                           
      N23 = 2                                                           
                                                                        
C Set S1 (ground distance) to the start of the current integration      
C region.                                                               
                                                                        
 230  S1 = U8                                                           
      IF (S1 .EQ. 0.) THEN                                              
                                                                        
C 1st region. Set indicator to check for next to last integration       
C step (U7).                                                            
                                                                        
         N24 = 1                                                        
         N25 = 2                                                        
      ELSE                                                              
                                                                        
C Set indicators to continue integration of current region.             
                                                                        
         N24 = 2                                                        
         N25 = 1                                                        
         GOTO 250                                                       
      ENDIF                                                             
                                                                        
 240  IF (N22 .EQ. 1) THEN                                              
                                                                        
C Linear step increments.                                               
                                                                        
         S1 = S1 + DR                                                   
         RDR = S1 * DR                                                  
      ELSE                                                              
                                                                        
C Log step increments.                                                  
                                                                        
         S11 = S1                                                       
         S1 = S1 * THORT                                                
         RDR = S1 * (S1 - S11)                                          
                                                                        
C Check for boundary between 2nd and third regions.                     
                                                                        
         IF (IIS1 .EQ. 1) THEN                                          
            IF (N21I .EQ. 2) THEN                                       
               S1 = U6                                                  
            ELSE                                                        
               S1 = TLOG                                                
            ENDIF                                                       
         ENDIF                                                          
                                                                        
C Boundary between 2nd and 3rd region not met.                          
                                                                        
         IIS1 = 0                                                       
      ENDIF                                                             
                                                                        
C If matrix is to be computed (NMAZ) and MTX is true 0, set MATX to TRUE
C for correct target characterization for the matrix.                   
                                                                        
 250  IF (NMAZ .NE. 1) THEN                                             
         IF (MTX) THEN                                                  
            IF (INDC .EQ. 1) THEN                                       
               MATX = .TRUE.                                            
            ELSE                                                        
               MATX = .FALSE.                                           
            ENDIF                                                       
            MTX = .FALSE.                                               
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C If shielding selected,                                                
                                                                        
      IF (NTRE .GT. 0) THEN                                             
                                                                        
C Set percentage of target NOT shielded (RATIO) for the current         
C environment and ground distance (S1).                                 
                                                                        
 260     IF (S1 .GT. BRAD(KTRE)) THEN                                   
            KTRE = KTRE + 1                                             
            IF (KTRE .GT. LUM) THEN                                     
               RATIO = 0.0                                              
               KTRE = LUM                                               
            ELSE                                                        
               GOTO 260                                                 
            ENDIF                                                       
         ELSE                                                           
            IF (S1 .EQ. BRAD(KTRE)) THEN                                
               RATIO = COVR(KTRE)                                       
            ELSE                                                        
               DIVIS = (COVR(KTRE) - COVR(KTRE - 1)) / (BRAD(KTRE) -    
     &                 BRAD(KTRE - 1))                                  
               RATIO = COVR(KTRE - 1) + DIVIS * (S1 - BRAD(KTRE - 1))   
            ENDIF                                                       
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C Compute percentage of target covered by terrain.                      
                                                                        
      RATTER = 1.0                                                      
      DO 270 I=1,NTPX                                                   
         IF (TERAIN) CALL TABLE(S1,Q43,Q41(I),RATTER)                   
         RATF(I) = RATIO * RATTER                                       
 270  CONTINUE                                                          
                                                                        
      S1S = S1 *  * 2                                                   
      Q43 = Q43R                                                        
      IF (IDHT .OR. ROP) THEN                                           
                                                                        
C If direct hit option, the set burst height to target height.          
                                                                        
         IF (S1 .LE. RD1) Q43 = TGTHT                                   
      ENDIF                                                             
                                                                        
C Compute if Line of Sight exists for mounded or revetted targets.      
                                                                        
      IF (MOUNDOPT) THEN                                                
         CALL MOUND                                                     
      ELSEIF (ROP) THEN                                                 
         CALL REVETLOS                                                  
      ENDIF                                                             
                                                                        
C Calculate the fragment striking angle for each fragment centroid      
C and at this ground range and call SUBROUTINE TEV to interpolate       
C vulnerable areas for that angle.                                      
                                                                        
      DO 280 I=1,NTPX                                                   
         IF (S1 .EQ. 0.) THEN                                           
            ZEA = 90.0                                                  
         ELSE                                                           
            TEMP = (Q43 - Q41(I)) / S1                                  
            ZEA = ATAN(TEMP) * RAD2DEG                                  
         ENDIF                                                          
         CALL TEV(I,ZEA,0)                                              
 280  CONTINUE                                                          
                                                                        
      IF (IFIRE) THEN                                                   
         TEMP = (Q43 - Q41(NTPX + 1)) / S1                              
         ZEA = ATAN(TEMP) * RAD2DEG                                     
         CALL TEV(1,ZEA,1)                                              
      ENDIF                                                             
                                                                        
C Set indicators to calculate matrix values only once at the            
C boundaries between regions.                                           
                                                                        
      IF (JAY1 .NE. 1) THEN                                             
         MATX = .FALSE.                                                 
         MTX = .TRUE.                                                   
         JAY1 = 1                                                       
      ENDIF                                                             
                                                                        
C Calculate Pk for this ground range.                                   
                                                                        
      CALL CALC                                                         
                                                                        
C Store Pk's * ground range in Y(II).                                   
                                                                        
      IF (N23 .EQ. 1) THEN                                              
                                                                        
C For linear regions...                                                 
                                                                        
         Y = Q1(1) * S1                                                 
         YF = PKFIRE * S1                                               
      ELSE                                                              
                                                                        
C For log regions.                                                      
                                                                        
         Y = Q1(1) * S1 * S1                                            
         YF = PKFIRE * S1 * S1                                          
      ENDIF                                                             
                                                                        
C Store cumulative values in AX, BX, CX for total target kill. These    
C values are used in the final region integration.                      
                                                                        
      IF (N25 .EQ. 1) THEN                                              
         AX = Y + AX                                                    
         AXF = YF + AXF                                                 
      ELSEIF (N25 .EQ. 2) THEN                                          
         BX = Y + BX                                                    
         BXF = YF + BXF                                                 
      ELSE                                                              
         CX = Y + CX                                                    
         CXF = YF + CXF                                                 
      ENDIF                                                             
                                                                        
      IF (N24 .EQ. 1) THEN                                              
                                                                        
C Check for the next to last integration step.                          
                                                                        
         IF (S1 .LT. U7) THEN                                           
                                                                        
C If U7, then set indicators to show that a region boundary has been    
C reached.                                                              
                                                                        
            N24 = 2                                                     
            N25 = 3                                                     
         ELSE                                                           
                                                                        
C Continue normal integration.                                          
                                                                        
            N24 = 3                                                     
            N25 = 1                                                     
            IF (N22 .EQ. 2) IIS1 = 1                                    
         ENDIF                                                          
      ELSEIF (N24 .EQ. 2) THEN                                          
                                                                        
C Continue normal integration.                                          
                                                                        
         N24 = 1                                                        
         N25 = 2                                                        
      ELSE                                                              
                                                                        
C Insure that the last increment for a region is printed.               
                                                                        
         NPRT = 2                                                       
         IF (ND .EQ. 1 .AND. NMAZ .NE. 1 .AND. ZZ(JP) .EQ. RMAX) THEN   
            JPC = JP                                                    
            IF (IP .NE. ' ') THEN                                       
               KNTR = KNTR + 1                                          
               JPCHOLD(KNTR) = JPC                                      
               DO 290 IJK=1,JPC                                         
                  HOLDZZ(KNTR,IJK) = ZZ(IJK)                            
 290           CONTINUE                                                 
            ENDIF                                                       
         ENDIF                                                          
         GOTO 310                                                       
      ENDIF                                                             
                                                                        
      IF (ND .EQ. 1 .AND. NMAZ .EQ. 0) THEN                             
                                                                        
C Store ARCS data.                                                      
                                                                        
         JPC = JP                                                       
         IF (IP .NE. ' ') THEN                                          
            KNTR = KNTR + 1                                             
            JPCHOLD(KNTR) = JPC                                         
            DO 300 IJK=1,JPC                                            
               HOLDZZ(KNTR,IJK) = ZZ(IJK)                               
 300        CONTINUE                                                    
         ENDIF                                                          
                                                                        
         IF (NPRT .EQ. 1) GOTO 240                                      
      ELSE                                                              
         GOTO 240                                                       
      ENDIF                                                             
                                                                        
C Set integration variables.                                            
                                                                        
 310  IF (ITRAP .EQ. 0) THEN                                            
                                                                        
C Simpson's integration.                                                
                                                                        
         DNOMI = 3.0                                                    
         SIMP1 = 4.0                                                    
      ELSE                                                              
                                                                        
C Trapezoidal integration.                                              
                                                                        
         DNOMI = 2.0                                                    
         SIMP1 = 2.0                                                    
      ENDIF                                                             
                                                                        
C Compute lethal areas for total kill and fire kill. Reset the          
C accumulators.                                                         
                                                                        
      Y6 = 2.0 * PI * DR / DNOMI                                        
      NPRT = 1                                                          
      Q2 = Y6 * (AX + SIMP1 * BX + 2.0 * CX)                            
      Q3 = Q3 + Q2                                                      
      AX = 0.0                                                          
      BX = 0.0                                                          
      CX = 0.0                                                          
      QF = Y6 * (AXF + SIMP1 * BXF + 2.0 * CXF)                         
      QFTOT = QFTOT + QF                                                
      AXF = 0.                                                          
      BXF = 0.                                                          
      CXF = 0.                                                          
                                                                        
C Increment region counter.                                             
                                                                        
      N21I = N21I + 1                                                   
                                                                        
C Check for end of a region.                                            
                                                                        
      IF (NMAZ .EQ. 0) JAY1 = 2                                         
                                                                        
C Print number of radii in a region.                                    
                                                                        
      IF (NMCTL .EQ. 0) THEN                                            
                                                                        
         IF (N21I .EQ. 1 .AND. IP .NE. ' ') WRITE(6,5060)XNX            
         IF (N21I .EQ. 2 .AND. IP .NE. ' ') WRITE(6,5070)XN             
         IF (N21I .EQ. 3 .AND. IP .NE. ' ') THEN                        
            IF (RB1 .LE. 0.) THEN                                       
               WRITE(6,5080)XN                                          
            ELSE                                                        
               WRITE(6,5090)XN                                          
            ENDIF                                                       
         ENDIF                                                          
                                                                        
C Print lethal areas for this region.                                   
                                                                        
         IF (IP .NE. ' ') WRITE(6,5100)Q2                               
      ENDIF                                                             
                                                                        
C All regions finished, if not transfer back.                           
                                                                        
      IF (N21 .NE. N21I) GOTO(220,200),N21I                             
                                                                        
C Print total lethal areas, and reset region counter.                   
                                                                        
 320  N21I = 0                                                          
                                                                        
C Convert to sq. meters.                                                
                                                                        
      Q3M = Q3 * .0929034                                               
      Q3F = QFTOT * .0929034                                            
      QQ43 = Q43 * .3048006                                             
      IF (NMCTL .EQ. 0) THEN                                            
         IF (IP .NE. ' ') WRITE(6,5030)Q3,Q3M                           
         IF (IP .EQ. ' ' .AND. (.NOT.(MATZ))) WRITE(6,5000)Q3,Q3M       
      ENDIF                                                             
                                                                        
C Following are output options used for various projects within the     
C JTCG/ME.  Other users may wish to generate output to suit their       
C needs.                                                                
                                                                        
C Write first polar lethal area for BM/AS option to MAE output file.    
C Revetted or Mound targets do NOT print out the polar lethal           
C areas - the matrix lethal area from subroutine OUTM is printed.       
                                                                        
      IF (NAME(61:65) .EQ. 'BM/AS' .AND. NMCTL .EQ. 0 .AND. (.NOT.ROP   
     &    .AND. .NOT.MOUNDOPT)) WRITE(55,5020)NAME(1:48),Q43,Q6,Q3      
                                                                        
C Write first polar lethal area for LAF option to MAE output file.      
                                                                        
c always write LAOUT.DAT
c      IF (NAME(61:63) .EQ. 'LAF' .AND. NMCTL .EQ. 0)                   
      IF (NMCTL .EQ. 0)
c     &     WRITE(55,5010)NAME(1:30),Q43,Q6,Q3,Q3M                      
     &     WRITE(55,5011)NAME(1:72),Q43,Q6,Q3,Q3M                       
                                                                        
C Write first and second polar lethal area for R/B option to MAE        
C output file.                                                          
                                                                        
      IF (NAME(61:63) .EQ. 'R/B') WRITE(55,5010)NAME(1:30),Q43,Q6,Q3    
                                                                        
C Write first and second polar lethal area in square meters for R/B     
C and TERAIN options to MAE output file.                                
                                                                        
      IF (NAME(61:63) .EQ. 'R/B' .AND. TERAIN) WRITE(55,5010)NAME(1:30),
     &    Q43,Q6,Q3M                                                    
                                                                        
C Write first and second polar lethal area in square meters for LAR     
C and TERAIN options to MAE output file.                                
                                                                        
      IF (NAME(61:63) .EQ. 'LAR' .AND. TERAIN) WRITE(55,5010)NAME(1:30),
     &    Q43,Q6,Q3M                                                    
                                                                        
C Write range and pk if PKVSR option is chosen                          
      OPEN(UNIT=89,FILE='PKVSR.DAT',FORM='FORMATTED',STATUS='unknown',  
     &     CARRIAGECONTROL='LIST')                                      
                                                                        
c always write PKVSR.DAT
c      IF (NT7 .AND. KNT .GT. 0 .AND. NMCTL .GT. 0) THEN                
      IF (NT7) THEN                                                     
         WRITE(6,5120)
         WRITE(89,5021)'PBH',PBH,'OMEGA',Q6,'VELM',C2, 'ZDATA',
     & ZDATAID, 'RCAS', RCAS
         WRITE(89,5111)((PKVSR(NUMLIN,III),III=1,2),NUMLIN=1,KNT)
         WRITE(6,5110)((PKVSR(NUMLIN,III),III=1,2),NUMLIN=1,KNT)        
      ENDIF                                                             
                                                                        
C Set counter for next case                                             
                                                                        
      KNT = 0                                                           
                                                                        
C Print ARCS vs Range                                                   
                                                                        
      IF (NMCTL .GT. 0 .AND. KNTR .GT. 0) THEN                          
         WRITE(6,5130)                                                  
         DO 340 KKK=1,KNTR                                              
            NOWJPC = JPCHOLD(KKK)                                       
                                                                        
C Single line                                                           
                                                                        
            IF (NOWJPC .LT. 18) THEN                                    
               WRITE(6,5140)(HOLDZZ(KKK,IJK),IJK=1,NOWJPC - 2)          
            ELSE                                                        
               MULTI = (NOWJPC - 3) / 14                                
               LAST = MOD(NOWJPC - 3,14)                                
                                                                        
C Multiple lines                                                        
                                                                        
               DO 330 K=1,MULTI                                         
                                                                        
C 14 elements per line                                                  
                                                                        
                  LL = (14 * K) + 1                                     
                  IF (K .EQ. 1) WRITE(6,5140)(HOLDZZ(KKK,IJK),IJK=1,LL) 
                  IF (K .GT. 1) WRITE(6,5150)(HOLDZZ(KKK,IJK),IJK=LL -  
     &                                       13,LL)                     
                  IF (K .EQ. MULTI .AND. LAST .GT. 0) WRITE(6,          
     &                                        5150)(HOLDZZ(KKK,IJK),    
     &                                        IJK=LL + 1,LL + LAST)     
 330           CONTINUE                                                 
            ENDIF                                                       
                                                                        
C Write last arc (-90) and average pk                                   
                                                                        
            WRITE(6,5160)HOLDZZ(KKK,NOWJPC - 1),HOLDZZ(KKK,NOWJPC)      
 340     CONTINUE                                                       
                                                                        
C reset counter for next case                                           
                                                                        
         KNTR = 0                                                       
      ENDIF                                                             
                                                                        
C Output the matrix to file (OUTM) and paper (OUTZ).                    
                                                                        
      IF (MATZ) CALL OUTM                                               
      IF (MOSK .EQ. 2) CALL OUTZ                                        
                                                                        
C Reset lethal areas.                                                   
                                                                        
      Q3 = 0.0                                                          
      QFTOT = 0.                                                        
      Q43 = Q43R                                                        
      RDH = .TRUE.                                                      
                                                                        
C If no other passes are needed, read data for next case.               
                                                                        
      IF (NMAZ .NE. 1) GOTO 60                                          
                                                                        
C Compute max ranges.                                                   
C If blast not effective...                                             
                                                                        
      IF ((RB2 .EQ. 0.0) .OR. (RB2 .LE. (Q43 - QAV))) THEN              
                                                                        
C Check direct hit distances.                                           
                                                                        
 350     RYMAX = MAX(RYMAX,RD1)                                         
         RXMAX = MAX(RXMAX,RD1)                                         
         IF (RXMIN .LT. 0.) THEN                                        
            RXMIN =  - (MAX(RD1,ABS(RXMIN)))                            
         ELSE                                                           
            RXMIN = MIN(RD1,RXMIN)                                      
         ENDIF                                                          
      ELSE                                                              
                                                                        
C Set blast max range.                                                  
                                                                        
         RB3 = RB2 * RB2 - (Q43 - QAV) *  * 2                           
         IF (RB3 .LT. 0.) GOTO 350                                      
         RB3 = SQRT(RB3)                                                
         IF (RD1 .GT. RB3) GOTO 350                                     
         RYMAX = MAX(RYMAX,RB3)                                         
         RXMAX = MAX(RXMAX,RB3)                                         
         IF (RXMIN .LT. 0.) THEN                                        
            RXMIN =  - (MAX(RB3,ABS(RXMIN)))                            
         ELSE                                                           
            RXMIN =  - RB3                                              
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C Set max ranges.                                                       
                                                                        
      XMIN = RXMIN                                                      
      XMAX = RXMAX                                                      
      YMAX = RYMAX                                                      
      IF (YMAX .EQ. 0.) YMAX = 1.                                       
      IF (XMIN .EQ. 0.) XMIN =  - 1.                                    
      IF (XMAX .EQ. 0.) XMAX = 1.                                       
      NDU = NDG / 2                                                     
                                                                        
C MTXCEL computes either matrix cell size or number of cells necessary. 
                                                                        
      CALL MTXCEL(NDON,XMIN,XMAX,YMAX,NRG,NDU,RA,DA,RAR,DAR)            
                                                                        
C Set variables for 2nd integration pass.                               
                                                                        
      NDG = NDU * 2                                                     
      MATZ = .TRUE.                                                     
      MOSK = 2                                                          
      NMAZ = 0                                                          
      IF (NYN1 .NE. 0) THEN                                             
         NYN = .TRUE.                                                   
         NYN2 = 0                                                       
         NYNX = 0                                                       
      ELSE                                                              
         NYN = .FALSE.                                                  
      ENDIF                                                             
      ND = 2                                                            
      KTRE = 1                                                          
      IF (NDCLS) ND = 1                                                 
                                                                        
C Print max and min ranges.                                             
                                                                        
      IF (IP .NE. ' ') THEN                                             
         WRITE(6,5040)                                                  
         WRITE(6,5050)RXMIN,RXMAX,RYMAX                                 
      ENDIF                                                             
                                                                        
C Start 2nd pass.                                                       
                                                                        
      GOTO 120                                                          
                                                                        
 5000 FORMAT ('0POLAR LETHAL AREA  = ',F10.1,' SQ FEET',F10.1,          
     &        ' SQ METERS')                                             
 5010 FORMAT (1X,A30,F10.3,3F10.2)                                      
 5011 FORMAT (1X,A72,F10.3,3F10.2)                                      
 5020 FORMAT (A48,F10.3,2F10.0)                                         
 5021 FORMAT (A9,1X,F9.4,1X,A9,1X,F9.4,1X,A9,1X,F9.4,1X,A9,1X,F9.4,1X,
     &          A9,1X,A9)
 5030 FORMAT ('0 TOTAL SINGLE POINT TARGET LETHAL AREA = ',12X,F10.1,   
     &        ' SQ.FT. ',/,54X,F10.1,' SQ.M. ')                         
 5040 FORMAT ('0',40X,'>>> MATRIX LETHAL AREA <<<',//1X,                
     &        'MATRIX DIMENSIONS (FT):'/1X,12X,'RANGE MINIMUM',12X,     
     &        'RANGE MAXIMUM',12X,'DEFLECTION MAXIMUM')                 
 5050 FORMAT (12X,F13.2,12X,F13.2,14X,F13.2)                            
 5060 FORMAT ('0',36X,'>>> POLAR LETHAL AREAS (SQUARE FEET) <<<'//2X,   
     &        'FIRST LINEAR REGION, INCREMENTS       = ',F5.0)          
 5070 FORMAT ('0',1X,'LOGARITHMIC REGION, INCREMENTS        = ',F5.0)   
 5080 FORMAT ('0',1X,'SECOND LINEAR REGION, INCREMENTS      = ',F5.0)   
 5090 FORMAT ('0',1X,'SECOND LOGARITHMIC REGION, INCREMENTS = ',F5.0)   
 5100 FORMAT (60X,'SINGLE POINT TARGET LETHAL AREA = ',F10.1)           
 5110 FORMAT (4(5X,F12.4,2X,F7.4))                                      
 5111 FORMAT (F9.4,1X,F9.4)
 5120 FORMAT ('1',50X,'>>> PK VS RANGE <<<',/,6X,99('-')/,2X,4(7X,      
     &        '   RANGE  ',4X,'PK   '),/,6X,99('-'))                    
 5130 FORMAT ('0',62X,'ARC VS RANGE',/,'0  RANGE |',T124,'| AVG. ARC',/,
     &        3X,'(FT)  |',7(1X,' ANGLE',2X,'  PK ',1X),1X,' ANGLE',    
     &        T124,'|    PK',/,1X,8('-'),8('+',7('-')),7('+',6('-')),8( 
     &        '-'))                                                     
 5140 FORMAT (1X,F7.2,' |',7(1X,F6.2,1X,1X,F5.3,1X),T124,'|')           
 5150 FORMAT (T124,'|',T9,' |',7(1X,F6.2,2X,F5.3,1X),1X,F6.2)           
 5160 FORMAT ('+',T117,F6.2,T124,'|  ',F5.3)                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE MOUND                                                  
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C This routine determines the cutoff angle (coff) for the dead zone     
C caused by the mound. The dead zone is the region downrange of the     
C mound where the weapon cannot physically reach.                       
C It also computes if a line of sight (los) exists between the weapon   
C and the target for both blast and frags.                              
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C COFF              deg     For a particular ground range, COFF is the  
C                           arc angle where the ground range arc        
C                           intersects the dead zone.                   
C                                                                       
C FT                 ft     Length of edge of mound shadow.             
C                                                                       
C IDEAD              --     Indicator:                                  
C                           TRUE  - A dead zone exists.                 
C                           FALSE - A dead zone does NOT exist.         
C                                                                       
C IDHT               --     Indicator :                                 
C                           TRUE  - Direct-hit option used.             
C                           FALSE - Direct-hit option NOT used.         
C                                                                       
C LOSBLT             --     Indicator for line of sight of blast        
C                             0 - line of sight does NOT exist.         
C                             1 - line of sight exists.                 
C                                                                       
C LOSFRG             --     Indicator for line of sight of fragments:   
C                             0 - line of sight does NOT exist.         
C                             1 - line of sight exists for fragments    
C                                                                       
C Q41(I)             ft     I=1,NTPX.                                   
C                           Target heights representing centers of      
C                           vulnerability to fragments.                 
C                                                                       
C Q43                ft     Weapon burst height.                        
C                                                                       
C QAV                ft     Height of target centroid for blast.        
C                           Includes mound height.                      
C                                                                       
C RAD2DEG            --     Constant.  180/PI. Radians to degrees       
C                           conversion.                                 
C                                                                       
C REVA              deg     Interior angle formed by the wall and base  
C                           of the revetment or mound.                  
C                                                                       
C REVBAS             ft     Width of revetment base or radius of mound  
C                           base.                                       
C                                                                       
C REVHT              ft     Height of revetment or mound.               
C                                                                       
C REVTOP             ft     Width of revetment top or radius of mound   
C                           top.                                        
C                                                                       
C RTRAJ             deg     Impact angle.                               
C                                                                       
C S1                 ft     Ground range. Distance from target to       
C                           weapon burst point in the plane             
C                           parallel to the ground at the weapon burst  
C                           height.                                     
C                                                                       
C S1D                ft     Length of mound shadow in the ground        
C                           plane. Measured from the target location    
C                           to the end of the mound shadow.             
C                                                                       
C STBST             deg     Angle measured from a vertical line         
C                           containing the target centroid and the      
C                           line containing the target and weapon       
C                           centroids.                                  
C                                                                       
C STEDG             deg     Angle measured from the vertical line       
C                           containing the target centroid and the      
C                           line containing the target centroid and     
C                           a point on the edge of the mound top.       
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C     None                                                              
C                                                                       
C---------------------------------------------------------------------- 
C Functions Called                                                      
C                                                                       
C     None                                                              
C                                                                       
C---------------------------------------------------------------------- 
C Calling Routine                                                       
C                                                                       
C     MAIN                                                              
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
C                                                                       
      COMMON  / DIRHIT /  PKH,RD1,TGTHT,Q43R,FRAGOPT                    
      COMMON  / REV /  REVHT,REVSLP,REVTOT,ACTR,DTD,REVBAS,REVDIS,DEAD, 
     &       REVA,COFF,GONG,REVTOP,RTRAJ,LOSFRG,LOSBLT                  
                                                                        
C Initialize the cutoff angle.                                          
                                                                        
      COFF = 90.                                                        
                                                                        
      IF (S1 .GE. REVBAS) THEN                                          
                                                                        
C Burst point beyond mound base. If dead zone exists, compute the       
C length of the mound shadow and cutoff angle.                          
                                                                        
         IF (IDEAD) THEN                                                
            FT = SQRT((S1D - REVTOP) *  * 2 - (REVBAS - REVTOP) *  * 2) 
            IF (S1 .GT. SQRT(REVBAS *  * 2 + FT *  * 2)) THEN           
               IF (S1 .LE. S1D) THEN                                    
                                                                        
C Law of cosines is used to calculate cutoff angle.                     
C Arc hits on semicircle at end of dead zone.                           
                                                                        
                  COFF = ACOS(((S1D - REVTOP) *  * 2 + S1 *  * 2 -      
     &                   REVTOP *  * 2) / (2 * S1 * (S1D + REVTOP)))    
                  COFF = (COFF * RAD2DEG) - 90.                         
               ENDIF                                                    
            ELSE                                                        
                                                                        
C Arc hits on straight edge of dead zone.                               
                                                                        
               COFF = ASIN(FT / (S1D - REVTOP)) * RAD2DEG - ACOS(REVBAS 
     &                / S1) * RAD2DEG                                   
               COFF = COFF - 90.                                        
            ENDIF                                                       
         ENDIF                                                          
                                                                        
C Weapon detonates on top of mound. Adjust burst height.                
                                                                        
      ELSEIF (S1 .LE. REVTOP) THEN                                      
         Q43 = Q43 + REVHT                                              
      ELSE                                                              
                                                                        
C Weapon hits on mound slope. Adjust burst height.                      
                                                                        
         Q43 = Q43 + (REVBAS - S1) * TAN(REVA)                          
         IF (IDEAD) THEN                                                
                                                                        
C Calculate cutoff angle when dead zone exists.                         
                                                                        
            FT = SQRT((S1D - REVTOP) *  * 2 - (REVBAS - REVTOP) *  * 2) 
            COFF = ASIN(FT / (S1D - REVTOP))                            
            COFF = (RAD2DEG * COFF) - 90.                               
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C If weapon is on mound top or burst height is above mound, line of     
C sight exists. Exit routine.                                           
                                                                        
      IF ((S1 .GT. REVTOP) .AND. (Q43 .LT. REVHT)) THEN                 
                                                                        
C Test for fragment line of sight. If angle between the weapon          
C centroid and the target centroid for fragments is greater than the    
C angle between the target centroid and the mound edge, line of         
C sight exists.                                                         
                                                                        
         STEDG = ATAN(REVTOP / (Q41(1) - REVHT)) * RAD2DEG              
         STBST = ATAN(S1 / (Q41(1) - Q43)) * RAD2DEG                    
         IF (STBST .GE. STEDG) THEN                                     
            LOSFRG = 1                                                  
         ELSE                                                           
            LOSFRG = 0                                                  
         ENDIF                                                          
                                                                        
C If the direct hit option is selected, there is no blast. Blast line   
C of sight is not calculated.                                           
                                                                        
         IF (IDHT) RETURN                                               
                                                                        
C Test for blast line of sight. If angle between the weapon             
C centroid and the target centroid for blast is greater than the        
C angle between the target centroid and the mound edge, line of         
C sight exists.                                                         
                                                                        
         STEDG = ATAN(REVTOP / (QAV - REVHT)) * RAD2DEG                 
         STBST = ATAN(S1 / (QAV - Q43)) * RAD2DEG                       
         IF (STBST .GE. STEDG) THEN                                     
            LOSBLT = 1                                                  
         ELSE                                                           
            LOSBLT = 0                                                  
         ENDIF                                                          
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE MTXCEL(K,XMIN,XMAX,YMAX,NR,ND,CR,CD,AR,AD)             
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    If the number of cells to place in the matrix is known (given in   
C the input stream), this routine calculates the size of each cell in   
C the matrix.  If the cell size is known, the routine calculates the    
C number of cells to place in the matrix up to a maximum of 40 X 40.    
C 0.3 is added to some equations as a sizing constant.                  
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ----------     ---------  -----------------------------------         
C AD(I)              ft     Deflection grid coordinate.                 
C                                                                       
C AR(I)              ft     Range grid coordinate.                      
C                                                                       
C ARTP(I)            ft     Distance of a cell in range as related to   
C                           XMIN.                                       
C                                                                       
C CD                 ft     Cell size in deflection.                    
C                                                                       
C CR                 ft     Cell size in range.                         
C                                                                       
C CR1                ft     Cell size in range computed using the max   
C                           range divided by the # of cells.            
C                                                                       
C CR2                ft     Cell size in range using the minimum range  
C                           divided by the # of cells.                  
C                                                                       
C K                  --     Indicator:                                  
C                            0 - Given the number of cells, compute cell
C                                size and grid coordinates.             
C                            1 - Given the cell size, compute grid      
C                                coordinates and the number of cells.   
C                                                                       
C ND                 --     Total number of matrix cells in deflection. 
C                                                                       
C NR                 --     Total number of matrix cells in range.      
C                           Even number with a maximum of 40.           
C                                                                       
C N1                 --     Number of cells associated with the         
C                           distance |XMAX|.                            
C                                                                       
C N2                 --     Number of cells associated with the         
C                           distance |XMIN|.                            
C                                                                       
C XMAX               ft     Maximum dimension of the matrix in range.   
C                                                                       
C XMIN               ft     Minimum dimension of the matrix in range.   
C                                                                       
C XMINS              ft     Intermediate variable for minimum dimension 
C                           of the matrix in range.                     
C                                                                       
C XS                 ft     Absolute sum of XMAX & XMIN.                
C                                                                       
C X3                 --     Real number representative of the number of 
C                           cells in range associated with XMAX.        
C                                                                       
C YMAX               ft     Maximum dimension of the matrix in          
C                           deflection.                                 
C                                                                       
C-----------------------------------------------------------------------
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C ROUND                                                                 
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      DIMENSION ARTP(42)                                                
      DIMENSION AR(41),AD(41)                                           
                                                                        
      IF (K.EQ.0) THEN                                                  
                                                                        
C Number of Cells (NR and ND) are known.                                
C Compute cell size in deflection.                                      
                                                                        
         CD = YMAX / FLOAT(ND)                                          
         CD = ROUND(CD,1)                                               
                                                                        
C Compute cell size in range.                                           
                                                                        
         IF (XMIN .GE. 0) THEN                                          
            CR = ABS(XMAX - XMIN) / FLOAT(NR)                           
            CR = ROUND(CR,1)                                            
         ELSE                                                           
                                                                        
C Compute cell size in range.                                           
                                                                        
            IF (XMAX .LE. 0) THEN                                       
               JX = NR + 2                                              
               CR = ABS(XMAX - XMIN) / FLOAT(NR)                        
                                                                        
C Compute range grid coordinates.                                       
                                                                        
               DO 10 I=1,NR + 1                                         
                  JX = JX - 1                                           
                  SI = I - 1                                            
                  AR(JX) = XMAX - (SI * CR)                             
                  AR(JX) = ROUND(AR(JX),1)                              
 10            CONTINUE                                                 
            ELSE                                                        
                                                                        
C Compute # of cells in range with negative coordinates and             
C positive coordinates.                                                 
                                                                        
               XS = ABS(XMAX) + ABS(XMIN)                               
               X3 = ((ABS(XMAX) / XS) * FLOAT(NR)) + 0.3                
               N1 = IFIX(X3)                                            
               N2 = NR - N1                                             
                                                                        
C Make sure that there is at least one cell in the positive and/or      
C negative direction for range.                                         
                                                                        
               IF (N1 .EQ. 0) THEN                                      
                  N1 = 1                                                
                  N2 = N2 - 1                                           
               ELSEIF (N2 .EQ. 0) THEN                                  
                  N2 = 1                                                
                  N1 = N1 - 1                                           
               ENDIF                                                    
                                                                        
C Compute cell size in range. Use the largest cell size for all cells.  
                                                                        
               CR1 = ABS(XMAX) / FLOAT(N1)                              
               CR2 = ABS(XMIN) / FLOAT(N2)                              
               CR = MAX(CR1,CR2)                                        
               CR = ROUND(CR,1)                                         
                                                                        
C Compute negative range grid coordinates starting at N2.               
                                                                        
               DO 20 IM=1,N2                                            
                  JM = N2 - IM + 1                                      
                  AR(JM) =  - FLOAT(IM) * CR                            
                  AR(JM) = ROUND(AR(JM),1)                              
 20            CONTINUE                                                 
                                                                        
               AR(N2 + 1) = 0.0                                         
                                                                        
C Compute positive range grid coordinates.                              
                                                                        
               DO 30 IM=1,N1                                            
                  JM = IM + N2 + 1                                      
                  AR(JM) = FLOAT(IM) * CR                               
                  AR(JM) = ROUND(AR(JM),1)                              
 30            CONTINUE                                                 
            ENDIF                                                       
         ENDIF                                                          
      ELSE                                                              
                                                                        
C Cell size (CR and CD) are known.                                      
C Compute # of deflection cells.                                        
                                                                        
         ND = IFIX((YMAX / CD) + 0.3)                                   
                                                                        
C Compute # of range cells.                                             
                                                                        
         IF (XMIN .GE. 0) THEN                                          
            NR = IFIX((ABS(XMAX - XMIN) / CR) + 0.3)                    
            NR = NR + 1                                                 
            XMINS = XMIN                                                
         ELSE                                                           
                                                                        
C Compute # cells in range and their coordinates.                       
                                                                        
            IF (XMAX .LE. 0) THEN                                       
               NR = IFIX(((ABS(XMAX - XMIN)) / CR) + 0.3)               
               NR = NR + 1                                              
               JX = NR + 2                                              
               DO 40 I=1,NR + 1                                         
                  JX = JX - 1                                           
                  SI = FLOAT(I - 1)                                     
                  AR(JX) = XMAX - SI * CR                               
                  AR(JX) = ROUND(AR(JX),1)                              
 40            CONTINUE                                                 
            ELSE                                                        
                                                                        
C Compute # of cells in range.                                          
                                                                        
               N1 = IFIX((ABS(XMAX) / CR) + 0.3)                        
               N2 = IFIX((ABS(XMIN) / CR) + 0.3)                        
               NR = N1 + N2                                             
                                                                        
C XMINS is approximately equal to -XMIN.                                
                                                                        
               XMINS =  - CR * FLOAT(N2)                                
            ENDIF                                                       
         ENDIF                                                          
                                                                        
C Check to be sure that # of deflection cells is an even number between 
C 2 and 40.                                                             
                                                                        
         IF (MOD(ND,2) .NE. 0) ND = ND + 1                              
         ND = MAX(2,ND)                                                 
         IF (ND .GT. 40) ND = 40                                        
                                                                        
      ENDIF                                                             
                                                                        
C Compute the deflection grid coordinates.                              
                                                                        
      AD(1) = 0.0                                                       
      DO 50 IM=2,ND + 1                                                 
         AD(IM) = AD(IM - 1) + CD                                       
         AD(IM) = ROUND(AD(IM),1)                                       
 50   CONTINUE                                                          
                                                                        
C If the minimum range dimension is positive or the cell sizes were     
C given in the input stream with a positive max range, then compute     
C the range grid coordinates.                                           
                                                                        
      IF ((XMIN .GE. 0) .OR. ((K.EQ.1) .AND. (XMAX .GT. 0))) THEN       
                                                                        
C Check to be sure that # of range cells is an even number between      
C 2 and 40.                                                             
                                                                        
         IF (MOD(NR,2) .NE. 0) NR = NR + 1                              
         NR = MAX(2,NR)                                                 
         IF (NR .GT. 40) NR = 40                                        
                                                                        
C Compute range grid coordinates.                                       
                                                                        
         AR(1) = XMINS + 0.00001                                        
         AR(1) = ROUND(AR(1),1)                                         
         DO 60 I=2,NR + 1                                               
            AR(I) = AR(I - 1) + CR                                      
            AR(I) = ROUND(AR(I),1)                                      
 60      CONTINUE                                                       
         IF ((XMIN .LT. 0) .AND. (XMAX .GE. 0)) AR(N2 + 1) = 0.0        
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE MTXLIM(JP,ZZ,XMAX,XMIN,YMAX)                           
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Compute the maximum effective ground range, both negative and      
C positive, and the maximum ground deflection distances.  This          
C routine will not be called if the impact angle equals 90 degrees.     
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ANG                RAD    Angle in a plane parallel to the ground     
C                           measured from the deflection axis to each   
C                           dynamic zone of the weapon having a radius  
C                           equal to the distance from the weapon       
C                           impact to the target.                       
C                                                                       
C ITOT               --     Number of dynamic zones.                    
C                                                                       
C JP                 --     Number of dynamic zones plus 1              
C                                                                       
C KTT                --     Subscript of the angle that defines the     
C                           last dynamic zone encountered that has      
C                           a PK > 0.                                   
C                                                                       
C TMAX               ft     Maximum distance in the positive range      
C                           direction.  Equal to the distance           
C                           from the target to the weapon impact        
C                           point times the sine of the largest         
C                           angle which contains a PK > 0.              
C                                                                       
C TMIN               ft     Maximum distance in the negative range      
C                           direction.  Equal to the distance           
C                           from the target to the weapon impact        
C                           point times the sine of the smallest        
C                           angle which contains a PK > 0.              
C                                                                       
C TTMAX              ft     Maximum distance in the positive deflection 
C                           direction.  Equal to the distance           
C                           from the target to the weapon impact        
C                           point times the cosine of the largest       
C                           angle which contains a PK > 0.              
C                                                                       
C XMAX               ft     Maximum effective distance in the           
C                           positive range direction.                   
C                                                                       
C XMIN               ft     Maximum effective distance in the           
C                           negative range direction.                   
C                                                                       
C YMAX               ft     Maximum effective distance                  
C                           in the positive deflection direction.       
C                                                                       
C ZZ                 --     Used to store PK for each arc versus        
C                           its corresponding angles.                   
C                           ZZ(1) = distance from bomb impact to tgt.   
C                           ZZ(2) = 90.0 degrees                        
C                           ZZ(I) where I is even = dynamic zone        
C                                                         angles        
C                           ZZ(I) where I is odd  = dynamic zone        
C                                                         PKs.          
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C CALC                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      LOGICAL MATX                                                      
      DIMENSION ZZ(300)                                                 
C                                                                       
      INCLUDE 'stdparameter_clean.inc'                                        
                                                                        
      KTT = 0                                                           
                                                                        
C Assign total number of dynamic zones.                                 
                                                                        
      ITOT = JP - 2                                                     
                                                                        
      DO 20 I=3,ITOT,2                                                  
                                                                        
C Locate first zone with Pk > 0.  This zone will determine the max      
C effective positive ground range for this weapon-target distance.      
C If there are no zones with Pk > 0, then exit this subroutine.         
                                                                        
         IF (ZERO1(ZZ(I)) .GT. 0.0) THEN                                
                                                                        
C Compute the maximum positive range distance and largest angle of the  
C weapon's dynamic zones with Pk > 0.                                   
                                                                        
            ANG = ZZ(I - 1) * DEG2RAD                                   
            TMAX = SIN(ANG) * ZZ(1)                                     
                                                                        
            DO 10 K=I,ITOT,2                                            
                                                                        
C Examine each zone to determine the maximum deflection distance        
C which contains a Pk.                                                  
                                                                        
               IF (ZERO1(ZZ(K)) .GT. 0.0) THEN                          
                  KTT = K                                               
                  IF (ZZ(K - 1) .EQ. 0.0) YMAX = ZZ(1)                  
                  IF (ZZ(K - 1) .GT. 0.0) THEN                          
                     ANG = ZZ(K + 1) * DEG2RAD                          
                     IF (ZZ(K + 1) .LE. 0.0) YMAX = ZZ(1)               
                  ELSE                                                  
                     ANG = ZZ(K - 1) * DEG2RAD                          
                  ENDIF                                                 
                  TTMAX = COS(ANG) * ZZ(1)                              
                  IF (TTMAX .GT. YMAX) YMAX = TTMAX                     
               ENDIF                                                    
 10         CONTINUE                                                    
                                                                        
C Assign the maximum positive range distance                            
                                                                        
            IF (TMAX .GT. XMAX) XMAX = TMAX                             
                                                                        
C Assign the minimum negative ground range distance using the lowest    
C angle that had Pk > 0.                                                
                                                                        
            ANG = ZZ(KTT + 1) * DEG2RAD                                 
            TMIN = SIN(ANG) * ZZ(1)                                     
            IF (XMIN .GT. TMIN) XMIN = TMIN                             
                                                                        
            RETURN                                                      
         ENDIF                                                          
 20   CONTINUE                                                          
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE OUTM                                                   
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
C PURPOSE: OUTM calculates the average probability of kill and lethal   
C          area of each cell and the total matrix lethal area           
C          and writes them to output.  Symmetry about the range axis is 
C          assumed.                                                     
C                                                                       
C-----------------------------------------------------------------------
C ABOX(I,J)         sq ft   I = 1,NDG/2, J = 1,NRG.                     
C                           Approximate area of a cell determined by    
C                           summation of arc length and width.          
C                                                                       
C BOX(I,J)          sq ft   I = 1,NDG/2; J = 1,NRG.                     
C                           Approximate lethal area of cell determined  
C                           by summation of arc length and width and    
C                           PK; also average PK for a cell.             
C                                                                       
C DAR(I)             ft     I = 1,NDG/2.                                
C                           Deflection grid coordinate.                 
C                                                                       
C DENM              sq ft   Area of a matrix cell.                      
C                                                                       
C IP                 --     Indicator:                                  
C                             BLANK = short output                      
C                             NONBLANK = long output                    
C                                                                       
C MOUNDOPT           --     Indicator:                                  
C                             TRUE - Target on a mound                  
C                             FALSE - Target not on a mound             
C                                                                       
C NAME               --     Title for each case.                        
C                                                                       
C NDG                --     Total number of matrix cells in deflection. 
C                                                                       
C NFIN               --     Final column subscript per page for printing
C                           array BOX.                                  
C                                                                       
C NRG                --     Total number of matrix cells in range.      
C                                                                       
C NST                --     Starting column subscript per page for      
C                           printing array BOX.                         
C                                                                       
C RAR(I)             ft     I=1,NRG/2 + 1.                              
C                           Range grid coordinate.                      
C                                                                       
C ROP                --     Indicator:                                  
C                             TRUE - Revetted target                    
C                             FALSE - NOT revetted target               
C                                                                       
C SQF2SQM          sq ft    Conversion factor for square feet to square 
C                           meters.                                     
C                                                                       
C TOT              sq ft    Lethal area of the matrix.                  
C                                                                       
C X1                 ft     Distance between two adjacent range grid    
C                           coordinates.                                
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
C                                                                       
      COMMON  / ARTXX /  ABOX(40,40),RDR                                
                                                                        
      TOT = 0.0                                                         
                                                                        
C  Considering only the positive half of the deflection axis ,          
C  extract the area of each cell, DENM, and the Pk of each cell,BOX.    
C  Total the lethal areas, TOT.                                         
                                                                        
      DO 20 I=1,NRG                                                     
         X1 = RAR(I + 1) - RAR(I)                                       
         DO 10 J=1,NDG / 2                                              
            DENM = (DAR(J + 1) - DAR(J)) * X1                           
            IF ((ABOX(J,I)) .GT. 0.0) THEN                              
               BOX(J,I) = BOX(J,I) / ABOX(J,I)                          
               TOT = TOT + BOX(J,I) * DENM                              
            ELSE                                                        
               BOX(J,I) = 0.0                                           
            ENDIF                                                       
 10      CONTINUE                                                       
 20   CONTINUE                                                          
                                                                        
C Assuming symmetry, multiply x 2 to obtain total lethal area.          
                                                                        
      TOT = 2.0 * TOT                                                   
                                                                        
C Write the matrix and total lethal area.                               
                                                                        
      IF (IP .NE. ' ') WRITE(6,5050)TOT,TOT * SQF2SQM                   
                                                                        
      DO 40 K=1,4                                                       
         NST = 10 * K - 9                                               
         NFIN = MIN0(K * 10,NDG / 2)                                    
         IF (NST .LE. NFIN) THEN                                        
            IF (IP .NE. ' ') THEN                                       
               WRITE(6,5020)RAR(1)                                      
               WRITE(6,5030)(DAR(I),I=NST + 1,NFIN + 1)                 
               DO 30 I=1,NRG                                            
                  WRITE(6,5040)RAR(I + 1),(BOX(J,I),J=NST,NFIN)         
 30            CONTINUE                                                 
            ENDIF                                                       
         ENDIF                                                          
 40   CONTINUE                                                          
      IF (IP .NE. ' ') THEN                                             
         WRITE(6,5050)TOT,TOT * SQF2SQM                                 
      ELSE                                                              
         WRITE(6,5010)TOT,TOT * SQF2SQM                                 
      ENDIF                                                             
c        IF (NAME(61:63) .EQ. 'LAF'.AND.(NRAD.EQ.1))    WRITE(55,       
c     &    5011)NAME(1:30),Q43,Q6,TOT,TOT*SQF2SQM                       
c write all 72 char title 
        IF (NRAD.EQ.1) WRITE(55,5012)NAME(1:72),Q43,Q6,TOT,TOT*SQF2SQM
C Write the matrix lethal area for revetment or mounds and BM/AS        
C option to MAE output file.                                            
                                                                        
      IF (NAME(61:65) .EQ. 'BM/AS' .AND. (ROP .OR. MOUNDOPT)) WRITE(55, 
     &    5000)NAME(1:48),Q43,Q6,TOT                                    
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (A48,F10.3,2F10.0)                                         
 5010 FORMAT ('0MATRIX LETHAL AREA = ',F10.1,' SQ FEET',F10.1,          
     &        ' SQ METERS')                                             
 5011 FORMAT (1X,A30,F10.3,3F10.2)                                      
 5012 FORMAT (1X,A72,F10.3,3F10.2)                                      
 5020 FORMAT ('1','MINIMUM RANGE COORDINATE =',F10.2/1X,39X,            
     &        'DAMAGE MATRIX (PROBABILITY OF KILL)',/,2X,'  RANGE  ','|'
     &       ,32X,'DEFLECTION COORDINATE (FEET)'/,1X,'COORDINATE','|',  
     &        99('-'))                                                  
 5030 FORMAT (1X,'  (FEET)  |',F9.2,9F10.2/1X,'----------',10(          
     &        '+---------'))                                            
 5040 FORMAT (1X,F8.2,'  |',F9.4,9F10.4)                                
 5050 FORMAT ('0','MATRIX LETHAL AREA =',F14.2,' SQ. FT.'/1X,20X,F14.2, 
     &        ' SQ. M.')                                                
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE OUTZ                                                   
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Purpose:  OUTZ writes the Pk matrix to a file.  If range grid         
C           coordinates are not input, then they are computed           
C           assuming symmetry about the deflection(Y) axis.             
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C                                                                       
C BOX(I,J)          sq ft   I = 1,NDG/2; J = 1,NRG                      
C                           Lethal area of a cell or portion of a cell. 
C                                                                       
C C2               ft/sec   Warhead terminal velocity.                  
C                                                                       
C C3               ft/sec   Constant cutoff velocity.                   
C                                                                       
C CENT               ft     Single point target height representing cent
C                           vulnerability to fragments.                 
C                                                                       
C COOPTN             --     Cutoff velocity option chosen. May be INTRVC
C                           CONCV or READVC.                            
C                                                                       
C DAR(I)             ft     I = 1,NDG/2.                                
C                           Deflection grid coordinate.                 
C                                                                       
C DRAG               --     Code for drag data.  Values may be 1,2,3,4, 
C                           or 5.  See Weapons Characteristics Manual.  
C                                                                       
C DRAGTYP            --     Drag name. Existing names are  ADRAG, CDRAG,
C                           JDRAG, RDRAG OR TDRAG.                      
C                                                                       
C GDMX(I)            ft     I= 1,NRG + 1.                               
C                           Adjusted range grid coordinates.            
C                                                                       
C GDMY(I)            ft     I = 1, NDG + 1.                             
C                           Negative and positive deflection grid coordi
C                                                                       
C INDC               --     Indicator:                                  
C                             1 = single point target.                  
C                             0 = NOT single point target.              
C                                                                       
C INTRVC             --     Intrvc code.                                
C                                                                       
C NAME               --     Title for each case.                        
C                                                                       
C NDG                --     Total number of matrix cells in deflection. 
C                                                                       
C NRAD               --     Indicates the option selected in option     
C                           MATRIX :                                    
C                           1 - Read in cell dimensions and center of   
C                               matrix.                                 
C                           2 - Compute cell dimensions and center of   
C                               matrix, given the number of cells.      
C                           3 - Compute the number of cells necessary   
C                               to cover the effective area of the      
C                               weapon, given the cell dimensions.      
C                           4 - Read in the coordinates of the cells.   
C                                                                       
C NRG                --     Total number of matrix cells in range.      
C                                                                       
C PBH                ft     Probable burst height.                      
C                                                                       
C PGD(I)             --     I = 1,NDG.                                  
C                           Used to store one row of the Pk matrix.     
C                                                                       
C Q6                 deg    Impact angle.                               
C                                                                       
C QAV                ft     Height of target centroid for blast.        
C                                                                       
C RA                 ft     Matrix cell size in range for NRAD=1; Number
C                           of cells in range for NRAD=2.               
C                                                                       
C RAR(I)             ft     I=1,NRG/2 + 1.                              
C                           Range grid coordinate.                      
C                                                                       
C RB1                ft     The maximum distance between burst point and
C                           target where Pk = 1.0 for blast.            
C                                                                       
C RB2                ft     Distance between burst point and target wher
C                           Pk becomes 0.0.                             
C                                                                       
C RCAS               --     Target code.                                
C                                                                       
C ZDATAID            --     Data identifier for weapon fragmentation dat
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      CHARACTER*6 COOPTN,DRAGTYP                                        
      CHARACTER*5 RCAS,INTRVC                                           
C                                                                       
      DIMENSION GDMX(41),GDMY(81),PGD(80)                               
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      COMMON  / OUT1 /  PBH,RCAS,DRAG,INTRVC,ZDATAID                    
      COMMON  / OUT2 /  DRAGTYP,COOPTN                                  
                                                                        
      OPEN(UNIT=22,FILE='LAM.DAT',FORM='FORMATTED',STATUS='unknown',    
     &     CARRIAGECONTROL='LIST')                                      
      OPEN(UNIT=88,FILE='LAM2.DAT',FORM='FORMATTED',STATUS='unknown',   
     &     CARRIAGECONTROL='LIST')                                      
                                                                        
C  Write input variables to LAM.DAT.                                    
      WRITE(88,5021)'PBH',PBH,'OMEGA',Q6,'VELM',C2, 'ZDATA',
     & ZDATAID, 'RCAS', RCAS
                                                                        
      WRITE(22,5020)'PBH   ',PBH,NDG,NRG                                
      WRITE(22,5020)'OMEGA ',Q6                                         
      WRITE(22,5020)'VELM  ',C2                                         
      WRITE(22,5030)'ZDATA ',ZDATAID                                    
      WRITE(22,5030)DRAGTYP,DRAG                                        
      IF (COOPTN .EQ. 'CONCV ') THEN                                    
         WRITE(22,5080)'RCAS  ',RCAS,COOPTN,C3                          
      ELSEIF (COOPTN .EQ. 'INTRVC') THEN                                
         WRITE(22,5090)'RCAS  ',RCAS,COOPTN,INTRVC                      
      ELSE                                                              
         WRITE(22,5080)'RCAS  ',RCAS,COOPTN                             
      ENDIF                                                             
      WRITE(22,5050)INDC,NRAD                                           
      WRITE(22,5040)RB1,RB2,CENT,QAV                                    
      WRITE(22,5060)NAME                                                
                                                                        
      IF (NRAD .LT. 4) THEN                                             
                                                                        
C Calculate the range grid coordinates. Print the negative of the center
C range grid coordinate and the range grid coordinates .                
                                                                        
         GDMX(1) =  - RA * NRG / 2                                      
         DO 10 I=2,NRG + 1                                              
            GDMX(I) = GDMX(I - 1) + RA                                  
 10      CONTINUE                                                       
         WRITE(22,5010) - RAR(NRG / 2 + 1)                              
         WRITE(22,5000)(GDMX(I),I=1,NRG + 1)                            
         WRITE(88,5001)((GDMX(I)+GDMX(NRG+1)),I=1,NRG+1)
      ELSE                                                              
                                                                        
C NRAD equal 4. Range grids in input stream.                            
                                                                        
         WRITE(22,5010) - RAR(NRG / 2 + 1)                              
         WRITE(22,5000)(RAR(I),I=1,NRG + 1)                             
         WRITE(88,5001)((RAR(I)+RAR(NRG+1)),I=1,NRG+1)
      ENDIF                                                             
                                                                        
C Assign the deflection grid coordinates. Print all deflection coordinat
                                                                        
      DO 20 J=1,NDG / 2                                                 
         GDMY(J) =  - DAR(NDG / 2 + 2 - J)                              
         GDMY(NDG / 2 + J) = DAR(J)                                     
 20   CONTINUE                                                          
                                                                        
      GDMY(NDG + 1) = DAR(NDG / 2 + 1)                                  
      WRITE(22,5000)(GDMY(I),I=1,NDG + 1)                               
                                                                        
C Store Pk per cell in the PGD array and print half of the array.       
                                                                        
      DO 40 IX=1,NRG                                                    
         DO 30 I=1,NDG / 2                                              
            PGD(I) = BOX(NDG / 2 + 1 - I,IX)                            
            PGD(NDG / 2 + I) = BOX(I,IX)                                
 30      CONTINUE                                                       
                                                                        
         WRITE(22,5070)(PGD(I),I=NDG / 2 + 1,NDG)                       
         WRITE(88,5071)
     +          GDMY(NRG/2+IX),(PGD(II),II=NDG / 2 + 1,NDG)             
 40   CONTINUE                                                          
      RETURN                                                            
                                                                        
 5000 FORMAT (10F7.1)                                                   
 5001 FORMAT (81(F8.1,1X))                                              
 5010 FORMAT (4F10.1)                                                   
 5020 FORMAT (A6,4X,F10.3,2I3)                                          
 5021 FORMAT (A8,1X,F8.3,1X,A8,1X,F8.3,1X,A8,1X,F8.3,1X,A8,1X,F8.3,1X,
     &          A8,1X,A8)
 5030 FORMAT (A6,4X,F10.3,I1,I3)                                        
 5040 FORMAT (7F10.4)                                                   
 5050 FORMAT (6X,I1,1X,I1)                                              
 5060 FORMAT (A72)                                                      
 5070 FORMAT (10F8.6)                                                   
 5071 FORMAT (F8.1,1X,40(F8.6,1X))                                      
 5080 FORMAT (A6,9X,A5,T25,A6,5X,F10.3)                                 
 5090 FORMAT (A6,9X,A5,T25,A6,10X,A5)                                   
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE PARBUR(JIX,T6,TARH,IBUR,GMID,S2X)                      
C                                                                       
C---------------------------------------------------------------------- 
C This subroutine determines if the fragmentation zone intersecting     
C the target is buried. It computes the point on the weapon where       
C the projection of the zone boundary intersects the ground range at    
C the zone angle. This point is the zone origination point. If the      
C upper zone origination point is buried and the lower zone             
C origination point is unburied, then a binary search is entered to     
C determine the zone angle at which the weapon becomes unburied.        
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C                                                                       
C CGGU               --     Cosine of the angle between the upper       
C                           and lower zone angles that is being         
C                           tested for burial.                          
C                                                                       
C CGL                ft     Projection of the ground distance onto      
C                           the range axis.                             
C                                                                       
C CGU                --     Cosine of the upper zone boundary angle.    
C                                                                       
C CPHI1              --     Cosine of the angle measured from the       
C                           weapon centerline to the upper zone         
C                           origination point.                          
C                                                                       
C CPHI2              --     Cosine of the angle measured from the       
C                           weapon centerline to the lower zone         
C                           origination point.                          
C                                                                       
C CPIH               --     Cosine of the angle between the weapon      
C                           centerline and the zone origination         
C                           point of the angle between the upper and    
C                           lower zone boundary angles that is          
C                           currently being tested for burial.          
C                                                                       
C CWR                --     Cosine of the impact angle.                 
C                                                                       
C DELH               --     Perpendicular distance from the weapon      
C                           trajectory to the target centroid.          
C                                                                       
C DGAMT             deg     Angle increment in partial burial binary    
C                           search.                                     
C                                                                       
C DH                 ft     Difference between the target height and    
C                           burst height.                               
C                                                                       
C DX                 ft     Distance from the ground to the zone        
C                           origination point.                          
C                                                                       
C FLP1               ft     Distance from the centroid of the weapon    
C                           to the interpolated location on the         
C                           weapon of the zone lower angle departure    
C                           point.                                      
C                                                                       
C FLP2               ft     Distance from the centroid of the weapon    
C                           to the interpolated location on the         
C                           weapon of the zone upper angle departure    
C                           point.                                      
C                                                                       
C G1(K)             deg     J = 1,50                                    
C                           Smallest vectored static angle for the      
C                           Kth zone.                                   
C                                                                       
C G2(K)             deg     J = 1,50                                    
C                           Largest vectored static angle for the       
C                           Kth zone.                                   
C                                                                       
C G2JX              deg     Fragment departure angle measured from      
C                           the weapon centroid to the target           
C                           centroid.                                   
C                                                                       
C G3                deg     Adjusted zone angle for binary search.      
C                                                                       
C GAMT              deg     Angle between the upper and lower zone      
C                           angles that is being tested for burial.     
C                                                                       
C GMID              deg     Angle returned to CALC for partial          
C                           burial.                                     
C                                                                       
C GMLO              deg     Lower zone angle.                           
C                                                                       
C GMUP              deg     Upper zone angle.                           
C                                                                       
C HFL                ft     Location on the weapon where the            
C                           projection of the lower dynamic zone        
C                           boundary intersects the S1 arc. Called      
C                           the lower zone origination point.           
C                                                                       
C HFU                ft     Location on the weapon where the            
C                           projection of the upper dynamic zone        
C                           boundary intersects the S1 arc. Called      
C                           the upper zone origination point.           
C                                                                       
C HFX                ft     Zone origination point of the binary        
C                           search angle being tested for partial       
C                           burial.                                     
C                                                                       
C IBUR               --     Indicator:                                  
C                             0 - Entire zone is above ground           
C                                 level. Not buried.                    
C                             1 - Part of zone is buried.               
C                             2 - Entire zone is below ground           
C                                 level. Total burial.                  
C                                                                       
C IXX                --     Binary search counter.                      
C                                                                       
C JIX                --     Index for zone angle arrays.                
C                                                                       
C PL                 ft     Interpolated distance from nose of          
C                           weapon for fragment departure for angle     
C                           S2X.                                        
C                                                                       
C PLT1(K)            ft     K=1,50                                      
C                           Distance from centroid of weapon for        
C                           lower boundary of Kth dynamic zone.         
C                                                                       
C PLT2(K)            ft     K=1,50                                      
C                           Distance from centroid of weapon for        
C                           upper boundary of Kth dynamic zone.         
C                                                                       
C PR                 ft     Interpolated weapon casing radius for       
C                           angle S2X.                                  
C                                                                       
C PRL1               ft     Weapon casing radius at the lower           
C                           boundary of the current dynamic zone.       
C                                                                       
C PRL2               ft     Weapon casing radius at the upper           
C                           boundary of the current dynamic zone.       
C                                                                       
C Q43                ft     Burst height of the munition.               
C                                                                       
C Q6                deg     Weapon impact angle measured from the       
C                           horizontal.                                 
C                                                                       
C RF1(K)             ft     K=1,50                                      
C                           Weapon casing radius at the lower           
C                           boundary of the Kth dynamic zone.           
C                                                                       
C RF2(K)             ft     K=1,50                                      
C                           Weapon casing radius at the lower           
C                           boundary of the Kth dynamic zone.           
C                                                                       
C S1                 ft     Ground range. Distance from target to       
C                           weapon in the ground plane.                 
C                                                                       
C S1S                ft     Ground range squared.                       
C                                                                       
C S1SG               ft     Good Question!                              
C                                                                       
C S2X               deg     Fragment departure angle. Angle between     
C                           the weapon centerline and the fragment      
C                           path.                                       
C                                                                       
C SGAM               --     Sine of the angle being tested for          
C                           burial in the binary search. Angle where    
C                           the zone unburies.                          
C                                                                       
C SGL                --     Sine of the lower zone boundary angle.      
C                                                                       
C SGU                --     Sine of the upper zone boundary angle.      
C                                                                       
C SWR                --     Sine of the impact angle.                   
C                                                                       
C T6                 ft     Slant range to target measured from the     
C                           burst point to the Ith target centroid.     
C                                                                       
C TARH               ft     Target height.                              
C                                                                       
C TH                 ft     Height of weapon trajectory at target for   
C                           the current ground range.                   
C                                                                       
C TP1                                                                   
C TP1X                                                                  
C TPDX                                                                  
C TPH1                                                                  
C TPH2                                                                  
C                                                                       
C TXX                ft     Distance from weapon centroid that the      
C                           fragment zone originates from.              
C-----------------------------------------------------------------------
C                                                                       
C Functions and Subroutines called                                      
C   BINT                                                                
C-----------------------------------------------------------------------
C Calling Routine                                                       
C   SEKS                                                                
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
                                                                        
      COMMON / ABUR / GMUP,GMLO,RF1(50),RF2(50),PLT1(50),PLT2(50)       
      COMMON / ARTXX / ABOX(40,40),RDR                                  
      COMMON / COSINE / CWR,SWR                                         
      COMMON / CUTVEL / IVCT,VELCUT                                     
                                                                        
C G1 is lower zone angle, G2 is upper zone angle. In ground plane.      
                                                                        
      G1J = G1(JIX)                                                     
      G2J = G2(JIX)                                                     
                                                                        
C Angles, in the ground plane, where S1 intersects the upper and        
C lower zone boundries, converted to radians.                           
                                                                        
      GMR1 = GMUP * DEG2RAD                                             
      GMR2 = GMLO * DEG2RAD                                             
                                                                        
      SGU = SIN(GMR1)                                                   
      CGU = COS(GMR1) * S1                                              
      SGL = SIN(GMR2)                                                   
      CGL = COS(GMR2) * S1                                              
                                                                        
C DH is difference between burst height and target height. Measured     
C below burst height.                                                   
                                                                        
      DH = Q43 - TARH                                                   
                                                                        
C DELH is perpendicular distance from weapon traj to target location.   
                                                                        
      DELH =  - DH * CWR                                                
                                                                        
C JIX is the current dynamic zone.                                      
C PRL1 is weapon casing radius at lower boundary of current dynamic     
C zone.                                                                 
C PRL2 is weapon casing radius at upper boundary of current dynamic     
C zone.                                                                 
                                                                        
      PRL1 = RF1(JIX)                                                   
      PRL2 = RF2(JIX)                                                   
                                                                        
C FLP1 is distance from centroid of weapon for lower boundary of        
C current dynamic zone.                                                 
C FLP2 is distance from centroid of weapon for upper boundary of        
C current dynamic zone.                                                 
                                                                        
      FLP1 = PLT1(JIX)                                                  
      FLP2 = PLT2(JIX)                                                  
                                                                        
C Impact angle = 90.                                                    
                                                                        
      IF (Q6 .EQ. 90.0) THEN                                            
                                                                        
C S2XX is angle between the weapon traj and the fragment departure      
C angle measured thru the weapon centerline.                            
                                                                        
         S2XX = S2X * DEG2RAD                                           
                                                                        
C PR is the interpolated weapon casing radius for angle S2X.            
C PL is interpolated distance from nose of weapon for fragment          
C departure for angle S2X                                               
                                                                        
         PR = BINT(G1J,G2J,PRL1,PRL2,S2X)                               
         PL = BINT(G1J,G2J,FLP1,FLP2,S2X)                               
                                                                        
C TXX is distance from weapon centroid that the fragment zone           
C originates from.                                                      
                                                                        
         TXX = PR / TAN(S2XX)                                           
         IBUR = 0                                                       
                                                                        
C If entire zone is buried, then set IBUR to 2.                         
                                                                        
         IF (Q43 - TXX - PL .LT. 0.0) IBUR = 2                          
         RETURN                                                         
      ELSE                                                              
         S1SG = S1 * SWR                                                
                                                                        
C Upper angle of ground arc.                                            
                                                                        
         IF (GMUP .NE. 90.0) THEN                                       
            TP1 = S1SG * SGU + DELH                                     
            TPH1 = TP1 * TP1 + CGU * CGU                                
            CPHI1 = TP1 / SQRT(TPH1)                                    
         ELSE                                                           
            FLP1X = FLP1                                                
            FLP1 = BINT(G1J,G2J,FLP1,FLP2,S2X)                          
            PRL1 = BINT(FLP1X,FLP2,PRL1,PRL2,FLP1)                      
            G1J = S2X                                                   
            CPHI1 = 1.0                                                 
                                                                        
C TH = Height of weapon trajectory at target for this ground range.     
                                                                        
            TH = Q43 - S1 * SWR / CWR                                   
            IF (TH .GT. TARH) CPHI1 =  - 1.0                            
         ENDIF                                                          
                                                                        
C Lower angle of ground arc.                                            
                                                                        
         IF (GMLO .NE.  - 90.0) THEN                                    
            TP1 = S1SG * SGL + DELH                                     
            TPH2 = TP1 * TP1 + CGL * CGL                                
            CPHI2 = TP1 / SQRT(TPH2)                                    
         ELSE                                                           
                                                                        
C Last angle in arc.                                                    
                                                                        
            IF (DH .NE. 0.0) THEN                                       
               G2JX = ATAN(S1 / DH) / DEG2RAD + 90.0 - Q6               
               IF (G2JX .LT. 0.0) G2JX = G2JX + 180.0                   
            ELSE                                                        
               G2JX = 180.0 - Q6                                        
            ENDIF                                                       
                                                                        
            FLP2X = FLP2                                                
            FLP2 = BINT(G1J,G2J,FLP1,FLP2,G2JX)                         
            PRL1 = BINT(FLP1,FLP2X,PRL1,PRL2,FLP2)                      
            G2J = G2JX                                                  
            CPHI2 = 1.0                                                 
            TH = Q43 + S1 * SWR / CWR                                   
            IF (TARH .LE. TH) CPHI2 =  - 1.0                            
         ENDIF                                                          
                                                                        
C HFL is the location on the weapon where the projection of the         
C lower dynamic zone boundary intersects the S1 arc. Called the         
C lower zone origination point.                                         
C HFU is the location on the weapon where the projection of the         
C upper dynamic zone boundary intersects the S1 arc. Called the         
C upper zone origination point.                                         
                                                                        
         HFL = PRL1 * CPHI1 * CWR - FLP1 * SWR                          
         HFU = PRL2 * CPHI2 * CWR - FLP2 * SWR                          
                                                                        
C Initialize the burial indicator.                                      
                                                                        
         IBUR = 0                                                       
                                                                        
C DX is the zone origination points adjusted for burst height. If DX    
C is less than zero, then the zone origination point is below           
C ground. Increment IBUR if the point is below ground.                  
                                                                        
         DX = Q43 + HFL                                                 
                                                                        
C Test for lower zone origination point below ground.                   
                                                                        
         IF (DX .LE. 0.0) IBUR = IBUR + 1                               
         DX = Q43 + HFU                                                 
                                                                        
C Test for upper zone origination point below ground.                   
                                                                        
         IF (DX .LE. 0.0) IBUR = IBUR + 1                               
                                                                        
C The zone is either completely unburied or completely buried.          
                                                                        
         IF ((IBUR .EQ. 0) .OR. (IBUR .EQ. 2)) RETURN                   
                                                                        
C Partial zone burial. This section uses a binary search to locate      
C where in a zone the weapon becomes unburied (visible to the           
C target).  It divides the zone in half and checks to see if the        
C midpoint angle is buried.  If the midpoint angle is within .001       
C of a boundary angle, then return either buried or unburied. If        
C the zone origination point of the midpoint angle is within .0001      
C of the ground, then return the  angle as the angle where the zone     
C unburies. If none of the exiting conditions are met, then adjust      
C the midpoint zone angle and test again.                               
                                                                        
C Initialize counter, compute angle increment, and add to lower zone    
C boundary angle.                                                       
                                                                        
         IXX = 0                                                        
         DGAMT = (G2J - G1J) / 2.0                                      
         G3 = G1J + DGAMT                                               
                                                                        
C Start of loop. Convert new lower zone angle to radians.               
                                                                        
 10      G3R = G3 * DEG2RAD                                             
         SGAM = (T6 * COS(G3R) - DH * SWR) / (S1 * CWR)                 
         IF (ABS(SGAM) .GT. 1.0) WRITE(6,5000)T6,G3,DH,S1,SGAM          
                                                                        
C Cos(gamma) = SQRT ( 1 - sin(gamma) * sin(gamma))                      
         CGGU = SQRT(1.0 - SGAM * SGAM)                                 
                                                                        
C Compute angle gamma from cos(gamma)                                   
         GAMT = ACOS(CGGU) / DEG2RAD                                    
                                                                        
C Adjust gamma if sin(gamma) is negative. Moves gamma into quadrant     
C 1 or 2.                                                               
         IF (SGAM .LT. 0.0) GAMT =  - GAMT                              
                                                                        
C Compute weapon radius and distance from center of gravity at          
C current gamma.                                                        
                                                                        
         PL = BINT(G1J,G2J,FLP1,FLP2,G3)                                
         PR = BINT(FLP1,FLP2,PRL1,PRL2,PL)                              
                                                                        
C Compute angle from the vertical line through the weapon centerline    
C and the weapon centerline and the lower zone origination point.       
                                                                        
         TP1X = S1SG * SGAM + DELH                                      
         TPDX = TP1X * TP1X + CGGU * CGGU * S1S                         
         CPIH = TP1X / SQRT(TPDX)                                       
                                                                        
C Compute lower zone origination point. Add burst height to find        
C distance the point is from the ground.                                
                                                                        
         HFX = PR * CPIH * CWR - PL * SWR                               
         HFX = Q43 + HFX                                                
                                                                        
         IF (ABS(HFX) .LT. 0.0001) THEN                                 
                                                                        
C Weapon distance from the ground to the zone origination point. If     
C within .0001 of the ground, then return gamma as the angle            
C where the zone unburies.                                              
                                                                        
            GMID = GAMT                                                 
            RETURN                                                      
         ENDIF                                                          
                                                                        
         IF (ABS(G2J - G3) .LT. 0.001) THEN                             
                                                                        
C Midpoint angle close to upper zone angle. Zone completely buried.     
                                                                        
            IBUR = 2                                                    
            RETURN                                                      
         ENDIF                                                          
                                                                        
         IF (ABS(G1J - G3) .LT. 0.001) THEN                             
                                                                        
C Midpoint angle close to lower zone angle. Zone completely unburied.   
                                                                        
            IBUR = 0                                                    
            RETURN                                                      
         ENDIF                                                          
                                                                        
         IF (IXX .GT. 15) THEN                                          
                                                                        
C No more than 15 iterations.                                           
                                                                        
            GMID = GAMT                                                 
            RETURN                                                      
         ENDIF                                                          
                                                                        
C Adjust midpoint angle and try again.                                  
                                                                        
         DGAMT = DGAMT / 2.                                             
         IXX = IXX + 1                                                  
         IF (HFX .GE. 0.0) THEN                                         
                                                                        
C Zone origination point above ground.                                  
                                                                        
            G3 = G3 - DGAMT                                             
         ELSE                                                           
                                                                        
C Zone origination point below ground.                                  
                                                                        
            G3 = G3 + DGAMT                                             
         ENDIF                                                          
         GOTO 10                                                        
      ENDIF                                                             
                                                                        
 5000 FORMAT (1X,'TINE PARBUR',5E15.5)                                  
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE PRINT                                                  
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Subroutine writes the input onto an output file and a temporary    
C input file.                                                           
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C ARF(I)             --     Array used to read the input record.        
C                                                                       
C IPAGE              --     Page number.                                
C                                                                       
C NGX                --     Line counter.                               
C                                                                       
C NGZ                --     Number of lines per page (Max. 60).         
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      CHARACTER*4 ARF(20)                                               
                                                                        
C Open the file which contains the input.                               
                                                                        
      OPEN(UNIT=5,FILE='IP.DAT',FORM='FORMATTED',STATUS='OLD')          
                                                                        
C Open the temporary input file (unit 9) and the output file (unit=6).  
                                                                        
      OPEN(UNIT=9,FORM='FORMATTED',STATUS='SCRATCH')  
      OPEN(UNIT=6,FILE='OUT.DAT',FORM='FORMATTED',STATUS='unknown')     
                                                                        
C Initialize variables.                                                 
                                                                        
      NGZ = 60                                                          
      NGX = 1                                                           
      IPAGE = 1                                                         
                                                                        
C Start a new page for the output and print a header.                   
                                                                        
 10   WRITE(6,5030)IPAGE                                                
                                                                        
C Read the input file and rewrite it.                                   
                                                                        
 20   READ(5,5000)(ARF(I),I=1,20)                                       
      WRITE(9,5000)(ARF(I),I=1,20)                                      
      WRITE(6,5020)(ARF(I),I=1,20)                                      
                                                                        
      NGX = NGX + 1                                                     
                                                                        
C If the record read is not the last record of the input, then...       
C If the record read is the last record, then exit routine.             
                                                                        
      IF (ARF(1) .NE. 'RATS') THEN                                      
                                                                        
C Check to see if a new page needs to be printed.                       
                                                                        
         IF (NGX .LT. NGZ) GOTO 20                                      
                                                                        
C If the output page is full, increase the line counter and increment   
C the page counter.                                                     
                                                                        
         NGZ = NGZ + 60                                                 
         IPAGE = IPAGE + 1                                              
         GOTO 10                                                        
      ENDIF                                                             
                                                                        
C Rewind Unit 9 so that subroutine BEGIN can access it.                 
                                                                        
      REWIND(9)                                                         
                                                                        
      CLOSE(5)                                                          
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (20A4)                                                     
 5020 FORMAT (15X,20A4)                                                 
 5030 FORMAT ('1',119X,'PAGE',I4,//)                                    
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE RESULT(IX,RTEMP,CMQQ,VOQ,VTQ)                          
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Compute the distance a fragment of a given weight moving at an     
C initial velocity would travel before reaching a cutoff velocity.      
C If the fragment hits the target, compute the impact velocity.         
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C ALH(IX,J)          --     Slope of drag curve for the jth velocity    
C                           and top layer of medium (usually air).      
C                                                                       
C BTA(IX,J)          --     Y Intercept of drag curve for jth velocity  
C                           and top layer of medium (usually air).      
C                                                                       
C CGAM               --     Factor used in the computation of distance  
C                           function.                                   
C                                                                       
C CMQQ              grains  Fragment weight.                            
C                                                                       
C CNDC              --      Drag Factor used in the computation of      
C                           distance function.                          
C                                                                       
C DXI               ft      Distance a fragment travels as its velocity 
C                           decays from an initial velocity, VOQ, to the
C                           largest velocity in the drag table which is 
C                           less than or equal to the initial velocity. 
C                                                                       
C DXT               ft      Distance a fragment travels as its velocity 
C                           decays from the smallest velocity in the    
C                           drag table which is greater than or equal   
C                           to the cutoff velocity, VTQ, to the actual  
C                           fragment cutoff velocity.                   
C                                                                       
C DXX               ft      Distance a fragment travels within a        
C                           portion of a layer of the medium.           
C                                                                       
C EX2               --      Exponential factor used in the calculation  
C                           of fragment velocity.                       
C                                                                       
C IIV               --      Subscript denoting the largest velocity in  
C                           the drag table which is less than or equal  
C                           to the initial fragment velocity.           
C                                                                       
C IVCT               --     Indicator:                                  
C                             1 -  Continue computations.               
C                             2 -  Velocity of fragment is slower than  
C                                  cutoff velocity.  End computation.   
C                                                                       
C IX                --      Number of altitudes in drag table.          
C                                                                       
C NCDP              --      Number of velocities in drag table.         
C                                                                       
C RHO(IX)          lb/ft3   Density of media for the IXth layer.        
C                                                                       
C RTEMP             ft      Slant Range from weapon to target or range  
C                           through the layers of media.                
C                                                                       
C SDX               ft      Total distance fragment travels to cutoff   
C                           velocity or strikes target.                 
C                                                                       
C SKT(IX)           --      Shape factor of fragment.                   
C                                                                       
C TEX               ft      Distance a fragment travels through one     
C                           velocity interval and part of another.      
C                           Factor used to compute the exiting velocity 
C                           of the fragment from the layer, VTQ.        
C                                                                       
C ULN(IX,ID)        --      Factor used in computation of distance      
C                           traveled through a velocity interval.       
C                                                                       
C VCF(I)           ft/sec   Ith Velocity in drag table.                 
C                                                                       
C VELCUT           ft/sec   Fragment cutoff velocity.                   
C                                                                       
C VHI              ft/sec   Velocity used as the upper limit in the     
C                           distance function FDIST.                    
C                                                                       
C VLO              ft/sec   Velocity used as the lower limit in the     
C                           distance function FDIST.                    
C                                                                       
C VOQ              ft/sec   Average initial velocity of the fragment.   
C                                                                       
C VTQ              ft/sec   Final velocity of fragment after passing    
C                           through the medium or strikes the target.   
C                                                                       
C XINT              ft      Distance a fragment travels over a given    
C                           velocity interval.                          
C                                                                       
C XTQ               ft      Entire distance the fragment traveled from  
C                           VOQ to VTQ.                                 
C                                                                       
C-----------------------------------------------------------------------
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C DRRR                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      COMMON  / CUTVEL /  IVCT,VELCUT                                   
                                                                        
C Function used to calculate the distance a fragment travels as its     
C velocity decays from VHI and VLO.                                     
                                                                        
      FDIST(IIV,VHI,VLO) = (1.0 / (BTA(IX,IIV) * CNDC)) * LOG((VHI *    
     &                     (ALH(IX,IIV) * VLO + BTA(IX,IIV))) / (VLO *  
     &                     (ALH(IX,IIV) * VHI + BTA(IX,IIV))))          
                                                                        
C Compute a drag factor used in the computation of distance function.   
                                                                        
      CNDC = RHO(IX) * SKT(IX) * CMQQ *  * ( - 1.0 / 3.0)               
                                                                        
C If the initial fragment velocity, VOQ, is less than the first         
C velocity in the drag table, then print an error and exit program.     
                                                                        
      IF (VOQ .LT. VCF(1)) THEN                                         
         WRITE(6,5010)                                                  
         WRITE(6,5000)IX,RTEMP,CMQQ,VOQ,S1                              
         CALL EXIT                                                      
      ENDIF                                                             
                                                                        
C Loop through the drag table until an interval is found that contains  
C the fragment initial velocity.  Use interval to calculate DXI.        
                                                                        
      DO 10 I=2,NCDP                                                    
                                                                        
C If the initial velocity is equal to a velocity in the drag table, the 
C distance, DXI, the fragment travels from the drag table velocity to   
C the initial velocity is zero.                                         
                                                                        
         IF (VOQ .EQ. VCF(I)) THEN                                      
            IIV = I                                                     
            DXI = 0.0                                                   
            GOTO 30                                                     
                                                                        
C If the initial velocity is greater than a velocity in the drag table, 
C then use the first velocity in the drag table that is less than the   
C initial velocity (label 20) to calculate the distance the fragment    
C travels as its velocity decays from its initial velocity to the drag  
C table velocity.                                                       
                                                                        
         ELSEIF (VCF(I) .GT. VOQ) THEN                                  
            GOTO 20                                                     
         ENDIF                                                          
 10   CONTINUE                                                          
                                                                        
C Increment I so that the last velocity will be selected.               
                                                                        
      I = NCDP + 1                                                      
                                                                        
 20   IIV = I - 1                                                       
                                                                        
C If the cutoff velocity is greater than or equal to the lower velocity 
C found for this interval, calculate the distance the fragment travels  
C until it reaches the cutoff velocity.                                 
                                                                        
      IF (VELCUT .GE. VCF(IIV)) THEN                                    
         DXT = FDIST(IIV,VOQ,VELCUT)                                    
                                                                        
C If the slant range of the fragment is greater than or equal to the    
C distance the fragment travels until reaching the cutoff velocity,     
C then set the fragment terminal velocity to the cutoff velocity and    
C turn on the indicator.                                                
                                                                        
         IF (RTEMP .GE. DXT) THEN                                       
            VTQ = VELCUT                                                
            IVCT = 2                                                    
                                                                        
         ELSE                                                           
                                                                        
C Calculate the striking velocity of the fragment.                      
                                                                        
            EX2 = EXP( - RTEMP / (1.0 / (BTA(IX,IIV) * CNDC)))          
            VTQ = (BTA(IX,IIV) * VOQ * EX2) / (ALH(IX,IIV) * VOQ * (1.0 
     &            - EX2) + BTA(IX,IIV))                                 
         ENDIF                                                          
                                                                        
C If the cutoff velocity is less than a velocity in the table then      
C determine the interval containing the cutoff velocity.                
                                                                        
      ELSE                                                              
                                                                        
C If the cutoff velocity is less than the first velocity in the         
C table, calculate the velocity of the fragment when it leaves          
C the initial medium layer.                                             
                                                                        
         IF (IIV .EQ. 1) THEN                                           
            EX2 = EXP( - RTEMP / (1.0 / (BTA(IX,IIV) * CNDC)))          
            VTQ = (BTA(IX,IIV) * VOQ * EX2) / (ALH(IX,IIV) * VOQ * (1.0 
     &            - EX2) + BTA(IX,IIV))                                 
                                                                        
C If the cutoff velocity is between two velocities in the table,        
C calculate the distance between the initial fragment velocity          
C and the closest velocity from the table.                              
                                                                        
         ELSE                                                           
            DXI = FDIST(IIV,VOQ,VCF(IIV))                               
                                                                        
C If the slant range of the fragment is less than the distance          
C the fragment travels from the initial velocity to the selected        
C table velocity, calculate the velocity the fragment exits             
C the medium.                                                           
                                                                        
 30         IF (RTEMP .LT. DXI) THEN                                    
               EX2 = EXP( - RTEMP / (1.0 / (BTA(IX,IIV) * CNDC)))       
               VTQ = (BTA(IX,IIV) * VOQ * EX2) / (ALH(IX,IIV) * VOQ *   
     &               (1.0 - EX2) + BTA(IX,IIV))                         
                                                                        
C If the slant range equals the distance the fragment travels from its  
C initial velocity, set the final fragment velocity equal to the        
C selected table velocity.                                              
                                                                        
            ELSEIF (RTEMP .EQ. DXI) THEN                                
               VTQ = VCF(IIV)                                           
                                                                        
C The slant range is greater than the distance the fragment has         
C traveled so store the distance computed and begin calculations        
C for next velocity interval.                                           
                                                                        
            ELSE                                                        
               SDX = DXI                                                
 40            IIV = IIV - 1                                            
                                                                        
C If the cutoff velocity is greater than the next velocity in the       
C interval then calculate the distance the fragment will travel         
C from the lower velocity to the cutoff velocity.                       
                                                                        
               IF (VELCUT .GE. VCF(IIV)) THEN                           
                  DXT = FDIST(IIV,VCF(IIV + 1),VELCUT)                  
                                                                        
C If the slant range of the fragment is larger than the total distance  
C calculated that the fragment has traveled through the layer, set      
C the final velocity equal to the cutoff velocity and set the           
C indicator.                                                            
                                                                        
                  IF (RTEMP .GT. SDX + DXT) THEN                        
                     VTQ = VELCUT                                       
                     IVCT = 2                                           
                                                                        
C Total computed distance fragment travels exceeds the slant range      
C of the fragment so recompute distance (RT) and determine final        
C velocity.                                                             
                                                                        
                  ELSE                                                  
                     RT = RTEMP - SDX                                   
                     EX2 = EXP( - RT / (1.0 / (BTA(IX,IIV) * CNDC)))    
                     VTQ = (BTA(IX,IIV) * VCF(IIV + 1) * EX2) / (ALH(IX,
     &                     IIV) * VCF(IIV + 1) * (1.0 - EX2) + BTA(IX,  
     &                     IIV))                                        
                  ENDIF                                                 
                                                                        
C If the cutoff velocity is less than the next velocity in the table,   
C then...                                                               
                                                                        
               ELSE                                                     
                                                                        
C If it was the last velocity in the table then set the terminal        
C velocity equal to 1.                                                  
                                                                        
                  IF (IIV .LE. 0) THEN                                  
                     VTQ = 1.                                           
                                                                        
C If not the last table velocity then find the total distance the       
C fragment travels through the next medium.                             
                                                                        
                  ELSE                                                  
                     DXX = ( - 1.0 / (BTA(IX,IIV) * CNDC)) * ULN(IX,    
     &                     IIV)                                         
                     SDX = SDX + DXX                                    
                                                                        
C If the slant range is less than the total accumulated fragment        
C distance, then recompute the distance the fragment traveled           
C and determine the terminal velocity from that distance.               
                                                                        
                     IF (RTEMP .LT. SDX) THEN                           
                        TEX = (SDX - RTEMP - DXX) / ( - 1.0 / (BTA(IX,  
     &                        IIV) * CNDC))                             
                        EX2 = EXP( - 1.0 * TEX)                         
                        VTQ = (BTA(IX,IIV) * VCF(IIV + 1) * EX2) /      
     &                        (ALH(IX,IIV) * VCF(IIV + 1) * (1.0 - EX2) 
     &                        + BTA(IX,IIV))                            
                                                                        
C If the slant range equals the accumulated fragment distance traveled, 
C then set the terminal velocity equal to the tabular velocity.         
                                                                        
                     ELSEIF (RTEMP .EQ. SDX) THEN                       
                        VTQ = VCF(IIV)                                  
                                                                        
C Otherwise increment the distance and check the next interval until    
C the cutoff velocity or slant range of the fragment has been           
C surpassed.                                                            
                                                                        
                     ELSE                                               
                        GOTO 40                                         
                     ENDIF                                              
                  ENDIF                                                 
               ENDIF                                                    
            ENDIF                                                       
         ENDIF                                                          
      ENDIF                                                             
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (1X,I3,4F15.5)                                             
 5010 FORMAT (' %-ERROR- SUBR=RESULT, CUTOFF VELOCITY IS LESS THAN',    
     &        ' FIRST VELOCITY IN DRAG CURVE')                          
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE REVETLOS                                               
C                                                                       
C---------------------------------------------------------------------- 
C Description : This subroutine determines if line of sight exists      
C               between the weapon and target for revetted targets.     
C               Also computed is the cutoff angle if the weapon lands   
C               inside the revetment and a dead zone exists.            
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C ACTR               ft     Distance in the ground plane from the impact
C                           point to a perpendicular line drawn from the
C                           uprange interior top corner of the revetment
C                           to the ground plane.  This distance is used 
C                           to calculate the cutoff angle in subroutine 
C                           MAIN.                                       
C                                                                       
C ATE               deg     Angle between the line containing the       
C                           weapon burst point and top edge of          
C                           revetment wall and the vertical line        
C                           from the burst point to the ground.         
C                                                                       
C ATT               deg     Angle between the line containing the       
C                           weapon burst point and target centroid      
C                           for fragments and the vertical line from    
C                           the burst point to the ground.              
C                                                                       
C COFF              deg     For a particular ground range, COFF is the  
C                           arc angle where the ground range arc        
C                           intersects the dead zone.                   
C                                                                       
C DDOR               ft     Horizontal distance from top edge of the    
C                           revetment nearest the burst point to the    
C                           burst point.                                
C                                                                       
C DEG2RAD            --     Constant. PI/180. Degree to radians         
C                           conversion.                                 
C                                                                       
C DOR                ft     Ground distance from bottom edge of         
C                           revetment wall to burst point of            
C                           weapon. Used when weapon impacts revetment  
C                           wall.                                       
C                                                                       
C DTD                ft     Distance from target to dead zone for       
C                           revetted targets.  DTD is negative if the   
C                           target is included in the dead zone.        
C                                                                       
C DTE                ft     Vertical distance from burst point to top   
C                           of revetment.                               
C                                                                       
C HOT                ft     Vertical distance from the target           
C                           centroid for fragments to the weapon        
C                           burst point.                                
C                                                                       
C HTRAJ              ft     Height of weapon trajectory at target       
C                           location.                                   
C                                                                       
C IRV                --     Indicator :                                 
C                           TRUE  - revetment has a dead zone.          
C                           FALSE - NO dead zone in revetment.          
C                                                                       
C LOS                --     Indicator:                                  
C                           TRUE - Line of sight exists.                
C                           FALSE - No line of sight.                   
C                                                                       
C LOSFRG             --     Indicator for line of sight of fragments:   
C                             0 - line of sight does NOT exist.         
C                             1 - line of sight exists for fragments    
C                                                                       
C PI                 --     Constant.                                   
C                                                                       
C Q41(I)             ft     I=1,NTPX.  Target heights representing      
C                           centers of vulnerability to fragments.      
C                                                                       
C Q43                ft     Weapon burst height.                        
C                                                                       
C Q43R               ft     Same as Q43.  Used to restore Q43 for the   
C                           next interation pass in subroutine MAIN.    
C                                                                       
C RAD2DEG            --     Constant.  180/PI. Radians to degrees       
C                           conversion.                                 
C                                                                       
C RD1                ft     Direct hit radius for direct hit weapons.   
C                           For revetted targets, RD1 is the equivalent 
C                           target size in the ground plane or presented
C                           area at 90 degrees converted to a radius.   
C                                                                       
C RDH                --     Indicator:                                  
C                           TRUE  - Weapon trajectory intersects target.
C                                   Use direct hit calculations.        
C                           FALSE - Weapon trajectory does NOT intersect
C                                   target.                             
C                                                                       
C REVA              deg     Interior angle formed by the wall and base  
C                           of the revetment or mound.                  
C                                                                       
C REVBAS             ft     Width of revetment base or radius of mound  
C                           base.                                       
C                                                                       
C REVDIS             ft     Distance from inside edge of revetment      
C                           bottom to target center.                    
C                                                                       
C REVHT              ft     Height of revetment or mound.               
C                                                                       
C REVSLP             ft     Distance on the ground from the base edge   
C                           to the top edge of the revetment.           
C                                                                       
C REVTOP             ft     Width of revetment top or radius of mound   
C                           top.                                        
C                                                                       
C REVTOT             ft     Distance on the ground from the target to   
C                           the top edge of the revetment.              
C                                                                       
C RTRAJ             deg     Impact angle.                               
C                                                                       
C S1                 ft     Ground range. Distance from target to       
C                           weapon burst point in the plane             
C                           parallel to the ground at the weapon burst  
C                           height.                                     
C                                                                       
C TGTHT              ft     Target height for direct-hit option.        
C                                                                       
C-----------------------------------------------------------------------
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      LOGICAL LOS                                                       
C                                                                       
      INCLUDE 'stdparameter_clean.inc'                                        
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      COMMON  / DIRHIT /  PKH,RD1,TGTHT,Q43R,FRAGOPT                    
      COMMON  / REV /  REVHT,REVSLP,REVTOT,ACTR,DTD,REVBAS,REVDIS,DEAD, 
     &       REVA,COFF,GONG,REVTOP,RTRAJ,LOSFRG,LOSBLT                  
                                                                        
      LOS = .TRUE.                                                      
                                                                        
C If ground range beyond top interior edge of revetment then            
                                                                        
      IF (S1 .GE. REVTOT) THEN                                          
                                                                        
C If ground range beyond top of revetment then                          
                                                                        
         IF (S1 .GT. (REVTOT + REVTOP)) THEN                            
                                                                        
C If ground range beyond entire revetment then                          
                                                                        
            IF (S1 .GT. (REVDIS + REVBAS)) THEN                         
                                                                        
C If burst height above revetment then                                  
                                                                        
               IF (Q43 .GE. REVHT) THEN                                 
                                                                        
C Calculate LOS.                                                        
C If the frag centroid is lower than the burst height then ...          
                                                                        
                  IF (Q41(1) .LT. Q43) THEN                             
                                                                        
C Calculate the vertical distance from the top of the revetment to      
C the burst point, DDOR, and the ground distance from the the burst     
C point to the upper interior edge of the revetment, DTE.               
                                                                        
                     DDOR = S1 - REVTOT                                 
                     DTE = Q43 - REVHT                                  
                                                                        
C If burst height = revetment height then set the angle to 90 deg.      
C Else compute angle.                                                   
                                                                        
                     IF (DTE .NE. 0.) THEN                              
                        ATE = ATAN(DDOR / DTE)                          
                     ELSE                                               
                        ATE = PI / 2.                                   
                     ENDIF                                              
                     ATE = ATE * RAD2DEG                                
                                                                        
C Compute angle between the burst point and the fragment centroid.      
                                                                        
                     HOT = Q43 - Q41(1)                                 
                     ATT = ATAN(S1 / HOT) * RAD2DEG                     
                                                                        
C If the angle for the fragment centroid is less than the angle to      
C the revetment edge, then the revetment is between the weapon and      
C the target and LOS does not exist. Set indicator.                     
                                                                        
                     IF (ATT .LT. ATE) LOS = .FALSE.                    
                  ENDIF                                                 
               ELSE                                                     
                                                                        
C Burst height below top of revetment and ground range beyond           
C revetment. If fragment centroid is above burst height then...         
                                                                        
                  IF (Q41(1) .GT. Q43) THEN                             
                     DDOR = S1 - REVTOT - REVTOP                        
                     DTE = REVHT - Q43                                  
                                                                        
C Compute the angle between the burst point and the outside, upper      
C edge of the revetment. 90 degrees added to measure the angle from     
C the vertical line containing the burst point.                         
                                                                        
                     ATE = ATAN(DTE / DDOR) * RAD2DEG + 90.             
                     HOT = Q41(1) - Q43                                 
                                                                        
C Compute the angle between the burst point and the fragment            
C centroid.  90 degrees added to measure the angle from the vertical    
C line containing the burst point.                                      
                                                                        
                     ATT = ATAN(HOT / S1) * RAD2DEG + 90.               
                                                                        
C If the angle for the fragment centroid is less than the angle to      
C the revetment edge, then the revetment is between the weapon and      
C the target and LOS does not exist. Set indicator.                     
                                                                        
                     IF (ATE .GE. ATT) LOS = .FALSE.                    
                  ELSE                                                  
                                                                        
C If fragment centroid is less than or equal to burst height then       
C the revetment is between the burst point and the frag centroid.       
C LOS does not exist. Set indicator.                                    
                                                                        
                     LOS = .FALSE.                                      
                  ENDIF                                                 
               ENDIF                                                    
            ELSE                                                        
                                                                        
C Ground range on back side of revetment.                               
                                                                        
               IF (Q43 .GE. REVHT) THEN                                 
                                                                        
C Burst height above or equal to top of revetment.                      
                                                                        
                  IF (Q41(1) .LT. Q43) THEN                             
                     DDOR = S1 - REVTOT                                 
                     DTE = Q43 - REVHT                                  
                                                                        
C Compute the angle between the burst point and the interior, upper     
C edge of the revetment.                                                
                                                                        
                     ATE = ATAN(DDOR / DTE) * RAD2DEG                   
                     HOT = ABS(Q43 - Q41(1))                            
                                                                        
C Compute the angle between the burst point and the fragment            
C centroid.                                                             
                                                                        
                     ATT = ATAN(S1 / HOT) * RAD2DEG                     
                                                                        
C If the angle for the fragment centroid is less than the angle to      
C the revetment edge, then the revetment is between the weapon and      
C the target and LOS does not exist. Set indicator.                     
                                                                        
                     IF (ATT .LT. ATE) LOS = .FALSE.                    
                  ENDIF                                                 
               ELSE                                                     
                                                                        
C Burst height below top of revetment. Burst on back side of            
C revetment.                                                            
                                                                        
                  DDOR = S1 - REVTOP - REVTOT                           
                  DOR = REVSLP - DDOR                                   
                                                                        
C Adjust burst height for burst on back of revetment.                   
                                                                        
                  Q43 = Q43R + (DOR * TAN(REVA))                        
                                                                        
C If the fragment centroid is below the burst height, then the          
C revetment is between them. LOS does not exist. Set indicator.         
                                                                        
                  IF (Q41(1) .LE. Q43) LOS = .FALSE.                    
                  DTE = REVHT - Q43                                     
                                                                        
C Compute the angle between the burst point and the interior, upper     
C edge of the revetment.                                                
                                                                        
                  ATE = ATAN(DTE / DDOR) * RAD2DEG + 90.                
                  HOT = ABS(Q43 - Q41(1))                               
                                                                        
C Compute the angle between the burst point and the fragment            
C centroid.                                                             
                                                                        
                  ATT = ATAN(S1 / HOT) * RAD2DEG                        
                  ATT = 180. - ATT                                      
                                                                        
C If the angle for the fragment centroid is less than the angle to      
C the revetment edge, then the revetment is between the weapon and      
C the target and LOS does not exist. Set indicator.                     
                                                                        
                  IF (ATT .LT. ATE) LOS = .FALSE.                       
               ENDIF                                                    
            ENDIF                                                       
         ELSE                                                           
                                                                        
C Burst on top of revetment.                                            
                                                                        
            LOS = .FALSE.                                               
                                                                        
C If weapon is ground burst, then adjust burst height for revetment.    
                                                                        
            IF (Q43 .LT. REVHT) Q43 = Q43R + REVHT                      
                                                                        
C If the fragment centroid is above the burst height, then LOS          
C exists.                                                               
                                                                        
            IF (Q41(1) .GE. Q43) LOS = .TRUE.                           
            HOT = ABS(Q43 - Q41(1))                                     
            DDOR = S1 - REVTOT                                          
                                                                        
C Compute the angle between the burst point and the interior, upper     
C edge of the revetment.                                                
                                                                        
            ATE = ATAN(DDOR / Q43R)                                     
            ATE = ATE * RAD2DEG                                         
                                                                        
C Compute the angle between the burst point and the fragment            
C centroid.                                                             
                                                                        
            ATT = ATAN(S1 / HOT)                                        
            ATT = ATT * RAD2DEG                                         
                                                                        
C If the angle for the fragment centroid is less than the angle to      
C the revetment edge, then the revetment is between the weapon and      
C the target and LOS does not exist. Set indicator.                     
                                                                        
            IF (ATT .GE. ATE) LOS = .TRUE.                              
         ENDIF                                                          
      ELSE                                                              
                                                                        
C Ground range inside revetment.                                        
C If ground range intersects dead zone, calculate cutoff angle.         
                                                                        
         IF (IRV .AND. (S1 .GT. ABS(DTD))) THEN                         
            COFF = ACOS((REVTOT *  * 2. - S1 *  * 2 - ACTR *  * 2.) / ( 
     &             - 2. * S1 * ACTR))                                   
            COFF = 180.0 - COFF * RAD2DEG                               
            COFF = 90. - COFF                                           
         ENDIF                                                          
                                                                        
C Burst on inside edge of revetment.                                    
                                                                        
         IF (S1 .GT. REVDIS .AND. Q43 .LE. REVHT) THEN                  
            DOR = S1 - REVDIS                                           
                                                                        
C Adjust burst height for burst on revetment face.                      
                                                                        
            Q43 = Q43R + (DOR * TAN(REVA))                              
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C Test for line of sight                                                
                                                                        
      IF (LOS .EQV. .TRUE.) THEN                                         
         LOSFRG = 1                                                     
                                                                        
C Direct hit added when portion of target is exposed to weapon          
C trajectory. If ground range less than direct hit radius and target    
C is inside dead zone then...                                           
                                                                        
         RDH = .TRUE.                                                   
         IF ((S1 .LE. RD1) .AND. (DTD .LE. 0.)) THEN                    
                                                                        
C Compute altitude of weapon as it passes over the target.              
                                                                        
            HTRAJ =  - DTD * TAN(RTRAJ * DEG2RAD)                       
                                                                        
C If weapon altitude at target is above the target height, then         
C weapon did not intersect the target. No direct hit. Set indicator.    
                                                                        
            IF (HTRAJ .GT. TGTHT) RDH = .FALSE.                         
         ENDIF                                                          
      ELSE                                                              
         LOSFRG = 0                                                     
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE RNUM(XMAX,XMIN,YMAX,NRG,NDG,RAR,DAR,N,RMAX,TLOG,N21,CM,
     &                RB1,IP)                                           
C                                                                       
C---------------------------------------------------------------------- 
C Description:                                                          
C    Computes the integration limit necessary to completely cover the   
C Pk matrix.  Routine also computes the number of radii necessary in    
C each region that will insure that MCUT radii will cut through each    
C cell in the matrix.                                                   
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C CK                 ft     Difference between two adjacent range or    
C                           deflection coordinates.                     
C                                                                       
C CM                 ft     Largest increment that can be used and      
C                           still insure that MCUT radii will cut       
C                           through each cell of the matrix.            
C                                                                       
C C1                 ft     Minimum difference between any two adjacent 
C                           range grid coordinates.                     
C                                                                       
C C2                 ft     Minimum difference between any two adjacent 
C                           deflection grid coordinates.                
C                                                                       
C DAR(I)             ft     Ith deflection grid coordinate.             
C                                                                       
C D1                 ft     Distance from the burst point to the        
C                           XMAX, YMAX coordinate of the matrix.        
C                                                                       
C D2                 ft     Distance from the burst point to the        
C                           XMIN, YMAX coordinate of the matrix.        
C                                                                       
C FX1                --     Function which defines the increment        
C                           between the log and linear regions.         
C                                                                       
C FX1P               --     Slope or 1st derivative of FX1.             
C                                                                       
C MCUT               --     Number of cuts per cell.                    
C                                                                       
C N                  --     Number of increments to be used in the log  
C                           or linear integration regions.  Used in     
C                           MAIN.                                       
C                                                                       
C NDG                --     Number of deflection grid coordinates.      
C                                                                       
C NRG                --     Number of range grid coordinates.           
C                                                                       
C N21                --     Indicator:                                  
C                             2 - Integrate linear and log region.      
C                             3 - Integrate linear, log, and linear     
C                                 region.                               
C                                                                       
C RAR(I)             ft     Ith range grid coordinate.                  
C                                                                       
C RMAX               ft     Integration distance necessary to           
C                           completely cover the matrix.                
C                                                                       
C TLOG               ft     Boundary point between the log and          
C                           second linear integration regions.          
C                                                                       
C XMAX               ft     Maximum dimension of the matrix in range.   
C                                                                       
C XMIN               ft     Minimum dimension of the matrix in range.   
C                                                                       
C XN                 --     Number of increments to be used in the log  
C                           or second linear integration regions.       
C                                                                       
C X1                 --     Remainder calculated in Newton's iterative  
C                           method which is used as a flag to signal    
C                           when the correct number of increments have  
C                           been determined.                            
C                                                                       
C YMAX               ft     Maximum dimension of the matrix in          
C                           deflection.                                 
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      DIMENSION RAR(41),DAR(41)                                         
C                                                                       
      COMMON  / MSIZE /  MCUT,ITRAP                                     
C                                                                       
      CHARACTER*1 IP                                                    
                                                                        
C Functions used to calculate the last increment in LOG and the         
C increment size for the linear integration.                            
                                                                        
      FX1(R,XN,D) = (XN - 1.0) * LOG(R - XN * D) - XN * LOG(R - XN * D -
     &               D)                                                 
      FX1P(R,XN,D) = LOG(R - XN * D) - LOG(R - XN * D - D) + XN * D *   
     &               (1.0 / (R - XN * D - D) - 1.0 / (R - XN * D)) + D /
     &                (R - XN * D)                                      
                                                                        
C Determine the greatest distance from the burst point to the far corner
C of the matrix.                                                        
                                                                        
      D1 = SQRT(XMAX ** 2 + YMAX ** 2)                                  
      D2 = SQRT(XMIN ** 2 + YMAX ** 2)                                  
      RMAX = MAX(D1,D2)                                                 
                                                                        
C Determine the minimum cell size in range.  The largest size a cell    
C can be is 10000x10000.                                                
                                                                        
      C1 = 10000.0                                                      
      DO 10 I=1,NRG - 1                                                 
         CK = ABS(RAR(I + 1) - RAR(I))                                  
         C1 = MIN(CK,C1)                                                
 10   CONTINUE                                                          
                                                                        
C Determine the minimum cell size in deflection. The largest size a cell
C can be is 10000x10000.                                                
                                                                        
      C2 = 10000.0                                                      
      DO 20 I=1,(NDG / 2) - 1                                           
         CK = ABS(DAR(I + 1) - DAR(I))                                  
         C2 = MIN(CK,C2)                                                
 20   CONTINUE                                                          
                                                                        
C Calculate the integration increment size, CM, so that MCUT radii will 
C cut through each cell of the matrix.                                  
                                                                        
      CM = MIN(C1,C2)                                                   
      CM = CM / FLOAT(MCUT) - 0.01                                      
                                                                        
C If the integration distance to cover the matrix is small enough,      
C less than 100, then the second linear integration region is not       
C necessary.                                                            
                                                                        
      IF (RMAX .LE. 100.0) THEN                                         
         N21 = 2                                                        
                                                                        
C Compute number of radii needed in log region to cut the cell MCUT     
C times with a computed increment size of CM.                           
                                                                        
         XN = LOG(RMAX) / LOG(RMAX / (RMAX - CM))                       
                                                                        
C Convert XN to then next largest even number.                          
                                                                        
         N = INT(XN / 2) * 2 + 2                                        
         XN = FLOAT(N)                                                  
                                                                        
C Assign TLOG the boundary point between the log and linear region.     
C Since there is no linear region for this case, TLOG is assigned       
C the size of the matrix.                                               
                                                                        
         TLOG = RMAX                                                    
                                                                        
      ELSE                                                              
                                                                        
C Run will take two integration regions.                                
                                                                        
         IF (RB1 .LE. 0) THEN                                           
                                                                        
C If the weapon does not contain blast, then..                          
C The last increment of the log region must equal the increments in the 
C linear region.  Newton's iterative method is used to determine the    
C number of radii needed for each region, log and linear.               
                                                                        
            XN = ((RMAX - CM) / CM) - 1.0                               
 30         X1 = FX1(RMAX,XN,CM)                                        
            IF (ABS(X1) .GT. 0.005) THEN                                
               XN = XN - (X1 / FX1P(RMAX,XN,CM))                        
               GOTO 30                                                  
            ELSE                                                        
                                                                        
C Round XN to the next largest even number.                             
                                                                        
               N = (INT(XN) / 2) * 2 + 2                                
               XN = FLOAT(N)                                            
                                                                        
C Calculate boundary point between the log and linear regions.          
                                                                        
               TLOG = RMAX - (XN * CM)                                  
               N21 = 3                                                  
            ENDIF                                                       
                                                                        
         ELSE                                                           
                                                                        
C If the weapon contains blast, then calculate the increment distance   
C between the last two steps in the log region.  If this distance is    
C larger than the necessary size to cut the cell at least twice, then   
C increase the number of cuts needed by 10 and check again.  Continue   
C until the number of cuts necessary has been calculated.               
                                                                        
 40         XTEMP = (FLOAT(N) - 1) / FLOAT(N)                           
            XL = TLOG ** XTEMP                                          
            IF ((TLOG - XL) .GT. CM) THEN                               
               N = N + 10                                               
               GOTO 40                                                  
            ENDIF                                                       
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C Print maximum range diagonal to output.                               
                                                                        
      IF (IP .NE. ' ') WRITE(6,5000)RMAX                                
      RETURN                                                            
                                                                        
 5000 FORMAT (1X,12X,'MAXIMUM RANGE (DIAGONAL) = ',F10.2)               
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE SEKS                                                   
C                                                                       
C---------------------------------------------------------------------- 
C This subroutine calculates the probability of kill for fragments and  
C the probability of kill for fire for a given dynamic fragmentation    
C zone.                                                                 
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C AA                ft/sec  Fragment striking velocity.                 
C                                                                       
C AOPEN             sq in   Area of holes in fuel tank for current      
C                           fragment weight group.                      
C                                                                       
C AREA              sq in   Average presented area of fragments.        
C                                                                       
C ATOT              sq in   Cumulative area of fuel tank holes.         
C                                                                       
C AVNZRO             --     Indicator:                                  
C                             0.0 - Vulnerable areas averaged over all  
C                                   azimuths.                           
C                             1.0 - Vulnerable areas averaged over only 
C                                   nonzero azimuths.                   
C                                                                       
C C1(I)             ft/sec  I = 1 , 50.                                 
C                           Average initial fragment velocity, Ith      
C                           dynamic zone.                               
C                                                                       
C C3                ft/sec  Constant fragment cutoff velocity.          
C                                                                       
C CC                 --     Probability of kill for fragments not       
C                           considering LOS.                            
C                                                                       
C CENT               ft     Target height representing center of        
C                           vulnerability to fragments for single       
C                           point target.                               
C                                                                       
C CKQ                --     Shape factor for the fragments.             
C                                                                       
C CMQQ              grains  Fragment weight.                            
C                                                                       
C D1(I,K)            --     I=1,25, K=1,50                              
C                           Number of fragments in the Ith weight       
C                           group, Kth static zone.                     
C                                                                       
C D2(I,K)           grains  I=1,25, K=1,50                              
C                           Fragment weight, Ith weight group, Kth      
C                           zone.                                       
C                                                                       
C DEN                --     Density of fragments at target.             
C                           Dimensions are number of fragments per      
C                           square inch.                                
C                                                                       
C DEXP               --     Expected number of fragments striking the   
C                           vulnerable area.                            
C                                                                       
C DL                 --     Accumulator for probability of survival.    
C                                                                       
C DLX                --     Probability of survival of the target for   
C                           the current weight group.                   
C                                                                       
C E                  --     Product of survival probabilities for all   
C                           zones.                                      
C                                                                       
C G1(K)             deg     J = 1,50                                    
C                           Smallest vectored static angle for the      
C                           Kth zone.                                   
C                                                                       
C G2(K)             deg     J = 1,50                                    
C                           Largest vectored static angle for the       
C                           Kth zone.                                   
C                                                                       
C G5(I)             deg     I = 1,KMAX                                  
C                           Dynamic fragmentation zone angles in        
C                           ascending order.                            
C                                                                       
C H1(I)              ft     K = 1,JC1                                   
C                           The maximum range of the fragments in       
C                           the Ith dynamic zone.                       
C                                                                       
C IBUR               --     Indicator:                                  
C                             0 - Entire zone is above ground           
C                                 level. Not buried.                    
C                             1 - Part of zone is buried.               
C                             2 - Entire zone is below ground           
C                                 level. Total burial.                  
C                                                                       
C IC2(K)             --     K=1,180.                                    
C                           Number of weight groups in the kth zone.    
C                                                                       
C IFIRE              --     Indicator for FIRE option:                  
C                             FALSE - FIRE option not used.             
C                             TRUE - FIRE option used.                  
C                                                                       
C IFT                --     Indicator:                                  
C                             TRUE  - FIRE does contribute to kill      
C                             FALSE - FIRE does not contribute to kill  
C                                                                       
C JC1                --     Number of static fragmentation zones.       
C                                                                       
C K                  --     Subscript of the lower angle of the         
C                           dynamic fragmentation zone containing the   
C                           target.                                     
C                                                                       
C KLBUR              --     Indicator :                                 
C                             TRUE  - Weapon buried.                    
C                             FALSE - Weapon NOT buried.                
C                                                                       
C KS3                --     Lower boundary subscript of the             
C                           dynamic zone containing the target          
C                           height.                                     
C                                                                       
C MT7                --     Indicator :                                 
C                             FALSE - Use constant cutoff velocity      
C                                     table.                            
C                             TRUE - Use computed or input cutoff       
C                                    velocity table.                    
C                                                                       
C NTPX               --     Number of target fragment centroids.        
C                           When NTPX > 1, Q41(NTPX+1) contains the     
C                           overall target centroid.                    
C                                                                       
C PEF                --     Probability of exposure of vulnerable area  
C                           to fire effects.                            
C                                                                       
C PIF                --     Probability of fire kill, given sufficient  
C                           fuel leakage, for a single arc increment.   
C                                                                       
C PSL                --     Indicator for sufficient fuel leakage to    
C                           start a fire:                               
C                             0.0 - Insufficient fuel leakage.          
C                             1.0 - Sufficient fuel leakage.            
C                                                                       
C Q43                ft     Weapon burst height.                        
C                                                                       
C RATF(I)            --     I = 1,13                                    
C                           Probability of exposure times ratio of      
C                           target NOT shielded by terrain.             
C                                                                       
C S(I)               --     I = 1,50                                    
C                           Number of steradians, Ith dynamic zone.     
C                                                                       
C S1                 ft     Ground range. Distance from target to       
C                           weapon burst point in the plane             
C                           parallel to the ground at the weapon burst  
C                           height.                                     
C                                                                       
C S2                deg     Angle between the warhead axis and the      
C                           line connecting the weapon burst            
C                           point and the target centroid.              
C                                                                       
C T6                 ft     Slant range to target measured from the     
C                           burst point to the Ith target centroid.     
C                                                                       
C T6SS              sq ft   Area of fragment zone at distance T6. Zone  
C                           area is spheroidal.                         
C                                                                       
C VELCUT            ft/sec  Fragment cutoff velocity.                   
C                                                                       
C VOQ               ft/sec  Average initial dynamic fragment velocity.  
C                                                                       
C VPA               sq ft   Area of target vulnerable to fragments      
C                           for velocity, AA, and mass, CMQQ.           
C                                                                       
C VPF                sq ft  Vulnerable area of fuel tanks for fire kill.
C                                                                       
C VPP                --     Probability of exposure of vulnerable       
C                           area for velocity, AA, and mass, CMQQ.      
C                                                                       
C VPT                sq ft  Total vulnerable area modified by terrain   
C                           effects.                                    
C                                                                       
C WZ4(I,K)         ft/sec   I=1,25; K=1,50.                             
C                           Computed cutoff velocity, ith weight        
C                           group, kth static fragment zone.            
C                           Interpolated from given fragment weight     
C                           array, D2(), in the vulnerability table.    
C                                                                       
C-----------------------------------------------------------------------
C SUBROUTINES REFERENCED                                                
C                                                                       
C Name                                                                  
C                                                                       
C DINTT                                                                 
C PARBUR                                                                
C VDRG                                                                  
C                                                                       
C-----------------------------------------------------------------------
C FUNCTIONS REFERENCED                                                  
C                                                                       
C Name                                                                  
C                                                                       
C ZERO                                                                  
C                                                                       
C-----------------------------------------------------------------------
C CALLING ROUTINE                                                       
C                                                                       
C CALC                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      LOGICAL IOUT,NT9                                                  
                                                                        
      INCLUDE 'lacommon_clean.inc'                                            
                                                                        
      COMMON  / ABUR /  GMUP,GMLO,RF1(50),RF2(50),PLT1(50),PLT2(50)     
      COMMON  / ALT1 /  COTM,D1I(50),IOUT,ND,NTRE,NT9,RATF(13)          
      COMMON  / ARTXX /  ABOX(40,40),RDR                                
      COMMON  / BVNZRO /  AVNZRO                                        
      COMMON  / CBUR /  GMID                                            
      COMMON  / COSINE /  CWR,SWR                                       
      COMMON  / CUTVEL /  IVCT,VELCUT                                   
                                                                        
C Initialize variables.                                                 
                                                                        
      ATOT = 0.0                                                        
      E = 1.0                                                           
      K = KS3 - 1                                                       
      T6 = SQRT(S1 ** 2 + (CENT - Q43) ** 2)                            
                                                                        
C For each dynamic zone do -                                            
                                                                        
      DO 50 JI=1,JC1                                                    
                                                                        
C Find the vectored zones contributing to the dynamic zone.             
                                                                        
         IF (ZERO(G5(K),G1(JI)) .GE. 0.0) THEN                          
            IF ((ZERO(G5(K),G1(JI)) .GT. 0.0) .AND. (G5(K) .GE.         
     &          G2(JI))) GOTO 40                                        
                                                                        
            IF (T6 .NE. 0.0) THEN                                       
                                                                        
C Slant range less than max range, zone contributes to target kill.     
                                                                        
               IF (T6 .LT. H1(JI)) THEN                                 
                                                                        
C Compute spherical surface area of zone, and initialize probability    
C of survival accumulator. Assume target survives.                      
                                                                        
                  T6SS = T6 ** 2 * S(JI)                                
                  DL = 1.0                                              
                                                                        
C Test zones for bomb burial.                                           
                                                                        
                  IBUR = 0                                              
                  IF (KLBUR) THEN                                       
                     CALL PARBUR(JI,T6,CENT,IBUR,GMID,S2)               
                                                                        
C If zone is partially or completely buried, step to the next dynamic   
C zone. For partial burial, subroutine PARBUR sets the next dynamic     
C zone to the portion of the zone that is not buried. Subroutine        
C SEKS then treats this new zone as unburied.                           
                                                                        
                     IF (IBUR .EQ. 2 .OR. IBUR .EQ. 1) GOTO 30          
                  ENDIF                                                 
                                                                        
C Set initial fragment velocity.                                        
                                                                        
                  VOQ = C1(JI)                                          
                                                                        
C For each weight group do                                              
                                                                        
                  DO 20 I10=1,IC2(JI)                                   
                                                                        
C Initialize vulnerable area and FIRE effects indicator.                
                                                                        
                     VPT = 0.0                                          
                     IFT = .FALSE.                                      
                                                                        
C Set cutoff velocity for this weight group.                            
                                                                        
                     IF (MT7) THEN                                      
                        VELCUT = WZ4(I10,JI)                            
                     ELSE                                               
                        VELCUT = C3                                     
                     ENDIF                                              
                                                                        
C Set fragment weight.                                                  
                                                                        
                     CMQQ = D2(I10,JI)                                  
                                                                        
C Test fragment velocity against cutoff velocity. If frag velocity      
C less than cutoff, exit loop.                                          
                                                                        
                     IF (VELCUT .GE. VOQ) GOTO 30                       
                     CALL VDRG(VOQ,CMQQ,CENT,T6,AA)                     
                                                                        
C Test fragment striking velocity against cutoff velocity. If frag      
C striking velocity less than cutoff, exit loop.                        
                                                                        
                     IF (VELCUT .GE. AA) GOTO 30                        
                                                                        
C Calculate vulnerable area for each target centroid.                   
                                                                        
                     DO 10 J1PT=1,NTPX                                  
                        CALL DINTT(AA,CMQQ,J1PT,VPA,VPP)                
                        VPT = RATF(J1PT) * VPA + VPT                    
 10                  CONTINUE                                           
                     VPA = VPT                                          
                                                                        
C If the FIRE option has been selected and distance to target is less   
C than the fire-start distance given, then interpolate the fuel tank    
C vulnerable area and probability of exposure.                          
C Note:  The fuel tank was considered to be on the third strip          
C        RATF(3).  This code needs to be changed for different          
C        targets.                                                       
                                                                        
                     IF ((IFIRE) .AND. PIF .NE. 0.) THEN                
                        IFT = .TRUE.                                    
                        CALL DINTT(AA,CMQQ,1,VPF,PEF)                   
                        VPF = RATF(3) * VPF * 144.                      
                                                                        
C Calculate average presented area, area of holes in fuel tank, and     
C sum the area of holes.                                                
                                                                        
                        AREA = CKQ * (CMQQ ** (2. / 3)) * (144. /       
     &                         7000.)                                   
                        DEN = D1(I10,JI) / (T6SS * 144.)                
                        AOPEN = DEN * VPF * AREA * PEF                  
                        ATOT = ATOT + AOPEN                             
                     ENDIF                                              
                                                                        
C If vulerable areas averaged over all azimuths, and probability of     
C exposure is not 0.0, then calculate probability of survival for       
C target.                                                               
                                                                        
                     IF (AVNZRO .LE. 0.0) THEN                          
                        IF (VPP .GT. 0.0) THEN                          
                           DEXP = (D1(I10,JI) * VPA) / (T6SS * VPP)     
                           IF (DEXP .GT. 25.) THEN                      
                              DLX = 1.0 - VPP                           
                           ELSE                                         
                              DLX = 1.0 - VPP * (1.0 - EXP( - DEXP ))   
                           ENDIF                                        
                        ELSE                                            
                                                                        
C Probability of exposure 0 or less, set probability of survival to 1.  
                                                                        
                           DLX = 1.0                                    
                        ENDIF                                           
                     ELSE                                               
                                                                        
C If vulnerable areas averaged over all non-zero azimuths, and          
C probability of exposure in not 0.0, then calculate probability of     
C survival for target.                                                  
                                                                        
                        DEXP = (D1(I10,JI) * VPA) / T6SS                
                        IF (DEXP .GT. 25.) THEN                         
                           DLX = 1.0 - VPP                              
                        ELSE                                            
                           DLX = 1.0 - VPP * (1.0 - EXP( - DEXP ))      
                        ENDIF                                           
                     ENDIF                                              
                                                                        
C Accumulate probabilities of survival for all weight groups.           
                                                                        
                     DL = DLX * DL                                      
 20               CONTINUE                                              
                                                                        
C Accumulate probabilities of survival for all fragment zones.          
                                                                        
 30               E = DL * E                                            
               ENDIF                                                    
            ENDIF                                                       
         ENDIF                                                          
 40      CONTINUE                                                       
 50   CONTINUE                                                          
                                                                        
C Calculate probability of kill.                                        
                                                                        
      CC = 1.0 - E                                                      
                                                                        
C Set probability of fire start to 1 if area of holes in fuel tank      
C exceeds .037 square inches.                                           
                                                                        
      IF (ATOT .LT. .037) THEN                                          
         PSL = 0.                                                       
      ELSE                                                              
         PSL = 1.                                                       
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE TABLE(S1,Q43,TGT,RATTER)                               
C                                                                       
C---------------------------------------------------------------------- 
C This routine calculates terrain effects by interpolating a            
C probability of exposure based upon ground range, burst height, and    
C target height.                                                        
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C CFCT               --     Fraction of interval between consecutive    
C                           target heights in probability of            
C                           exposure table that is covered by the       
C                           current target height.                      
C                                                                       
C EXPTR (I,J,K)      --     I = 1,18; J = 1,10; K = 1,10                
C                           Probability of exposure table indexed by    
C                           target height, burst height, and ground     
C                           range.                                      
C                                                                       
C HA                 --     Intermediate variable used to               
C                           interpolate probability of exposure.        
C                           Used for burst height interpolation.        
C                                                                       
C HB                 --     Intermediate variable used to               
C                           interpolate probability of exposure.        
C                           Used for burst height interpolation.        
C                                                                       
C HBFCT              --     Fraction of interval between consecutive    
C                           burst heights in probability of             
C                           exposure table that is covered by the       
C                           current burst height.                       
C                                                                       
C HOB (I)            ft     I = 1,10. Table of burst heights used in    
C                           the probability of exposure table.          
C                                                                       
C I                  --     Index of the ground range closest to but    
C                           less than the current ground range.         
C                                                                       
C J                  --     Index of the burst height closest to, but   
C                           less than, the current burst height.        
C                                                                       
C K                  --     Index of the target height closest to, but  
C                           less than ,the current target height.       
C                                                                       
C Q4                 ft     Burst height of the weapon. Adjusted to     
C                           a minimum height if lower than lowest       
C                           burst height in table.                      
C                                                                       
C Q43                ft     Burst height of the weapon.                 
C                                                                       
C RATTER             --     Computed probability of exposure.           
C                                                                       
C S1                 ft     Ground range. Distance from target to       
C                           weapon in the ground plane.                 
C                                                                       
C S1FCT              --     Fraction of interval between consecutive    
C                           ground ranges in probability of exposure    
C                           table that is covered by the current        
C                           ground range.                               
C                                                                       
C S1M                ft     Current ground range. Adjusted to a         
C                           maximum if current ground range is          
C                           beyond farthest ground range in the         
C                           probability of exposure table.              
C                                                                       
C S1T (I)            ft     I = 1,10. Table of ground ranges used in    
C                           the probability of exposure table.          
C                                                                       
C SA                 --     Interpolated probability of exposure for    
C                           ground range at the smaller target          
C                           height and smaller burst height.            
C                                                                       
C SB                 --     Interpolated probability of exposure for    
C                           ground range at the smaller burst height.   
C                                                                       
C SC                 --     Interpolated probability of exposure for    
C                           ground range at the smaller target height.  
C                                                                       
C SD                 --     Interpolated probability of exposure for    
C                           ground range.                               
C                                                                       
C TGT                ft     Current target height.                      
C                                                                       
C TGTHGT             ft     Current target height. Adjusted to a        
C                           maximum value if the target height is       
C                           taller than the tallest height in the       
C                           probability of exposure table.              
C                                                                       
C TARGHT (18)        ft     Table of target heights used in the         
C                           probability of exposure table.              
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C   NONE                                                                
C                                                                       
C---------------------------------------------------------------------- 
C Functions Called                                                      
C   NONE                                                                
C                                                                       
C---------------------------------------------------------------------- 
C Calling Routine                                                       
C   MAIN                                                                
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Values for the dimensioned arrays are contained in the following      
C data statements.                                                      
C                                                                       
      DIMENSION HOB(10),S1T(10),TARGHT(18),EXPTR(18,10,10)              
                                                                        
      DATA HOB/.125,.25,.5,1.,2.,4.,8.,16.,24.,48./                     
      DATA S1T/0.,4.,8.,16.,32.,64.,128.,256.,512.,1024./               
      DATA TARGHT/0.,.083,.167,.25,.333,.5,.667,.833,1.25,1.667,2.5,    
     13.333,4.167,5.,6.667,8.333,11.667,15.000/                         
      DATA ((EXPTR(K,I,1),K=1,18),I=1,10)/1.00,1.00,1.00,1.00,1.00,1.00,
     11.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     2.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     300,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     40,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00
     5,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     61.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     7.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     800,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     90,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00
     A,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     B1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     C.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     D00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     E0,1.00,1.00/                                                      
      DATA ((EXPTR(K,I,2),K=1,18),I=1,10)/0.65,0.82,0.90,0.93,0.96,0.98,
     10.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,0.74,0
     2.89,0.95,0.97,0.99,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     300,1.00,1.00,1.00,0.88,0.96,0.98,0.99,1.00,1.00,1.00,1.00,1.00,1.0
     40,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,0.96,0.99,1.00,1.00,1.00
     5,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     60.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     7.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     800,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     90,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00
     A,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     B1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     C.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     D00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     E0,1.00,1.00/                                                      
      DATA ((EXPTR(K,I,3),K=1,18),I=1,10)/0.37,0.63,0.79,0.86,0.91,0.95,
     10.97,0.98,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,0.46,0
     2.72,0.86,0.91,0.94,0.97,0.98,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.
     300,1.00,1.00,1.00,0.64,0.86,0.93,0.96,0.97,0.98,0.99,0.99,1.00,1.0
     40,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,0.82,0.93,0.97,0.98,0.98
     5,0.99,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     60.92,0.98,0.99,0.99,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     7.00,1.00,1.00,1.00,1.00,0.97,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.
     800,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     90,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00
     A,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     B1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     C.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     D00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     E0,1.00,1.00/                                                      
      DATA ((EXPTR(K,I,4),K=1,18),I=1,10)/0.14,0.28,0.44,0.54,0.61,0.71,
     10.77,0.81,0.87,0.91,0.95,0.97,0.98,0.99,1.00,1.00,1.00,1.00,0.20,0
     2.38,0.54,0.63,0.69,0.76,0.82,0.85,0.90,0.93,0.96,0.98,0.99,1.00,1.
     300,1.00,1.00,1.00,0.35,0.59,0.73,0.77,0.81,0.85,0.88,0.89,0.93,0.9
     46,0.98,0.99,1.00,1.00,1.00,1.00,1.00,1.00,0.57,0.76,0.83,0.87,0.89
     5,0.91,0.93,0.94,0.96,0.97,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     60.79,0.87,0.91,0.93,0.94,0.96,0.97,0.98,0.99,1.00,1.00,1.00,1.00,1
     7.00,1.00,1.00,1.00,1.00,0.92,0.95,0.96,0.97,0.98,0.99,0.99,1.00,1.
     800,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,0.97,0.99,0.99,1.0
     90,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00
     A,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     B1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     C.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     D00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     E0,1.00,1.00/                                                      
      DATA ((EXPTR(K,I,5),K=1,18),I=1,10)/0.07,0.15,0.23,0.31,0.38,0.48,
     10.56,0.61,0.71,0.77,0.84,0.89,0.92,0.94,0.96,0.98,1.00,1.00,0.10,0
     2.20,0.30,0.38,0.44,0.54,0.62,0.67,0.76,0.82,0.88,0.92,0.94,0.95,0.
     397,0.98,1.00,1.00,0.17,0.34,0.48,0.57,0.62,0.69,0.74,0.79,0.84,0.8
     47,0.92,0.94,0.96,0.97,0.98,0.99,1.00,1.00,0.34,0.52,0.64,0.70,0.75
     5,0.80,0.83,0.85,0.89,0.92,0.95,0.96,0.97,0.99,0.99,1.00,1.00,1.00,
     60.54,0.70,0.77,0.81,0.84,0.87,0.89,0.91,0.94,0.96,0.98,0.99,0.99,1
     7.00,1.00,1.00,1.00,1.00,0.76,0.83,0.88,0.90,0.91,0.93,0.95,0.96,0.
     897,0.98,0.99,0.99,0.99,1.00,1.00,1.00,1.00,1.00,0.86,0.93,0.95,0.9
     96,0.97,0.98,0.99,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00
     A,1.00,0.97,0.98,0.99,0.99,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,
     B1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1
     C.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     D00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     E0,1.00,1.00/                                                      
      DATA ((EXPTR(K,I,6),K=1,18),I=1,10)/0.03,0.07,0.11,0.14,0.17,0.23,
     10.29,0.33,0.45,0.53,0.64,0.71,0.78,0.83,0.88,0.92,0.96,1.00,0.04,0
     2.09,0.14,0.18,0.22,0.28,0.35,0.40,0.51,0.59,0.69,0.76,0.82,0.86,0.
     392,0.93,0.97,1.00,0.07,0.16,0.23,0.29,0.35,0.43,0.51,0.56,0.65,0.7
     40,0.78,0.85,0.89,0.91,0.94,0.96,0.98,1.00,0.14,0.26,0.36,0.44,0.50
     5,0.59,0.65,0.68,0.75,0.80,0.87,0.91,0.94,0.96,0.97,0.98,0.99,1.00,
     60.27,0.44,0.54,0.61,0.66,0.74,0.79,0.82,0.88,0.91,0.95,0.97,0.98,0
     7.98,0.99,1.00,1.00,1.00,0.51,0.64,0.71,0.76,0.79,0.84,0.87,0.90,0.
     893,0.96,0.97,0.99,0.99,0.99,1.00,1.00,1.00,1.00,0.70,0.79,0.83,0.8
     96,0.88,0.91,0.94,0.95,0.97,0.98,0.99,0.99,1.00,1.00,1.00,1.00,1.00
     A,1.00,0.84,0.90,0.93,0.94,0.96,0.98,0.99,0.99,1.00,1.00,1.00,1.00,
     B1.00,1.00,1.00,1.00,1.00,1.00,0.92,0.98,0.99,0.99,0.99,1.00,1.00,1
     C.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.
     D00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     E0,1.00,1.00/                                                      
      DATA ((EXPTR(K,I,7),K=1,18),I=1,10)/0.03,0.05,0.07,0.08,0.10,0.12,
     10.15,0.17,0.22,0.26,0.35,0.45,0.54,0.61,0.70,0.76,0.85,0.91,0.03,0
     2.05,0.07,0.09,0.11,0.14,0.17,0.20,0.26,0.32,0.42,0.51,0.59,0.66,0.
     374,0.81,0.91,0.96,0.04,0.07,0.10,0.13,0.15,0.20,0.25,0.29,0.38,0.4
     45,0.58,0.67,0.72,0.76,0.82,0.87,0.93,0.99,0.08,0.14,0.18,0.22,0.25
     5,0.32,0.38,0.43,0.54,0.62,0.71,0.77,0.82,0.85,0.90,0.93,0.98,1.00,
     60.12,0.22,0.28,0.34,0.40,0.49,0.56,0.62,0.69,0.75,0.82,0.87,0.90,0
     7.93,0.95,0.97,1.00,1.00,0.26,0.40,0.48,0.55,0.59,0.67,0.71,0.74,0.
     881,0.85,0.91,0.94,0.96,0.97,0.98,0.99,1.00,1.00,0.44,0.57,0.64,0.6
     98,0.72,0.77,0.81,0.83,0.88,0.91,0.95,0.97,0.98,0.99,1.00,1.00,1.00
     A,1.00,0.65,0.74,0.78,0.82,0.84,0.87,0.90,0.92,0.95,0.97,0.99,0.99,
     B1.00,1.00,1.00,1.00,1.00,1.00,0.73,0.82,0.85,0.88,0.91,0.93,0.95,0
     C.96,0.97,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.00,0.87,0.94,0.
     D95,0.96,0.97,0.98,0.99,0.99,1.00,1.00,1.00,1.00,1.00,1.00,1.00,1.0
     E0,1.00,1.00/                                                      
      DATA ((EXPTR(K,I,8),K=1,18),I=1,10)/0.03,0.04,0.06,0.07,0.08,0.09,
     10.11,0.12,0.15,0.18,0.23,0.27,0.31,0.35,0.42,0.49,0.61,0.71,0.03,0
     2.05,0.06,0.08,0.09,0.11,0.13,0.14,0.18,0.21,0.26,0.31,0.35,0.39,0.
     346,0.54,0.67,0.77,0.04,0.06,0.08,0.10,0.11,0.14,0.17,0.19,0.23,0.2
     47,0.34,0.41,0.46,0.50,0.58,0.66,0.78,0.88,0.08,0.11,0.14,0.16,0.18
     5,0.21,0.24,0.26,0.32,0.36,0.44,0.51,0.57,0.62,0.69,0.75,0.86,0.94,
     60.10,0.15,0.19,0.22,0.25,0.29,0.33,0.36,0.43,0.49,0.58,0.65,0.70,0
     7.74,0.82,0.86,0.93,0.96,0.15,0.23,0.27,0.31,                      
     70.35,0.41,0.46,0.50,0.58,0.64,                                    
     8   0.72,0.78,0.82,0.86,0.90,0.92,0.96,0.98,0.23,0.31,0.41,0.45,0.4
     99,0.56,0.61,0.64,0.71,0.75,0.82,0.87,0.90,0.92,0.96,0.98,1.00,1.00
     A,0.44,0.50,0.57,0.61,0.64,0.68,0.72,0.75,0.80,0.83,0.88,0.92,0.95,
     B0.96,0.99,1.00,1.00,1.00,0.55,0.60,0.65,0.67,0.70,0.75,0.79,0.82,0
     C.86,0.88,0.92,0.94,0.96,0.97,0.99,1.00,1.00,1.00,0.71,0.75,0.79,0.
     D81,0.84,0.87,0.90,0.92,0.95,0.96,0.98,0.99,0.99,0.99,1.00,1.00,1.0
     E0,1.00/                                                           
      DATA ((EXPTR(K,I,9),K=1,18),I=1,10)/0.03,0.04,0.06,0.07,0.08,0.09,
     10.10,0.11,0.15,0.17,0.21,0.24,0.28,0.31,0.36,0.41,0.48,0.54,0.03,0
     2.04,0.06,0.07,0.08,0.10,0.11,0.12,0.16,0.18,0.23,0.27,0.31,0.34,0.
     340,0.44,0.53,0.59,0.04,0.05,0.07,0.08,0.09,0.11,0.13,0.15,0.19,0.2
     42,0.28,0.33,0.37,0.41,0.47,0.53,0.63,0.71,0.06,0.08,0.10,0.12,0.13
     5,0.16,0.18,0.20,0.25,0.29,0.35,0.40,0.45,0.49,0.56,0.63,0.74,0.83,
     60.07,0.10,0.13,0.16,0.18,0.20,0.23,0.25,0.29,0.33,0.40,0.46,0.50,0
     7.54,0.62,0.69,0.80,0.90,0.09,0.14,0.18,0.21,0.23,0.27,0.30,0.32,0.
     837,0.41,0.48,0.55,0.60,0.64,0.73,0.78,0.88,0.95,0.12,0.21,0.28,0.3
     90,0.33,0.36,0.39,0.41,0.47,0.50,0.57,0.64,0.70,0.75,0.83,0.88,0.93
     A,0.97,0.20,0.29,0.35,0.39,0.42,0.47,0.50,0.53,0.59,0.64,0.73,0.79,
     B0.83,0.86,0.90,0.92,0.96,0.98,0.33,0.37,0.41,0.45,0.48,0.54,0.58,0
     C.61,0.69,0.75,0.83,0.87,0.90,0.92,0.95,0.97,0.99,1.00,0.48,0.55,0.
     D59,0.61,0.64,0.67,0.70,0.73,0.78,0.82,0.87,0.90,0.93,0.95,0.98,0.9
     E9,1.00,1.00/                                                      
      DATA ((EXPTR(K,I,10),K=1,18),I=1,10)/0.01,0.03,0.04,0.06,0.07,0.09
     1,0.10,0.11,0.14,0.16,0.20,0.23,0.26,0.28,0.33,0.36,0.42,0.46,0.01,
     20.04,0.05,0.07,0.08,0.09,0.10,0.12,0.15,0.17,0.21,0.25,0.28,0.31,0
     3.36,0.40,0.45,0.50,0.02,0.05,0.06,0.07,0.09,0.10,0.12,0.13,0.16,0.
     419,0.24,0.30,0.33,0.37,0.43,0.47,0.54,0.60,0.04,0.06,0.08,0.09,0.1
     51,0.13,0.15,0.16,0.20,0.23,0.28,0.33,0.37,0.40,0.47,0.52,0.61,0.67
     6,0.05,0.08,0.09,0.12,0.13,0.15,0.17,0.19,0.22,0.24,0.30,0.35,0.39,
     70.43,0.50,0.55,0.56,0.72,0.06,0.09,0.12,0.15,0.17,0.20,0.22,0.23,0
     8.26,0.29,0.35,0.40,0.44,0.48,0.55,0.61,0.71,0.79,0.07,0.13,0.18,0.
     921,0.23,0.25,0.27,0.28,0.32,0.35,0.41,0.46,0.50,0.55,0.62,0.67,0.7
     A7,0.86,0.11,0.17,0.21,0.24,0.27,0.31,0.35,0.37,0.42,0.46,0.52,0.57
     B,0.62,0.66,0.71,0.76,0.85,0.92,0.16,0.22,0.26,0.29,0.32,0.36,0.39,
     C0.42,0.48,0.53,0.60,0.66,0.70,0.73,0.78,0.82,0.89,0.94,0.28,0.33,0
     D.36,0.38,0.40,0.44,0.47,0.50,0.56,0.62,0.69,0.75,0.78,0.81,0.84,0.
     E87,0.92,0.97/                                                     
                                                                        
C Initialize burst height and ground range. These values may be         
C changed so temporary variables are used.                              
                                                                        
      Q4 = Q43                                                          
      S1M = S1                                                          
      TGTHGT = TGT                                                      
                                                                        
C If ground range is beyond largest ground range in table, use the      
C last table ground range. Same for target height and burst height.     
                                                                        
      IF (S1M .GE. S1T(10)) S1M = S1T(10) - .01                         
      IF (TGTHGT .GT. TARGHT(18)) TGTHGT = 8.3329                       
      IF (Q4 .LT. .125) Q4 = .125                                       
                                                                        
                                                                        
C Determine table ground ranges to interpolate between.                 
                                                                        
      DO 10 I=1,10                                                      
         IF (S1M .LT. S1T(I)) THEN                                      
                                                                        
C Table ground range is beyond current ground range.                    
C S1FCT is the fraction of the interval between 2 consecutive           
C table distances covered by S1M.                                       
                                                                        
            S1FCT = (S1M - S1T(I - 1)) / (S1T(I) - S1T(I - 1))          
            GOTO 30                                                     
         ELSEIF (S1M .EQ. S1T(I)) THEN                                  
                                                                        
C Current ground range is a ground range found in the table.            
                                                                        
            GOTO 20                                                     
         ENDIF                                                          
 10   CONTINUE                                                          
                                                                        
C Current ground range is in the table. Increment index to              
C the next table ground range for later interpolation. Set              
C percentage of interval covered to 0.                                  
                                                                        
 20   I = I + 1                                                         
      S1FCT = 0.                                                        
                                                                        
C If burst height is above all table burst heights, set probability     
C of exposure to 1 and exit routine.                                    
                                                                        
 30   IF (Q4 .GE. HOB(10)) THEN                                         
         RATTER = 1.                                                    
         RETURN                                                         
      ENDIF                                                             
                                                                        
C Interpolate for burst height.                                         
                                                                        
      DO 40 J=1,10                                                      
         IF (Q4 .LT. HOB(J)) THEN                                       
                                                                        
C Burst height less than current burst height. Compute fraction of      
C interval covered by current burst height.                             
                                                                        
            HBFCT = (Q4 - HOB(J - 1)) / (HOB(J) - HOB(J - 1))           
            GOTO 60                                                     
         ELSEIF (Q4 .EQ. HOB(J)) THEN                                   
            GOTO 50                                                     
         ENDIF                                                          
 40   CONTINUE                                                          
                                                                        
C Burst height equals a table burst height. Increment index ands set    
C fractional coverage to 0.                                             
                                                                        
 50   J = J + 1                                                         
      HBFCT = 0.                                                        
                                                                        
C Interpolate for target height.                                        
                                                                        
 60   DO 70 K=1,18                                                      
         IF (TGTHGT .LT. TARGHT(K)) THEN                                
                                                                        
C Current target height is less than a table target height. Compute     
C fractional coverage of interval by current target height.             
                                                                        
            CFCT = (TGTHGT - TARGHT(K-1)) / (TARGHT(K) - TARGHT(K-1))   
            GOTO 90                                                     
         ELSEIF (TGTHGT .EQ. TARGHT(K)) THEN                            
            GOTO 80                                                     
         ENDIF                                                          
 70   CONTINUE                                                          
                                                                        
C Target height equals a table target height. Increment index and set   
C fractional coverage to 0.                                             
                                                                        
 80   K = K + 1                                                         
      CFCT = 0.                                                         
                                                                        
C Interpolate from probability of exposure table for ground range.      
                                                                        
 90   SD = (EXPTR(K,J,I) - EXPTR(K,J,I - 1)) * S1FCT + EXPTR(K,J,I - 1) 
      SC = (EXPTR(K - 1,J,I) - EXPTR(K - 1,J,I - 1)) * S1FCT + EXPTR(K -
     &      1,J,I - 1)                                                  
      SB = (EXPTR(K,J - 1,I) - EXPTR(K,J - 1,I - 1)) * S1FCT + EXPTR(K, 
     &     J - 1,I - 1)                                                 
      SA = (EXPTR(K - 1,J - 1,I) - EXPTR(K - 1,J - 1,I - 1)) * S1FCT +  
     &     EXPTR(K - 1,J - 1,I - 1)                                     
                                                                        
C Interpolate for height of burst.                                      
                                                                        
      HA = (SC - SA) * HBFCT + SA                                       
      HB = (SD - SB) * HBFCT + SB                                       
                                                                        
C Interpolate for target height. Return prob of exposure.               
                                                                        
      RATTER = (HB - HA) * CFCT + HA                                    
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE TEV(J1,ZEA,IT)                                         
C                                                                       
C---------------------------------------------------------------------- 
C DESCRIPTION:  This subroutine interpolates the single-fragment        
C               vulnerable area tables (for fragmentation and fire      
C               kills) at the impact elevation angle of fragments       
C               striking the target (striking angle, ZEA) for the       
C               integration radius that is being calculated.  This      
C               reduces the table to vulnerable areas for those         
C               fragment masses and velocities that are at the correct  
C               elevation angle.                                        
C                                                                       
C VARIABLES:                                                            
C     Name          Units                  Definition                   
C ---------------  -------  --------------------------------------------
C FAMV(I,J)        sq ft    I=1,J1*MAN ; J=1,KNVLE.  Fire vulnerability 
C                           areas for ith mass and jth velocity for the 
C                           fragment impact elevation angle.            
C                                                                       
C FELE(I)           deg     I=1,KNELA.  Elevation angles in fire effects
C                           table.                                      
C                                                                       
C FPMV(I,J)          --     I=1,J1*MAN ; J=1,KNVLE.  Fire probability of
C                           exposure for the ith mass and jth velocity  
C                           for the fragment impact elevation angle.    
C                                                                       
C FPPA(I,J,K)        --     I=1,KNELA ; J=1,KMAN ; K=1,KNVLE.           
C                           Probability of exposure for fire effects,   
C                           ith elevation, jth weight group, kth        
C                           velocity.                                   
C                                                                       
C FZA(I,J,K)       sq ft    I=1,KNELA ; J=1,KMAN ; K=1,KNVLE.           
C                           Average vulnerable area data for fire       
C                           effects, ith elevation, jth weight group,   
C                           kth velocity.                               
C                                                                       
C IA                 --     Array index for elevation angle which is    
C                           the lower limit of bracket for striking     
C                           angle, ZEA.                                 
C                                                                       
C IB                 --     Index for TZA and TPPA arrays which is the  
C                           lower limit of bracket for interpolation    
C                           purposes.                                   
C                                                                       
C IC                 --     Index for TZA and TPPA arrays which is the  
C                           upper limit of bracket for interpolation    
C                           purposes.                                   
C                                                                       
C IT                 --     Indicator :                                 
C                             0 - compute fragment vulnerable areas;    
C                             1 - compute fire vulnerable areas.        
C                                                                       
C J1                 --     Target strip being considered.  Parameter   
C                           passed into TEV.                            
C                                                                       
C KMAN               --     Number of fragment masses in fire effects   
C                           table.                                      
C                                                                       
C KNELA              --     Number of elevation angles in fire effects  
C                           table.                                      
C                                                                       
C KNVLE              --     Number of fragment velocities in fire       
C                           effects table.                              
C                                                                       
C KTM                --     Index for interpolated arrays XAMV, XPMV,   
C                           FAMV, and FPMV.  Value is assigned          
C                           according to the masses of each target      
C                           strip.                                      
C                                                                       
C LZE                --     Adjusts indices IB and IC to select the     
C                           J1th target strip in the fragment kill      
C                           table.                                      
C                                                                       
C LZF                --     Adjusts array index KTM to select the       
C                           J1th target strip in the fire effects table.
C                                                                       
C LZM                --     Adjusts array index KTM to select the       
C                           J1th target strip in the fragment kill table
C                                                                       
C MAN                --     Number of fragment masses in target         
C                           vulnerability table.                        
C                                                                       
C NELA               --     Array index, NELA.  Number of elevation     
C                           angles in target vulnerability table.       
C                                                                       
C NVLE               --     Number of fragment velocities in target     
C                           vulnerability table.                        
C                                                                       
C TELE(I)           deg     I=1,NELA.  Elevation angles in fragment kill
C                           table.                                      
C                                                                       
C TEMP1              --     Interpolation factor for elevation angle    
C                           produced when NUM is divided by DEN, where: 
C                             NUM is the difference between the striking
C                                 angle, ZEA, and the lower angle in    
C                                 TELE which is closest to ZEA, and,    
C                             DEN is the difference between the two     
C                                 angles in TELE which bracket ZEA.     
C                                                                       
C TPPA(I,J,K)        --     I=1,NELA ; J=1,MAN ; K=1,NVLE.              
C                           Probability of exposure for fragment        
C                           kill, ith elevation, jth weight group, kth  
C                           velocity.                                   
C                                                                       
C TZA(I,J,K)       sq ft    I=1,NELA ; J=1,MAN ; K=1,NVLE.              
C                           Average vulnerable area data for fragment   
C                           kill, ith elevation, jth weight group, kth  
C                           velocity.                                   
C                                                                       
C XAMV(I,J)        sq ft    I=1,J1*MAN ; J=1,KVLE.  Fragment vulnerable 
C                           areas for the ith mass and jth velocity for 
C                           the fragment elevation angle.               
C                                                                       
C XELE(I)           deg     I=1,NELA or KNELA (depending on value of    
C                           IT).  Elevation angles in fragment or fire  
C                           kill table.                                 
C                                                                       
C XMAN               --     Number of fragment weights in fragmentation 
C                           or fire effects table.                      
C                                                                       
C XNELA              --     Number of elevation angles in fragmentation 
C                           or fire effects table.                      
C                                                                       
C XNVLE              --     Number of fragment velocities in            
C                           fragmentation or fire effects table.        
C                                                                       
C XPMV(I,J)          --     I=1,J1*MAN ; J=1,KVLE.  Fragment            
C                           probability of exposure data for ith mass   
C                           and jth velocity for the fragment           
C                           elevation angle.                            
C                                                                       
C ZEA               deg     The angle formed by the plane parallel to   
C                           the ground and containing the target        
C                           centroid and the line connecting the weapon 
C                           burst point and the target centroid.  This  
C                           angle is also referred to as the striking   
C                           angle, the elevation angle of fragments     
C                           striking the target.                        
C---------------------------------------------------------------------- 
C Subroutines called:                                                   
C                                                                       
C  NONE                                                                 
C---------------------------------------------------------------------- 
C Functions called:                                                     
C                                                                       
C  NONE                                                                 
C---------------------------------------------------------------------- 
C Calling routine:                                                      
C                                                                       
C  MAIN                                                                 
C---------------------------------------------------------------------- 
C                                                                       
      DIMENSION XELE(11)                                                
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
                                                                        
C Initialize variables for fragmentation kill (IT=0) or fire kill       
C (IT=1).                                                               
                                                                        
      IF (IT .EQ. 0) THEN                                               
         XNELA = NELA                                                   
         XMAN = MAN                                                     
         XNVLE = NVLE                                                   
         DO 10 I=1,NELA                                                 
            XELE(I) = TELE(I)                                           
 10      CONTINUE                                                       
      ELSE                                                              
         XNELA = KNELA                                                  
         XMAN = KMAN                                                    
         XNVLE = KNVLE                                                  
         DO 20 I=1,KNELA                                                
            XELE(I) = FELE(I)                                           
 20      CONTINUE                                                       
      ENDIF                                                             
                                                                        
C Determine the array limits for each of the target strips.             
                                                                        
      LZM = (J1 - 1) * XMAN                                             
      LZE = (J1 - 1) * XNELA                                            
                                                                        
C If the striking angle, ZEA, is less than or equal to the smallest     
C fragment or fire kill table elevation angle, XELE(1), use the         
C smallest fragment or fire kill elevation angle, and no                
C interpolation is needed.                                              
                                                                        
      IF (ZEA .LE. XELE(1)) THEN                                        
         I = 1 + LZE                                                    
      ELSE                                                              
                                                                        
C Determine the elevation angles that bracket the striking angle        
C for fragment or fire kills.                                           
                                                                        
         DO 50 K=2,XNELA                                                
            IF (ZEA .LT. XELE(K)) THEN                                  
                                                                        
C The striking angle is greater than XELE(1) and is bracketed by        
C XELE(K) and XELE(K + 1).  Set indicator IA to locate bracket on       
C the lower elevation angle.  Set indicators IB and IC to access        
C the strip data for fragmentation kills.                               
                                                                        
               IA = K - 1                                               
               IF (IT .EQ. 0) THEN                                      
                  IB = LZE + K - 1                                      
                  IC = LZE + K                                          
               ENDIF                                                    
                                                                        
C Interpolate table values for vulnerable areas and probabilities of    
C exposure for fragmentation or fire kills, and fill the arrays XAMV or 
C FAMV and XPMV or FPMV which are used for the current range.           
                                                                        
C Note: the probability of exposures for strips are reflected in the    
C vulnerable area array, TZA (calculations done in BEGIN). Exit TEV and 
C return to MAIN.                                                       
                                                                        
               DO 40 KM=1,XMAN                                          
                  KTM = LZM + KM                                        
                  DO 30 KV=1,XNVLE                                      
                     TEMP1 = (ZEA - XELE(IA)) / (XELE(K) - XELE(IA))    
                     IF (IT .EQ. 0) THEN                                
                        XAMV(KTM,KV) = TZA(IB,KM,KV) + TEMP1 * (TZA(IC, 
     &                                 KM,KV) - TZA(IB,KM,KV))          
                        IF (NQ .NE. 1) XPMV(KTM,KV) = TPPA(IB,KM,KV) +  
     &                                        TEMP1 * (TPPA(IC,KM,KV) - 
     &                                        TPPA(IB,KM,KV))           
                     ELSE                                               
                        FAMV(KTM,KV) = FZA(IA,KM,KV) + TEMP1 * (FZA(K,  
     &                                 KM,KV) - FZA(IA,KM,KV))          
                        FPMV(KTM,KV) = FPPA(IA,KM,KV) + TEMP1 * (FPPA(K,
     &                                 KM,KV) - FPPA(IA,KM,KV))         
                     ENDIF                                              
 30               CONTINUE                                              
 40            CONTINUE                                                 
               RETURN                                                   
            ELSEIF (ZEA .EQ. XELE(K)) THEN                              
                                                                        
C The striking angle, ZEA, is equal to one of the fragment or fire kill 
C table elevation angles, XELE(K).  Use that fragment or fire kill      
C elevation angle, and no interpolation is needed.                      
                                                                        
               I = K + LZE                                              
               GOTO 60                                                  
            ENDIF                                                       
 50      CONTINUE                                                       
                                                                        
C The striking angle, ZEA, is greater than all of the fragment or fire  
C kill table elevation angles, XELE(K).  Use the largest fragment or    
C fire kill elevation angle, and no interpolation is needed.            
                                                                        
         I = XNELA + LZE                                                
      ENDIF                                                             
                                                                        
C Fill arrays for fragment or fire vulnerable areas, XAMV or FAMV,      
C and probabilities of exposure, XPMV or FPMV, for the mass-velocity    
C combinations when,                                                    
C   1) the striking angle is lower than or equal to the smallest angle  
C      in the table,                                                    
C   2) the striking angle is larger than the largest angle in the       
C      table, or                                                        
C   3) the striking angle is equal to one of the angles in the table.   
C Exit TEV and return to MAIN.                                          
                                                                        
 60   DO 80 KM=1,XMAN                                                   
         KTM = LZM + KM                                                 
         DO 70 KV=1,XNVLE                                               
            IF (IT .EQ. 0) THEN                                         
               XAMV(KTM,KV) = TZA(I,KM,KV)                              
               IF (NQ .NE. 1) XPMV(KTM,KV) = TPPA(I,KM,KV)              
            ELSE                                                        
               FAMV(KTM,KV) = FZA(I,KM,KV)                              
               FPMV(KTM,KV) = FPPA(I,KM,KV)                             
            ENDIF                                                       
 70      CONTINUE                                                       
 80   CONTINUE                                                          
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE THLS                                                   
C                                                                       
C---------------------------------------------------------------------- 
C Description:                                                          
C    Computes the angle between the weapon's trajectory path and the    
C path of the fragment from burst point to the target's height.         
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   -------        -------  -------------------------------------       
C CENT               ft     Single-point target fragment centroid.      
C                                                                       
C Q43                ft     Burst height.                               
C                                                                       
C Q6                deg    Impact angle of the weapon.                  
C                                                                       
C RAD2DEG            --     Conversion factor for radians to degrees.   
C                                                                       
C S1                 ft     Ground distance from burst point to target. 
C                                                                       
C S2                deg     Angle between weapon's trajectory path and  
C                           flight path of fragment.                    
C                                                                       
C S34               deg     Angle between flight path of fragment and   
C                           ground plane.                               
C                                                                       
C-----------------------------------------------------------------------
C SUBROUTINES REFERENCED                                                
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C FUNCTIONS REFERENCED                                                  
C                                                                       
C ZERO,ZERO1                                                            
C                                                                       
C-----------------------------------------------------------------------
C CALLING ROUTINE                                                       
C                                                                       
C CALC                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
      INCLUDE 'stdparameter_clean.inc'                                        
                                                                        
C If the impact angle = 90 and the distance from the burst point to     
C the target = 0, then the angle = 0.                                   
                                                                        
      IF ((ZERO(Q6,90.0) .EQ. 0.0) .AND. (ZERO1(S1) .EQ. 0.0)) THEN     
         S2 = 0.0                                                       
                                                                        
C If the impact angle <> 90 and the distance from the burst point to    
C the target = 0, then the angle = 90 - impact angle.                   
                                                                        
      ELSEIF (ZERO1(S1) .EQ. 0) THEN                                    
                                                                        
         If (Q43 .gt. CENT) then                                        
            S2 = 90.0 - Q6                                              
         else                                                           
            S2 = 90.0 + Q6                                              
         endif                                                          
                                                                        
C Otherwise the angle = the impact angle + the angle between the flight 
C path of the fragment and the ground plane.                            
                                                                        
      ELSE                                                              
         S34 = ATAN((CENT - Q43) / S1) * RAD2DEG                        
         S2 = ABS(S34 + Q6)                                             
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE VDRG(VOX,CMQQ,TARH,T6,VS)                              
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Computes the impact (striking) velocity of a fragment upon a target
C after  passing through air or vegetation layers.                      
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C CMQQ              grains  Fragment weight.                            
C                                                                       
C CSAL               --     Cosine of angle measured from vertical to   
C                           the slant range of the burst point to the   
C                           target. ** Only used when the burst height  
C                           is greater than the target height.          
C                                                                       
C HDT(I)             ft     Lower altitude of the ith layer of          
C                           vegetation.                                 
C                                                                       
C HTEMP              ft     Vertical distance the fragment travels      
C                           through the layers from burst point to      
C                           target.  May be either a full layer of      
C                           some portion of a layer.                    
C                                                                       
C ITP                --     Subscript of the lower boundaries of the    
C                           layers when tracing the fragment from the   
C                           burst point to the target.                  
C                                                                       
C IVCT               --     Indicator:                                  
C                             (1) Continue computations.                
C                             (2) Velocity of fragment is slower than   
C                                 cutoff velocity.  End computation.    
C                                                                       
C JTP                --     Lower bound of the layer which contains the 
C                           target.                                     
C                                                                       
C NHDT               --     Number of boundaries for all the layers.    
C                                                                       
C QH                 ft     Height of the fragment as it travels from   
C                           each layer to the target.                   
C                                                                       
C Q43                ft     Burst height.                               
C                                                                       
C RS                 ft     Distance a fragment travels through a       
C                           vegetation zone.                            
C                                                                       
C SNAL               --     Sine of angle measured from horizontal to   
C                           the slant range of the burst point to the   
C                           target. ** Only used when the target height 
C                           is greater than the burst height.           
C                                                                       
C TARH               ft     Target height.                              
C                                                                       
C T6                 ft     Slant range from burst point to target.     
C                                                                       
C VOQ              ft/sec   Initial velocity of fragment at the         
C                           beginning of each layer of medium.          
C                                                                       
C VOX              ft/sec   Average initial velocity of the fragment.   
C                                                                       
C VS               ft/sec   Impact velocity when fragment hits target.  
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C RESULT                                                                
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C SEKS                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      COMMON  / CUTVEL /  IVCT,VELCUT                                   
                                                                        
C Initialize working variables.                                         
                                                                        
      IVCT = 1                                                          
      QH = Q43                                                          
      RS = T6                                                           
      VOQ = VOX                                                         
                                                                        
C For one layer, the target and fragment are in the same layer. This is 
C used for drag in air.                                                 
                                                                        
      IF (NHDT .EQ. 1) THEN                                             
         ITP = 1                                                        
         JTP = 1                                                        
                                                                        
C For multiple layers, determine in which layer the fragment and target 
C are located.                                                          
                                                                        
      ELSE                                                              
                                                                        
C Layer where fragment is located initially.                            
                                                                        
         IF (Q43 .LE. HDT(1)) THEN                                      
            ITP = 1                                                     
         ELSE                                                           
            DO 10 I=2,NHDT                                              
               IF (Q43 .LE. HDT(I)) GOTO 20                             
 10         CONTINUE                                                    
 20         ITP = I - 1                                                 
         ENDIF                                                          
                                                                        
C Layer where target is located.                                        
                                                                        
         IF (TARH .LE. HDT(1)) THEN                                     
            JTP = 1                                                     
         ELSE                                                           
            DO 30 J=2,NHDT                                              
               IF (TARH .LE. HDT(J)) GOTO 40                            
 30         CONTINUE                                                    
 40         JTP = J - 1                                                 
         ENDIF                                                          
      ENDIF                                                             
                                                                        
C If the target's height is greater than the burst height, calculate    
C the distance from the burst point to the target and determine         
C the velocity of the fragment at that distance.                        
                                                                        
      IF (ITP .LT. JTP) THEN                                            
                                                                        
C If the burst height is greater than the target height, calculate the  
C distance the fragment must travel through each layer.                 
C ** Note: RS is calculated using similar triangles.                    
                                                                        
         SNAL = (TARH - Q43) / T6                                       
 50      HTEMP = HDT(ITP + 1) - QH                                      
 60      RS = HTEMP / SNAL                                              
                                                                        
C Determine the terminal velocity of fragment after passing through     
C layer.                                                                
                                                                        
         CALL RESULT(ITP,RS,CMQQ,VOQ,VS)                                
                                                                        
C If the fragment velocity is still greater than the cutoff velocity,   
C then goto the next layer of vegetation and recalculate the            
C fragment's velocity.                                                  
                                                                        
         IF (IVCT .EQ. 1) THEN                                          
            ITP = ITP + 1                                               
            VOQ = VS                                                    
                                                                        
C If the fragment is not in the last layer of vegetation, then move     
C the fragment into the next layer.                                     
                                                                        
            IF (ITP .LT. JTP) THEN                                      
               QH = QH + HTEMP                                          
               GOTO 50                                                  
                                                                        
C After fragment velocity has been calculated for the last vegetation   
C layer, move the fragment above the layer to determine the velocity    
C of the fragment when it hits the target.                              
                                                                        
            ELSEIF (ITP .EQ. JTP) THEN                                  
               HTEMP = TARH - QH - HTEMP                                
               GOTO 60                                                  
            ENDIF                                                       
         ENDIF                                                          
                                                                        
C If the fragment and the target are in the same layer,                 
C determine the terminal velocity of fragment after passing through     
C the layer and hitting the target.                                     
                                                                        
      ELSEIF (ITP .EQ. JTP) THEN                                        
         CALL RESULT(ITP,RS,CMQQ,VOQ,VS)                                
                                                                        
      ELSE                                                              
                                                                        
C If burst height > target height, calculate the distance the fragment  
C travels through this layer. RS is calculated using similar triangles. 
                                                                        
         CSAL = (Q43 - TARH) / T6                                       
 70      HTEMP = QH - HDT(ITP)                                          
 80      RS = HTEMP / CSAL                                              
                                                                        
C Determine the terminal velocity of fragment after passing through     
C the vegetation layer.                                                 
                                                                        
         CALL RESULT(ITP,RS,CMQQ,VOQ,VS)                                
                                                                        
C If the fragment velocity is still greater than the cutoff velocity,   
C then goto the next layer of vegetation and recalculate the            
C fragment's velocity.                                                  
                                                                        
         IF (IVCT .EQ. 1) THEN                                          
            ITP = ITP - 1                                               
            VOQ = VS                                                    
                                                                        
C If the fragment is not in the last layer of vegetation, then move     
C the fragment into the next layer.                                     
                                                                        
            IF (ITP .EQ. JTP) THEN                                      
               HTEMP = QH - HTEMP - TARH                                
               GOTO 80                                                  
                                                                        
C After fragment velocity has been calculated for the last vegetation   
C layer, move the fragment above the layer to determine the velocity    
C of the fragment when it hits the target.                              
                                                                        
            ELSEIF (ITP .GT. JTP) THEN                                  
               QH = QH - HTEMP                                          
               GOTO 70                                                  
            ENDIF                                                       
         ENDIF                                                          
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE XDRG(VOQ,CMQQ,VTQ,XTQ)                                 
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Compute the distance a fragment of a given weight moving at an     
C initial velocity would travel before reaching a cutoff velocity.      
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C   ---------       -----              ----------------                 
C ALH(NHDT,J)        --     Slope of drag curve for the jth velocity    
C                           and top layer of medium (usually air).      
C                                                                       
C BTA(NHDT,J)        --     Y Intercept of drag curve for jth velocity  
C                           and top layer of medium (usually air).      
C                                                                       
C CGAM               --     Factor used in the computation of distance  
C                           function.                                   
C                                                                       
C CMQQ              grains  Fragment weight.                            
C                                                                       
C CNDC              --      Factor used in the computation of distance  
C                           function.                                   
C                                                                       
C DXI               ft      Distance a fragment travels as its velocity 
C                           decays from an initial velocity, VOQ, to the
C                           largest velocity in the drag table which is 
C                           less than or equal to the initial velocity. 
C                                                                       
C DXT               ft      Distance a fragment travels as its velocity 
C                           decays from the smallest velocity in the    
C                           drag table which is greater than or equal   
C                           to the cutoff velocity, VTQ, to the actual  
C                           fragment cutoff velocity.                   
C                                                                       
C IIV               --      Subscript denoting the largest velocity in  
C                           the drag table which is less than or equal  
C                           to the initial fragment velocity.           
C                                                                       
C K000FX            --      Subscript denoting the smallest velocity in 
C                           the drag table which is greater than or     
C                           equal to the fragment cutoff velocity.      
C                                                                       
C NCDP              --      Number of velocities in drag table.         
C                                                                       
C NHDT              --      Number of altitudes in drag table.          
C                                                                       
C RHO(NHDT)        lb/ft3   Density of media at maximum height.         
C                                                                       
C SKT(NHDT)         --      Shape factor of fragment at maximum height. 
C                                                                       
C SUMX              ft      Sum of the distances traveled by fragment.  
C                                                                       
C ULN(NHDT,ID)      --      Factor used in computation of distance      
C                           traveled through a velocity interval.       
C                                                                       
C VCF(I)           ft/sec   Ith Velocity in drag table.                 
C                                                                       
C VHI              ft/sec   Velocity used as the lower limit in the     
C                           distance function FDIST.                    
C                                                                       
C VLO              ft/sec   Velocity used as the upper limit in the     
C                           distance function FDIST.                    
C                                                                       
C VOQ              ft/sec   Average initial velocity of the fragment.   
C                                                                       
C VTQ              ft/sec   Cutoff velocity of the fragment.            
C                                                                       
C XINT              ft      Distance a fragment travels over a given    
C                           velocity interval.                          
C                                                                       
C XTQ               ft      Entire distance the fragment traveled from  
C                           VOQ to VTQ.                                 
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C FDIST (internal)                                                      
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C DRRR                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
                                                                        
C Function used to calculate the distance a fragment travels as its     
C velocity decays from VHI and VLO.                                     
                                                                        
      FDIST(IX,VHI,VLO) = (1.0 / (BTA(NHDT,IX) * CNDC)) * LOG((VHI *    
     &                    (ALH(NHDT,IX) * VLO + BTA(NHDT,IX))) / (VLO * 
     &                    (ALH(NHDT,IX) * VHI + BTA(NHDT,IX))))         
                                                                        
C Compute a factor used in the computation of distance function.        
                                                                        
      CNDC = RHO(NHDT) * SKT(NHDT) * CMQQ *  * ( - 1.0 / 3.0)           
                                                                        
C If the initial fragment velocity is less than the velocities in the   
C drag table, then print an error.                                      
                                                                        
      IF (VOQ .LT. VCF(1)) THEN                                         
         WRITE(6,5000)'INITIAL'                                         
         CALL EXIT                                                      
      ENDIF                                                             
                                                                        
C Loop through the drag table until an interval is found that contains  
C the fragment initial velocity.  Use interval to calculate DXI.        
                                                                        
      DO 10 I=2,NCDP                                                    
                                                                        
C If the initial velocity is equal to a velocity in the drag table, the 
C distance, DXI, the fragment travels from the drag table velocity to   
C the initial vel is zero.                                              
                                                                        
         IF (VCF(I) .EQ. VOQ) THEN                                      
            IIV = I                                                     
            DXI = 0.0                                                   
            GOTO 20                                                     
                                                                        
C If the initial velocity is greater than a velocity in the drag table, 
C then use the first velocity in the drag table that is less than the   
C initial velocity to calculate the distance the fragment travels as    
C its velocity decays from its initial velocity to the drag table       
C velocity.                                                             
                                                                        
         ELSEIF (VCF(I) .GT. VOQ) THEN                                  
            IIV = I - 1                                                 
                                                                        
C If the initial velocity falls in the first velocity interval in the   
C drag table then compute the distance the fragment travels as the      
C velocity decays from the initial velocity to the cutoff velocity.     
C Exit routine. Otherwise, compute the distance the fragment travels    
C as the velocity decays from the initial velocity to the next lowest   
C velocity interval.                                                    
                                                                        
            IF (IIV .EQ. 1) THEN                                        
               XTQ = FDIST(IIV,VOQ,VTQ)                                 
               RETURN                                                   
            ENDIF                                                       
                                                                        
            DXI = FDIST(IIV,VOQ,VCF(IIV))                               
            GOTO 20                                                     
         ENDIF                                                          
 10   CONTINUE                                                          
                                                                        
C If the initial velocity is greater than all the velocities in the drag
C table, then use the largest velocity in the drag table to calculate   
C the distance the fragment travels as its velocity decays from its     
C initial velocity to the drag table's largest velocity.                
                                                                        
      IIV = NCDP                                                        
      DXI = FDIST(IIV,VOQ,VCF(IIV))                                     
                                                                        
C If the cutoff velocity is less than the velocities in the drag table, 
C then write an error message.                                          
                                                                        
 20   IF (VTQ .LT. VCF(1)) THEN                                         
         WRITE(6,5000)'CUTOFF'                                          
         CALL EXIT                                                      
      ENDIF                                                             
                                                                        
C Loop through the drag table until an interval is found that contains  
C the fragment cutoff velocity. Use interval to calculate DXT.          
                                                                        
      DO 40 I=2,NCDP                                                    
                                                                        
C If the cutoff velocity is equal to a velocity in the drag table, the  
C distance, DXT, is equal to zero.                                      
                                                                        
         IF (VCF(I) .GE. VTQ) THEN                                      
            K000FX = I - 1                                              
            DXT = 0.0                                                   
                                                                        
C If a velocity in the drag table is greater than the cutoff velocity,  
C then calculate the distance the fragment travels as its velocity      
C decays from the drag table velocity to the cutoff velocity.           
                                                                        
            IF (VCF(I) .GT. VTQ) DXT = FDIST(K000FX,VCF(K000FX + 1),    
     &                                 VTQ)                             
                                                                        
C If the initial velocity is less than the cutoff velocity, then print  
C an error.                                                             
                                                                        
            IF (IIV .LT. K000FX) THEN                                   
               WRITE(6,5010)                                            
               CALL EXIT                                                
                                                                        
C Calculate the total distance, XTQ, the fragment would have to travel  
C through the computed number of velocity intervals in the drag table.  
                                                                        
            ELSEIF (IIV .GT. K000FX) THEN                               
               SUMX = DXT + DXI                                         
               IF ((IIV-1) .GE. (K000FX+1)) THEN                        
                  DO 30 ID=(K000FX+1),(IIV-1)                           
                     CGAM = 1.0 / (BTA(NHDT,ID) * CNDC)                 
                     XINT =  - CGAM * ULN(NHDT,ID)                      
                     SUMX = SUMX + XINT                                 
 30               CONTINUE                                              
               ENDIF                                                    
               XTQ = SUMX                                               
               RETURN                                                   
                                                                        
C If the initial velocity and cutoff velocity are within the same       
C drag table interval, calculate the distance the fragment travels as   
C its velocity decays from its initial velocity to the cutoff velocity. 
                                                                        
            ELSE                                                        
               XTQ = FDIST(IIV,VOQ,VTQ)                                 
               RETURN                                                   
            ENDIF                                                       
         ENDIF                                                          
 40   CONTINUE                                                          
                                                                        
C If the cutoff velocity is less than all the velocities in the drag    
C table, calculate the distance the fragment travels as  its velocity   
C decays from its initial velocity to the cutoff velocity.              
                                                                        
      XTQ = FDIST(IIV,VOQ,VTQ)                                          
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (' %-ERROR- SUBR=XDRG, POSSIBLE ERROR IN DRAG CURVE',      
     &        ' VELOCITIES, A FRAGMENT ',A,                             
     &        ' VELOCITY IS LESS THAN FIRST',' VELOCITY IN DRAG TABLE') 
 5010 FORMAT (' %-ERROR- SUBR=XDRG, CUTOFF VELOCITY IS COMPUTED AS',    
     &        ' GREATER THAN INITIAL VELOCITY')                         
      END                                                               
C --------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE YAC1                                                   
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    This subroutine applies impact velocity to the weapon static       
C    fragmentation zones and creates vectored static fragmentation      
C    zones.                                                             
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C A1(K)            ft/sec   K=1, JC1                                    
C                           Initial velocity of the fragments at the    
C                           lower boundary of the kth static zone.      
C                                                                       
C A2(K)            ft/sec   K = 1,JC1                                   
C                           Initial fragment velocity at middle boundary
C                           of Kth static zone.                         
C                                                                       
C A3(K)            ft/sec   K = 1,JC1                                   
C                           Initial fragment velocity at upper boundary 
C                           of Kth static zone.                         
C                                                                       
C B1(K)              deg    K=1, JC1.                                   
C                           Angle defining the lower boundary of the kth
C                           static zone.                                
C                                                                       
C B2(K)             deg     K = 1,JC1.                                  
C                           Angle defining the middle boundary of the Kt
C                           static zone.                                
C                                                                       
C B3(K)              deg    K=1, JC1.                                   
C                           Angle defining the upper boundary of the kth
C                           static zone.                                
C                                                                       
C B10               deg     Resultant lower boundary angle of the       
C                           vectored static zone.                       
C                                                                       
C B11               deg     Resultant upper boundary angle of the       
C                           vectored static zone.                       
C                                                                       
C B12               deg     Resultant middle boundary angle of the      
C                           vectored static zone.                       
C                                                                       
C C1(I)             ft/sec  I = 1,JC1.                                  
C                           Average initial fragment velocity, Ith      
C                           zone.                                       
C                                                                       
C C2               ft/sec   Weapon impact velocity.                     
C                                                                       
C C4               ft/sec   Resultant lower boundary fragment velocity. 
C                                                                       
C C5               ft/sec   Resultant upper boundary fragment velocity. 
C                                                                       
C C6               ft/sec   Resultant middle boundary fragment velocity.
C                                                                       
C F1                 --     Cosine of the upper static angle. Used for  
C                           calculation of steradians.                  
C                                                                       
C F2                 --     Cosine of lower static angle. Used for      
C                           calculation of steradians.                  
C                                                                       
C G1(K)             deg     J = 1,50                                    
C                           Smallest vectored static angle for the      
C                           Kth zone.                                   
C                                                                       
C G2(K)             deg     J = 1,50                                    
C                           Largest vectored static angle for the       
C                           Kth zone.                                   
C                                                                       
C JC1                --     Total number of static fragmentation zones. 
C                                                                       
C P1                 --     Sine of static lower angle.                 
C                                                                       
C P2                 --     Cosine of resultant lower angle. The        
C                           resultant lower angle is the lower static   
C                           zone angle with impact velocity applied.    
C                                                                       
C P3                 --     Sine of static upper angle.                 
C                                                                       
C P4                 --     Cosine of resultant upper angle. The        
C                           resultant upper angle is the upper static   
C                           zone angle with impact velocity applied.    
C                                                                       
C P5                 --     Sine of static middle angle.                
C                                                                       
C P6                 --     Cosine of resultant middle angle. The       
C                           resultant middle angle is the middle static 
C                           zone angle with impact velocity applied.    
C                                                                       
C PLF1(K)            ft     K=1,50                                      
C                           Distance along the weapon axis from         
C                           centroid of the weapon to the lower         
C                           boundary of the Kth static zone.            
C                                                                       
C PLF2(K)            ft     K=1,50                                      
C                           Distance along the weapon axis from         
C                           centroid of the weapon to the middle        
C                           boundary of the Kth static zone.            
C                                                                       
C PLF3(K)            ft     K=1,50                                      
C                           Distance along the weapon axis from         
C                           centroid of the weapon to the upper         
C                           boundary of the Kth static zone.            
C                                                                       
C PLT1(K)            ft     K=1,50                                      
C                           Distance along the weapon axis from         
C                           centroid of the weapon to the lower         
C                           boundary of the Kth static zone.            
C                                                                       
C PLT2(K)            ft     K=1,50                                      
C                           Distance along the weapon axis from         
C                           centroid of the weapon to the upper         
C                           boundary of the Kth static zone.            
C                                                                       
C RF1(K)             ft     K=1,50                                      
C                           Weapon casing radius at the lower           
C                           boundary of the Kth dynamic zone.           
C                                                                       
C RF2(K)             ft     K=1,50                                      
C                           Weapon casing radius at the upper           
C                           boundary of the Kth dynamic zone.           
C                                                                       
C RPF1(K)            ft     K=1,50                                      
C                           Weapon radius at the lower boundary of      
C                           the Kth static zone.                        
C                                                                       
C RPF2(K)            ft     K=1,50                                      
C                           Weapon radius at the middle boundary of     
C                           the Kth static zone.                        
C                                                                       
C RPF3(K)            ft     K=1,50                                      
C                           Weapon radius at the upper boundary of      
C                           the Kth static zone.                        
C                                                                       
C S(I)               --     Number of steradians, Ith dynamic zone.     
C                                                                       
C-----------------------------------------------------------------------
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C ZERO1                                                                 
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
                                                                        
      INCLUDE 'stdparameter_clean.inc'                                        
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      COMMON / ABUR / GMUP,GMLO,RF1(50),RF2(50),PLT1(50),PLT2(50)       
      COMMON / BBUR / RPF1(50),RPF2(50),RPF3(50),PLF1(50),PLF2(50),     
     &       PLF3(50)                                                   
                                                                        
C If impact velocity = 0 then dynamic zones = static zones              
                                                                        
      IF (C2 .EQ. 0.) THEN                                              
         DO 10 J=1,JC1                                                  
                                                                        
C Set upper (G2) and lower (G1) angles of static zone.                  
                                                                        
            G1(J) = B1(J)                                               
            G2(J) = B3(J)                                               
                                                                        
C Set burial radii and locations for the upper and lower static zone    
C angle.                                                                
                                                                        
            RF1(J) = RPF1(J)                                            
            RF2(J) = RPF3(J)                                            
            PLT1(J) = PLF1(J)                                           
            PLT2(J) = PLF3(J)                                           
                                                                        
C Set fragment velocities at each angle.                                
                                                                        
            C4 = A1(J)                                                  
            C5 = A3(J)                                                  
            C6 = A2(J)                                                  
                                                                        
C Compute the Steradians (S) for each zone.                             
                                                                        
            F1 = COS(G1(J) * DEG2RAD)                                   
            F2 = COS(G2(J) * DEG2RAD)                                   
            S(J) = 2.0 * PI * (F1 - F2)                                 
                                                                        
C Average fragment velocities at each angle.                            
                                                                        
            C1(J) = (C4 + C5 + C6) / 3.0                                
  10      CONTINUE                                                      
      ELSE                                                              
                                                                        
C Impact velocity not equal to 0.                                       
                                                                        
         DO 30 J=1,JC1                                                  
                                                                        
C Find SIN and COS of lower, upper, and middle angles.                  
                                                                        
            P1 = SIN(B1(J) * DEG2RAD)                                   
            P2 = COS(B1(J) * DEG2RAD)                                   
            P3 = SIN(B3(J) * DEG2RAD)                                   
            P4 = COS(B3(J) * DEG2RAD)                                   
            P5 = SIN(B2(J) * DEG2RAD)                                   
            P6 = COS(B2(J) * DEG2RAD)                                   
                                                                        
C SIN of lower angle = 0 then lower angle = 0                           
                                                                        
            IF (B1(J) .EQ. 0.) THEN                                     
               B10 = 0.0                                                
            ELSE                                                        
                                                                        
C P2 is cosine of the resultant angle.                                  
C P2 = Cos(Static angle) + Impact Vel / Fragment Velocity.              
C If COS of lower resultant angle = 0 then lower angle = 90.            
                                                                        
               P2 = P2 + (C2 / A1(J))                                   
               IF (ZERO1(P2) .EQ. 0.) THEN                              
                  B10 = 90.0                                            
               ELSE                                                     
                                                                        
C Compute resultant lower angle. Adjust to positive angle if necessary. 
                                                                        
                  B10 = ATAN(P1 / P2) / DEG2RAD                         
                  IF (B10 .LT. 0.) B10 = B10 + 180.0                    
               ENDIF                                                    
            ENDIF                                                       
                                                                        
C SIN of upper angle = 0 then upper angle = 180                         
                                                                        
            IF (B3(J) .EQ. 180.) THEN                                   
               B11 = 180.0                                              
            ELSE                                                        
                                                                        
C P4 is cosine of the resultant angle.                                  
C P4 = Cos(Static angle) + Impact Vel / Fragment Velocity.              
C If COS of upper angle = 0 then lower angle = 90.                      
                                                                        
               P4 = P4 + (C2 / A3(J))                                   
               IF (ZERO1(P4) .EQ. 0.) THEN                              
                  B11 = 90.0                                            
               ELSE                                                     
                                                                        
C Compute resultant upper angle.                                        
                                                                        
                  B11 = ATAN(P3 / P4) / DEG2RAD                         
                                                                        
C Adjust to positive angle if necessary.                                
                                                                        
                  IF (B11 .LT. 0.) B11 = B11 + 180.0                    
               ENDIF                                                    
            ENDIF                                                       
                                                                        
C P6 is cosine of the resultant angle.                                  
C P6 = Cos(Static angle) + Impact Vel / Fragment Velocity.              
C If COS of middle angle = 0 then lower angle = 90.                     
                                                                        
            P6 = P6 + (C2 / A2(J))                                      
            IF (ZERO1(P6) .EQ. 0.) THEN                                 
               B12 = 90.0                                               
            ELSE                                                        
                                                                        
C Compute resultant middle angle                                        
                                                                        
               B12 = ATAN(P5 / P6) / DEG2RAD                            
                                                                        
C Adjust to positive angle if necessary                                 
                                                                        
               IF (B12 .LT. 0.) B12 = B12 + 180.0                       
            ENDIF                                                       
                                                                        
C Find the maximum and minimum angles for each zone and store in G1 and 
C G2.                                                                   
C If lower angle .lt. middle angle                                      
                                                                        
            IF (B10 .LT. B12) THEN                                      
                                                                        
C If lower .lt. upper                                                   
                                                                        
               IF (B10 .LT. B11) THEN                                   
                                                                        
C Set lower boundary of Jth dynamic zone.                               
                                                                        
                  G1(J) = B10                                           
                  RF1(J) = RPF1(J)                                      
                  PLT1(J) = PLF1(J)                                     
                                                                        
C If middle .lt. upper                                                  
                                                                        
                  IF (B12 .LT. B11) THEN                                
                                                                        
C set upper boundary of Jth dynamic zone.                               
                                                                        
                     G2(J) = B11                                        
                     RF2(J) = RPF3(J)                                   
                     PLT2(J) = PLF3(J)                                  
                  ELSE                                                  
                                                                        
C If middle .eq. upper                                                  
                                                                        
                     IF (B12 .EQ. B11) THEN                             
                                                                        
C Set boundaries of Jth dynamic zone.                                   
                                                                        
                        G1(J) = B10                                     
                        RF1(J) = RPF1(J)                                
                        PLT1(J) = PLF1(J)                               
                        G2(J) = B11                                     
                        RF2(J) = RPF3(J)                                
                        PLT2(J) = PLF3(J)                               
                     ELSE                                               
                                                                        
C Set upper boundary of Jth dynamic zone.                               
                                                                        
                        G2(J) = B12                                     
                        RF2(J) = RPF2(J)                                
                        PLT2(J) = PLF2(J)                               
                     ENDIF                                              
                  ENDIF                                                 
               ELSE                                                     
                                                                        
C If lower .eq. upper                                                   
                                                                        
                  IF (B10 .EQ. B11) THEN                                
                                                                        
C Set zone boundaries of Jth dynamic zone.                              
                                                                        
                     G1(J) = B10                                        
                     G2(J) = B12                                        
                     RF1(J) = RPF1(J)                                   
                     PLT1(J) = PLF1(J)                                  
                     RF2(J) = RPF2(J)                                   
                     PLT2(J) = PLF2(J)                                  
                  ELSE                                                  
                                                                        
C Lower .gt. upper - Set zone boundries of Jth dynamic zone.            
                                                                        
                     G1(J) = B11                                        
                     RF1(J) = RPF3(J)                                   
                     PLT1(J) = PLF3(J)                                  
                     G2(J) = B12                                        
                     RF2(J) = RPF2(J)                                   
                     PLT2(J) = PLF2(J)                                  
                  ENDIF                                                 
               ENDIF                                                    
            ELSE                                                        
                                                                        
C If lower .eq. middle                                                  
                                                                        
               IF (B10 .EQ. B12) THEN                                   
                                                                        
C If lower .lt. upper                                                   
                                                                        
                  IF (B10 .LT. B11) THEN                                
                                                                        
C Set zone boundaries of Jth dynamic zone.                              
                                                                        
                     G1(J) = B10                                        
                     RF1(J) = RPF1(J)                                   
                     PLT1(J) = PLF1(J)                                  
                     G2(J) = B11                                        
                     RF2(J) = RPF3(J)                                   
                     PLT2(J) = PLF3(J)                                  
                  ELSE                                                  
                                                                        
C If lower .eq. upper                                                   
                                                                        
                     IF (B10 .EQ. B11) THEN                             
                                                                        
C All angles equal, set to 180 (no zone) and evaluate next zone.        
                                                                        
                        G1(J) = 180.0                                   
                        G2(J) = 180.0                                   
                        RF1(J) = RPF1(J)                                
                        RF2(J) = RPF3(J)                                
                        PLT1(J) = PLF1(J)                               
                        PLT2(J) = PLF3(J)                               
                        GOTO 30                                         
                     ELSE                                               
                                                                        
C Lower .gt. upper - Set zone boundaries of Jth dynamic zone.           
                                                                        
                        G1(J) = B11                                     
                        RF1(J) = RPF3(J)                                
                        PLT1(J) = PLF3(J)                               
                        G2(J) = B10                                     
                        RF2(J) = RPF1(J)                                
                        PLT2(J) = PLF1(J)                               
                     ENDIF                                              
                  ENDIF                                                 
               ELSE                                                     
                                                                        
C If upper .le. middle                                                  
                                                                        
                  IF (B11 .LE. B12) THEN                                
                                                                        
C Set zone boundaries of Jth dynamic zone.                              
                                                                        
                     G1(J) = B11                                        
                     RF1(J) = RPF3(J)                                   
                     PLT1(J) = PLF3(J)                                  
                     G2(J) = B10                                        
                     RF2(J) = RPF1(J)                                   
                     PLT2(J) = PLF1(J)                                  
                  ELSE                                                  
                                                                        
C If lower .lt. upper                                                   
                                                                        
                     IF (B10 .LT. B11) THEN                             
                                                                        
C Set zone boundaries of Jth dynamic zone.                              
                                                                        
                        G1(J) = B12                                     
                        PLT1(J) = PLF2(J)                               
                        RF1(J) = RPF2(J)                                
                        G2(J) = B11                                     
                        RF2(J) = RPF3(J)                                
                        PLT2(J) = PLF3(J)                               
                     ELSE                                               
                                                                        
C Lower .gt. upper - Set zone boundaries of Jth dynamic zone.           
                                                                        
                        G1(J) = B12                                     
                        G2(J) = B10                                     
                        RF1(J) = RPF2(J)                                
                        PLT1(J) = PLF2(J)                               
                        RF2(J) = RPF1(J)                                
                        PLT2(J) = PLF1(J)                               
                     ENDIF                                              
                  ENDIF                                                 
               ENDIF                                                    
            ENDIF                                                       
                                                                        
C Compute the Steradians for the dynamic zone.                          
                                                                        
            F1 = COS(G1(J) * DEG2RAD)                                   
            F2 = COS(G2(J) * DEG2RAD)                                   
            S(J) = 2.0 * PI * (F1 - F2)                                 
                                                                        
C Find resultant velocity for lower angle.                              
                                                                        
            IF (ZERO1(B1(J)) .EQ. 0.) THEN                              
               C4 = A1(J) + C2                                          
            ELSE                                                        
               C4 = A1(J) * SIN(B1(J) * DEG2RAD) / SIN(B10 * DEG2RAD)   
            ENDIF                                                       
                                                                        
C Find resultant velocity for upper angle.                              
                                                                        
            IF (B3(J) .EQ. 180.0) THEN                                  
               C5 = A3(J) - C2                                          
            ELSE                                                        
               C5 = A3(J) * SIN(B3(J) * DEG2RAD) / SIN(B11 * DEG2RAD)   
            ENDIF                                                       
                                                                        
C Find resultant velocity for middle angle.                             
                                                                        
            C6 = A2(J) * SIN(B2(J) * DEG2RAD) / SIN(B12 * DEG2RAD)      
                                                                        
C Compute average resultant velocity.                                   
                                                                        
            C1(J) = (C4 + C5 + C6) / 3.0                                
 30      CONTINUE                                                       
      ENDIF                                                             
      RETURN                                                            
      END                                                               
C --------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE YAC2                                                   
C                                                                       
C --------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    This subroutine arranges the smallest and largest vectored angles  
C in each zone in ascending order.  All distinct zones and overlapped   
C zones are reordered and the resultant zones, called dynamic zones,    
C are stored in array GS.                                               
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C ---------------  -------  --------------------------------------------
C G1(K)             deg     J = 1,50                                    
C                           Smallest vectored static angle for the      
C                           Kth zone.                                   
C                                                                       
C G2(K)             deg     J = 1,50                                    
C                           Largest vectored static angle for the       
C                           Kth zone.                                   
C                                                                       
C G3(K)             deg     J = 1,100                                   
C                           Array containing zone boundary angles.      
C                                                                       
C G4(K)             deg     J = 1,100                                   
C                           Sorted (ascending) G3 array.                
C                                                                       
C G5(K)             deg     J = 1,100                                   
C                           Reordered non-overlapping and overlapping   
C                           zones (dynamic zones).                      
C                                                                       
C JCX                --     2 X Number of static zones.                 
C                                                                       
C JCY                --     2 X Number of static zones.                 
C                                                                       
C JC1                --     Number of static zones.                     
C                                                                       
C KMAX               --     Number of distinct dynamic fragmentation    
C                           zones.                                      
C                                                                       
C-----------------------------------------------------------------------
C Subroutines Called                                                    
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Functions Called                                                      
C                                                                       
C NONE                                                                  
C                                                                       
C-----------------------------------------------------------------------
C Calling Routine                                                       
C                                                                       
C MAIN                                                                  
C                                                                       
C-----------------------------------------------------------------------
C                                                                       
      DIMENSION G3(100),G4(100)                                         
C                                                                       
      INCLUDE 'lacommon_clean.inc'                                            
                                                                        
      I10 = 1                                                           
                                                                        
C Load dynamic angles into G3                                           
                                                                        
      DO 10 J=1,JC1                                                     
         G3(I10) = G1(J)                                                
         G3(I10 + 1) = G2(J)                                            
         I10 = I10 + 2                                                  
 10   CONTINUE                                                          
      JCX = 2 * JC1                                                     
      JCY = 2 * JC1                                                     
      I11 = 1                                                           
                                                                        
C Sort G3 into ascending order and load into G4.                        
                                                                        
      DO 30 JCX=2 * JC1,2, - 1                                          
         G4(I11) = G3(1)                                                
         I12 = 1                                                        
         DO 20 I10=2,JCX                                                
            IF (G3(I10) .LT. G4(I11)) THEN                              
               G4(I11) = G3(I10)                                        
               I12 = I10                                                
            ENDIF                                                       
 20      CONTINUE                                                       
         G3(I12) = G3(JCX)                                              
         I11 = I11 + 1                                                  
 30   CONTINUE                                                          
                                                                        
      G4(JCY) = G3(1)                                                   
      G5(1) = G4(1)                                                     
      I11 = 2                                                           
      KMAX = 1                                                          
      JCY = JCY - 1                                                     
                                                                        
C Delete duplicates and load result into G5.                            
                                                                        
      DO 40 I10=1,JCY                                                   
         IF (G4(I10) .NE. G4(I10 + 1)) THEN                             
            G5(I11) = G4(I10 + 1)                                       
                                                                        
C Set KMAX to number of dynamic frag zones.                             
                                                                        
            KMAX = I11                                                  
            I11 = I11 + 1                                               
         ENDIF                                                          
 40   CONTINUE                                                          
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      SUBROUTINE ZONE                                                   
C                                                                       
C---------------------------------------------------------------------- 
C DESCRIPTION:  This subroutine prints warhead fragmentation data (if   
C               OUTP option is selected) and calls subroutine DRRR to   
C               calculate the maximum effective range for each weight   
C               group.                                                  
C VARIABLES:                                                            
C     Name          Units                  Definition                   
C ---------------  -------  --------------------------------------------
C A(I)             sq ft    I=1, ICJ2.  Presented area, ith weight      
C                           group.                                      
C                                                                       
C A1(I)            ft/sec   I=1, JC1.  Initial velocity of the fragments
C                           at the lower boundary of the ith static     
C                           zone.                                       
C                                                                       
C A3(I)            ft/sec   I=1, JC1.  Initial velocity of the fragments
C                           at the upper boundary of the ith static     
C                           zone.                                       
C                                                                       
C B1(I)              deg    I=1, JC1.  Angle defining the lower boundary
C                           of the ith static zone.                     
C                                                                       
C B3(I)              deg    I=1, JC1.  Angle defining the upper boundary
C                           of the ith static zone.                     
C                                                                       
C CKQ                --     Shape factor for the fragments.             
C                           Units are:  ft^(2)gr^(1/3)/lb               
C                                                                       
C C1(I)            ft/sec   I=1, JC1.  Average initial vectored fragment
C                           velocity, ith zone.                         
C                                                                       
C D1(I,J)            --     I=1, ICJ2; J=1, JC1.  Number of fragments,  
C                           ith weight group, jth static zone.          
C                                                                       
C D2(I,J)          grains   I=1, ICJ2; J=1, JC1.  Fragment weight, ith  
C                           weight group, jth static zone.              
C                                                                       
C G1(I)              deg    I=1, JC1.  Smallest of the three vectored   
C                           static angles, ith zone.                    
C                                                                       
C G2(I)              deg    I=1, JC1.  Largest of the three vectored    
C                           static angles, ith zone.                    
C                                                                       
C H1(I)              ft     I=1, JC1.  Maximum range, ith vectored      
C                           static zone.                                
C                                                                       
C ICJ2               --     Temporary storage for IC2(K), number of     
C                           weight groups in a particular static zone.  
C                                                                       
C IC2(I)             --     I=1, JC1.  Number of weight groups in the   
C                           ith static zone.                            
C                                                                       
C IOUT               --     Indicator:                                  
C                           TRUE  - Warhead fragmentation data will be  
C                                   printed.                            
C                           FALSE - Warhead fragmentation data will NOT 
C                                   be printed.                         
C                                                                       
C JC1                --     Total number of static fragmentation zones. 
C                                                                       
C RM(I)              ft     I=1, ICJ2.  Maximum range, ith weight group,
C                           particular static zone.                     
C                                                                       
C WZ4(I,J)         ft/sec   I=1, ICJ2; J=1, JC1.  Cutoff velocity, ith  
C                           weight group, jth static zone.              
C                                                                       
C---------------------------------------------------------------------- 
C Subroutines called:                                                   
C                                                                       
C  DRRR                                                                 
C---------------------------------------------------------------------- 
C Functions called:                                                     
C                                                                       
C  NONE                                                                 
C---------------------------------------------------------------------- 
C Calling routine:                                                      
C                                                                       
C  MAIN                                                                 
C---------------------------------------------------------------------- 
C                                                                       
      LOGICAL IOUT,NT9                                                  
      DIMENSION A(25),RM(25)                                            
      INCLUDE 'lacommon_clean.inc'                                            
C                                                                       
      COMMON  / ALT1 /  COTM,D1I(50),IOUT,ND,NTRE,NT9,RATF(13)          
                                                                        
      DO 30 K=1,JC1                                                     
                                                                        
C Set ICJ2 to compute the maximum effective range for the largest       
C fragment weight in each zone.                                         
                                                                        
         ICJ2 = 1                                                       
                                                                        
C If the warhead fragmentation data output option is selected compute   
C the presented area, A, of each weight group where CKQ is the shape    
C factor for the fragments and D2 is the mass.                          
                                                                        
         IF (IOUT) THEN                                                 
                                                                        
            ICJ2 = IC2(K)                                               
            DO 10 I=1,ICJ2                                              
               A(I) = D2(I,K) *  * (2. / 3.) * CKQ / 7000.0             
 10         CONTINUE                                                    
                                                                        
C Print the static angles that define zone boundaries, B1 and B2, the   
C average initial fragment velocity at the boundary angles, A1 and A2,  
C the angles after vectoring due to velocity of the weapon, G1 and G2,  
C and the average initial vectored fragment velocity, C1.               
                                                                        
            IF (IP .NE. ' ') WRITE(6,5000)B1(K),B3(K),A1(K),A3(K),G1(K),
     &                                       G2(K),C1(K)                
         ENDIF                                                          
                                                                        
C Call subroutine DRRR to compute the maximum effective range, RM, for  
C each weight group.  Only the first weight group, is necessary when    
C no output is selected.                                                
                                                                        
         CALL DRRR(K,RM,ICJ2)                                           
                                                                        
C If the warhead fragmentation data output option is selected print     
C the weight of the fragments, D2, number of fragments, D1,  cutoff     
C velocity, WZ4, maximum effective range, RM, and presented area, A.    
                                                                        
         IF (IOUT) THEN                                                 
            DO 20 I=1,ICJ2                                              
               IF (IP .NE. ' ') WRITE(6,5010)D2(I,K),D1(I,K),WZ4(I,K),  
     &                                        RM(I),A(I)                
 20         CONTINUE                                                    
         ENDIF                                                          
                                                                        
C Set the maximum effective range for the kth vectored static zone, H1. 
C The largest weight group is stored first, and its maximum effective   
C range is used for the entire kth zone.                                
                                                                        
         H1(K) = RM(1)                                                  
 30   CONTINUE                                                          
                                                                        
C Computations are completed for all static fragmentation zones.  Exit  
C from ZONE and return to MAIN.                                         
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT ('0',1X,57('=='),/,11X,'STATIC ANGLES',16X,                
     &        'STATIC VELOCITIES',14X,'DYNAMIC ANGLES',8X,              
     &        'DYNAMIC VELOCITY',/,13X,' DEGREES ',21X,' FT./SEC. ',20X,
     &        ' DEGREES ',13X,' FT./SEC. ',//,4X,3(F10.2,3X,F10.2,7X),  
     &        F10.2,/,57('--'),/,11X,'MASS',12X,'NUMBER',11X,'CUT-OFF ' 
     &        'VELOCITY',8X,'MAX RANGE',8X,'PRESENTED AREA'/10X,'GRAINS'
     &       ,7X,'OF FRAGMENTS',13X,'FT./SEC.',15X,'FT.',14X,           
     &        'SQUARE FT.')                                             
 5010 FORMAT (5X,F10.2,3(7X,F10.2,5X),F15.7)                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      FUNCTION BINT(A1,A2,B1,B2,C)                                      
C                                                                       
C---------------------------------------------------------------------- 
C DESCRIPTION:  This subroutine interpolates to produce the             
C               appropriate buried weapon segment radius or location.   
C                                                                       
C               NOTE:  The following figure shows an example of the     
C               segment locations and radii for a buried weapon.        
C                                                                       
C           Segment locations (measured from centroid, noted by x)      
C  Segment # -->    (1)  (2)      (3)    (4)  (5)   (6)                 
C                                                                       
C                  4.0  2.75      .5   -1.5 -2.5  -4.0                  
C                                                                       
C                          |       | 0.0   |   |                        
C                    |---------------x---------------|                  
C                     .2   |.4     |.55    |.5 |.45   .4                
C                                                                       
C                             Segment radii                             
C                                                                       
C VARIABLES:                                                            
C     Name          Units                  Definition                   
C ---------------  -------  --------------------------------------------
C A1                        Interpolation variable:                     
C                   deg       1) Angle defining the lower boundary of   
C                                the static zone, or                    
C                    ft       2) Weapon segment location (measured      
C                                from the centroid) corresponding to the
C                                angle defining the lower boundary of   
C                                the static zone.                       
C                                                                       
C A2                        Interpolation variable:                     
C                   deg       1) Angle defining the upper boundary of   
C                                the static zone, or                    
C                    ft       2) Weapon segment location (measured      
C                                from the centroid) corresponding to the
C                                angle defining the upper boundary of   
C                                the static zone.                       
C                                                                       
C BINT               ft      Weapon segment radius or location          
C                            (measured from the centroid) corresponding 
C                            to interpolation variable C.               
C                                                                       
C B1                 ft     Interpolation variable:                     
C                              Weapon segment radius or location        
C                              (measured from the centroid)             
C                              corresponding to the angle defining the  
C                              lower boundary of the static zone.       
C                                                                       
C B2                 ft     Interpolation variable:                     
C                              Weapon segment radius or location        
C                              (measured from the centroid)             
C                              corresponding to the angle defining the  
C                              upper boundary of the static zone.       
C                                                                       
C C                         Interpolation variable:                     
C                   deg        1) Angle between weapon's trajectory path
C                                 and flight path of fragment,          
C                   deg        2) Angle between the weapon trajectory   
C                                 and the line connecting the weapon and
C                                 target centroids.                     
C                   deg        3) Angle midway between the angles       
C                                 defining the lower and upper          
C                                 boundaries of the static zone,        
C                    ft        4) Weapon segment location (measured     
C                                 from the centroid) for the angle      
C                                 defining the lower, middle, or upper  
C                                 boundary of the static zone,          
C---------------------------------------------------------------------- 
C Subroutines called:                                                   
C                                                                       
C  NONE                                                                 
C---------------------------------------------------------------------- 
C Functions called:                                                     
C                                                                       
C  ROUND                                                                
C---------------------------------------------------------------------- 
C Calling routine:                                                      
                                                                        
C  PARBUR                                                               
C---------------------------------------------------------------------- 
                                                                        
      IF (ROUND(A1,6) .NE. ROUND(A2,6)) THEN                            
                                                                        
C A1 does NOT equal A2, therefore interpolation is needed to compute    
C the value for BINT.                                                   
                                                                        
         BINT = ((B1 - B2) / (A1 - A2)) * (C - A2) + B2                 
      ELSE                                                              
                                                                        
C A1 equals A2, therefore no interpolation is needed, and BINT is set   
C equal to B1.                                                          
                                                                        
         BINT = B1                                                      
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      FUNCTION ROUND(VAR,NDEC)                                          
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    The real number 'VAR' will be rounded to 'NDEC' decimal places.    
C                                                                       
C Variables:                                                            
C     Name          Units                 Definitions                   
C CHAR_NDEC          --     Character used to hold Integer 'NDEC'.      
C                                                                       
C CHAR_VAR           --     Character used to hold Real 'VAR'.          
C                                                                       
C FMT                --     Representative of the variable format       
C                           statement.                                  
C                                                                       
C NDEC               --     Number of decimal places desired after      
C                           rounding is complete.                       
C                                                                       
C VAR                --     Real value to be rounded.                   
C---------------------------------------------------------------------- 
C                                                                       
      CHARACTER*20 CHAR_VAR                                             
      CHARACTER*8 FMT                                                   
      CHARACTER*1 CHAR_NDEC                                             
                                                                        
C If NDEC is negative or larger than the format statement can           
C represent, then the function equals the original real number.         
                                                                        
      TEMP = VAR                                                        
                                                                        
      IF ((NDEC .GE. 0) .AND. (NDEC .LE. 9)) THEN                       
         WRITE(CHAR_NDEC,5000)NDEC                                      
                                                                        
C Build format according to number of decimal places to round real.     
                                                                        
         FMT = '(F10.' // CHAR_NDEC // ')'                              
                                                                        
         WRITE(CHAR_VAR,FMT)VAR                                         
         READ(CHAR_VAR, * )TEMP                                         
                                                                        
      ENDIF                                                             
                                                                        
      ROUND = TEMP                                                      
                                                                        
      RETURN                                                            
                                                                        
 5000 FORMAT (I1)                                                       
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      FUNCTION SHADE(I)                                                 
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Initializes SHADE with values for distances from weapon to target  
C and percentage of target exposed for temperate forests and tropical   
C forests.                                                              
C                                                                       
C---------------------------------------------------------------------- 
                                                                        
      DIMENSION A(73)                                                   
                                                                        
      DATA A /                                                          
                                                                        
C Number of distances and associated percentage of exposure for         
C temperate and tropical forests.                                       
                                                                        
     &   24.0,                                                          
                                                                        
C Distances that the weapon is from the target.                         
                                                                        
     &   0.0,   1.0,   5.0,  10.0,  20.0,  25.0,  30.0,  40.0,          
     &  50.0,  60.0,  70.0,  75.0,  80.0,  90.0, 100.0, 125.0,          
     & 150.0, 175.0, 200.0, 225.0, 250.0, 275.0, 300.0,1000.0,          
                                                                        
C Percentage of the target not shielded by temperate forest.            
                                                                        
     & 1.000, 1.000, 0.989, 0.941, 0.891, 0.861, 0.822, 0.767,          
     & 0.719, 0.661, 0.619, 0.597, 0.575, 0.533, 0.491, 0.409,          
     & 0.337, 0.279, 0.232, 0.192, 0.158, 0.132, 0.110, 0.000,          
                                                                        
C Percentage of the target not shielded by tropical forest.             
                                                                        
     & 1.000, 1.000, 0.970, 0.905, 0.810, 0.773, 0.740, 0.678,          
     & 0.618, 0.570, 0.520, 0.500, 0.480, 0.440, 0.410, 0.340,          
     & 0.280, 0.220, 0.180, 0.150, 0.120, 0.100, 0.080, 0.000/          
                                                                        
      SHADE=A(I)                                                        
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      FUNCTION ZERO(X,Y)                                                
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    Purpose of this function is to compare two real numbers to         
C determine if they are close enough together to be considered the      
C same value. If the difference of the two reals are less than or       
C equal to .000001 then the numbers are considered to be equal, the     
C function returns a zero.  Otherwise the function returns the          
C difference of the two reals.                                          
                                                                        
C---------------------------------------------------------------------- 
                                                                        
      IF (ABS(X - Y) .LE. 1.0E - 6) THEN                                
         ZERO = 0.                                                      
      ELSE                                                              
         ZERO = X - Y                                                   
      ENDIF                                                             
                                                                        
      RETURN                                                            
      END                                                               
C---------------------------------------------------------------------- 
C                                                                       
      FUNCTION ZERO1(X)                                                 
C                                                                       
C---------------------------------------------------------------------- 
C                                                                       
C Description:                                                          
C    This function tests number magnitude. If the number is smaller     
C than 1E-06 then the function is set to zero.                          
                                                                        
C---------------------------------------------------------------------- 
                                                                        
      ZERO1 = X                                                         
      IF (ABS(ZERO1) .LT. 1E - 06) ZERO1 = 0.0                          
      RETURN                                                            
      END                                                               
