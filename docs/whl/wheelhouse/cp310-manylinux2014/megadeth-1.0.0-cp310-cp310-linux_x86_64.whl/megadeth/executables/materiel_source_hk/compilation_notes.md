- __Problem:__ The `materiel_linux` executable was segfaulting on specific conditions (High AOF/Velocity), failing to produce `LAM2.DAT`.
- __Root Cause:__ The legacy Fortran code relies on local variables retaining their values between subroutine calls (static allocation behavior), which is standard in older compilers but not in modern `gfortran` (which uses stack allocation by default).
- __Fix:__ I recompiled `materiel_linux` with the `-fno-automatic` flag (in addition to `-fdec` and `-O2`). This forces all local variables to be static, matching legacy behavior.
- __Verification:__ I ran a reproduction script (`debug_fsm.py`) against all 48 test conditions. It passed with __0 failures__.

Recompiled `megadeth/executables/materiel_linux` with `-fno-automatic`.
