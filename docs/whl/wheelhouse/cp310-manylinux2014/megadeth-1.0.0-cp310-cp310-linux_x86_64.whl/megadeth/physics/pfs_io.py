from __future__ import annotations

import io
import logging
import math
import os
import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

# C++ Accelerator (optional)
try:
    from megadeth.analysis._accelerator import (
        AVAILABLE as CPP_ACCEL_AVAILABLE,
        parse_floats_fast,
        parse_lam2_block_fast,
    )
except ImportError:
    CPP_ACCEL_AVAILABLE = False
    parse_floats_fast = None
    parse_lam2_block_fast = None

from megadeth.physics.types import TerminalCondition, feet_to_meters, meters_to_feet


@dataclass
class MatrixSettings:
    """Grid matrix settings for FullSpray."""

    dimensions: tuple = (80, 40)  # (nx, ny) cell counts
    range_offset_m: float = 0.0  # Range axis offset
    cell_size_m: Optional[float] = None  # Optional override for cell size


@dataclass
class CutoffSettings:
    """Velocity cutoff settings."""

    mode: str = "intrvc"  # 'intrvc' or 'concv'
    cutoff_mass_grains: float = 0.5


def _build_ip_dat_block(
    rcas: int,
    zdata: int,
    condition: TerminalCondition,
    tch_ft: float,
    matrix_settings: Optional[MatrixSettings] = None,
    cutoff_settings: Optional[CutoffSettings] = None,
) -> str:
    """Construct a single IP.DAT block (without EOF marker)."""
    matrix_settings = matrix_settings or MatrixSettings()
    cutoff_settings = cutoff_settings or CutoffSettings()

    # Pre-processing (from pfs_data_io.py - unchanged)
    vel_fps_raw = meters_to_feet(condition.velocity_mps)
    hob_ft_raw = meters_to_feet(condition.hob_m)
    aof_deg_raw = condition.aof_deg

    # Compute cell dimensions from miss distance requirements
    if matrix_settings.cell_size_m is not None:
        cell_dim_m = max(matrix_settings.cell_size_m, 0.3)  # enforce minimum
    else:
        cell_dim_x_m = (
            abs(condition.miss_deflection_m / 37.5)
            if condition.miss_deflection_m != 0
            else 0.3
        )
        cell_dim_y_m = (
            abs(condition.miss_range_m / 17.5) if condition.miss_range_m != 0 else 0.3
        )
        cell_dim_m = max(cell_dim_x_m, cell_dim_y_m, 0.3)  # Minimum 0.3m cells
    cell_dim_ft_raw = meters_to_feet(cell_dim_m)

    # MATLAB-compatible rounding rules
    aof_deg_processed = math.floor(aof_deg_raw * 1000) / 1000.0
    vel_fps_processed = math.floor(vel_fps_raw * 1000) / 1000.0
    hob_ft_processed = math.floor(hob_ft_raw * 1000) / 1000.0
    tch_ft_processed = round(tch_ft * 1000) / 1000.0
    cell_dim_ft_processed = math.ceil(cell_dim_ft_raw * 10) / 10.0
    range_offset_ft_processed = round(meters_to_feet(matrix_settings.range_offset_m) * 10) / 10.0

    buffer = io.StringIO()
    buffer.write(
        f"zdata{zdata}_rcas{rcas}_om{aof_deg_processed:.3g}_v{vel_fps_processed:.3g}_pbh{hob_ft_processed:.3g}\n"
    )
    buffer.write(f"NTP{' ' * 14}1.0  \n")

    # Target Centroid Height
    if tch_ft_processed < 10:
        buffer.write(f"     {tch_ft_processed:4.2f}  \n")
    else:
        buffer.write(f"    {tch_ft_processed:5.2f}  \n")

    buffer.write("SPTM\n")
    buffer.write("PKVSR\n")

    # Point Burst Height
    if hob_ft_processed < 10:
        buffer.write(f"PBH           {hob_ft_processed:6.4f}\n")
    elif hob_ft_processed < 100:
        buffer.write(f"PBH          {hob_ft_processed:7.4f}\n")
    elif hob_ft_processed < 1000:
        buffer.write(f"PBH         {hob_ft_processed:8.4f}\n")
    else:
        buffer.write(f"PBH        {hob_ft_processed:9.4f}\n")

    # Angle of Fall
    if aof_deg_processed < 10:
        buffer.write(f"OMEGA         {aof_deg_processed:6.4f}\n")
    else:
        buffer.write(f"OMEGA        {aof_deg_processed:7.4f}\n")

    # Velocity
    if vel_fps_processed < 10:
        buffer.write(f"VELM          {vel_fps_processed:6.4f}\n")
    elif vel_fps_processed < 100:
        buffer.write(f"VELM         {vel_fps_processed:7.4f}\n")
    elif vel_fps_processed < 1000:
        buffer.write(f"VELM        {vel_fps_processed:8.4f}\n")
    elif vel_fps_processed < 10000:
        buffer.write(f"VELM       {vel_fps_processed:9.4f}\n")
    else:
        buffer.write(f"VELM      {vel_fps_processed:10.4f}\n")

    # ZDATA
    if zdata < 10:
        buffer.write(f"ZDATA         {float(zdata):6.4f}   \n")
    elif zdata < 100:
        buffer.write(f"ZDATA        {float(zdata):7.4f}   \n")
    elif zdata < 1000:
        buffer.write(f"ZDATA       {float(zdata):8.4f}   \n")
    else:
        buffer.write(f"ZDATA      {float(zdata):9.4f}   \n")

    # RCAS and cutoff
    buffer.write(f"RCAS{' ' * 23}{rcas}\n")
    buffer.write(f"CDRAG{' ' * 12}1.0  \n")

    if cutoff_settings.mode == "intrvc":
        buffer.write(f"INTRVC{' ' * 21}{rcas}\n")
    else:
        buffer.write(f"CONCV{' ' * 9}100.0\n")

    # Matrix definition
    buffer.write("MATRIX\n")
    nx, ny = matrix_settings.dimensions
    buffer.write(f"{float(nx):>6.1f}{float(ny):>10.1f}{range_offset_ft_processed:>12.1f}\n")
    buffer.write("0000001011\n")
    buffer.write(f"{cell_dim_ft_processed:>7.1f}{cell_dim_ft_processed:>10.1f}       0.0\n")
    buffer.write(f"COTM{' ' * 10}{cutoff_settings.cutoff_mass_grains:.1f}\n")
    buffer.write("\n")

    return buffer.getvalue()


def _normalize_crlf(text: str) -> str:
    """Normalize all newlines in ``text`` to CRLF."""

    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    return normalized.replace("\n", "\r\n")


def generate_ip_dat(
    filepath: Path,
    rcas: int,
    zdata: int,
    condition: TerminalCondition,
    tch_ft: float,
    matrix_settings: Optional[MatrixSettings] = None,
    cutoff_settings: Optional[CutoffSettings] = None,
) -> None:
    """
    Generate IP.DAT input file for FullSpray solver.

    CRITICAL: Preserves the EXACT formatting from pfs_data_io.py to ensure
    bit-for-bit compatibility with the FSM solver.

    Architecture Spec: Section 3.1 FullSpray Integration – IP.DAT Generation
    (Lines 253-338) for formatting and rounding rules.
    """
    block = _normalize_crlf(
        _build_ip_dat_block(
            rcas=rcas,
            zdata=zdata,
            condition=condition,
            tch_ft=tch_ft,
            matrix_settings=matrix_settings,
            cutoff_settings=cutoff_settings,
        ).rstrip("\r\n")
    ) + "\r\n\r\n"

    with open(filepath, "w", newline="") as f:
        f.write(block)
        f.write("RATS\r\n")


def generate_ip_dat_content(
    rcas: int,
    zdata: int,
    condition: TerminalCondition,
    tch_ft: float,
    matrix_settings: Optional[MatrixSettings] = None,
    cutoff_settings: Optional[CutoffSettings] = None,
) -> bytes:
    """
    Generate IP.DAT content as bytes for in-memory C++ engine use.
    
    No file I/O - returns bytes directly for passing to GFSEngine.run_batch().
    """
    block = _normalize_crlf(
        _build_ip_dat_block(
            rcas=rcas,
            zdata=zdata,
            condition=condition,
            tch_ft=tch_ft,
            matrix_settings=matrix_settings,
            cutoff_settings=cutoff_settings,
        ).rstrip("\r\n")
    ) + "\r\n\r\n"
    
    content = block + "RATS\r\n"
    return content.encode('ascii')


def generate_ip_dat_batch_content(
    items: list[tuple[int, int, TerminalCondition, float]],
    matrix_settings: Optional[MatrixSettings] = None,
    cutoff_settings: Optional[CutoffSettings] = None,
) -> bytes:
    """
    Generate batched IP.DAT content as bytes for in-memory C++ engine use.
    
    Combines multiple cases into single bytes buffer - more cache-friendly
    than generating individually in a loop.
    
    Args:
        items: List of (rcas, zdata, condition, tch_ft) tuples
        matrix_settings: Optional matrix settings
        cutoff_settings: Optional cutoff settings
        
    Returns:
        Combined IP.DAT content as bytes
    """
    matrix_settings = matrix_settings or MatrixSettings()
    cutoff_settings = cutoff_settings or CutoffSettings()
    
    parts = []
    for rcas, zdata, condition, tch_ft in items:
        block = _normalize_crlf(
            _build_ip_dat_block(
                rcas=rcas,
                zdata=zdata,
                condition=condition,
                tch_ft=tch_ft,
                matrix_settings=matrix_settings,
                cutoff_settings=cutoff_settings,
            ).rstrip("\r\n")
        )
        parts.append(block)
    
    content = "\r\n\r\n".join(parts) + "\r\n\r\nRATS\r\n"
    return content.encode('ascii')


def generate_ip_dat_batch(
    filepath: Path,
    items: list[tuple[int, int, TerminalCondition, float]],
    matrix_settings: Optional[MatrixSettings] = None,
    cutoff_settings: Optional[CutoffSettings] = None,
) -> None:
    """Generate a batched IP.DAT with CRLF separators between job blocks."""
    matrix_settings = matrix_settings or MatrixSettings()
    cutoff_settings = cutoff_settings or CutoffSettings()

    with open(filepath, "w", newline="") as f:
        for rcas, zdata, condition, tch_ft in items:
            block = _normalize_crlf(
                _build_ip_dat_block(
                    rcas=rcas,
                    zdata=zdata,
                    condition=condition,
                    tch_ft=tch_ft,
                    matrix_settings=matrix_settings,
                    cutoff_settings=cutoff_settings,
                ).rstrip("\r\n")
            )
            f.write(block)
            f.write("\r\n\r\n")
        f.write("RATS\r\n")


def _parse_lam2_header(header_line: str) -> Dict[str, Any]:
    if "PBH" not in header_line:
        raise ValueError("LAM2.DAT missing valid 'PBH' header")

    values = _extract_floats(header_line)
    if len(values) < 5:
        raise ValueError("LAM2.DAT header missing required numeric fields")

    return {
        "pbh_ft": float(values[0]),
        "omega_deg": float(values[1]),
        "velm_fps": float(values[2]),
        "zdata": int(float(values[3])),
        "rcas": int(float(values[4])),
    }


def _compute_lam2_geometry(block_lines: list[str]) -> Dict[str, Any]:
    """
    Derive axis geometry from the first LAM2 block, mirroring legacy MATLAB behavior.
    """
    if len(block_lines) < 3:
        raise ValueError("LAM2.DAT block missing required lines for geometry inference")

    x_indices_raw = None
    data_grid = None
    pk_cols = 0

    # Try C++ accelerator first
    if CPP_ACCEL_AVAILABLE and parse_lam2_block_fast is not None:
        try:
            _validate_lam2_block_spacing(block_lines)
            # parse_lam2_block_fast expects the header + x-axis + data rows
            x_raw, y_raw, pk_vals = parse_lam2_block_fast(block_lines)
            x_indices_raw = x_raw
            data_grid = np.column_stack((y_raw, pk_vals))
            pk_cols = pk_vals.shape[1]
        except ValueError:
            raise
        except Exception:
            # Fallback to Python parsing on any error (including malformed data)
            x_indices_raw = None
            data_grid = None

    # Python fallback
    if x_indices_raw is None or data_grid is None:
        x_indices_raw = np.asarray(_extract_floats(block_lines[1]), dtype=np.float64)
        if x_indices_raw.size == 0:
            raise ValueError("LAM2.DAT x-axis line is empty")

        data_rows: list[list[float]] = []
        for idx, line in enumerate(block_lines[2:], start=3):
            parsed = _extract_floats(line)
            if not parsed:
                raise ValueError(f"LAM2.DAT data line {idx} is empty")
            data_rows.append(parsed)

        if not data_rows:
            raise ValueError("LAM2.DAT block missing grid data")

        pk_cols = len(data_rows[0]) - 1
        if pk_cols <= 0:
            raise ValueError("LAM2.DAT data rows must contain at least one pk value")

        for idx, row in enumerate(data_rows, start=3):
            if len(row) - 1 != pk_cols:
                raise ValueError(
                    f"LAM2.DAT block has inconsistent row widths: expected {pk_cols} pk columns, "
                    f"found {len(row) - 1} on data line {idx}"
                )

        data_grid = np.asarray(data_rows, dtype=np.float64)
    if np.isnan(data_grid).any():
        logging.getLogger(__name__).warning(
            "LAM2 block contains NaN; interpolating pk grid for geometry inference"
        )
        # Only interpolate pk values, keep y-index column intact
        pk_half = _interpolate_nans(data_grid[:, 1:])
        data_grid = np.column_stack((data_grid[:, 0], pk_half))
    y_indices_ft_raw = data_grid[:, 0]

    # MATLAB centering rules for X-axis
    x_indices_work = x_indices_raw.copy()
    dxabsmean = float(np.mean(np.abs(np.diff(x_indices_raw)))) if x_indices_raw.size > 1 else 0.0
    shift_x = False
    if x_indices_raw.size >= 3:
        dx = x_indices_raw[2] - x_indices_raw[1]
        dx0 = x_indices_raw[1] - x_indices_raw[0]
        shift_x = abs(dx - dx0) <= 0.1

    if x_indices_work.size > 0 and np.isclose(x_indices_work[0], 0.0):
        x_indices_work = x_indices_work[1:]

    if shift_x and x_indices_work.size > 0:
        x_indices_work = x_indices_work - (dxabsmean / 2.0)

    if x_indices_work.size != pk_cols:
        raise ValueError(
            f"LAM2.DAT x-axis length ({x_indices_work.size}) does not match pk columns ({pk_cols})"
        )

    if y_indices_ft_raw.size > 1:
        dy_mean = float(np.mean(np.abs(np.diff(y_indices_ft_raw))))
        if abs(y_indices_ft_raw[0]) > abs(y_indices_ft_raw[-1]):
            y_indices_centered_ft = y_indices_ft_raw + (dy_mean / 2.0)
        else:
            y_indices_centered_ft = y_indices_ft_raw - (dy_mean / 2.0)
    else:
        y_indices_centered_ft = y_indices_ft_raw

    x_indices_neg_ft = -np.flip(x_indices_work)
    full_x_indices_ft = np.concatenate((x_indices_neg_ft, x_indices_work))

    return {
        "x_indices_pos_ft": x_indices_work,
        "y_indices_ft": y_indices_centered_ft,
        "y_indices_raw_ft": y_indices_ft_raw,
        "full_x_indices_ft": full_x_indices_ft,
        "pk_cols": pk_cols,
        "y_rows": data_grid.shape[0],
        "data_grid": data_grid,
    }


def _parse_lam2_block(
    block_lines: list[str],
    geometry: Optional[Dict[str, Any]] = None,
    block_index: Optional[int] = None,
    preloaded_grid: Optional[np.ndarray] = None,
) -> Dict[str, Any]:
    header_line = block_lines[0]
    header = _parse_lam2_header(header_line)

    geom = geometry or _compute_lam2_geometry(block_lines)
    pk_cols_expected = geom["pk_cols"]
    y_rows_expected = geom["y_rows"]

    data_grid = None
    if preloaded_grid is not None:
        data_grid = preloaded_grid
    elif CPP_ACCEL_AVAILABLE and parse_lam2_block_fast is not None:
        try:
            _validate_lam2_block_spacing(block_lines)
            # parse_lam2_block_fast expects the header + x-axis + data rows
            _, y_raw, pk_vals = parse_lam2_block_fast(block_lines)
            data_grid = np.column_stack((y_raw, pk_vals))

            # Validation check
            if data_grid.shape[0] != y_rows_expected:
                data_grid = None  # Fallback
            elif (data_grid.shape[1] - 1) != pk_cols_expected:
                data_grid = None  # Fallback
        except ValueError:
            raise
        except Exception:
            data_grid = None  # Fallback

    if data_grid is None:
        data_grid = np.empty((y_rows_expected, pk_cols_expected + 1), dtype=np.float64)
        for row_idx, line in enumerate(block_lines[2:], start=0):
            parsed = _extract_floats(line)
            if not parsed:
                raise ValueError(f"LAM2.DAT data line {row_idx + 3} is empty")
            if len(parsed) - 1 != pk_cols_expected:
                raise ValueError(
                    f"LAM2.DAT block {block_index if block_index is not None else ''} has inconsistent "
                    f"row widths: expected {pk_cols_expected} pk columns, found {len(parsed) - 1} on data line {row_idx + 3}"
                )
            if row_idx >= y_rows_expected:
                raise ValueError(
                    f"LAM2.DAT block {block_index if block_index is not None else ''} has too many rows; expected {y_rows_expected}"
                )
            data_grid[row_idx, :] = parsed

        if data_grid.shape[0] != y_rows_expected:
            raise ValueError(
                f"LAM2.DAT block {block_index if block_index is not None else ''} has "
                f"{data_grid.shape[0]} rows; expected {y_rows_expected}"
            )
    if np.isnan(data_grid).any():
        logging.getLogger(__name__).warning(
            "LAM2 block %s contains NaN; interpolating pk grid",
            block_index if block_index is not None else "?",
        )
        pk_half_interp = _interpolate_nans(data_grid[:, 1:])
        data_grid = np.column_stack((data_grid[:, 0], pk_half_interp))
    y_indices_ft_raw = data_grid[:, 0]
    pk_data_half = np.atleast_2d(data_grid[:, 1:])

    # Optional sanity check on y-axis alignment across blocks
    if y_indices_ft_raw.size == geom["y_indices_raw_ft"].size:
        if not np.allclose(y_indices_ft_raw, geom["y_indices_raw_ft"], atol=1e-6):
            logging.getLogger(__name__).warning(
                "LAM2 block %s y-axis differs from first block; using first block geometry",
                block_index,
            )

    pk_data_mirrored = np.fliplr(pk_data_half)
    full_pk_grid = np.hstack((pk_data_mirrored, pk_data_half))

    y_indices_ft = geom["y_indices_ft"]
    full_x_indices_ft = geom["full_x_indices_ft"]

    # Ensure Y-axis is always ascending (pyfullspray canonical behavior)
    if y_indices_ft.size > 1 and y_indices_ft[0] > y_indices_ft[-1]:
        y_indices_ft = np.flip(y_indices_ft)
        full_pk_grid = np.flipud(full_pk_grid)

    return {
        "x_indices_m": feet_to_meters(full_x_indices_ft),
        "y_indices_m": feet_to_meters(y_indices_ft),
        "pk_grid": full_pk_grid,
        "header": header,
    }


def parse_lam2_dat(filepath: Path) -> Dict[str, Any]:
    """Parse a single-block LAM2.DAT file."""
    results = parse_lam2_dat_batch(filepath, expected_blocks=1)
    if not results:
        raise ValueError("LAM2.DAT empty")
    return results[0]


_FLOAT_PATTERN = re.compile(
    r"[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?|nan", re.IGNORECASE
)


def _validate_numeric_spacing(line: str, matches: Optional[list[re.Match[str]]] = None) -> None:
    token_matches = matches if matches is not None else list(_FLOAT_PATTERN.finditer(line))
    if not token_matches:
        return

    for prev, curr in zip(token_matches, token_matches[1:]):
        separator = line[prev.end() : curr.start()]
        if not any(ch.isspace() for ch in separator):
            raise ValueError(
                "LAM2.DAT contains adjacent numeric fields without whitespace "
                f"separator: '{line.strip()}'"
            )


def _validate_lam2_block_spacing(block_lines: list[str]) -> None:
    # Skip header (line 0) but validate x-axis and data rows for fused tokens.
    for line in block_lines[1:]:
        _validate_numeric_spacing(line)


def _extract_floats(line: str) -> list[float]:
    """
    Extract all float-like tokens from a line.

    A missing whitespace separator between numeric fields is treated as an error
    because it indicates a malformed LAM2 export.
    """

    matches = list(_FLOAT_PATTERN.finditer(line))
    if not matches:
        return []

    _validate_numeric_spacing(line, matches)

    if CPP_ACCEL_AVAILABLE and parse_floats_fast is not None:
        try:
            parsed = parse_floats_fast(line.encode("utf-8"))
            if parsed.size == len(matches):
                return parsed.tolist()
        except Exception:
            # Fall back to Python conversion on any parsing issue
            pass

    values: list[float] = []
    for match in matches:
        token = match.group(0)
        val = float(token)
        values.append(val)

    return values


def _interpolate_nans(grid: np.ndarray) -> np.ndarray:
    """
    Fill NaNs in a 2D array by averaging orthogonal neighbors.

    Edge cells use up to 3 neighbors; interior uses up to 4. If no
    non-NaN neighbors are available, the cell remains NaN and will
    be zeroed at the end.
    """

    filled = grid.copy()
    if not np.isnan(filled).any():
        return filled

    max_iters = np.count_nonzero(np.isnan(filled))
    for _ in range(max_iters):
        mask = np.isnan(filled)
        if not mask.any():
            break

        vals = np.nan_to_num(filled, nan=0.0)

        # Sum of orthogonal neighbors via shifted views (no wrap)
        up = np.zeros_like(vals)
        up[1:, :] = vals[:-1, :]
        down = np.zeros_like(vals)
        down[:-1, :] = vals[1:, :]
        left = np.zeros_like(vals)
        left[:, 1:] = vals[:, :-1]
        right = np.zeros_like(vals)
        right[:, :-1] = vals[:, 1:]
        neighbor_sum = up + down + left + right

        # Count of available neighbors (non-NaN)
        valid = (~mask).astype(np.float64)
        up_c = np.zeros_like(valid)
        up_c[1:, :] = valid[:-1, :]
        down_c = np.zeros_like(valid)
        down_c[:-1, :] = valid[1:, :]
        left_c = np.zeros_like(valid)
        left_c[:, 1:] = valid[:, :-1]
        right_c = np.zeros_like(valid)
        right_c[:, :-1] = valid[:, 1:]
        neighbor_count = up_c + down_c + left_c + right_c

        update_mask = (neighbor_count > 0) & mask
        if not update_mask.any():
            break

        filled[update_mask] = neighbor_sum[update_mask] / neighbor_count[update_mask]

    return np.nan_to_num(filled, nan=0.0)


def parse_lam2_dat_batch(
    filepath: Path,
    expected_blocks: Optional[int] = None,
    block_lines: int = 42,
    max_threads: Optional[int] = None,
) -> list[Dict[str, Any]]:
    """
    Parse a batched LAM2.DAT containing multiple fixed-size sections.

    Args:
        filepath: Path to LAM2.DAT
        expected_blocks: Optional expected section count for validation
        block_lines: Number of lines per section (header included)
        max_threads: Thread pool size for parallel block parsing (defaults to CPU count)
    """

    # Preserve order while trimming empty lines and the EOF marker.
    # Using a simple loop avoids loading very large files twice and keeps
    # the parser cheap in the common case.
    lines = []
    for raw in filepath.read_text().splitlines():
        stripped = raw.strip()
        if not stripped:
            continue
        if stripped == "RATS":
            break
        lines.append(raw)

    header_indices = [i for i, line in enumerate(lines) if line.lstrip().startswith("PBH")]
    if not header_indices:
        raise ValueError("LAM2.DAT missing any PBH headers; cannot parse")

    # Build block slices based on header offsets to tolerate blank lines or formatting drift
    # while still allowing optional validation against an expected block size.
    header_indices.append(len(lines))
    blocks: list[list[str]] = []
    for start, end in zip(header_indices, header_indices[1:]):
        block = lines[start:end]
        if not block:
            continue
        blocks.append(block)

    if not blocks:
        raise ValueError("LAM2.DAT empty after header parsing")

    if expected_blocks is not None and len(blocks) != expected_blocks:
        logging.getLogger(__name__).warning(
            "LAM2 sections mismatch: expected %s, parsed %s; continuing with parsed blocks",
            expected_blocks,
            len(blocks),
        )

    if block_lines and any(len(block) != block_lines for block in blocks):
        logging.getLogger(__name__).warning(
            "LAM2 sections differ from nominal block size %s; proceeding with header-delimited parsing",
            block_lines,
        )

    # Infer geometry from the first block (legacy MATLAB behavior) and enforce it for all blocks.
    geometry = _compute_lam2_geometry(blocks[0])

    results: list[Dict[str, Any]] = []

    # Parse first block directly, reusing the precomputed grid to avoid a second pass.
    results.append(
        _parse_lam2_block(
            blocks[0],
            geometry=geometry,
            block_index=1,
            preloaded_grid=geometry.get("data_grid"),
        )
    )

    if len(blocks) == 1:
        return results

    max_threads = max_threads or os.cpu_count() or 1

    def _parse_with_geometry(args: tuple[int, list[str]]) -> Dict[str, Any]:
        idx, block = args
        return _parse_lam2_block(block, geometry=geometry, block_index=idx)

    with ThreadPoolExecutor(max_workers=max_threads) as pool:
        tail_results = list(pool.map(_parse_with_geometry, enumerate(blocks[1:], start=2)))
        results.extend(tail_results)

    return results
