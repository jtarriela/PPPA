from __future__ import annotations

from dataclasses import dataclass
import numpy as np


@dataclass
class FrameTransform:
    """
    Configuration for coordinate frame transformations.
    
    MATLAB Parity (2025-12-02):
    - X-axis = Deflection (crossrange/lateral) - MATLAB PkDatabase{1}
    - Y-axis = Range (downrange) - MATLAB PkDatabase{2}
    - Target Frame: Analysis coordinate system (miss distance from target)
    - Weapon Frame: FullSpray/LAM2 coordinate system (Pk lookup grid)
    """

    flip_x: bool = True  # Negate X-axis (deflection)
    flip_y: bool = True  # Negate Y-axis (range)
    flip_z: bool = False  # Keep Z-axis (altitude) unchanged


def target_to_weapon_frame(
    x_target: np.ndarray,
    y_target: np.ndarray,
    z_target: np.ndarray | None = None,
    transform: FrameTransform | None = None,
):
    """
    Convert target-centered coordinates to weapon-centered (FullSpray) frame.

    Architecture Spec: Section 7.2 Reference Frame Transforms (Lines 972-1033)
    for axis flips between analysis frame and weapon frame.
    From MATLAB SalvoAnalysis03x3.m (lines 457-461):
        tempTargetLocations_m(:,1:3:end) = hitLocations_m(:,1:3:end) * -1;
        tempTargetLocations_m(:,2:3:end) = hitLocations_m(:,2:3:end) * -1;
        tempTargetLocations_m(:,3:3:end) = hitLocations_m(:,3:3:end);  # unchanged
    """
    transform = transform or FrameTransform()
    x_weapon = -x_target if transform.flip_x else x_target
    y_weapon = -y_target if transform.flip_y else y_target

    if z_target is not None:
        z_weapon = -z_target if transform.flip_z else z_target
        return x_weapon, y_weapon, z_weapon
    return x_weapon, y_weapon


def weapon_to_target_frame(
    x_weapon: np.ndarray,
    y_weapon: np.ndarray,
    z_weapon: np.ndarray | None = None,
    transform: FrameTransform | None = None,
):
    """Inverse of target_to_weapon_frame (self-inverse for flips)."""
    return target_to_weapon_frame(x_weapon, y_weapon, z_weapon, transform)


def compute_range_shift(hob_m: float, aof_deg: float) -> float:
    """
    Compute geometric range shift for burst-to-target offset.

    From MATLAB buildpkdb6mod3.m:
        betaAOFs_deg = 90 - alphaAOFs_deg
        rangeShifts_m = HOBs_m × ( sin(betaAOFs_rad) / sin(alphaAOFs_rad) )
    """
    if aof_deg < 0.1:
        raise ValueError(f"AOF must be > 0.1° to avoid singularity, got {aof_deg}°")

    alpha_rad = np.deg2rad(aof_deg)
    beta_rad = np.deg2rad(90.0 - aof_deg)
    return hob_m * np.sin(beta_rad) / np.sin(alpha_rad)
