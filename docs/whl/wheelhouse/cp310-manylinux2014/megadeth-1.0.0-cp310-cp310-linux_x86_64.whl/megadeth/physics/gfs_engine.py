"""
C++ GFS Physics Engine wrapper for in-memory execution.

Replaces subprocess calls to the bundled legacy solver with direct C++ library calls.
Eliminates file I/O overhead by operating entirely in memory.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

# Try to import the C++ extension module
try:
    import gfs_py
    GFS_CPP_AVAILABLE = True
except ImportError:
    GFS_CPP_AVAILABLE = False
    gfs_py = None

from megadeth.physics.types import LAM2Result, TerminalCondition

# Unit conversions
_FT_TO_M = 0.3048
_M_TO_FT = 1.0 / _FT_TO_M


class GFSEngine:
    """
    In-memory C++ physics engine context.

    Caches static data files (CDRAG, ZDATA, RCAS, INTRVC) and executes
    simulations without file I/O or subprocess overhead.

    Usage:
        engine = GFSEngine()
        engine.load_cdrag(cdrag_path)
        engine.load_zdata(1200, zdata_path)
        engine.load_rcas(1, rcas_path, intrvc_path)

        # Run batch from IP.DAT content
        results = engine.run_batch(ip_content)
    """

    def __init__(self):
        if not GFS_CPP_AVAILABLE:
            raise ImportError(
                "gfs_py module not available. Build with -DGFS_BUILD_PYTHON=ON.\n"
                "Set PYTHONPATH to include the build directory, e.g.:\n"
                "  export PYTHONPATH=/path/to/gfs-cpp/build_py:$PYTHONPATH"
            )
        self._ctx = gfs_py.GFSContext()
        self._loaded_zdata: set[int] = set()
        self._loaded_rcas: set[int] = set()
        self._loaded_intrvc: set[int] = set()
        self._cdrag_loaded = False

    @property
    def is_ready(self) -> bool:
        """Check if engine has minimum required data loaded."""
        return self._cdrag_loaded and len(self._loaded_zdata) > 0

    def load_cdrag(self, cdrag_path: Path) -> None:
        """Load CDRAG data file into context."""
        content = Path(cdrag_path).read_bytes()
        self._ctx.load_cdrag(content)
        self._cdrag_loaded = True

    def load_zdata(self, zdata_id: int, zdata_path: Path) -> None:
        """Load ZDATA file into context."""
        if zdata_id not in self._loaded_zdata:
            content = Path(zdata_path).read_bytes()
            self._ctx.load_zdata(zdata_id, content)
            self._loaded_zdata.add(zdata_id)

    def load_rcas(
        self,
        rcas_id: int,
        rcas_path: Path,
        intrvc_path: Path | None = None,
        nq: int = 1,
        ntpx: int = 1,
    ) -> None:
        """Load RCAS and optional INTRVC files."""
        if rcas_id not in self._loaded_rcas:
            content = Path(rcas_path).read_bytes()
            self._ctx.load_rcas(rcas_id, content, nq, ntpx)
            self._loaded_rcas.add(rcas_id)

        if intrvc_path is not None and rcas_id not in self._loaded_intrvc:
            if Path(intrvc_path).exists():
                content = Path(intrvc_path).read_bytes()
                self._ctx.load_intrvc(rcas_id, content)
                self._loaded_intrvc.add(rcas_id)

    def run_batch(
        self,
        ip_content: bytes,
        conditions: list[TerminalCondition] | None = None,
    ) -> list[LAM2Result]:
        """
        Execute batched simulation from IP.DAT content.

        Args:
            ip_content: Raw IP.DAT file content (batched cases)
            conditions: Optional list of terminal conditions (for metadata)

        Returns:
            List of LAM2Result objects with pk_grid and axes
        """
        batch_result = self._ctx.run_batch(ip_content)

        results = []
        for i, case in enumerate(batch_result.cases):
            # Get arrays and ensure float64 dtype + contiguous layout for performance
            # C++ pybind11 may return float32 which DuckDB can't handle
            # np.ascontiguousarray ensures cache-friendly memory layout for numpy ops
            pk_grid = np.ascontiguousarray(case.pk_grid, dtype=np.float64)
            x_indices_m = np.ascontiguousarray(case.x_indices_m, dtype=np.float64)
            y_indices_m = np.ascontiguousarray(case.y_indices_m, dtype=np.float64)

            # Get condition from passed list or create from header
            if conditions is not None and i < len(conditions):
                condition = conditions[i]
            else:
                condition = TerminalCondition(
                    hob_m=float(case.header.pbh_ft) * _FT_TO_M,
                    velocity_mps=float(case.header.velm_fps) * _FT_TO_M,
                    aof_deg=float(case.header.omega_deg),
                    miss_deflection_m=0.0,
                    miss_range_m=0.0,
                )

            # Create LAM2Result with all required fields
            # Use float() to ensure native Python types for DB serialization
            result = LAM2Result(
                condition=condition,
                x_indices_m=x_indices_m,
                y_indices_m=y_indices_m,
                pk_grid=pk_grid,
                pbh_ft=float(case.header.pbh_ft),
                omega_deg=float(case.header.omega_deg),
                velm_fps=float(case.header.velm_fps),
                zdata=int(case.header.zdata),
                rcas=int(case.header.rcas),
            )
            results.append(result)

        return results

    def run_single(self, ip_content: bytes) -> LAM2Result:
        """Execute single case simulation from IP.DAT content."""
        results = self.run_batch(ip_content)
        if not results:
            raise RuntimeError("No results from simulation")
        return results[0]


def get_gfs_engine_path() -> Path | None:
    """
    Get path to the gfs_py shared library.

    Checks:
    1. GFS_PY_PATH environment variable
    2. Standard build locations relative to this file
    """
    # Check environment variable
    import os

    env_path = os.environ.get("GFS_PY_PATH")
    if env_path:
        p = Path(env_path)
        if p.exists():
            return p

    # Try to find relative to gfsm checkout
    gfsm_paths = [
        Path.home() / "proj" / "gfsm" / "gfs-cpp" / "build_py",
        Path.home() / "proj" / "gfsm" / "gfs-cpp" / "build",
        Path.home() / "gfsm" / "gfs-cpp" / "build_py",
        Path.home() / "gfsm" / "gfs-cpp" / "build",
    ]

    for base in gfsm_paths:
        if base.exists():
            # Look for the .so file
            for so_file in base.glob("gfs_py*.so"):
                return base

    return None


def ensure_gfs_py_available() -> bool:
    """
    Ensure gfs_py module is importable.

    Returns True if available, False otherwise.
    """
    # Access module-level variable using globals()
    if globals().get("GFS_CPP_AVAILABLE", False):
        return True

    # Try to add to path dynamically
    engine_path = get_gfs_engine_path()
    if engine_path:
        import sys
        if str(engine_path) not in sys.path:
            sys.path.insert(0, str(engine_path))

        try:
            import gfs_py as _gfs_py
            # Update module globals
            globals()["gfs_py"] = _gfs_py
            globals()["GFS_CPP_AVAILABLE"] = True
            return True
        except ImportError:
            pass

    return False
