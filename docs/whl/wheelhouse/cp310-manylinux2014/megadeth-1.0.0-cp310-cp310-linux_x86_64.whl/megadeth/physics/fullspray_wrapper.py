from __future__ import annotations

import logging
import os
import platform
import shutil
import subprocess
from collections.abc import Sequence
from pathlib import Path

from megadeth.physics.pfs_io import (
    MatrixSettings,
    generate_ip_dat,
    generate_ip_dat_batch,
    parse_lam2_dat,
    parse_lam2_dat_batch,
)
from megadeth.physics.types import LAM2Result, TargetConfig, TerminalCondition, WarheadConfig

logger = logging.getLogger(__name__)

# Track hardlink capability per filesystem to avoid repeated failed attempts
_hardlink_supported: dict[str, bool] = {}


def get_fsm_executable_name() -> str:
    """Returns platform-appropriate FSM executable name."""
    system = platform.system()
    if system == "Linux":
        return "materiel_linux"
    if system == "Windows":
        return "materiel_win.exe"
    raise NotImplementedError(f"Platform '{system}' not supported")


def select_executable() -> Path:
    """
    Select the FullSpray/Materiel physics executable.

    Resolution order:
    1. MEGADETH_GFS_EXE environment variable (absolute path)
    2. Default location: /megadeth/megadeth/executables/<platform_exe> (Docker)
    3. Relative to this file: ../executables/<platform_exe> (development)

    Returns:
        Path to the executable.

    Raises:
        FileNotFoundError: If no executable is found.
    """
    exe_name = get_fsm_executable_name()

    # Check environment variable first
    env_exe = os.environ.get("MEGADETH_GFS_EXE")
    if env_exe:
        exe_path = Path(env_exe)
        if exe_path.exists() and os.access(exe_path, os.X_OK):
            return exe_path
        # If env var is a directory, look for the executable in it
        if exe_path.is_dir():
            candidate = exe_path / exe_name
            if candidate.exists() and os.access(candidate, os.X_OK):
                return candidate

    # Standard search paths
    search_paths = [
        # Docker container path
        Path("/megadeth/megadeth/executables") / exe_name,
        # Development path (relative to this file)
        Path(__file__).parent.parent / "executables" / exe_name,
        # Project root paths
        Path("/megadeth/executables") / exe_name,
        Path("megadeth/executables") / exe_name,
    ]

    # Add MEGADETH_EXECUTABLE_PATH if set
    exec_path = os.environ.get("MEGADETH_EXECUTABLE_PATH")
    if exec_path:
        search_paths.insert(0, Path(exec_path) / exe_name)

    for path in search_paths:
        if path.exists() and os.access(path, os.X_OK):
            return path.resolve()

    # Build helpful error message
    searched = "\n  ".join(str(p) for p in search_paths)
    raise FileNotFoundError(
        f"FullSpray physics executable '{exe_name}' not found.\n"
        f"Set MEGADETH_GFS_EXE environment variable to the executable path, "
        f"or place it in one of:\n  {searched}"
    )


def get_data_directory() -> Path:
    """
    Get the directory containing physics input data files (ZDATA, RCAS, INTRVC, CDRAG).

    Resolution order:
    1. MEGADETH_DATA_DIR environment variable
    2. 'input' subdirectory next to the executable
    3. Same directory as the executable

    Returns:
        Path to the data directory.
    """
    # Check environment variable first
    data_dir = os.environ.get("MEGADETH_DATA_DIR")
    if data_dir:
        path = Path(data_dir)
        if path.is_dir():
            return path

    # Find based on executable location
    try:
        exe = select_executable()
        exe_dir = exe.parent

        # Try 'input' subdirectory first
        input_dir = exe_dir / "input"
        if input_dir.is_dir():
            return input_dir

        # Fall back to executable's directory
        return exe_dir
    except FileNotFoundError:
        # Default to common paths
        for path in [
            Path("/megadeth/megadeth/executables/input"),
            Path(__file__).parent.parent / "executables" / "input",
        ]:
            if path.is_dir():
                return path

        return Path(".")


class WorkerSandbox:
    """
    Manages a single staging directory per worker for batched FullSpray runs.

    Architecture Spec: Section 3.1 FullSpray Integration (Lines 222-429) for
    sandbox lifecycle and executable management.

    CRITICAL: Each shard uses one clean directory with a single IP.DAT and
    LAM2.DAT. Static inputs (CDRAG, RCAS/INTRVC pairs, ZDATA files) are copied
    once per shard to minimize I/O churn.

    OPTIMIZATION (v3.1+): The executable is copied ONCE per worker during
    initialization, then reused for all runs. This avoids:
    - Repeated executable copy overhead
    - Redundant I/O for copying the ~5MB binary
    - Filesystem churn in the staging area
    """

    def __init__(
        self,
        worker_id: int,
        staging_path: Path,
        fsm_exe_path: Path,
        cdrag_path: Path,
        isolated_runs: bool = False,
        save_ipdat_sample: bool = False,
        matrix_settings: MatrixSettings | None = None,
    ):
        self.worker_id = worker_id
        self.staging_path = staging_path
        self.fsm_exe_path = fsm_exe_path
        self.cdrag_path = cdrag_path
        self.isolated_runs = isolated_runs
        self.save_ipdat_sample = save_ipdat_sample
        self.matrix_settings = matrix_settings
        self._initialized = False
        self.exe_name = get_fsm_executable_name()
        self._current_run_path: Path | None = None
        self._ip_sample_saved = False

        # Per-worker persistent paths (initialized once, reused across runs)
        self._worker_dir: Path | None = None
        self._worker_exe_path: Path | None = None
        self._cdrag_dest: Path | None = None
        self._run_counter = 0

    def initialize(self) -> None:
        """
        Create staging area for this worker and copy the executable ONCE.

        The executable is placed in the worker's base directory and reused
        for all runs, eliminating repeated copies and security scans.
        """
        # Create worker-level directory
        self._worker_dir = self.staging_path / f"worker_{self.worker_id:03d}"
        self._worker_dir.mkdir(parents=True, exist_ok=True)

        # Copy executable ONCE to worker directory
        self._worker_exe_path = self._worker_dir / self.exe_name
        if not self._worker_exe_path.exists():
            shutil.copy2(self.fsm_exe_path, self._worker_exe_path)
            if platform.system() != "Windows":
                self._worker_exe_path.chmod(0o755)
            logger.info(f"[Worker {self.worker_id}] Executable staged: {self._worker_exe_path}")

        # Copy CDRAG once per worker
        self._cdrag_dest = self._worker_dir / "CDRAG1.DAT"
        if not self._cdrag_dest.exists():
            self._link_or_copy(self.cdrag_path, self._cdrag_dest)

        self._initialized = True

    @property
    def sandbox_path(self) -> Path:
        """Current run directory (for backwards compatibility)."""
        if self._current_run_path is None:
            raise RuntimeError("No active run - call prepare_batch first")
        return self._current_run_path

    def prepare_batch(self, shard: Sequence) -> Path:
        """
        Prepare the worker directory for a shard of work items.

        Copies all required static inputs once and writes a single IP.DAT
        containing all shard entries separated by CRLF, ending with RATS.
        """
        if not self._initialized:
            self.initialize()

        if self._worker_dir is None:
            raise RuntimeError("Worker not initialized")

        # Choose run directory based on staging strategy
        if self.isolated_runs:
            self._run_counter += 1
            run_dir = self._worker_dir / f"run_{self._run_counter:04d}"
            if run_dir.exists():
                shutil.rmtree(run_dir, ignore_errors=True)
            run_dir.mkdir(parents=True, exist_ok=True)
            self._current_run_path = run_dir
        else:
            # Reuse the worker directory directly for the shard
            self._current_run_path = self._worker_dir
            self._cleanup_outputs()

        if self._current_run_path is None:
            raise RuntimeError("Failed to establish run directory")

        # Copy all required inputs once per shard
        zdata_paths = {}
        rcas_paths = {}
        intrvc_paths = {}
        for item in shard:
            zdata_paths[item.warhead.zdata_path.name] = item.warhead.zdata_path
            rcas_paths[item.target.rcas_path.name] = item.target.rcas_path
            intrvc_paths[item.target.intrvc_path.name] = item.target.intrvc_path

        dest_dir = self._current_run_path

        # Ensure drag table is available in the active run directory
        self._link_or_copy(self.cdrag_path, dest_dir / "CDRAG1.DAT")

        for path in zdata_paths.values():
            self._link_or_copy(path, dest_dir / path.name)
        for path in rcas_paths.values():
            self._link_or_copy(path, dest_dir / path.name)
        for path in intrvc_paths.values():
            self._link_or_copy(path, dest_dir / path.name)

        ip_path = dest_dir / "IP.DAT"
        batch_items = [
            (
                item.target.rcas_number,
                item.warhead.zdata_number,
                item.condition,
                item.target.centroid_height_ft,
            )
            for item in shard
        ]

        # Legacy compatibility: single-item runs write IP.DAT without batch separators
        if self.isolated_runs and len(batch_items) == 1:
            rcas, zdata, condition, centroid = batch_items[0]
            generate_ip_dat(
                ip_path,
                rcas=rcas,
                zdata=zdata,
                condition=condition,
                tch_ft=centroid,
                matrix_settings=self.matrix_settings,
            )
        else:
            generate_ip_dat_batch(ip_path, batch_items, matrix_settings=self.matrix_settings)

        if self.save_ipdat_sample and not self._ip_sample_saved:
            try:
                debug_dir = Path.cwd() / "output" / "lam2_debug"
                debug_dir.mkdir(parents=True, exist_ok=True)
                sample_dest = debug_dir / f"IP_worker{self.worker_id}_sample.dat"
                shutil.copy2(ip_path, sample_dest)
                self._ip_sample_saved = True
            except Exception as copy_exc:  # pragma: no cover - best effort
                print(f"[Worker {self.worker_id}] Failed to snapshot IP.DAT sample: {copy_exc}")
        return ip_path

    def prepare_run(
        self,
        condition: TerminalCondition,
        warhead: WarheadConfig,
        target: TargetConfig,
    ) -> Path:
        """Compatibility shim that delegates to prepare_batch for single runs."""

        class _SingleItem:
            def __init__(self, condition, warhead, target):
                self.condition = condition
                self.warhead = warhead
                self.target = target

        return self.prepare_batch([_SingleItem(condition, warhead, target)])

    def execute(self, timeout: float = 30.0) -> bool:
        """
        Run FSM solver. Returns True on success.

        Note: The FSM binary may segfault after writing output files due to
        legacy Fortran memory issues. We consider execution successful if
        LAM2.DAT is produced, regardless of exit code.

        OPTIMIZATION (v3.1): Uses the per-worker executable via absolute path,
        executed from the worker directory with batched inputs. This avoids
        copying the binary for each run while maintaining clean I/O state.

        Args:
            timeout: Maximum time in seconds to wait for FSM completion.
                     Default 30s to handle complex terminal conditions.
        """
        if self._current_run_path is None:
            raise RuntimeError("No active run - call prepare_batch first")
        if self._worker_exe_path is None:
            raise RuntimeError("Worker not initialized - call initialize first")

        # Use absolute path to per-worker executable, run from the worker directory
        exe_abs_path = str(self._worker_exe_path.resolve())
        proc: subprocess.CompletedProcess[str] | None = None
        try:
            proc = subprocess.run(
                [exe_abs_path],
                cwd=self._current_run_path,
                capture_output=True,
                text=True,
                check=False,  # Don't raise on non-zero exit - FSM may crash after writing output
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            print(f"[Worker {self.worker_id}] FSM timeout after {timeout}s")
            # Fall through to check if output was produced before timeout

        # Success is determined by LAM2.DAT existence, not exit code
        lam2_path = self._current_run_path / "LAM2.DAT"
        if lam2_path.exists() and lam2_path.stat().st_size > 0:
            return True
        else:
            if proc is not None:
                stdout_path = self._current_run_path / "fsm_stdout.log"
                stderr_path = self._current_run_path / "fsm_stderr.log"
                stdout_path.write_text(proc.stdout or "")
                stderr_path.write_text(proc.stderr or "")
                print(
                    f"[Worker {self.worker_id}] FSM failed: LAM2.DAT not produced. "
                    f"Captured stdout/stderr in {self._current_run_path}"
                )
            else:
                print(f"[Worker {self.worker_id}] FSM failed: LAM2.DAT not produced")
            return False

    def extract_results(
        self, shard: Sequence, max_threads: int | None = None
    ) -> list[LAM2Result]:
        """Parse batched LAM2.DAT into ordered LAM2Result objects."""
        if self._current_run_path is None:
            return []

        lam2_path = self._current_run_path / "LAM2.DAT"
        if not lam2_path.exists():
            return []

        try:
            parsed_blocks = parse_lam2_dat_batch(
                lam2_path, expected_blocks=len(shard), max_threads=max_threads
            )
        except Exception as exc:
            lam2_copy = None
            ip_copy = None
            try:
                debug_dir = Path.cwd() / "output" / "lam2_debug"
                debug_dir.mkdir(parents=True, exist_ok=True)
                if lam2_path.exists():
                    lam2_copy = debug_dir / f"LAM2_worker{self.worker_id}_error.dat"
                    shutil.copy2(lam2_path, lam2_copy)
                ip_path = self._current_run_path / "IP.DAT" if self._current_run_path else None
                if ip_path and ip_path.exists():
                    ip_copy = debug_dir / f"IP_worker{self.worker_id}_error.dat"
                    shutil.copy2(ip_path, ip_copy)
            except Exception as copy_exc:  # pragma: no cover - best effort
                print(
                    f"[Worker {self.worker_id}] Failed to snapshot debug files: {copy_exc}"
                )

            debug_parts = []
            if lam2_copy:
                debug_parts.append(f"LAM2: {lam2_copy}")
            if ip_copy:
                debug_parts.append(f"IP: {ip_copy}")
            debug_msg = f" (debug copies: {', '.join(debug_parts)})" if debug_parts else ""
            print(f"[Worker {self.worker_id}] LAM2 parse error: {exc}{debug_msg}")
            return []

        results: list[LAM2Result] = []
        for item, parsed in zip(shard, parsed_blocks):
            results.append(
                LAM2Result(
                    condition=item.condition,
                    x_indices_m=parsed["x_indices_m"],
                    y_indices_m=parsed["y_indices_m"],
                    pk_grid=parsed["pk_grid"],
                    pbh_ft=parsed["header"]["pbh_ft"],
                    omega_deg=parsed["header"]["omega_deg"],
                    velm_fps=parsed["header"]["velm_fps"],
                    zdata=parsed["header"]["zdata"],
                    rcas=parsed["header"]["rcas"],
                )
            )
        return results

    def extract_result(self, condition: TerminalCondition) -> LAM2Result | None:
        """Compatibility shim for single-run parsing."""
        if self._current_run_path is None:
            return None

        lam2_path = self._current_run_path / "LAM2.DAT"
        if not lam2_path.exists():
            return None
        try:
            parsed = parse_lam2_dat(lam2_path)
            return LAM2Result(
                condition=condition,
                x_indices_m=parsed["x_indices_m"],
                y_indices_m=parsed["y_indices_m"],
                pk_grid=parsed["pk_grid"],
                pbh_ft=parsed["header"]["pbh_ft"],
                omega_deg=parsed["header"]["omega_deg"],
                velm_fps=parsed["header"]["velm_fps"],
                zdata=parsed["header"]["zdata"],
                rcas=parsed["header"]["rcas"],
            )
        except Exception as exc:
            lam2_copy = None
            ip_copy = None
            try:
                debug_dir = Path.cwd() / "output" / "lam2_debug"
                debug_dir.mkdir(parents=True, exist_ok=True)
                if lam2_path.exists():
                    lam2_copy = debug_dir / f"LAM2_worker{self.worker_id}_error.dat"
                    shutil.copy2(lam2_path, lam2_copy)
                ip_path = self._current_run_path / "IP.DAT" if self._current_run_path else None
                if ip_path and ip_path.exists():
                    ip_copy = debug_dir / f"IP_worker{self.worker_id}_error.dat"
                    shutil.copy2(ip_path, ip_copy)
            except Exception as copy_exc:  # pragma: no cover - best effort
                print(
                    f"[Worker {self.worker_id}] Failed to snapshot debug files: {copy_exc}"
                )

            debug_parts = []
            if lam2_copy:
                debug_parts.append(f"LAM2: {lam2_copy}")
            if ip_copy:
                debug_parts.append(f"IP: {ip_copy}")
            debug_msg = f" (debug copies: {', '.join(debug_parts)})" if debug_parts else ""
            print(f"[Worker {self.worker_id}] LAM2 parse error: {exc}{debug_msg}")
            return None

    def cleanup_run(self) -> None:
        """Remove generated outputs after extracting results."""
        if os.getenv("MEGADETH_KEEP_STAGE"):
            return

        if self.isolated_runs and self._current_run_path is not None:
            shutil.rmtree(self._current_run_path, ignore_errors=True)
        else:
            self._cleanup_outputs()
        self._current_run_path = None

    def destroy(self) -> None:
        """Remove entire worker directory including staged executable."""
        # Clean up any active run first
        self.cleanup_run()
        if os.getenv("MEGADETH_KEEP_STAGE"):
            if self._worker_dir is not None:
                logger.info(
                    "[Worker %s] Keeping staging directory %s (MEGADETH_KEEP_STAGE set)",
                    self.worker_id,
                    self._worker_dir,
                )
            return
        # Remove entire worker directory (includes executable and all run dirs)
        if self._worker_dir is not None and self._worker_dir.exists():
            shutil.rmtree(self._worker_dir, ignore_errors=True)
        self._worker_dir = None
        self._worker_exe_path = None
        self._cdrag_dest = None
        self._initialized = False

    def _cleanup_outputs(self) -> None:
        target_dir = self._current_run_path or self._worker_dir
        if target_dir is None:
            return
        for fname in ["IP.DAT", "LAM2.DAT", "OUT.DAT", "PKVSR.DAT"]:
            try:
                (target_dir / fname).unlink()
            except FileNotFoundError:
                continue

    @staticmethod
    def _link_or_copy(src: Path, dest: Path) -> bool:
        """
        Hard link if possible, else copy.

        Hard links provide significant I/O savings for large data files (ZDATA, RCAS, INTRVC)
        by avoiding actual data copy. Falls back to copy2 on:
        - Windows (hardlinks require admin privileges)
        - Cross-filesystem operations (e.g., /dev/shm staging from HDD source)
        - Network filesystems that don't support hardlinks

        Args:
            src: Source file path
            dest: Destination file path

        Returns:
            True if hardlink succeeded, False if fell back to copy
        """
        dest.unlink(missing_ok=True)

        # Skip hardlink attempt on Windows (requires elevated privileges)
        if platform.system() == "Windows":
            shutil.copy2(src, dest)
            return False

        # Check if we've already determined this filesystem doesn't support hardlinks
        try:
            dest_mount = str(dest.parent.resolve())
            # Use first 20 chars as filesystem key (covers /dev/shm, /tmp, etc.)
            fs_key = dest_mount[:20]
        except (OSError, ValueError):
            fs_key = "unknown"

        if fs_key in _hardlink_supported and not _hardlink_supported[fs_key]:
            shutil.copy2(src, dest)
            return False

        try:
            os.link(src, dest)
            _hardlink_supported[fs_key] = True
            logger.debug(f"Hardlink: {src.name} → {dest}")
            return True
        except OSError as e:
            # errno 18 (EXDEV) = cross-device link, common with ramdisk staging
            # errno 1 (EPERM) = operation not permitted (some filesystems)
            _hardlink_supported[fs_key] = False
            logger.debug(f"Hardlink failed ({e.errno}), falling back to copy: {src.name}")
            shutil.copy2(src, dest)
            return False


class FullSprayBatchExecutor:
    """Executes batches of FullSpray runs using worker sandboxes."""

    def __init__(
        self,
        staging_path: Path,
        fsm_exe_path: Path,
        cdrag_path: Path,
        n_workers: int,
        isolated_runs: bool = False,
        save_ipdat_sample: bool = False,
        matrix_settings: MatrixSettings | None = None,
    ):
        self.staging_path = staging_path
        self.n_workers = n_workers
        self.workers = [
            WorkerSandbox(
                worker_id=i,
                staging_path=staging_path,
                fsm_exe_path=fsm_exe_path,
                cdrag_path=cdrag_path,
                isolated_runs=isolated_runs,
                save_ipdat_sample=save_ipdat_sample,
                matrix_settings=matrix_settings,
            )
            for i in range(n_workers)
        ]

    def initialize_workers(self) -> None:
        for worker in self.workers:
            worker.initialize()

    def execute_batch(
        self,
        work_items: Sequence,  # Sequence of WorkItem or (condition, warhead, target)
        worker_id: int,
        postprocess_threads: int | None = None,
    ) -> list[LAM2Result]:
        worker = self.workers[worker_id]
        if not work_items:
            return []

        worker.prepare_batch(work_items)
        results: list[LAM2Result] = []
        dynamic_timeout = 30.0 + (len(work_items) * 0.5)

        # Pass the calculated timeout
        if worker.execute(timeout=dynamic_timeout):
            results = worker.extract_results(work_items, max_threads=postprocess_threads)

        worker.cleanup_run()
        return results

    def shutdown(self) -> None:
        for worker in self.workers:
            worker.destroy()
