"""
ZDATA File Reader and Analyzer.

Reads standard ZDATA format (ARL-TN-541) describing fragment distributions.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class ZDataZone:
    """Data for a single angular zone in ZDATA."""
    angle_lower: float
    angle_mid: float
    angle_upper: float
    vel_lower: float
    vel_mid: float
    vel_upper: float
    mass_groups: list[float]
    count_groups: list[float]

    @property
    def total_mass(self) -> float:
        """Total mass in this zone (sum of count * mass)."""
        return sum(c * m for c, m in zip(self.count_groups, self.mass_groups))

    @property
    def total_count(self) -> float:
        """Total fragment count in this zone."""
        return sum(self.count_groups)

    @property
    def avg_velocity_sq(self) -> float:
        """Average squared velocity (V_L^2 + V_M^2 + V_U^2) / 3."""
        return (self.vel_lower**2 + self.vel_mid**2 + self.vel_upper**2) / 3.0

    @property
    def total_ke(self) -> float:
        """Total kinetic energy in this zone (0.5 * sum(N*M) * V_avg^2)."""
        # Note: ZDATA spec says KE is calculated per bin or per zone using average v^2
        # ARL-TN-541 Section 7.1: KE += .5 * M[i][j] * N[i][j] * v_avg_2
        return 0.5 * self.total_mass * self.avg_velocity_sq

@dataclass
class ZData:
    """Complete ZDATA file contents."""
    num_zones: int
    zones: list[ZDataZone]
    shape_factor: float
    zdata_number: int | None = None
    wpent_lbs: float = 1.0

    @property
    def total_mass(self) -> float:
        return sum(z.total_mass for z in self.zones)

    @property
    def total_count(self) -> float:
        return sum(z.total_count for z in self.zones)

    @property
    def total_ke(self) -> float:
        return sum(z.total_ke for z in self.zones)

    @property
    def avg_mass(self) -> float:
        return self.total_mass / self.total_count if self.total_count > 0 else 0.0

    @property
    def avg_velocity(self) -> float:
        # v_avg = sqrt(2 * KE / M)
        m = self.total_mass
        return np.sqrt(2 * self.total_ke / m) if m > 0 else 0.0

def read_zdata(path: Path) -> ZData:
    """
    Read a ZDATA file from the given path.

    Format is whitespace-delimited (fixed width logic not required if space separated).
    Handles wrapping of mass/count lines.
    """
    with open(path) as f:
        # Read all tokens (numbers/strings) into a flat list
        content = f.read()

    # Header: ZDATA N_ZONES
    # Handle optional legacy ID line (e.g. "ZDATA 1200" followed by "ZDATA 36")
    # Using index-based access to allow peeking/backtracking logic
    tokens = content.split()
    idx = 0

    def get_token():
        nonlocal idx
        if idx >= len(tokens):
            raise ValueError("Unexpected end of file")
        t = tokens[idx]
        idx += 1
        return t

    header = get_token()
    if header != "ZDATA":
        raise ValueError(f"Invalid ZDATA header: {header}")

    val = get_token()

    zdata_number: int | None = None
    # Legacy FullSpray files carry a file identifier before the true zone count.
    if idx < len(tokens) and tokens[idx] == "ZDATA":
        zdata_number = int(float(val))
        get_token()  # Consume second "ZDATA"
        num_zones = int(float(get_token()))
    else:
        num_zones = int(float(val))

    zones: list[ZDataZone] = []

    for _ in range(num_zones):
        # FullSpray fixtures use AL AU AM / VL VU VM ordering.
        al = float(get_token())
        au = float(get_token())
        am = float(get_token())
        vl = float(get_token())
        vu = float(get_token())
        vm = float(get_token())
        n_groups = int(float(get_token()))

        masses = [float(get_token()) for _ in range(n_groups)]
        counts = [float(get_token()) for _ in range(n_groups)]

        zones.append(ZDataZone(al, am, au, vl, vm, vu, masses, counts))

    shape_factor = float(get_token())
    wpent_lbs = float(get_token()) if idx < len(tokens) else 1.0

    return ZData(
        num_zones=num_zones,
        zones=zones,
        shape_factor=shape_factor,
        zdata_number=zdata_number,
        wpent_lbs=wpent_lbs,
    )


# =============================================================================
# ZDATA Serialization (ARL-TN-541 format)
# =============================================================================

GRAMS_TO_GRAINS = 15.432358  # 1 gram = 15.432358 grains


def zdata_to_bytes(zdata: ZData, decimal_places: int = 4) -> bytes:
    """
    Serialize ZData to ARL-TN-541 ZDATA format (ASCII text).

    Format follows the legacy FullSpray fixture convention used by the solver:
    - Optional legacy header: ``ZDATA <id>`` then ``ZDATA <zone_count>``
    - Per zone: ``AL AU AM VL VU VM N_GROUPS``
    - Footer: shape factor, and optional ``WPENT`` legacy multiplier

    Args:
        zdata: ZData object to serialize
        decimal_places: Digits after decimal (default 4, matching bundled legacy fixtures)

    Returns:
        UTF-8 encoded bytes ready for disk or DesignVector.zdata_bytes

    Example:
        >>> zdata = ZData(num_zones=1, zones=[...], shape_factor=0.5)
        >>> zdata_bytes = zdata_to_bytes(zdata)
        >>> # Pass to DesignVector(zdata_number=1, zdata_bytes=zdata_bytes)
    """
    from io import StringIO

    buf = StringIO()
    d = decimal_places

    if zdata.zdata_number is not None:
        buf.write(f"ZDATA {zdata.zdata_number:<9d}\n")
        buf.write(f"ZDATA {float(zdata.num_zones):11.{d}f}\n")
    else:
        buf.write(f"ZDATA     {zdata.num_zones:10d}\n")

    for zone in zdata.zones:
        n_groups = len(zone.mass_groups)

        # Zone header: AL AU AM VL VU VM N_GROUPS (legacy FullSpray order)
        buf.write(
            f"   {zone.angle_lower:9.{d}f} {zone.angle_upper:9.{d}f} "
            f"{zone.angle_mid:9.{d}f} {zone.vel_lower:9.{d}f} "
            f"{zone.vel_upper:9.{d}f} {zone.vel_mid:9.{d}f}{n_groups:10d}\n"
        )

        # Masses (7 per line, matching C++ ZdataToString)
        for j, mass in enumerate(zone.mass_groups):
            prefix = "   " if j % 7 == 0 else ""
            suffix = "\n" if (j % 7 == 6) or (j == n_groups - 1) else ""
            buf.write(f"{prefix}{mass:9.{d}f}{suffix}")

        # Counts (7 per line)
        for j, count in enumerate(zone.count_groups):
            prefix = "   " if j % 7 == 0 else ""
            suffix = "\n" if (j % 7 == 6) or (j == n_groups - 1) else ""
            buf.write(f"{prefix}{count:9.{d}f}{suffix}")

    buf.write(f"   {zdata.shape_factor:9.{d}f}\n")
    if zdata.zdata_number is not None or zdata.wpent_lbs != 1.0:
        buf.write(f"   {zdata.wpent_lbs:9.{d}f}\n")

    return buf.getvalue().encode("utf-8")


def zdata_from_ga_chromosome(
    n_zones: int,
    velocities_fps: list[float] | None = None,
    frag_masses_grams: list[list[float]] | None = None,
    frag_counts: list[list[float]] | None = None,
    shape_factor: float = 0.5,
    zdata_number: int | None = None,
    wpent_lbs: float = 1.0,
    velocity_spread_fps: float = 0.0,
    smooth_continuity: bool = True,
    velocity_strategy: str | None = None,
    *,
    zone_velocities_fps: list[float] | None = None,
) -> ZData:
    """
    Construct ZData from GA chromosome representation.

    Handles unit conversion (grams → grains) and polar zone angle computation.
    This is the primary interface for genetic algorithms to generate ZDATA
    without intermediate file I/O.

    Args:
        n_zones: Number of polar zones (e.g., 15 for 12° per zone)
        velocities_fps: Velocity input for advanced modes. Use with
                       ``velocity_strategy="nodal"`` to provide N+1 boundary
                       velocities, or ``velocity_strategy="zonal"`` to provide
                       N midpoint velocities.
        frag_masses_grams: Fragment mass per [zone][bin] in GRAMS (converted to grains)
        frag_counts: Fragment count per [zone][bin] (floats allowed per ZDATA spec)
        shape_factor: Drag shape factor (default 0.5, in ft²·gr^(1/3)/lb)
        zdata_number: Optional legacy ZDATA file identifier. Set this when the
            output will be written to disk for FullSpray/Fortran consumption.
        wpent_lbs: Optional legacy Pentolite equivalent footer value written
            when ``zdata_number`` is provided.
        velocity_spread_fps: Optional ± spread for VL=VM-spread, VU=VM+spread
            in zonal midpoint mode.
        smooth_continuity: If True with ``velocities_fps`` +
            ``velocity_strategy="zonal"``, interpolate zone boundary
            velocities from neighboring zone midpoints.
        velocity_strategy: Optional strategy for ``velocities_fps``. Use
            ``"nodal"`` for N+1 boundary velocities or ``"zonal"`` for N
            midpoint velocities. If omitted, zonal midpoint semantics are used
            for backward compatibility.
        zone_velocities_fps: Backward-compatible per-zone midpoint velocities.
            This preserves the original GA API and uses zonal midpoint
            semantics with ``velocity_spread_fps``.

    Returns:
        ZData ready for zdata_to_bytes() serialization

    Raises:
        ValueError: If array lengths don't match expected sizes

    Example (Legacy GA Contract):
        >>> zdata = zdata_from_ga_chromosome(
        ...     n_zones=15,
        ...     zone_velocities_fps=[3000.0] * 15,
        ...     frag_masses_grams=[[10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0]] * 15,
        ...     frag_counts=[[100.0, 80.0, 60.0, 40.0, 20.0, 10.0, 5.0]] * 15,
        ...     shape_factor=0.5,
        ... )

    Example (Explicit Nodal Contract):
        >>> zdata = zdata_from_ga_chromosome(
        ...     n_zones=15,
        ...     velocities_fps=[3000.0] * 16,  # N+1 boundary velocities
        ...     frag_masses_grams=[[10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0]] * 15,
        ...     frag_counts=[[100.0, 80.0, 60.0, 40.0, 20.0, 10.0, 5.0]] * 15,
        ...     shape_factor=0.5,
        ...     velocity_strategy="nodal",
        ... )
        >>> zdata_bytes = zdata_to_bytes(zdata)

    Example (Solver-Bound Legacy File):
        >>> zdata = zdata_from_ga_chromosome(
        ...     n_zones=15,
        ...     zone_velocities_fps=[3000.0] * 15,
        ...     frag_masses_grams=[[10.0] * 7] * 15,
        ...     frag_counts=[[100.0] * 7] * 15,
        ...     zdata_number=9999,
        ... )
        >>> Path("ZDATA9999.DAT").write_bytes(zdata_to_bytes(zdata))
    """
    if frag_masses_grams is None or frag_counts is None:
        raise ValueError("frag_masses_grams and frag_counts are required")

    if zone_velocities_fps is not None and velocities_fps is not None:
        raise ValueError("Provide either zone_velocities_fps or velocities_fps, not both")

    if zone_velocities_fps is not None:
        if velocity_strategy not in (None, "zonal"):
            raise ValueError(
                "zone_velocities_fps preserves legacy zonal semantics; "
                "use velocities_fps with velocity_strategy='nodal' for nodal input"
            )
        velocity_values = zone_velocities_fps
        active_strategy = "zonal"
        active_smooth_continuity = False
    elif velocities_fps is not None:
        velocity_values = velocities_fps
        active_strategy = "zonal" if velocity_strategy is None else velocity_strategy
        active_smooth_continuity = (
            active_strategy == "zonal"
            and smooth_continuity
            and velocity_strategy == "zonal"
        )
    else:
        raise ValueError("Either zone_velocities_fps or velocities_fps must be provided")

    if active_strategy not in {"nodal", "zonal"}:
        raise ValueError(f"velocity_strategy must be 'nodal' or 'zonal', got {active_strategy!r}")

    # Validate array lengths based on strategy
    if active_strategy == "nodal":
        expected_vel_len = n_zones + 1
    else:
        expected_vel_len = n_zones

    if len(velocity_values) != expected_vel_len:
        raise ValueError(
            f"velocity input must have length {expected_vel_len} for {active_strategy} strategy, "
            f"got {len(velocity_values)}"
        )

    if not (len(frag_masses_grams) == len(frag_counts) == n_zones):
        raise ValueError(
            f"frag_masses_grams and frag_counts must have length {n_zones}, got: "
            f"masses={len(frag_masses_grams)}, counts={len(frag_counts)}"
        )

    angle_per_zone = 180.0 / n_zones
    zones: list[ZDataZone] = []

    for i in range(n_zones):
        # Compute polar angle bounds for this zone
        al = i * angle_per_zone
        am = (i + 0.5) * angle_per_zone
        au = (i + 1) * angle_per_zone

        # --- VELOCITY LOGIC ---
        if active_strategy == "nodal":
            # NODAL APPROACH: Use boundary velocities directly
            # v_lower = node[i], v_upper = node[i+1], v_mid = average
            vl = velocity_values[i]
            vu = velocity_values[i + 1]
            vm = (vl + vu) / 2.0
        elif active_smooth_continuity:
            # ZONAL WITH CONTINUITY: Interpolate from zone midpoints (legacy)
            if i == 0:
                vl = velocity_values[i]
            else:
                v_prev_mid = velocity_values[i-1]
                v_curr_mid = velocity_values[i]
                vl = (v_prev_mid + v_curr_mid) / 2.0

            if i == n_zones - 1:
                vu = velocity_values[i]
            else:
                v_curr_mid = velocity_values[i]
                v_next_mid = velocity_values[i+1]
                vu = (v_curr_mid + v_next_mid) / 2.0

            vm = (vl + vu) / 2.0
        else:
            # ZONAL UNIFORM: Stepped velocities (legacy)
            vm = velocity_values[i]
            vl = vm - velocity_spread_fps
            vu = vm + velocity_spread_fps
        # ---------------------------------

        # Convert grams → grains for ZDATA format
        # ZDATA uses grains (1 gram = 15.432358 grains)
        masses_grains = [m * GRAMS_TO_GRAINS for m in frag_masses_grams[i]]

        zones.append(ZDataZone(
            angle_lower=al,
            angle_mid=am,
            angle_upper=au,
            vel_lower=vl,
            vel_mid=vm,
            vel_upper=vu,
            mass_groups=masses_grains,
            count_groups=list(frag_counts[i]),
        ))

    return ZData(
        num_zones=n_zones,
        zones=zones,
        shape_factor=shape_factor,
        zdata_number=zdata_number,
        wpent_lbs=wpent_lbs,
    )
