"""Physics-side types and helpers."""

from .types import (
    LAM2Result,
    TargetConfig,
    TerminalCondition,
    WarheadConfig,
    CENTROID_HEIGHT_DB_FT,
    feet_to_meters,
    get_centroid_height_ft,
    meters_to_feet,
)
from .pfs_io import (
    CutoffSettings,
    MatrixSettings,
    generate_ip_dat,
    generate_ip_dat_batch,
    parse_lam2_dat,
    parse_lam2_dat_batch,
)
from .fullspray_wrapper import (
    FullSprayBatchExecutor,
    WorkerSandbox,
    get_fsm_executable_name,
    select_executable,
    get_data_directory,
)
from .reference_frames import (
    FrameTransform,
    compute_range_shift,
    target_to_weapon_frame,
    weapon_to_target_frame,
)
from .hypercube_builder import HypercubeBuilder

__all__ = [
    "LAM2Result",
    "TargetConfig",
    "TerminalCondition",
    "WarheadConfig",
    "CENTROID_HEIGHT_DB_FT",
    "feet_to_meters",
    "get_centroid_height_ft",
    "meters_to_feet",
    "CutoffSettings",
    "MatrixSettings",
    "generate_ip_dat",
    "generate_ip_dat_batch",
    "parse_lam2_dat",
    "parse_lam2_dat_batch",
    "FullSprayBatchExecutor",
    "WorkerSandbox",
    "get_fsm_executable_name",
    "select_executable",
    "get_data_directory",
    "FrameTransform",
    "compute_range_shift",
    "target_to_weapon_frame",
    "weapon_to_target_frame",
    "HypercubeBuilder",
]
