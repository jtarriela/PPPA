from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import numpy as np


def meters_to_feet(m: float) -> float:
    return m * 3.28084


def feet_to_meters(ft: float) -> float:
    return ft / 3.28084


@dataclass
class TerminalCondition:
    """Terminal conditions for a single FullSpray run."""

    hob_m: float
    velocity_mps: float
    aof_deg: float
    miss_deflection_m: float = 0.0
    miss_range_m: float = 0.0


@dataclass
class WarheadConfig:
    """Warhead configuration."""

    zdata_number: int
    zdata_path: Path


@dataclass
class TargetConfig:
    """Target configuration."""

    rcas_number: int
    rcas_path: Path
    intrvc_path: Path
    centroid_height_ft: float


@dataclass
class LAM2Result:
    """Parsed LAM2 output in weapon frame."""

    condition: TerminalCondition
    x_indices_m: np.ndarray
    y_indices_m: np.ndarray
    pk_grid: np.ndarray
    pbh_ft: float
    omega_deg: float
    velm_fps: float
    zdata: int
    rcas: int


CENTROID_HEIGHT_DB_FT: Dict[int, float] = {
    8421: 6.35,
    8422: 1.93,
    8423: 3.41,
    4901: 2.89,
    4902: 6.49,
    4903: 7.14,
    4904: 4.48,
    5221: 7.78,
    5222: 6.44,
    5223: 5.69,
    5224: 5.69,
    5231: 21.91,
    5232: 21.41,
    5233: 19.51,
    5234: 20.35,
    7131: 2.3,
    7132: 10.96,
    7151: 3.2,
    7152: 16.0,
    7153: 15.7,
    7173: 14.968,
    1001: 7.3,
    1002: 23.87,
    1003: 5.515,
    1004: 5.92,
    1005: 6.5,
    1006: 9.06,
    503: 6.5,
    1: 2.3,
}


def get_centroid_height_ft(rcas_number: int, fallback: Optional[float] = None) -> float:
    """Lookup centroid height with optional fallback."""
    value = CENTROID_HEIGHT_DB_FT.get(rcas_number, fallback)
    if value is None:
        raise KeyError(f"Unknown RCAS centroid height for {rcas_number}")
    return value
