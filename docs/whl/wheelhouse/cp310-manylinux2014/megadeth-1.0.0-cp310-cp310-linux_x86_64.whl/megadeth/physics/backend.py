"""
Physics backend selection for MEGADETH campaigns.

Provides selection between Fortran (FSM executable) and C++ (gfs_physics) backends.
Fortran is the default for backward compatibility.
"""
from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


class PhysicsBackend(Enum):
    """Available physics engine backends."""
    FORTRAN = "fortran"  # Legacy FSM executable (materiel_linux / materiel_win.exe)
    CPP = "cpp"          # gfs_physics C++ engine


# Check if C++ backend is available
try:
    from gfs_physics import GFSContext
    GFS_CPP_AVAILABLE = True
except ImportError:
    GFS_CPP_AVAILABLE = False
    GFSContext = None


def get_backend_from_config(config) -> PhysicsBackend:
    """
    Extract backend selection from campaign config.

    Args:
        config: Campaign configuration (dict or CampaignConfig)

    Returns:
        PhysicsBackend enum value (defaults to FORTRAN)
    """
    # Handle both dict and CampaignConfig objects
    if isinstance(config, dict):
        solver_config = config.get("solver", {})
        backend_str = (solver_config.get("backend") or "fortran").lower()
    else:
        # CampaignConfig object
        backend_str = (getattr(config.solver, "backend", None) or "fortran").lower()

    if backend_str == "cpp":
        if not GFS_CPP_AVAILABLE:
            import warnings
            warnings.warn(
                "C++ backend requested but gfs_physics not available. "
                "Falling back to Fortran."
            )
            return PhysicsBackend.FORTRAN
        return PhysicsBackend.CPP

    return PhysicsBackend.FORTRAN


def is_cpp_available() -> bool:
    """Check if C++ physics backend is available."""
    return GFS_CPP_AVAILABLE


def get_cpp_engine():
    """
    Get a configured C++ physics engine instance.

    Returns:
        GFSEngine instance or None if not available
    """
    if not GFS_CPP_AVAILABLE:
        return None

    from megadeth.physics.gfs_engine import GFSEngine
    return GFSEngine()
