from __future__ import annotations

import hashlib
from typing import Optional, Sequence, Tuple

import numpy as np

from megadeth.physics.reference_frames import compute_range_shift
from megadeth.physics.types import LAM2Result


class HypercubeBuilder:
    """
    Assemble a 5D Pk hypercube from LAM2 outputs.

    Native mode uses the first LAM2 result's grid directly and requires later
    results to match that grid. Legacy interpolated mode projects results onto
    an explicit miss grid and can apply the ShiftRange correction.
    """

    def __init__(
        self,
        hob_axis: Sequence[float],
        velocity_axis: Sequence[float],
        aof_axis: Sequence[float],
        miss_x_axis: Optional[Sequence[float]] = None,
        miss_y_axis: Optional[Sequence[float]] = None,
        apply_shift_range: bool = True,
        use_native_lam2_grid: bool = True,
    ):
        """
        Initialize HypercubeBuilder.

        Args:
            hob_axis: Height of burst values in meters
            velocity_axis: Velocity values in m/s
            aof_axis: Angle of fall values in degrees
            miss_x_axis: Deprecated miss X grid. If None, use the native LAM2 grid.
            miss_y_axis: Deprecated miss Y grid. If None, use the native LAM2 grid.
            apply_shift_range: Apply ShiftRange correction in interpolated mode.
            use_native_lam2_grid: If True, use native LAM2 grid from first result
        """
        self.axes = {
            "hob": np.array(hob_axis, dtype=float),
            "vel": np.array(velocity_axis, dtype=float),
            "aof": np.array(aof_axis, dtype=float),
        }
        
        self.use_native_lam2_grid = use_native_lam2_grid and (miss_x_axis is None or miss_y_axis is None)
        self.apply_shift_range = apply_shift_range and not self.use_native_lam2_grid
        
        # Native grid mode: axes will be set from first LAM2 result
        if self.use_native_lam2_grid:
            self.axes["miss_x"] = None
            self.axes["miss_y"] = None
            self.pk_hypercube = None  # Will be allocated on first result
            self._filled = None
            self._native_grid_initialized = False
        else:
            # Legacy interpolated mode
            self.axes["miss_x"] = np.array(miss_x_axis, dtype=float)
            self.axes["miss_y"] = np.array(miss_y_axis, dtype=float)
            shape = (
                len(hob_axis),
                len(velocity_axis),
                len(aof_axis),
                len(miss_x_axis),
                len(miss_y_axis),
            )
            self.pk_hypercube = np.zeros(shape, dtype=np.float64)
            self._filled = np.zeros(shape[:3], dtype=bool)
            self._native_grid_initialized = True

            if self.apply_shift_range:
                self._range_shifts_m = self._compute_range_shifts()

    def _compute_range_shifts(self) -> np.ndarray:
        """Pre-compute ShiftRange geometric correction for all HOB × AOF."""
        hob_axis = self.axes["hob"]
        aof_axis = self.axes["aof"]
        shifts = np.zeros((len(hob_axis), len(aof_axis)), dtype=float)
        for i_hob, hob in enumerate(hob_axis):
            for i_aof, aof in enumerate(aof_axis):
                shifts[i_hob, i_aof] = compute_range_shift(hob, aof)
        return shifts
    
    def _initialize_from_lam2(self, result: LAM2Result) -> None:
        """Initialize hypercube dimensions from first LAM2 result."""
        self.axes["miss_x"] = result.x_indices_m.copy()
        self.axes["miss_y"] = result.y_indices_m.copy()
        
        n_hob = len(self.axes["hob"])
        n_vel = len(self.axes["vel"])
        n_aof = len(self.axes["aof"])
        n_x = len(self.axes["miss_x"])
        n_y = len(self.axes["miss_y"])
        
        # Shape: (n_x, n_y, n_hob, n_vel, n_aof) - miss grid first, then terminal conditions
        self.pk_hypercube = np.zeros((n_x, n_y, n_hob, n_vel, n_aof), dtype=np.float64)
        self._filled = np.zeros((n_hob, n_vel, n_aof), dtype=bool)
        self._native_grid_initialized = True

    def add_lam2_result(self, result: LAM2Result) -> bool:
        """
        Add LAM2 result to hypercube.

        Native grid mode inserts the Pk grid directly. Interpolated mode maps
        onto the user-defined grid.
        """
        cond = result.condition
        i_hob = self._find_nearest_index(self.axes["hob"], cond.hob_m)
        i_vel = self._find_nearest_index(self.axes["vel"], cond.velocity_mps)
        i_aof = self._find_nearest_index(self.axes["aof"], cond.aof_deg)
        if None in (i_hob, i_vel, i_aof):
            return False
        
        if self.use_native_lam2_grid:
            return self._add_lam2_native(result, i_hob, i_vel, i_aof)
        else:
            return self._add_lam2_interpolated(result, i_hob, i_vel, i_aof)
    
    def _add_lam2_native(self, result: LAM2Result, i_hob: int, i_vel: int, i_aof: int) -> bool:
        """Insert LAM2 grid directly without interpolation."""
        if not self._native_grid_initialized:
            self._initialize_from_lam2(result)
        
        # Verify grid dimensions match
        if (len(result.x_indices_m) != len(self.axes["miss_x"]) or
            len(result.y_indices_m) != len(self.axes["miss_y"])):
            # Grid mismatch - this shouldn't happen if all runs use same IP.DAT settings
            return False
        
        # Insert Pk grid directly
        # LAM2 pk_grid shape is (n_y, n_x), we need (n_x, n_y)
        self.pk_hypercube[:, :, i_hob, i_vel, i_aof] = result.pk_grid.T
        self._filled[i_hob, i_vel, i_aof] = True
        return True
    
    def _add_lam2_interpolated(self, result: LAM2Result, i_hob: int, i_vel: int, i_aof: int) -> bool:
        """Interpolate LAM2 grid onto target miss grid (legacy mode)."""
        try:
            from scipy.interpolate import RegularGridInterpolator
        except Exception as exc:
            raise RuntimeError(
                "scipy is required for hypercube interpolation. "
                "Install with `pip install scipy`."
            ) from exc

        interp = RegularGridInterpolator(
            (result.x_indices_m, result.y_indices_m),
            result.pk_grid.T,
            method="linear",
            bounds_error=False,
            fill_value=0.0,  # Out-of-bounds returns 0 (equivalent to no kill)
        )

        mx, my = np.meshgrid(
            self.axes["miss_x"], self.axes["miss_y"], indexing="ij"
        )
        x_weapon = -mx  # symmetric axis
        y_weapon = -my  # asymmetric axis requires flip
        if self.apply_shift_range:
            y_weapon = y_weapon + self._range_shifts_m[i_hob, i_aof]

        pts = np.column_stack([x_weapon.ravel(), y_weapon.ravel()])
        pk_slice = interp(pts).reshape(mx.shape)

        self.pk_hypercube[i_hob, i_vel, i_aof, :, :] = pk_slice
        self._filled[i_hob, i_vel, i_aof] = True
        return True
    
    @property
    def grid_shape(self) -> Optional[Tuple[int, int]]:
        """Return miss grid shape (n_x, n_y) or None if not initialized."""
        if self.axes.get("miss_x") is None:
            return None
        return (len(self.axes["miss_x"]), len(self.axes["miss_y"]))

    def get_range_shift(self, hob_m: float, aof_deg: float) -> float:
        if not self.apply_shift_range:
            return 0.0
        i_hob = self._find_nearest_index(self.axes["hob"], hob_m)
        i_aof = self._find_nearest_index(self.axes["aof"], aof_deg)
        return self._range_shifts_m[i_hob, i_aof]

    def save_npz(self, path):
        """Save hypercube with SHA256 checksum."""
        if self.pk_hypercube is None:
            raise ValueError("Cannot save: hypercube not initialized (no LAM2 results added)")
        
        # Keep `pk_det` as the canonical key but also emit `pk_hypercube`
        # for backward compatibility with older docs/tools.
        save_dict = {
            "pk_det": self.pk_hypercube,
            "pk_hypercube": self.pk_hypercube,
        }
        
        # Save all axes
        for name, axis in self.axes.items():
            if axis is not None:
                save_dict[name] = axis
        
        # Add native grid flag for loaders
        save_dict["native_lam2_grid"] = np.array([self.use_native_lam2_grid])
        
        if self.apply_shift_range and hasattr(self, '_range_shifts_m'):
            save_dict["range_shifts_m"] = self._range_shifts_m
            
        np.savez_compressed(path, **save_dict)
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()

    @staticmethod
    def _find_nearest_index(axis: np.ndarray, value: float):
        if axis is None:
            return None
        idx = int(np.argmin(np.abs(axis - value)))
        if axis.size == 1:
            return idx
        step = np.mean(np.diff(axis))
        if abs(axis[idx] - value) > max(1e-6, 0.01 * step):
            return None
        return idx
