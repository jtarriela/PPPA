import streamlit as st
import duckdb
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from pathlib import Path
import yaml
import io

from megadeth.visualization.plots import detect_hypercube_format, normalize_hypercube_to_native
from megadeth.visualization.plotly_plots import (
    plot_pk_heatmap_plotly,
    plot_3d_volume_plotly,
    plot_hob_mr_contour_plotly,
    plot_iso_mesh_colored_by_pk,
    plot_salvo_boxplot_plotly,
    plot_r2k_heatmap_plotly,
    compute_hob_mr_grid,
    plot_stoplight_grid_plotly,
    plot_error_model_pdf_plotly,
    plot_pk_vs_vel_hob_plotly,
    plot_r2k_stoplight_plotly,
    plot_multi_threshold_boxplot_plotly,
    plot_mc_draw_diagnostics_plotly,
)
from megadeth.physics.zdata import read_zdata
from megadeth.config.loader import load_config

# Page Configuration
st.set_page_config(
    page_title="MEGADETH Analytics Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)

# =============================================================================
# Database & Data Loading
# =============================================================================

@st.cache_resource
def get_db_connection(db_path: str):
    """Connect to DuckDB (cached) with HPC-safe settings (no network access)."""
    try:
        # Disable extension auto-install for air-gapped HPC environments
        config = {
            "autoinstall_known_extensions": False,
            "autoload_known_extensions": False,
        }
        conn = duckdb.connect(db_path, read_only=True, config=config)
        return conn
    except Exception as e:
        st.error(f"Failed to connect to database at {db_path}: {e}")
        return None

def get_campaigns(conn):
    """Fetch list of campaigns."""
    query = """
    SELECT campaign_id, name, description, created_at, status 
    FROM campaigns 
    ORDER BY created_at DESC
    """
    return conn.execute(query).df()

def get_hypercube_info(conn, campaign_id):
    """Fetch hypercube info for a campaign."""
    query = """
    SELECT hypercube_id, npz_path, miss_x_axis, miss_y_axis 
    FROM pk_hypercubes 
    WHERE campaign_id = ? 
    ORDER BY created_at DESC LIMIT 1
    """
    result = conn.execute(query, [campaign_id]).fetchone()
    if result:
        return {
            "id": result[0],
            "path": result[1],
            "miss_x": np.array(result[2]) if result[2] else None,
            "miss_y": np.array(result[3]) if result[3] else None
        }
    return None

def get_discrete_analysis(conn, hypercube_id):
    """Fetch discrete analysis results."""
    query = """
    SELECT analysis_id, system_pk_npz, reliability_npz 
    FROM discrete_analyses 
    WHERE hypercube_id = ? 
    ORDER BY created_at DESC LIMIT 1
    """
    result = conn.execute(query, [hypercube_id]).fetchone()
    if result:
        return {"id": result[0], "system_pk_path": result[1], "reliability_path": result[2]}
    return None

def get_mc_analysis(conn, hypercube_id):
    """Fetch Monte Carlo analysis results by hypercube ID.
    
    Handles schema variations - older DBs may not have result_npz/draws_npz columns.
    """
    # First check if the table exists and what columns it has
    try:
        cols_result = conn.execute("""
            SELECT column_name FROM information_schema.columns 
            WHERE table_name = 'monte_carlo_analyses'
        """).fetchall()
        existing_cols = {row[0] for row in cols_result}
    except Exception:
        # Table might not exist at all (pure discrete campaign)
        return None
    
    if not existing_cols:
        return None  # Table doesn't exist
    
    # Build query based on available columns
    has_result_npz = 'result_npz' in existing_cols
    has_draws_npz = 'draws_npz' in existing_cols
    
    select_cols = ["analysis_id"]
    if has_result_npz:
        select_cols.append("result_npz")
    if has_draws_npz:
        select_cols.append("draws_npz")
    select_cols.extend(["precision_label", "n_salvos", "n_shots", "random_seed"])
    
    # Filter to only columns that exist
    valid_cols = [c for c in select_cols if c in existing_cols or c == "analysis_id"]
    
    query = f"""
    SELECT {', '.join(valid_cols)}
    FROM monte_carlo_analyses 
    WHERE hypercube_id = ? 
    ORDER BY analysis_id DESC LIMIT 1
    """
    
    try:
        result = conn.execute(query, [hypercube_id]).fetchone()
    except Exception:
        return None
    
    if result:
        # Map results back to dict, handling missing columns
        col_idx = {col: i for i, col in enumerate(valid_cols)}
        return {
            "id": result[col_idx.get("analysis_id", 0)] if "analysis_id" in col_idx else None,
            "result_path": result[col_idx["result_npz"]] if "result_npz" in col_idx else None,
            "draws_path": result[col_idx["draws_npz"]] if "draws_npz" in col_idx else None,
            "precision_label": result[col_idx["precision_label"]] if "precision_label" in col_idx else None,
            "n_salvos": result[col_idx["n_salvos"]] if "n_salvos" in col_idx else None,
            "n_shots_per_salvo": result[col_idx["n_shots"]] if "n_shots" in col_idx else None,
            "random_seed": result[col_idx["random_seed"]] if "random_seed" in col_idx else None,
        }
    return None

@st.cache_data
def load_npz_data(path: str, base_dir: str = None):
    """Load NPZ file (cached). Resolves relative paths against base_dir."""
    if path is None:
        return None
    
    p = Path(path)
    
    # If path is relative and base_dir is provided, resolve against base_dir
    if not p.is_absolute() and base_dir:
        p = Path(base_dir) / p
    
    # Also try resolving relative to CWD if not found
    if not p.exists() and base_dir:
        # Try the original path as-is (relative to CWD)
        cwd_path = Path(path)
        if cwd_path.exists():
            p = cwd_path
    
    try:
        with np.load(str(p)) as data:
            return dict(data)
    except Exception as e:
        st.error(f"Failed to load NPZ at {p}: {e}")
        return None

def compute_curvature(data):
    """
    Compute scalar curvature (Laplacian) of a 3D array.
    Returns the sum of second derivatives (Laplacian).
    Positive = Valley (concave up), Negative = Peak (concave down), Zero = Flat.
    """
    grads = np.gradient(data)
    # Laplacian is divergence of gradient (sum of second partials)
    laplacian = np.sum([np.gradient(g, axis=i) for i, g in enumerate(grads)], axis=0)
    return laplacian

# =============================================================================
# Main Application
# =============================================================================

def main():
    # Sidebar: Configuration
    st.sidebar.title("MEGADETH Configuration")
    
    # 1. Config File Selection
    # Search for config files
    config_search_paths = [Path("configs"), Path("output")]
    available_configs = []
    for p in config_search_paths:
        if p.exists():
            available_configs.extend(sorted(p.rglob("*.yaml")))
            
    config_opts = [str(p) for p in available_configs] + ["Manual Entry..."]
    selected_config = st.sidebar.selectbox("Select Campaign Config", config_opts, index=0 if available_configs else len(config_opts)-1)
    
    config = {}
    config_path = None
    
    if selected_config == "Manual Entry...":
        config_path_str = st.sidebar.text_input("Config Path", value="configs/sample_discrete_campaign.yaml")
        config_path = Path(config_path_str)
    else:
        config_path = Path(selected_config)
    
    # Load Config and Derive Paths
    db_path = "output/megadeth.duckdb" # Default fallback
    zdata_path = None
    analysis_type = "unknown"  # Will be "discrete", "monte_carlo", or "hybrid"
    
    if config_path and config_path.exists():
        try:
            with open(config_path) as f:
                config = yaml.safe_load(f)
            
            st.sidebar.success(f"Loaded: {config.get('name', config_path.name)}")
            
            # Detect analysis type from config
            mc_enabled = config.get('monte_carlo', {}).get('enabled', False)
            disc_enabled = config.get('discrete_analysis', {}).get('enabled', False)
            
            if mc_enabled and disc_enabled:
                analysis_type = "hybrid"
            elif mc_enabled:
                analysis_type = "monte_carlo"
            elif disc_enabled:
                analysis_type = "discrete"
            else:
                analysis_type = "discrete"  # Default fallback
            
            st.sidebar.info(f"Analysis Type: **{analysis_type.replace('_', ' ').title()}**")
            
            # Derive DB Path
            if 'output' in config and 'directory' in config['output']:
                out_dir = Path(config['output']['directory'])
                # Handle relative paths - resolve relative to config file directory
                if not out_dir.is_absolute():
                    out_dir = config_path.parent / out_dir
                db_path = str(out_dir / "megadeth.duckdb")
            
            # Derive ZDATA Path (resolve relative to config file directory)
            if 'warheads' in config and len(config['warheads']) > 0:
                zdata_path = config['warheads'][0].get('zdata_path')
                if zdata_path and not Path(zdata_path).is_absolute():
                    zdata_resolved = config_path.parent / zdata_path
                    if zdata_resolved.exists():
                        zdata_path = str(zdata_resolved)
                
        except Exception as e:
            st.sidebar.error(f"Error loading config: {e}")
    else:
        st.sidebar.warning("Config file not found. Using defaults.")

    # DB Connection
    st.sidebar.markdown("---")
    st.sidebar.caption(f"**Database:** `{db_path}`")
    
    if not Path(db_path).exists():
        st.sidebar.warning(f"Database not found at {db_path}")
        st.info("Please run the campaign to generate results.")
        # Allow manual override if config-derived path is wrong
        db_path = st.sidebar.text_input("Override Database Path", value=db_path)
        if not Path(db_path).exists():
            return

    conn = get_db_connection(db_path)
    if not conn:
        return

    # 2. Campaign Selection
    campaigns = get_campaigns(conn)
    if campaigns.empty:
        st.warning("No campaigns found in database.")
        return

    selected_campaign_name = st.sidebar.selectbox(
        "Select Campaign", 
        campaigns['name'].tolist(),
        format_func=lambda x: f"{x} ({campaigns[campaigns['name']==x]['status'].values[0]})"
    )
    
    campaign_row = campaigns[campaigns['name'] == selected_campaign_name].iloc[0]
    campaign_id = campaign_row['campaign_id']
    
    st.sidebar.info(f"ID: {campaign_id}\nCreated: {campaign_row['created_at']}")

    # 3. Load Data
    # NPZ paths in DB are relative to where the campaign was run (config file's directory)
    workspace_dir = str(config_path.parent) if config_path and config_path.exists() else str(Path(db_path).parent)
    
    hc_info = get_hypercube_info(conn, campaign_id)
    if not hc_info:
        st.error("No hypercube data found for this campaign.")
        return

    disc_info = get_discrete_analysis(conn, hc_info['id'])
    mc_info = get_mc_analysis(conn, hc_info['id'])  # Look up by hypercube_id
    
    # Load NPZ files - resolve paths relative to workspace directory (where campaign ran)
    hc_data = load_npz_data(hc_info['path'], workspace_dir)
    disc_data = load_npz_data(disc_info['system_pk_path'], workspace_dir) if disc_info else None
    mc_data = load_npz_data(mc_info['result_path'], workspace_dir) if mc_info and mc_info.get('result_path') else None
    mc_draws = load_npz_data(mc_info['draws_path'], workspace_dir) if mc_info and mc_info.get('draws_path') else None
    
    if not hc_data:
        return

    # Extract Axes
    hob = hc_data['hob_axis'] if 'hob_axis' in hc_data else hc_data['hob']
    vel = hc_data['velocity_axis'] if 'velocity_axis' in hc_data else hc_data['vel']
    aof = hc_data['aof_axis'] if 'aof_axis' in hc_data else hc_data['aof']
    
    # Main Layout
    st.title(f"Campaign Analysis: {selected_campaign_name}")
    
    # View Mode Selection - varies by analysis type
    if analysis_type == "monte_carlo":
        view_modes = ["Campaign Statistics", "Weapon Characteristics", "MC Salvo Analysis", "Single Slice Analysis"]
    elif analysis_type == "discrete":
        view_modes = ["Campaign Statistics", "Weapon Characteristics", "Single Slice Analysis", "3D Volume Explorer"]
    else:  # hybrid or unknown
        view_modes = ["Campaign Statistics", "Weapon Characteristics", "MC Salvo Analysis", "Single Slice Analysis", "3D Volume Explorer"]
    
    view_mode = st.radio("View Mode", view_modes, horizontal=True)
    
    if view_mode == "Weapon Characteristics":
        st.subheader("Weapon Characteristics (ZDATA Analysis)")
        
        # 1. ZDATA Path (from Config or Manual)
        if not zdata_path:
            # Fallback search if not in config
            search_paths = [Path("megadeth/executables/input"), Path("megadeth/legacy/MEGADETH_Headless_v2/Input"), Path(".")]
            zdata_files = []
            for p in search_paths:
                if p.exists():
                    zdata_files.extend(sorted(p.glob("ZDATA*.DAT")))
            
            zdata_opts = [str(p) for p in zdata_files] + ["Manual Entry..."]
            zdata_sel = st.selectbox("Select ZDATA File (Not found in config)", zdata_opts)
            if zdata_sel == "Manual Entry...":
                zdata_path = st.text_input("ZDATA Path", value="megadeth/executables/input/ZDATA1200.DAT")
            else:
                zdata_path = zdata_sel
        else:
            st.info(f"Using ZDATA from config: `{zdata_path}`")
            # Allow override
            if not Path(zdata_path).exists():
                st.error(f"File not found: {zdata_path}")
                zdata_path = st.text_input("Override ZDATA Path")

        # 2. Load and Analyze
        if zdata_path and Path(zdata_path).exists():
            try:
                zdata = read_zdata(Path(zdata_path))
                
                # Extract data for plotting
                raw_angles = [z.angle_mid for z in zdata.zones]
                raw_masses = [z.total_mass for z in zdata.zones] # grains
                
                # Conversions
                # Velocity: ft/s -> m/s
                FT_TO_M = 0.3048
                # Mass: grains -> kg (for KE calc)
                GRAINS_TO_KG = 6.479891e-5
                # Mass: grains -> grams (for display)
                GRAINS_TO_GRAMS = 0.06479891
                
                # Convert raw masses to grams for display
                raw_masses_grams = [m * GRAINS_TO_GRAMS for m in raw_masses]
                
                raw_velocities = []
                raw_energies_mj = []
                
                for z in zdata.zones:
                    # Original KE is in grains * (ft/s)^2 * 0.5 (from zdata.py)
                    # We need to convert to Joules then MJ
                    
                    # Compute v_avg in m/s
                    m_grains = z.total_mass
                    ke_raw = z.total_ke # 0.5 * grains * (ft/s)^2
                    
                    if m_grains > 0:
                        v_fps = np.sqrt(2 * ke_raw / m_grains)
                        v_mps = v_fps * FT_TO_M
                    else:
                        v_mps = 0
                    
                    # Compute KE in MJ
                    # KE_J = 0.5 * M_kg * V_mps^2
                    m_kg = m_grains * GRAINS_TO_KG
                    ke_j = 0.5 * m_kg * (v_mps**2)
                    ke_mj = ke_j / 1e6
                    
                    raw_velocities.append(v_mps)
                    raw_energies_mj.append(ke_mj)

                # Mirror data to 360 degrees (0-180 -> 180-360)
                # ZDATA is axisymmetric. Mirror across Z-axis (vertical).
                # Angles: [10, 20... 170] -> [10...170, 190...350]
                # Note: If we just reflect, 10 deg (front right) corresponds to 350 deg (front left).
                # Mirror logic: 360 - angle
                
                angles = raw_angles + [360 - a for a in reversed(raw_angles)]
                masses_grams = raw_masses_grams + list(reversed(raw_masses_grams))
                velocities = raw_velocities + list(reversed(raw_velocities))
                energies = raw_energies_mj + list(reversed(raw_energies_mj))
                
                # Close the loop for clean plotting
                angles.append(angles[0])
                masses_grams.append(masses_grams[0])
                velocities.append(velocities[0])
                energies.append(energies[0])
                
                # 3. Radar Plots
                st.markdown("### Fragment Distribution (Radar Plots)")
                
                col1, col2, col3 = st.columns(3)
                
                def make_radar(r, theta, color=None):
                    """Create radar plot without title (title handled by Streamlit)."""
                    import plotly.graph_objects as go_local
                    fig = go_local.Figure(data=go_local.Scatterpolar(
                        r=r, theta=theta, fill='toself',
                        line_color=color,
                        fillcolor=color.replace('rgb', 'rgba').replace(')', ',0.3)') if color and 'rgb' in color else None
                    ))
                    fig.update_layout(
                        showlegend=False,
                        polar=dict(
                            bgcolor="white",
                            radialaxis=dict(visible=True, showticklabels=True, tickfont=dict(color="black", size=12), gridcolor="lightgray"),
                            angularaxis=dict(direction="clockwise", rotation=90, tickfont=dict(color="black", size=11))
                        ),
                        paper_bgcolor="rgba(255, 255, 255, 0.95)", 
                        font=dict(color="black"),
                        margin=dict(l=35, r=35, t=20, b=35),
                        height=350
                    )
                    return fig
                
                with col1:
                    st.markdown("**Fragment Mass**")
                    st.caption("Total Mass (grams)")
                    fig_mass = make_radar(masses_grams, angles, "#1f77b4")
                    st.plotly_chart(fig_mass, use_container_width=True)
                    
                with col2:
                    st.markdown("**Fragment Velocity**")
                    st.caption("Avg Velocity (m/s)")
                    fig_vel = make_radar(velocities, angles, "#ff7f0e")
                    st.plotly_chart(fig_vel, use_container_width=True)
                    
                with col3:
                    st.markdown("**Kinetic Energy**")
                    st.caption("Total KE (MJ)")
                    fig_ke = make_radar(energies, angles, "#2ca02c")
                    st.plotly_chart(fig_ke, use_container_width=True)
                
                # 4. Campaign Config (TLE/CEP)
                st.markdown("### Campaign Configuration (Error Model)")
                
                if config:
                    # Support discrete_analysis, legacy structure, or MC precisions
                    err = config.get('discrete_analysis', {}).get('error_model', {})
                    if not err:
                         err = config.get('discrete_grid_analysis', {}).get('error_model', {})
                    
                    # Fallback to MC precision config (first precision entry)
                    if not err:
                        mc_precs = config.get('monte_carlo', {}).get('precisions', [])
                        if mc_precs:
                            prec = mc_precs[0]  # Use first precision
                            err = {
                                'tle_radius_m': prec.get('tle_radius_m', 0),
                                'tle_fraction': prec.get('tle_fraction', 0.9),
                                'cep_radius_m': prec.get('cep_radius_m', 0),
                                'cep_fraction': prec.get('cep_fraction', 0.5),
                                'fixed_bias_x_m': prec.get('fixed_bias_deflection_m', 0),
                                'fixed_bias_y_m': prec.get('fixed_bias_range_m', 0),
                            }
                    
                    c1, c2, c3, c4 = st.columns(4)
                    tle_radius = err.get('tle_radius_m', 0)
                    tle_frac = err.get('tle_fraction', 0.9)
                    cep_radius = err.get('cep_radius_m', 0)
                    cep_frac = err.get('cep_fraction', 0.5)
                    bias_x = err.get('fixed_bias_x_m', 0)
                    bias_y = err.get('fixed_bias_y_m', 0)
                    
                    c1.metric("TLE Radius", f"{tle_radius} m", f"P={tle_frac:.0%}")
                    c2.metric("CEP Radius", f"{cep_radius} m", f"P={cep_frac:.0%}")
                    c3.metric("Fixed Bias X", f"{bias_x} m")
                    c4.metric("Fixed Bias Y", f"{bias_y} m")
                    
                    # Convert radii to 1-sigma values for display
                    # TLE: P=0.9 -> k=sqrt(-2*ln(0.1)) ≈ 2.146
                    # CEP: P=0.5 -> k=sqrt(-2*ln(0.5)) ≈ 1.177
                    tle_k = np.sqrt(-2 * np.log(1 - tle_frac)) if tle_frac > 0 and tle_frac < 1 else 1.0
                    cep_k = np.sqrt(-2 * np.log(1 - cep_frac)) if cep_frac > 0 and cep_frac < 1 else 1.0
                    tle_1sigma = tle_radius / tle_k if tle_k > 0 else tle_radius
                    cep_1sigma = cep_radius / cep_k if cep_k > 0 else cep_radius
                    
                    # Show error model visualization
                    mc_enabled = config.get('monte_carlo', {}).get('enabled', False)
                    
                    # For MC campaigns with draws available, show draw diagnostics
                    if mc_enabled and mc_draws is not None and 'aimpoint_offsets' in mc_draws:
                        st.markdown("### Monte Carlo Draw Diagnostics (Sampled Errors)")
                        
                        # Toggle to show/hide the plot (default off for performance)
                        show_draws = st.checkbox(
                            "Show MC Draw Scatter Plots", 
                            value=False,
                            help="Toggle to display scatter plots of sampled TLE/CEP draws. May slow down page with many points."
                        )
                        
                        if show_draws:
                            st.caption("Actual TLE/CEP samples used in Monte Carlo analysis — circles show 1/2/3σ regions")
                            
                            aim_offsets = mc_draws['aimpoint_offsets']
                            disp_offsets = mc_draws['dispersion_offsets']
                            
                            n_salvos = mc_info.get('n_salvos', aim_offsets.shape[0]) if mc_info else aim_offsets.shape[0]
                            n_shots = mc_info.get('n_shots_per_salvo', disp_offsets.shape[1] if disp_offsets.ndim == 3 else 1) if mc_info else 1
                            
                            var_bias = (bias_x, bias_y) if (bias_x != 0 or bias_y != 0) else None
                            
                            fig_draws = plot_mc_draw_diagnostics_plotly(
                                aimpoint_offsets=aim_offsets,
                                dispersion_offsets=disp_offsets,
                                tle_1sigma=tle_1sigma,
                                cep_1sigma=cep_1sigma,
                                var_bias=var_bias,
                                n_salvos=n_salvos,
                                n_shots_per_salvo=n_shots,
                                title="Monte Carlo Delivery Error Draws",
                                height=600,
                            )
                            st.plotly_chart(fig_draws, use_container_width=True)
                        else:
                            # Show summary statistics instead
                            aim_offsets = mc_draws['aimpoint_offsets']
                            disp_offsets = mc_draws['dispersion_offsets']
                            
                            st.caption("Summary of sampled error distributions (enable checkbox above to see scatter plots)")
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                st.markdown("**TLE (Aimpoint) Draws**")
                                st.write(f"- Samples: {aim_offsets.shape[0]:,}")
                                st.write(f"- Std X: {np.std(aim_offsets[:, 0]):.2f} m (expected 1σ: {tle_1sigma:.2f} m)")
                                st.write(f"- Std Y: {np.std(aim_offsets[:, 1]):.2f} m")
                            with col2:
                                st.markdown("**CEP (Dispersion) Draws**")
                                disp_flat = disp_offsets.reshape(-1, 2) if disp_offsets.ndim == 3 else disp_offsets
                                st.write(f"- Samples: {disp_flat.shape[0]:,}")
                                st.write(f"- Std X: {np.std(disp_flat[:, 0]):.2f} m (expected 1σ: {cep_1sigma:.2f} m)")
                                st.write(f"- Std Y: {np.std(disp_flat[:, 1]):.2f} m")
                    
                    # For discrete campaigns OR as a fallback, show theoretical PDF
                    elif disc_info or not mc_enabled:
                        st.markdown("### Delivery Error Model (Probability Density Function)")
                        st.caption("2D Gaussian probability *density* (can exceed 1) — integrates with Pk over miss grid to give System Pk")
                        
                        if tle_radius > 0 or cep_radius > 0:
                            fig_pdf = plot_error_model_pdf_plotly(
                                tle_radius_m=tle_radius,
                                tle_fraction=tle_frac,
                                cep_radius_m=cep_radius,
                                cep_fraction=cep_frac,
                                bias_x_m=bias_x,
                                bias_y_m=bias_y,
                                height=500,
                            )
                            st.plotly_chart(fig_pdf, use_container_width=True)
                            
                            # Display individual sigma values
                            st.markdown("**Error Model Parameters (1σ values):**")
                            col_tle, col_cep, col_combined = st.columns(3)
                            with col_tle:
                                st.metric("TLE 1σ", f"{tle_1sigma:.2f} m", 
                                         help=f"σ_TLE = {tle_radius:.1f}m / {tle_k:.3f} (from P={tle_frac:.0%})")
                            with col_cep:
                                st.metric("CEP 1σ", f"{cep_1sigma:.2f} m",
                                         help=f"σ_CEP = {cep_radius:.1f}m / {cep_k:.3f} (from P={cep_frac:.0%})")
                            with col_combined:
                                sigma_combined = np.sqrt(tle_1sigma**2 + cep_1sigma**2)
                                st.metric("Combined 1σ", f"{sigma_combined:.2f} m",
                                         help="σ_total = √(σ_TLE² + σ_CEP²)")
                            
                            # Interpretation blurb
                            with st.expander("How to Interpret This Plot"):
                                st.markdown(f"""
                                **What the PDF represents:**
                                - This is a *probability density* — values can exceed 1.0
                                - The integral over any region gives the probability of landing in that region
                                - Total integral over all space = 1.0
                                
                                **Circle Legend:**
                                - **TLE (solid blue)**: r = {tle_radius:.1f}m — {tle_frac:.0%} of impacts fall within this radius (Target Location Error)
                                - **TLE 1σ (dashed blue)**: σ = {tle_1sigma:.2f}m — standard deviation of TLE distribution
                                - **CEP (solid gold)**: r = {cep_radius:.1f}m — {cep_frac:.0%} of impacts fall within this radius (Circular Error Probable)
                                - **CEP 1σ (dashed gold)**: σ = {cep_1sigma:.2f}m — standard deviation of CEP distribution
                                - **Combined 1σ (dotted red)**: σ = {sigma_combined:.2f}m — RSS of TLE and CEP sigmas
                                
                                **Connection to System Pk:**
                                $$P_{{system}} = \\iint P_k(x,y) \\cdot PDF(x,y) \\, dx \\, dy$$
                                
                                The System Pk is the integral of (Raw Pk × PDF) over the miss grid.
                                
                                **What it means for performance:**
                                - Tight distribution (small TLE/CEP) → probability concentrated near target center where Pk is highest
                                - Wide distribution → probability spread out, more misses, lower System Pk
                                - Your combined σ = **{sigma_combined:.2f} m** — smaller is better!
                                """)
                        else:
                            st.info("Error model has zero radius - perfect accuracy assumed.")
                    else:
                        st.info("Run Monte Carlo analysis to see draw diagnostics, or enable discrete analysis for theoretical PDF.")
                else:
                    st.warning("No configuration loaded.")

            except Exception as e:
                st.error(f"Failed to read ZDATA file: {e}")
        else:
            st.warning(f"ZDATA file not found: {zdata_path}")

    if view_mode == "Campaign Statistics":
        st.subheader("Campaign Statistics")
        if disc_data:
            # 1. System Pk Overview
            st.markdown("### System Probability of Kill (Single Shot)")
            sys_pk = disc_data['system_pk'] if 'system_pk' in disc_data else disc_data['reliability']
            
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Max System Pk", f"{np.max(sys_pk):.4f}", help="Maximum Pk achievable considering guidance/delivery errors.")
            c2.metric("Mean System Pk", f"{np.mean(sys_pk):.4f}")
            
            # Check for Warhead Potential (Pk_det)
            if 'pk_det' in hc_data:
                pk_det = hc_data['pk_det']
                # Use nanmax to handle potential NaNs in raw physics output
                max_warhead_pk = np.nanmax(pk_det)
                c3.metric("Max Warhead Pk", f"{max_warhead_pk:.4f}", help="Maximum Pk of the warhead (assuming perfect impact). If this is high but System Pk is low, accuracy is the bottleneck.")
            else:
                c3.metric("Min System Pk", f"{np.min(sys_pk):.4f}")
                
            c4.metric("Std Dev", f"{np.std(sys_pk):.4f}")
            
            if np.max(sys_pk) < 0.8 and 'pk_det' in hc_data:
                max_warhead_pk = np.nanmax(hc_data['pk_det'])
                if max_warhead_pk > 0.9:
                    st.warning("**Note:** Warhead is lethal (>0.9), but Single-Shot System Pk is low (<0.8). This indicates **Delivery Accuracy (TLE/CEP)** is limiting performance. Use the 'Accumulated Pk' chart below to see if multiple shots solve this.")
            
            # 2. Accumulated Pk (if available)
            if 'mean_pk_by_shot' in disc_data:
                st.markdown("### Accumulated Pk by Salvo Size")
                mpk = disc_data['mean_pk_by_shot'] # shape: (K, H, V, A)
                
                # Compute max Pk achievable for each shot count
                max_pk_by_shot = np.max(mpk, axis=(1, 2, 3))
                mean_pk_by_shot = np.mean(mpk, axis=(1, 2, 3))
                
                df_pk = pd.DataFrame({
                    "Shot Count": range(1, len(max_pk_by_shot) + 1),
                    "Max Pk": max_pk_by_shot,
                    "Mean Pk": mean_pk_by_shot
                })
                
                c_chart, c_table = st.columns([2, 1])
                with c_chart:
                    # Plotly chart
                    fig_pk = px.line(df_pk, x="Shot Count", y=["Max Pk", "Mean Pk"], 
                                     title="Effectiveness vs. Salvo Size", markers=True)
                    fig_pk.update_layout(yaxis_range=[0, 1.05], hovermode="x unified")
                    st.plotly_chart(fig_pk, use_container_width=True)
                with c_table:
                    st.dataframe(df_pk.set_index("Shot Count"), use_container_width=True)
            
            # 3. Rounds to Kill (if available)
            if 'rounds_to_kill' in disc_data and 'pk_thresholds' in disc_data:
                st.markdown("### Rounds to Kill (R2K)")
                r2k = disc_data['rounds_to_kill'] # shape: (H, V, A, T)
                thresholds = disc_data['pk_thresholds']
                
                r2k_stats = []
                for i, thresh in enumerate(thresholds):
                    # Extract slice for this threshold
                    r2k_slice = r2k[:, :, :, i].flatten()
                    # Filter out NaNs (infeasible)
                    valid_r2k = r2k_slice[~np.isnan(r2k_slice)]
                    
                    if len(valid_r2k) > 0:
                        r2k_stats.append({
                            "Target Pk": f"{thresh:.0%}",
                            "Median Rounds": f"{np.median(valid_r2k):.1f}",
                            "Mean Rounds": f"{np.mean(valid_r2k):.1f}",
                            "Feasible Envelope": f"{len(valid_r2k)/len(r2k_slice):.1%}"
                        })
                    else:
                        r2k_stats.append({
                            "Target Pk": f"{thresh:.0%}",
                            "Median Rounds": "N/A",
                            "Mean Rounds": "N/A",
                            "Feasible Envelope": "0%"
                        })
                
                st.table(pd.DataFrame(r2k_stats))
            
            # 4. Sensitivity / Robustness
            st.markdown("### Robustness Analysis")
            if 'sensitivity' in disc_data:
                sens = disc_data['sensitivity']
            else:
                grads = np.gradient(sys_pk)
                sens = np.sqrt(sum(g**2 for g in grads))
            
            c1, c2 = st.columns(2)
            c1.metric("Max Gradient (Worst Case)", f"{np.max(sens):.4f}", help="High values indicate regions where Pk is very sensitive to errors.")
            c2.metric("Mean Gradient (Stability)", f"{np.mean(sens):.4f}", help="Low mean gradient implies generally stable performance.")
            
        elif mc_data:
            # MC-only campaign - show MC statistics
            st.markdown("### Monte Carlo Analysis Results")
            
            # Single-shot Pk statistics
            if 'mean_acc_pk_by_shot' in mc_data:
                acc_pk = mc_data['mean_acc_pk_by_shot']  # Shape: (n_shots, n_hob, n_vel, n_aof)
                single_shot_pk = acc_pk[0]  # First shot
                
                c1, c2, c3, c4 = st.columns(4)
                c1.metric("Mean Single-Shot Pk", f"{np.nanmean(single_shot_pk):.4f}")
                c2.metric("Max Single-Shot Pk", f"{np.nanmax(single_shot_pk):.4f}")
                c3.metric("Final Salvo Pk (Mean)", f"{np.nanmean(acc_pk[-1]):.4f}")
                c4.metric("Final Salvo Pk (Max)", f"{np.nanmax(acc_pk[-1]):.4f}")
                
                # Accumulated Pk progression
                st.markdown("### Accumulated Pk by Shot Number")
                n_shots = acc_pk.shape[0]
                mean_acc_pk = [np.nanmean(acc_pk[i]) for i in range(n_shots)]
                max_acc_pk = [np.nanmax(acc_pk[i]) for i in range(n_shots)]
                
                df_pk = pd.DataFrame({
                    "Shot Count": range(1, n_shots + 1),
                    "Max Pk": max_acc_pk,
                    "Mean Pk": mean_acc_pk
                })
                
                c_chart, c_table = st.columns([2, 1])
                with c_chart:
                    fig_pk = px.line(df_pk, x="Shot Count", y=["Max Pk", "Mean Pk"], 
                                     title="Accumulated Pk vs. Shot Count (MC)", markers=True)
                    fig_pk.update_layout(yaxis_range=[0, 1.05], hovermode="x unified")
                    st.plotly_chart(fig_pk, use_container_width=True)
                with c_table:
                    st.dataframe(df_pk.set_index("Shot Count"), use_container_width=True)
            
            # Rounds to Kill from MC
            if 'rounds_to_kill' in mc_data and 'pk_thresholds' in mc_data:
                st.markdown("### Rounds-to-Kill Summary (MC)")
                r2k = mc_data['rounds_to_kill']
                thresholds = mc_data['pk_thresholds']
                
                r2k_stats = []
                for i, thresh in enumerate(thresholds):
                    data = r2k[..., i].flatten()
                    valid = data[~np.isnan(data)]
                    if len(valid) > 0:
                        r2k_stats.append({
                            "Threshold": f"Pk >= {thresh:.0%}",
                            "Median": f"{np.median(valid):.1f}",
                            "Mean": f"{np.mean(valid):.1f}",
                            "Std": f"{np.std(valid):.1f}",
                            "Min": int(np.min(valid)),
                            "Max": int(np.max(valid)),
                        })
                if r2k_stats:
                    st.table(pd.DataFrame(r2k_stats))
        else:
            st.warning("No analysis data found. Run discrete or Monte Carlo analysis first.")

    if view_mode == "Single Slice Analysis":
        col_ctrl, col_plot = st.columns([1, 3])
        
        with col_ctrl:
            st.subheader("Slice Controls")
            
            # Plot type selection first - determines which sliders to show
            plot_type = st.selectbox("Plot Type", [
                "Pk Contour (Miss Grid)",
                "System Pk (Vel vs HOB)",
                "HOB vs Miss Range Contour",
                "Rounds-to-Kill Heatmap",
                "R2K Stoplight Grid",
                "R2K Box Plot (by Threshold)",
            ])
            
            st.markdown("---")
            
            # Conditionally show sliders based on plot type
            # Default values
            i_hob = len(hob) // 2
            i_vel = len(vel) // 2
            i_aof = len(aof) // 2
            
            # AOF is always needed
            sel_aof = st.select_slider("AOF (deg)", options=aof, value=aof[i_aof])
            i_aof = np.where(aof == sel_aof)[0][0]
            
            # HOB slider - hide for "HOB vs Miss Range" and "System Pk (Vel vs HOB)"
            if plot_type not in ["HOB vs Miss Range Contour", "System Pk (Vel vs HOB)"]:
                sel_hob = st.select_slider("HOB (m)", options=hob, value=hob[i_hob])
                i_hob = np.where(hob == sel_hob)[0][0]
            
            # Velocity slider - hide for "System Pk (Vel vs HOB)"
            if plot_type not in ["System Pk (Vel vs HOB)"]:
                sel_vel = st.select_slider("Velocity (m/s)", options=vel, value=vel[i_vel])
                i_vel = np.where(vel == sel_vel)[0][0]
            
            # Miss Grid specific: toggle for weighted vs raw
            if plot_type == "Pk Contour (Miss Grid)":
                st.markdown("---")
                use_weighted = st.toggle("Weight by Error Model", value=True, 
                    help="Show Pk weighted by delivery error PDF (System Pk view)")

        with col_plot:
            if plot_type == "Pk Contour (Miss Grid)":
                # Explanatory blurb
                if use_weighted:
                    st.markdown("""
                    **System-Level Pk (Weighted by Error Model)**
                    
                    This shows the raw Pk multiplied by the delivery error probability density function (PDF).
                    Brighter regions contribute more to the final System Pk. The integral of this surface 
                    equals the System Pk value shown below.
                    """)
                else:
                    st.markdown("""
                    **Raw Physics Pk (No Error Model)**
                    
                    This shows the unweighted probability of kill directly from the physics simulation.
                    Each point represents the Pk if the weapon detonated at exactly that miss distance.
                    This does NOT account for delivery accuracy.
                    """)
                
                pk_det = hc_data['pk_det']
                axes = {
                    "miss_x": hc_info['miss_x'],
                    "miss_y": hc_info['miss_y'],
                    "hob": hob,
                    "vel": vel,
                    "aof": aof
                }
                pk_det = normalize_hypercube_to_native(pk_det, axes)
                pk_slice = pk_det[:, :, i_hob, i_vel, i_aof]
                
                if use_weighted and disc_data:
                    # Get error model from config and compute PDF weights
                    err = config.get('discrete_analysis', {}).get('error_model', {})
                    if not err:
                        err = config.get('discrete_grid_analysis', {}).get('error_model', {})
                    
                    tle_radius = err.get('tle_radius_m', 0)
                    tle_frac = err.get('tle_fraction', 0.9)
                    cep_radius = err.get('cep_radius_m', 0)
                    cep_frac = err.get('cep_fraction', 0.5)
                    bias_x = err.get('fixed_bias_x_m', 0)
                    bias_y = err.get('fixed_bias_y_m', 0)
                    
                    # Compute sigma from radii
                    def radius_to_sigma(radius, fraction):
                        if fraction <= 0 or fraction >= 1 or radius <= 0:
                            return 0.0
                        return radius / np.sqrt(-2 * np.log(1 - fraction))
                    
                    sigma_tle = radius_to_sigma(tle_radius, tle_frac)
                    sigma_cep = radius_to_sigma(cep_radius, cep_frac)
                    sigma_total = np.sqrt(sigma_tle**2 + sigma_cep**2)
                    
                    if sigma_total > 0:
                        # Create 2D Gaussian PDF on the miss grid
                        miss_x = hc_info['miss_x']
                        miss_y = hc_info['miss_y']
                        X, Y = np.meshgrid(miss_x, miss_y, indexing='ij')
                        
                        # 2D Gaussian centered at bias
                        pdf = np.exp(-((X - bias_x)**2 + (Y - bias_y)**2) / (2 * sigma_total**2))
                        pdf = pdf / pdf.sum()  # Normalize
                        
                        # Weighted Pk = Pk * PDF (shows contribution to integral)
                        weighted_pk = pk_slice * pdf
                        weighted_pk_display = weighted_pk / weighted_pk.max() if weighted_pk.max() > 0 else weighted_pk
                        
                        fig = plot_pk_heatmap_plotly(
                            pk_slice=weighted_pk_display,
                            x_axis=miss_x,
                            y_axis=miss_y,
                            x_label="Deflection (m)",
                            y_label="Range (m)",
                            title=f"Weighted Pk @ HOB={hob[i_hob]:.1f}m, Vel={vel[i_vel]:.0f}m/s, AOF={aof[i_aof]:.0f}°",
                            colorscale='blue_red',
                            z_min=0.0,
                            z_max=1.0,
                            colorbar_title="Pk×PDF",
                        )
                        st.plotly_chart(fig, use_container_width=True)
                        
                        # Show System Pk and optimal conditions
                        if 'system_pk' in disc_data:
                            sys_pk_val = disc_data['system_pk'][i_hob, i_vel, i_aof]
                            
                            # Find optimal conditions (max System Pk)
                            sys_pk_full = disc_data['system_pk']
                            max_idx = np.unravel_index(np.argmax(sys_pk_full), sys_pk_full.shape)
                            opt_hob = hob[max_idx[0]]
                            opt_vel = vel[max_idx[1]]
                            opt_aof = aof[max_idx[2]]
                            max_sys_pk = sys_pk_full[max_idx]
                            
                            c1, c2 = st.columns(2)
                            c1.metric("Current System Pk", f"{sys_pk_val:.4f}")
                            c2.metric("Max System Pk", f"{max_sys_pk:.4f}", 
                                      delta=f"@ HOB={opt_hob:.1f}m, Vel={opt_vel:.0f}m/s, AOF={opt_aof:.0f}°",
                                      delta_color="off")
                    else:
                        st.warning("No error model configured - showing raw Pk.")
                        use_weighted = False
                
                if not use_weighted or not disc_data:
                    # Raw Pk view
                    fig = plot_pk_heatmap_plotly(
                        pk_slice=pk_slice,
                        x_axis=hc_info['miss_x'],
                        y_axis=hc_info['miss_y'],
                        x_label="Deflection (m)",
                        y_label="Range (m)",
                        title=f"Raw Pk @ HOB={hob[i_hob]:.1f}m, Vel={vel[i_vel]:.0f}m/s, AOF={aof[i_aof]:.0f}°",
                        colorscale='blue_red'
                    )
                    st.plotly_chart(fig, use_container_width=True)
                
                # Data Export
                csv_buffer = io.StringIO()
                pd.DataFrame(pk_slice).to_csv(csv_buffer)
                st.download_button("Download Slice CSV", csv_buffer.getvalue(), "pk_slice.csv", "text/csv")

            elif plot_type == "System Pk (Vel vs HOB)":
                # Explanatory blurb
                st.markdown("""
                **System-Level Pk (Integrated over Error Model)**
                
                This heatmap shows the **System Pk** across all Height-of-Burst and Velocity combinations 
                at the selected Angle of Fall. Each cell represents the probability of kill after 
                accounting for delivery errors (TLE, CEP, Bias).
                
                *Higher values (red) = more effective engagement conditions.*
                """)
                
                sys_pk = None
                source_label = ""
                
                # Check available data sources and allow selection if both exist
                has_discrete = disc_data is not None and ('system_pk' in disc_data or 'reliability' in disc_data)
                has_mc = mc_data is not None and 'mean_acc_pk_by_shot' in mc_data
                
                if has_discrete and has_mc:
                    source = st.radio("Data Source", ["Discrete Analysis (Theoretical PDF)", "Monte Carlo (Sampled Mean)"], horizontal=True)
                    if "Monte Carlo" in source:
                        # Use MC
                        acc_pk = mc_data['mean_acc_pk_by_shot']  # [n_shots, H, V, A]
                        n_shots_avail = acc_pk.shape[0]
                        shot_idx = st.slider("Shot Count (Accumulated)", 1, n_shots_avail, 1) - 1
                        sys_pk = acc_pk[shot_idx]
                        source_label = f"MC Mean (Shot {shot_idx+1})"
                    else:
                        # Use Discrete
                        sys_pk = disc_data['system_pk'] if 'system_pk' in disc_data else disc_data['reliability']
                        source_label = "Discrete System Pk"
                
                elif has_mc:
                    # Only MC available
                    st.info("Using Monte Carlo results (Mean Accumulated Pk).")
                    acc_pk = mc_data['mean_acc_pk_by_shot']  # [n_shots, H, V, A]
                    n_shots_avail = acc_pk.shape[0]
                    shot_idx = st.slider("Shot Count (Accumulated)", 1, n_shots_avail, 1) - 1
                    sys_pk = acc_pk[shot_idx]
                    source_label = f"MC Mean (Shot {shot_idx+1})"
                    
                elif has_discrete:
                    # Only Discrete available
                    sys_pk = disc_data['system_pk'] if 'system_pk' in disc_data else disc_data['reliability']
                    source_label = "Discrete System Pk"
                
                if sys_pk is not None:
                    slice_2d = sys_pk[:, :, i_aof]  # [n_hob, n_vel]
                    
                    fig = plot_pk_vs_vel_hob_plotly(
                        pk_2d=slice_2d,
                        vel_axis=vel,
                        hob_axis=hob,
                        title=f"{source_label} @ AOF={aof[i_aof]:.0f}°",
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Find optimal conditions (max System Pk)
                    max_idx = np.unravel_index(np.argmax(sys_pk), sys_pk.shape)
                    opt_hob = hob[max_idx[0]]
                    opt_vel = vel[max_idx[1]]
                    opt_aof = aof[max_idx[2]]
                    max_sys_pk = sys_pk[max_idx]
                    
                    # Stats for this slice + optimal
                    c1, c2, c3, c4 = st.columns(4)
                    c1.metric("Slice Max", f"{np.max(slice_2d):.4f}")
                    c2.metric("Slice Mean", f"{np.mean(slice_2d):.4f}")
                    c3.metric("Slice Min", f"{np.min(slice_2d):.4f}")
                    c4.metric("Global Max", f"{max_sys_pk:.4f}", 
                              delta=f"HOB={opt_hob:.1f}, Vel={opt_vel:.0f}, AOF={opt_aof:.0f}°",
                              delta_color="off")
                else:
                    st.warning("System Pk requires discrete analysis or Monte Carlo results. Run a campaign first.")
            
            elif plot_type == "HOB vs Miss Range Contour":
                # Explanatory blurb
                st.markdown("""
                **Raw Physics Pk (Radially Averaged)**
                
                This contour shows raw Pk from the physics simulation as a function of Height-of-Burst 
                and Miss Radius. The Pk values are **radially averaged** around the target 
                (averaged over all miss angles at each radius).
                
                *This does NOT include error model weighting - it shows warhead lethality potential.*
                """)
                
                pk_det = hc_data['pk_det']
                axes = {
                    "miss_x": hc_info['miss_x'],
                    "miss_y": hc_info['miss_y'],
                    "hob": hob,
                    "vel": vel,
                    "aof": aof
                }
                pk_det = normalize_hypercube_to_native(pk_det, axes)
                
                # Compute HOB-MR grid
                mr_axis, pk_hob_mr = compute_hob_mr_grid(
                    pk_hypercube=pk_det,
                    hob_axis=hob,
                    deflection_axis=hc_info['miss_x'],
                    range_axis=hc_info['miss_y'],
                    i_vel=i_vel,
                    i_aof=i_aof,
                    n_mr_points=50,
                    n_angles=36,
                )
                
                fig = plot_hob_mr_contour_plotly(
                    hob_axis=hob,
                    miss_range_axis=mr_axis,
                    pk_grid=pk_hob_mr,
                    title=f"HOB vs Miss Range @ Vel={vel[i_vel]:.0f}m/s, AOF={aof[i_aof]:.0f}°",
                    levels=15,
                )
                st.plotly_chart(fig, use_container_width=True)
            
            elif plot_type == "Rounds-to-Kill Heatmap":
                # Explanatory blurb
                st.markdown("""
                **System-Level Metric (Derived from System Pk)**
                
                This heatmap shows the minimum number of rounds required to achieve the target 
                accumulated Pk threshold using the survivor rule: $P_{salvo} = 1 - (1-P_k)^n$.
                
                *Lower values (green) = fewer rounds needed = more efficient engagement.*
                """)
                
                if disc_data and 'rounds_to_kill' in disc_data and 'pk_thresholds' in disc_data:
                    r2k = disc_data['rounds_to_kill']  # [H, V, A, T]
                    thresholds = disc_data['pk_thresholds']
                    
                    # Select threshold
                    thresh_idx = st.selectbox(
                        "Pk Threshold", 
                        range(len(thresholds)),
                        format_func=lambda i: f"Pk ≥ {thresholds[i]:.0%}"
                    )
                    
                    r2k_slice = r2k[:, :, i_aof, thresh_idx]
                    
                    fig = plot_r2k_heatmap_plotly(
                        r2k_slice=r2k_slice,
                        x_axis=vel,
                        y_axis=hob,
                        x_label="Velocity (m/s)",
                        y_label="HOB (m)",
                        title=f"Rounds to Kill (Pk ≥ {thresholds[thresh_idx]:.0%}, AOF={aof[i_aof]:.0f}°)",
                        max_rounds=int(np.nanmax(r2k_slice)) + 1 if not np.all(np.isnan(r2k_slice)) else 10,
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Stats
                    valid_r2k = r2k_slice[~np.isnan(r2k_slice)]
                    if len(valid_r2k) > 0:
                        c1, c2, c3, c4 = st.columns(4)
                        c1.metric("Median R2K", f"{np.median(valid_r2k):.1f}")
                        c2.metric("Mean R2K", f"{np.mean(valid_r2k):.1f}")
                        c3.metric("Min R2K", f"{np.min(valid_r2k):.0f}")
                        c4.metric("Feasible %", f"{len(valid_r2k)/r2k_slice.size:.1%}")
                else:
                    st.warning("R2K data requires discrete analysis with rounds_to_kill output.")
            
            elif plot_type == "R2K Stoplight Grid":
                # Explanatory blurb
                st.markdown("""
                **System-Level Metric (Pass/Fail Grid)**
                
                This stoplight grid shows which terminal conditions meet the Threshold (green) 
                or Objective (blue) rounds-to-kill requirements. Based on System Pk.
                
                *Blue = Objective met, Green = Threshold only, White = Neither met.*
                """)
                
                if disc_data and 'rounds_to_kill' in disc_data and 'pk_thresholds' in disc_data:
                    r2k = disc_data['rounds_to_kill']
                    thresholds = disc_data['pk_thresholds']
                    
                    # Select threshold
                    thresh_idx = st.selectbox(
                        "Pk Threshold",
                        range(len(thresholds)),
                        format_func=lambda i: f"Pk ≥ {thresholds[i]:.0%}",
                        key="stoplight_thresh"
                    )
                    
                    # T/O rounds configuration
                    st.markdown("**Threshold/Objective Criteria:**")
                    col_t, col_o = st.columns(2)
                    threshold_rounds = col_t.number_input("Threshold (max rounds)", 1, 20, 3, key="t_rounds")
                    objective_rounds = col_o.number_input("Objective (max rounds)", 1, 20, 2, key="o_rounds")
                    
                    r2k_slice = r2k[:, :, i_aof, thresh_idx]
                    
                    fig = plot_r2k_stoplight_plotly(
                        r2k_2d=r2k_slice,
                        vel_axis=vel,
                        hob_axis=hob,
                        threshold_rounds=threshold_rounds,
                        objective_rounds=objective_rounds,
                        title=f"R2K Stoplight (Pk ≥ {thresholds[thresh_idx]:.0%}, AOF={aof[i_aof]:.0f}°)",
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Compliance stats
                    valid_mask = ~np.isnan(r2k_slice)
                    pass_t = np.sum((r2k_slice <= threshold_rounds) & valid_mask)
                    pass_o = np.sum((r2k_slice <= objective_rounds) & valid_mask)
                    total = np.sum(valid_mask)
                    
                    c1, c2, c3 = st.columns(3)
                    c1.metric("Objective Met", f"{pass_o}/{total} ({pass_o/total:.1%})" if total > 0 else "N/A")
                    c2.metric("Threshold Met", f"{pass_t}/{total} ({pass_t/total:.1%})" if total > 0 else "N/A")
                    c3.metric("Envelope Coverage", f"{total}/{r2k_slice.size} ({total/r2k_slice.size:.1%})")
                else:
                    st.warning("Stoplight grid requires discrete analysis with rounds_to_kill output.")
            
            elif plot_type == "R2K Box Plot (by Threshold)":
                # Explanatory blurb
                st.markdown("""
                **System-Level Metric (Distribution Summary)**
                
                Box plots showing the distribution of Rounds-to-Kill across all terminal conditions 
                for each Pk threshold. Based on System Pk values.
                
                *Lower and tighter distributions = more consistently effective weapon system.*
                """)
                
                if disc_data and 'rounds_to_kill' in disc_data and 'pk_thresholds' in disc_data:
                    r2k = disc_data['rounds_to_kill']
                    thresholds = disc_data['pk_thresholds']
                    
                    fig = plot_multi_threshold_boxplot_plotly(
                        r2k_data=r2k,
                        pk_thresholds=list(thresholds),
                        title=f"R2K Distribution by Threshold (All Terminal Conditions)",
                        max_rounds=int(np.nanmax(r2k)) + 1 if not np.all(np.isnan(r2k)) else 10,
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Summary table
                    summary_data = []
                    for i, thresh in enumerate(thresholds):
                        data = r2k[:, :, :, i].flatten()
                        valid = data[~np.isnan(data)]
                        if len(valid) > 0:
                            summary_data.append({
                                "Threshold": f"Pk ≥ {thresh:.0%}",
                                "Median": f"{np.median(valid):.1f}",
                                "Mean": f"{np.mean(valid):.1f}",
                                "Std": f"{np.std(valid):.1f}",
                                "Min": f"{np.min(valid):.0f}",
                                "Max": f"{np.max(valid):.0f}",
                                "Feasible %": f"{len(valid)/data.size:.1%}",
                            })
                    if summary_data:
                        st.table(pd.DataFrame(summary_data))
                else:
                    st.warning("Box plot requires discrete analysis with rounds_to_kill output.")

    elif view_mode == "MC Salvo Analysis":
        st.subheader("Monte Carlo Salvo Analysis")
        
        with st.expander("About Monte Carlo Analysis"):
            st.markdown("""
            **What is this?**
            Monte Carlo analysis uses **statistical sampling** to estimate weapon effectiveness. 
            Unlike discrete grid integration, MC randomly samples delivery errors and computes 
            kill probabilities across many simulated engagements (salvos).
            
            **Key Outputs:**
            - **Salvo Pk Distribution**: How Pk varies across random error samples
            - **Rounds-to-Kill Statistics**: How many rounds needed to achieve target Pk
            - **Confidence Intervals**: Statistical bounds on performance estimates
            
            **When to use MC vs Discrete:**
            - **MC**: Better for understanding variability and worst-case scenarios
            - **Discrete**: Better for exact integration and 3D visualization
            """)
        
        # Get MC-specific config
        mc_config = config.get('monte_carlo', {})
        mc_sampling = mc_config.get('sampling', {})
        mc_precs = mc_config.get('precisions', [])
        
        # Display MC Configuration
        st.markdown("### Monte Carlo Configuration")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Salvos", f"{mc_sampling.get('n_salvos', 'N/A'):,}")
        c2.metric("Shots/Salvo", mc_sampling.get('n_shots', 'N/A'))
        c3.metric("Random Seed", mc_sampling.get('random_seed', 'N/A'))
        c4.metric("Precision Sets", len(mc_precs))
        
        # Display precision configs
        if mc_precs:
            st.markdown("### Precision Configurations")
            prec_df = pd.DataFrame([
                {
                    "Label": p.get('label', 'unnamed'),
                    "TLE (m)": p.get('tle_radius_m', 0),
                    "TLE %": f"{p.get('tle_fraction', 0.9):.0%}",
                    "CEP (m)": p.get('cep_radius_m', 0),
                    "CEP %": f"{p.get('cep_fraction', 0.5):.0%}",
                    "Bias X (m)": p.get('fixed_bias_deflection_m', 0),
                    "Bias Y (m)": p.get('fixed_bias_range_m', 0),
                }
                for p in mc_precs
            ])
            st.dataframe(prec_df, use_container_width=True, hide_index=True)
        
        # Show MC results if available
        if mc_data:
            st.markdown("### MC Results Summary")
            
            # Single-shot Pk statistics
            if 'single_shot_pk' in mc_data:
                pk = mc_data['single_shot_pk']  # Shape: (n_hob, n_vel, n_aof) or (n_salvos, n_shots, ...)
                c1, c2, c3 = st.columns(3)
                c1.metric("Mean Single-Shot Pk", f"{np.nanmean(pk):.4f}")
                c2.metric("Max Single-Shot Pk", f"{np.nanmax(pk):.4f}")
                c3.metric("Std Dev", f"{np.nanstd(pk):.4f}")
            elif 'accumulated_pk_by_round' in mc_data:
                acc_pk = mc_data['accumulated_pk_by_round']  # Shape: (n_shots, ...)
                c1, c2, c3 = st.columns(3)
                c1.metric("Mean Accumulated Pk (Last Shot)", f"{np.nanmean(acc_pk[-1]):.4f}")
                c2.metric("Max Accumulated Pk", f"{np.nanmax(acc_pk[-1]):.4f}")
                c3.metric("Final Shot Std Dev", f"{np.nanstd(acc_pk[-1]):.4f}")
            
            # Accumulated Pk progression
            if 'accumulated_pk_by_round' in mc_data:
                st.markdown("### Accumulated Pk by Shot Number")
                acc_pk = mc_data['accumulated_pk_by_round']  # Shape: (n_shots, ...)
                n_shots = acc_pk.shape[0]
                
                # Show mean accumulated Pk over all conditions for each shot
                mean_acc_pk = [np.nanmean(acc_pk[i]) for i in range(n_shots)]
                
                import plotly.graph_objects as go
                fig_acc = go.Figure()
                fig_acc.add_trace(go.Scatter(
                    x=list(range(1, n_shots + 1)),
                    y=mean_acc_pk,
                    mode='lines+markers',
                    name='Mean Accumulated Pk',
                    line=dict(color='blue', width=2),
                    marker=dict(size=8),
                ))
                fig_acc.update_layout(
                    title="Mean Accumulated Pk vs Shot Number",
                    xaxis_title="Shot Number",
                    yaxis_title="Accumulated Pk",
                    yaxis_range=[0, 1.05],
                    height=400,
                )
                st.plotly_chart(fig_acc, use_container_width=True)
            
            # R2K boxplot if available
            if 'rounds_to_kill' in mc_data and 'pk_thresholds' in mc_data:
                st.markdown("### Rounds-to-Kill Distribution (MC Sampling)")
                
                r2k = mc_data['rounds_to_kill']
                thresholds = mc_data['pk_thresholds']
                
                fig = plot_multi_threshold_boxplot_plotly(
                    r2k_data=r2k,
                    pk_thresholds=list(thresholds),
                    title="R2K Distribution by Pk Threshold",
                    max_rounds=int(np.nanmax(r2k)) + 1 if not np.all(np.isnan(r2k)) else 10,
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # Summary stats
                st.markdown("### R2K Summary Statistics")
                r2k_summary = []
                for i, thresh in enumerate(thresholds):
                    if r2k.ndim == 4:
                        data = r2k[:, :, :, i].flatten()
                    else:
                        data = r2k[..., i].flatten()
                    valid = data[~np.isnan(data)]
                    if len(valid) > 0:
                        r2k_summary.append({
                            "Threshold": f"Pk >= {thresh:.0%}",
                            "Median Rounds": f"{np.median(valid):.1f}",
                            "Mean Rounds": f"{np.mean(valid):.1f}",
                            "Std Dev": f"{np.std(valid):.2f}",
                            "Min": int(np.min(valid)),
                            "Max": int(np.max(valid)),
                            "Feasible %": f"{len(valid)/len(data):.1%}",
                        })
                if r2k_summary:
                    st.table(pd.DataFrame(r2k_summary))
            
            # Show salvo Pk distribution (histogram)
            if 'salvo_pk' in mc_data:
                st.markdown("### Salvo Pk Distribution")
                salvo_pk = mc_data['salvo_pk'].flatten()
                valid_pk = salvo_pk[~np.isnan(salvo_pk)]
                
                if len(valid_pk) > 0:
                    fig_hist = go.Figure()
                    fig_hist.add_trace(go.Histogram(
                        x=valid_pk,
                        nbinsx=50,
                        marker_color='steelblue',
                        opacity=0.75,
                        name='Salvo Pk',
                    ))
                    fig_hist.add_vline(
                        x=np.mean(valid_pk), line_dash="dash", line_color="red",
                        annotation_text=f"Mean: {np.mean(valid_pk):.3f}"
                    )
                    fig_hist.update_layout(
                        title="Distribution of Salvo Pk Values",
                        xaxis_title="Salvo Pk",
                        yaxis_title="Count",
                        height=400,
                    )
                    st.plotly_chart(fig_hist, use_container_width=True)
        
        elif disc_data:
            # Fallback to discrete data if MC not available
            st.info("MC-specific results not found. Showing available discrete analysis data.")
            
            if 'system_pk' in disc_data:
                sys_pk = disc_data['system_pk']
                
                c1, c2, c3 = st.columns(3)
                c1.metric("Mean Single-Shot Pk", f"{np.mean(sys_pk):.4f}")
                c2.metric("Max Single-Shot Pk", f"{np.max(sys_pk):.4f}")
                c3.metric("Std Dev", f"{np.std(sys_pk):.4f}")
            
            # R2K boxplot if available
            if 'rounds_to_kill' in disc_data and 'pk_thresholds' in disc_data:
                st.markdown("### Rounds-to-Kill Distribution")
                
                r2k = disc_data['rounds_to_kill']
                thresholds = disc_data['pk_thresholds']
                
                fig = plot_multi_threshold_boxplot_plotly(
                    r2k_data=r2k,
                    pk_thresholds=list(thresholds),
                    title="R2K Distribution by Pk Threshold",
                    max_rounds=int(np.nanmax(r2k)) + 1 if not np.all(np.isnan(r2k)) else 10,
                )
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Discrete analysis does not have rounds-to-kill output.")
        else:
            st.warning("No MC or discrete analysis results found. Run the campaign first.")

    elif view_mode == "3D Volume Explorer":
        st.subheader("3D Volume Explorer")
        
        with st.expander("About the 3D Volume & Integration"):
            st.markdown("""
            **What is this?**
            This interactive visualization displays the **System Probability of Kill (Pk)** and related metrics over the entire 3D terminal condition space (Height of Burst, Velocity, Angle of Fall).
            
            **How the Volume Integral Works:**
            The "System Pk" at each point $(H, V, A)$ in this volume is calculated by integrating the single-shot Pk over the error distributions (dispersion, aimpoint error, etc.):
            
            $$ P_k(\\text{System}) = \\iint P_k(\\text{impact}) \\cdot f(\\text{impact}) \\, dx \\, dy $$
            
            Where:
            *   $P_k(\\text{impact})$ comes from the physics simulation (the Pk Hypercube).
            *   $f(\\text{impact})$ is the Probability Density Function (PDF) of the delivery errors (CEP, TLE, Bias).
            
            This integration is performed for millions of points to build the full effectiveness landscape you see here.
            """)
            
        if disc_data:
            # Select Shot Count (Accumulated Pk)
            n_shots = 1
            if 'mean_pk_by_shot' in disc_data:
                max_shots = disc_data['mean_pk_by_shot'].shape[0]
                n_shots = st.slider("Shots in Salvo", 1, max_shots, 1, help="Accumulate Pk over N shots (Survivor Rule).")
                # Use accumulated Pk for visualization
                sys_pk = disc_data['mean_pk_by_shot'][n_shots-1]
            else:
                # Fallback to single shot
                sys_pk = disc_data['system_pk'] if 'system_pk' in disc_data else disc_data['reliability']
                st.caption("Multi-shot data not available. Showing Single-Shot Pk.")

            # Metric Selection
            metric = st.radio(
                "Metric to Visualize", 
                ["System Pk", "Sensitivity (Gradient)", "Curvature (Laplacian)"],
                horizontal=True
            )
            
            if metric == "System Pk":
                data_3d = sys_pk
                st.caption(f"Visualizing System Probability of Kill (after {n_shots} shots).")
            
            elif metric == "Sensitivity (Gradient)":
                # Compute gradient on the accumulated Pk
                grads = np.gradient(sys_pk)
                data_3d = np.sqrt(sum(g**2 for g in grads))
                
                with st.expander("How to Interpret Sensitivity (Gradient)"):
                    st.markdown(r"**Metric:** Gradient Magnitude $|\nabla P_k|$ — Measures rate of change in Pk.")
                    
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.success("**Low (Blue)**\n\n**Stable / Robust**\nPk changes slowly here. Small errors in terminal conditions won't significantly affect performance.")
                    with col2:
                        st.info("**Medium**\n\n**Transition Zone**\nPk is changing moderately. Performance is sensitive to terminal condition variations.")
                    with col3:
                        st.error("**High (Red)**\n\n**Unstable / Cliff Edge**\nPk changes rapidly. Small deviations cause large Pk swings. Avoid operating here.")
            
            elif metric == "Curvature (Laplacian)":
                data_3d = compute_curvature(sys_pk)
                
                with st.expander("How to Interpret Curvature (Laplacian)"):
                    st.markdown(r"**Metric:** Laplacian $\nabla^2 P_k$ — Measures local surface shape.")
                    
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.info("**Negative (Blue)**\n\n**Peak / Maximum**\nSurface curves downwards (concave down), like a hill top.")
                    with col2:
                        st.success("**Near Zero**\n\n**Flat Plateau**\nSurface is locally flat. Look for high Pk plateaus as robust operating points.")
                    with col3:
                        st.warning("**Positive (Red)**\n\n**Valley / Minimum**\nSurface curves upwards (concave up), like a bowl bottom.")
            
            col_ctrl, col_viz = st.columns([1, 4])
            
            with col_ctrl:
                # Volume Calculation
                st.markdown("### Envelope Volume")
                vol_threshold = st.slider("Pk Threshold", 0.1, 0.99, 0.5, 0.05, help="Compute volume where System Pk >= Threshold")
                
                # Compute Volume
                # Volume element dV = dH * dV * dA
                # Assuming roughly uniform spacing for estimation
                d_hob = (hob[-1] - hob[0]) / (len(hob) - 1) if len(hob) > 1 else 1.0
                d_vel = (vel[-1] - vel[0]) / (len(vel) - 1) if len(vel) > 1 else 1.0
                d_aof = (aof[-1] - aof[0]) / (len(aof) - 1) if len(aof) > 1 else 1.0
                voxel_vol = d_hob * d_vel * d_aof
                
                # Count cells >= threshold
                # Use the SELECTED sys_pk (which might be multi-shot accumulated)
                effective_cells = np.sum(sys_pk >= vol_threshold)
                total_volume = effective_cells * voxel_vol
                
                st.metric(f"Effective Volume ({n_shots} shots)", f"{total_volume:,.0f}", delta=None, help="Total volume of engagement envelope (m · m/s · deg)")
                st.markdown("---")

                # Color By Toggle (only if metric is not Pk)
                use_pk_color = False
                if metric != "System Pk":
                    use_pk_color = st.toggle("Color by System Pk", value=False, help="Color the surface by Pk value instead of metric value.")
                
                opacity = st.slider("Opacity", 0.1, 1.0, 0.3)
                
                if use_pk_color:
                    # For colored mesh, we typically look at a specific level
                    min_val, max_val = float(np.min(data_3d)), float(np.max(data_3d))
                    iso_level = st.slider(f"Isosurface Level ({metric})", min_val, max_val, (min_val+max_val)/2)
                    st.caption(f"Showing surface where {metric} is constant at {iso_level:.3f}, colored by Pk.")
                else:
                    surfaces = st.slider("Surface Count", 2, 10, 5)
                    st.markdown("---")
                    st.markdown("**Legend**")
                    st.markdown("- **Blue:** Low Value")
                    st.markdown("- **Red:** High Value")
                
                # Dynamic Interpretation Guide (Restored to Control Column)
                if metric == "Sensitivity (Gradient)":
                    with st.expander("How to Interpret Sensitivity", expanded=True):
                        st.markdown(r"**Metric:** Gradient Magnitude $|\nabla P_k|$")
                        if use_pk_color:
                            st.info(f"**Visualizing:** Surface where Gradient = {iso_level:.2f}")
                            st.markdown("Shape = Sensitivity\nColor = **Pk**")
                            st.success("**Goal:** Low Gradient (Shape) + Red (High Pk)")
                        else:
                            st.success("**Low (Blue):** Stable/Robust")
                            st.error("**High (Red):** Unstable")

                elif metric == "Curvature (Laplacian)":
                    with st.expander("How to Interpret Curvature", expanded=True):
                        st.markdown(r"**Metric:** Laplacian $\nabla^2 P_k$")
                        if use_pk_color:
                            st.info(f"**Visualizing:** Surface where Curvature = {iso_level:.2f}")
                            st.markdown("Shape = Geometry\nColor = **Pk**")
                            if abs(iso_level) < 0.1:
                                st.success("Flat Plateau + Red = Sweet Spot!")
                        else:
                            st.info("**Blue:** Peak")
                            st.success("**Zero:** Plateau")
                            st.warning("**Red:** Valley")

            with col_viz:
                if use_pk_color:
                    fig = plot_iso_mesh_colored_by_pk(
                        iso_data=data_3d,
                        color_data=sys_pk,
                        hob_axis=hob,
                        vel_axis=vel,
                        aof_axis=aof,
                        level=iso_level,
                        opacity=opacity
                    )
                    fig.update_layout(title=f"{metric} Isosurface @ {iso_level:.3f} (Colored by Pk)")
                else:
                    fig = plot_3d_volume_plotly(
                        system_pk=data_3d,
                        hob_axis=hob,
                        vel_axis=vel,
                        aof_axis=aof,
                        opacity=opacity,
                        surface_count=surfaces,
                        colorbar_title=metric if metric != "System Pk" else "Pk"
                    )
                    fig.update_layout(title=f"3D Volume: {metric}")
                
                st.plotly_chart(fig, use_container_width=True)
            
            # Table of points above threshold
            st.markdown("### Terminal Conditions Above Threshold")
            st.caption(f"All (HOB, Velocity, AOF) combinations where System Pk ≥ {vol_threshold:.0%}")
            
            # Compute gradient and laplacian for the table
            grads = np.gradient(sys_pk)
            gradient_mag = np.sqrt(sum(g**2 for g in grads))
            laplacian = compute_curvature(sys_pk)
            
            # Find indices where Pk >= threshold
            above_mask = sys_pk >= vol_threshold
            indices = np.argwhere(above_mask)
            
            if len(indices) > 0:
                # Build table data
                table_rows = []
                for idx in indices:
                    i_h, i_v, i_a = idx
                    table_rows.append({
                        "HOB (m)": f"{hob[i_h]:.1f}",
                        "Velocity (m/s)": f"{vel[i_v]:.0f}",
                        "AOF (°)": f"{aof[i_a]:.0f}",
                        "System Pk": f"{sys_pk[i_h, i_v, i_a]:.4f}",
                        "Gradient |∇Pk|": f"{gradient_mag[i_h, i_v, i_a]:.4f}",
                        "Laplacian ∇²Pk": f"{laplacian[i_h, i_v, i_a]:.4f}",
                    })
                
                df_above = pd.DataFrame(table_rows)
                
                # Sort by System Pk descending
                df_above_sorted = df_above.sort_values("System Pk", ascending=False)
                
                # Show count and table
                st.info(f"**{len(indices)} points** meet the Pk ≥ {vol_threshold:.0%} threshold out of {sys_pk.size} total ({len(indices)/sys_pk.size:.1%})")
                
                # Limit display to avoid overwhelming UI
                max_display = 100
                if len(df_above_sorted) > max_display:
                    st.warning(f"Showing top {max_display} of {len(df_above_sorted)} points (sorted by Pk descending). Export CSV for full data.")
                    st.dataframe(df_above_sorted.head(max_display), use_container_width=True, hide_index=True)
                else:
                    st.dataframe(df_above_sorted, use_container_width=True, hide_index=True)
                
                # CSV Export - build full numeric version for export
                export_rows = []
                for idx in indices:
                    i_h, i_v, i_a = idx
                    export_rows.append({
                        "HOB_m": hob[i_h],
                        "Velocity_mps": vel[i_v],
                        "AOF_deg": aof[i_a],
                        "System_Pk": sys_pk[i_h, i_v, i_a],
                        "Gradient_Magnitude": gradient_mag[i_h, i_v, i_a],
                        "Laplacian": laplacian[i_h, i_v, i_a],
                    })
                df_export = pd.DataFrame(export_rows).sort_values("System_Pk", ascending=False)
                
                csv_buffer = io.StringIO()
                df_export.to_csv(csv_buffer, index=False)
                st.download_button(
                    "Export Above-Threshold Points (CSV)", 
                    csv_buffer.getvalue(), 
                    f"pk_above_{vol_threshold:.0%}_threshold.csv", 
                    "text/csv",
                    help=f"Download all {len(indices)} points with Pk ≥ {vol_threshold:.0%}"
                )
            else:
                st.warning(f"No points meet the Pk ≥ {vol_threshold:.0%} threshold. Try lowering the threshold.")
                
        else:
            st.warning("No discrete analysis data available for 3D view.")

    elif view_mode == "Comparison View":
        st.subheader("Side-by-Side Comparison")
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### Left View")
            l_hob = st.selectbox("L-HOB", hob, key="l_h")
            l_vel = st.selectbox("L-Vel", vel, key="l_v")
            # Logic to plot... (simplified for brevity)
            
        with col2:
            st.markdown("### Right View")
            r_hob = st.selectbox("R-HOB", hob, key="r_h")
            r_vel = st.selectbox("R-Vel", vel, key="r_v")
            
        st.info("Comparison features coming soon (requires more complex state management).")

if __name__ == "__main__":
    main()
