import os
import sys
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Control flag: Default to using C++ unless explicitly disabled
_USE_CPP = os.environ.get("MEGADETH_USE_CPP", "1") != "0"

# C++ accelerator module
_cpp_module = None

try:
    import megadeth_accelerator as _cpp_module
    _CPP_AVAILABLE = True
except ImportError:
    logger.warning("MEGADETH C++ accelerator not found. Performance will be degraded.")
    _CPP_AVAILABLE = False
    _USE_CPP = False

def use_cpp() -> bool:
    """Return True if C++ backend should be used."""
    return _USE_CPP and _CPP_AVAILABLE

# Expose C++ functions directly
if _CPP_AVAILABLE:
    compute_multi_shot_nested = _cpp_module.compute_multi_shot_nested
    compute_rounds_to_kill = _cpp_module.compute_rounds_to_kill
    build_gaussian_weights = _cpp_module.build_gaussian_weights
    compute_multi_shot_hybrid = _cpp_module.compute_multi_shot_hybrid
    bilinear_interpolate_2d = _cpp_module.bilinear_interpolate_2d
    gaussian_filter = _cpp_module.gaussian_filter
    
    # Check for OpenMP support
    HAS_OPENMP = getattr(_cpp_module, "HAS_OPENMP", False)
else:
    # Stubs for type checking / import safety
    compute_multi_shot_nested = None
    compute_rounds_to_kill = None
    build_gaussian_weights = None
    compute_multi_shot_hybrid = None
    bilinear_interpolate_2d = None
    gaussian_filter = None
    HAS_OPENMP = False
