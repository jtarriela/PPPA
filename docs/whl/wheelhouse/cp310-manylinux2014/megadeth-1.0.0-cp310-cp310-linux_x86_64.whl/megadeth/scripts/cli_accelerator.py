#!/usr/bin/env python3
"""
megadeth-accel: Query and benchmark the MEGADETH C++ accelerator.

Usage:
    megadeth-accel           # Show accelerator status
    megadeth-accel --bench   # Run benchmark comparison

Examples:
    $ megadeth-accel
    MEGADETH Accelerator Status
    -------------------------
    Available: Yes
    Version: 0.1.0
    OpenMP: Yes

    $ megadeth-accel --bench
    Running benchmark...
    compute_multi_shot_nested:
      Python:  1.234s
      C++:     0.156s
      Speedup: 7.9x
"""

import argparse
import sys
import time


def print_status():
    """Print accelerator status information."""
    from megadeth.analysis._accelerator import get_info

    info = get_info()

    print("MEGADETH Accelerator Status")
    print("=" * 25)
    print(f"  Available: {'Yes' if info['available'] else 'No'}")

    if info["available"]:
        print(f"  Version:   {info['version']}")
        print(f"  OpenMP:    {'Yes' if info['has_openmp'] else 'No'}")
    else:
        print()
        print("C++ accelerator not installed.")
        print("To build and install:")
        print("  cd /path/to/megadeth")
        print("  pip install -e .")
        print()
        print("Requirements:")
        print("  - C++17 compiler (GCC, Clang, MSVC)")
        print("  - CMake >= 3.15")
        print("  - pybind11")


def run_benchmark():
    """Run benchmark comparing Python vs C++ implementations."""
    import numpy as np

    from megadeth.analysis._accelerator import AVAILABLE

    if not AVAILABLE:
        print("ERROR: C++ accelerator not available. Cannot run benchmark.")
        print("Install with: pip install -e .")
        sys.exit(1)

    from megadeth.analysis._accelerator import compute_multi_shot_nested as cpp_nested
    from megadeth.analysis._accelerator import compute_rounds_to_kill as cpp_r2k

    print("MEGADETH Accelerator Benchmark")
    print("=" * 30)
    print()

    # Test parameters
    n_cx, n_cy = 31, 31
    n_h, n_v, n_a = 20, 15, 16
    max_shots = 10
    thresholds = [0.3, 0.5, 0.7, 0.9]

    # Generate test data
    np.random.seed(42)
    pk_grid = np.random.random((n_cx, n_cy, n_h, n_v, n_a)) * 0.3
    cx_axis = np.linspace(-50, 50, n_cx)
    cy_axis = np.linspace(-50, 50, n_cy)
    sigma_salvo = 15.0
    bias_x, bias_y = 0.0, 0.0

    print(f"Test data shape: pk_grid[{n_cx}, {n_cy}, {n_h}, {n_v}, {n_a}]")
    print(f"Max shots: {max_shots}")
    print()

    # Benchmark compute_multi_shot_nested
    print("compute_multi_shot_nested:")

    # Python implementation (import from discrete_grid)
    try:
        from megadeth.analysis.discrete_grid import DiscreteGridAnalyzer, SalvoCenterGrid

        # Create analyzer and salvo center grid
        analyzer = DiscreteGridAnalyzer.__new__(DiscreteGridAnalyzer)
        analyzer._gaussian_weights = lambda cx, cy, s, bx, by: np.exp(
            -((cx - bx) ** 2 + (cy - by) ** 2) / (2 * s**2)
        )

        salvo_grid = SalvoCenterGrid(
            pk_sys_grid=pk_grid,
            cx_axis=cx_axis,
            cy_axis=cy_axis,
            sigma_salvo=sigma_salvo,
            fixed_bias=(bias_x, bias_y),
        )

        # Time Python
        start = time.perf_counter()
        for _ in range(3):
            result_py = analyzer.compute_multi_shot_pk_nested(salvo_grid, max_shots)
        py_time = (time.perf_counter() - start) / 3

        print(f"  Python:  {py_time:.3f}s")
    except Exception as e:
        print(f"  Python:  Error - {e}")
        py_time = None
        result_py = None

    # Time C++
    start = time.perf_counter()
    for _ in range(3):
        result_cpp = cpp_nested(pk_grid, cx_axis, cy_axis, sigma_salvo, bias_x, bias_y, max_shots)
    cpp_time = (time.perf_counter() - start) / 3

    print(f"  C++:     {cpp_time:.3f}s")

    if py_time:
        speedup = py_time / cpp_time
        print(f"  Speedup: {speedup:.1f}x")

        # Check parity
        if result_py is not None:
            max_diff = np.max(np.abs(result_py - result_cpp))
            print(f"  Max diff: {max_diff:.2e}")

    print()

    # Benchmark compute_rounds_to_kill
    print("compute_rounds_to_kill:")

    mean_pk = result_cpp  # Use C++ result as input

    try:
        # Time Python
        start = time.perf_counter()
        for _ in range(3):
            r2k_py = analyzer.compute_rounds_to_kill(mean_pk, thresholds)
        py_time_r2k = (time.perf_counter() - start) / 3
        print(f"  Python:  {py_time_r2k:.3f}s")
    except Exception as e:
        print(f"  Python:  Error - {e}")
        py_time_r2k = None
        r2k_py = None

    # Time C++
    start = time.perf_counter()
    for _ in range(3):
        r2k_cpp = cpp_r2k(mean_pk, thresholds)
    cpp_time_r2k = (time.perf_counter() - start) / 3

    print(f"  C++:     {cpp_time_r2k:.3f}s")

    if py_time_r2k:
        speedup_r2k = py_time_r2k / cpp_time_r2k
        print(f"  Speedup: {speedup_r2k:.1f}x")

        if r2k_py is not None:
            # Compare non-NaN values
            mask = ~np.isnan(r2k_py) & ~np.isnan(r2k_cpp)
            if mask.any():
                max_diff_r2k = np.max(np.abs(r2k_py[mask] - r2k_cpp[mask]))
                print(f"  Max diff: {max_diff_r2k:.2e}")

    print()
    print("Benchmark complete.")


def cmd_doctor():
    """Check environment, compilers, and CPU features."""
    import json
    import subprocess
    from pathlib import Path
    
    print("=" * 60)
    print("MEGADETH - Environment Diagnostics")
    print("=" * 60)
    print()
    
    # CPU
    cpu = {"vendor": "unknown", "model": "unknown", "avx": False, "avx2": False, "avx512": False, "fma": False}
    try:
        with open("/proc/cpuinfo") as f:
            cpuinfo = f.read()
        if "AuthenticAMD" in cpuinfo:
            cpu["vendor"] = "AMD"
        elif "GenuineIntel" in cpuinfo:
            cpu["vendor"] = "Intel"
        for line in cpuinfo.split("\n"):
            if line.startswith("model name"):
                cpu["model"] = line.split(":")[1].strip()
            if line.startswith("flags"):
                flags = line.split(":")[1].lower()
                cpu["avx"] = " avx " in f" {flags} "
                cpu["avx2"] = " avx2 " in f" {flags} "
                cpu["avx512"] = "avx512" in flags
                cpu["fma"] = " fma " in f" {flags} "
    except:
        pass
    
    print("CPU:")
    print(f"  Vendor:   {cpu['vendor']}")
    print(f"  Model:    {cpu['model']}")
    features = [k.upper() for k in ["avx", "avx2", "avx512", "fma"] if cpu[k]]
    print(f"  Features: {', '.join(features) if features else 'None detected'}")
    
    if cpu["avx512"] and cpu["vendor"] == "Intel":
        recommended = "intel"
    elif cpu["avx2"] and cpu["vendor"] == "AMD":
        recommended = "amd"
    elif cpu["avx2"]:
        recommended = "native"
    else:
        recommended = "generic"
    print(f"  Recommended: --arch {recommended}")
    print()
    
    # Compilers
    print("Compilers:")
    compiler = {}
    for cmd in ["gcc", "clang", "cmake", "ninja"]:
        try:
            result = subprocess.run([cmd, "--version"], capture_output=True, text=True, timeout=5)
            compiler[cmd] = result.stdout.split("\n")[0] if result.returncode == 0 else None
        except:
            compiler[cmd] = None
    try:
        import pybind11
        compiler["pybind11"] = f"pybind11 {pybind11.__version__}"
    except:
        compiler["pybind11"] = None
    
    for name, version in compiler.items():
        print(f"  {name:12} {version if version else 'NOT FOUND'}")
    print()
    
    # Build readiness
    can_build = bool(compiler["cmake"] and (compiler["gcc"] or compiler["clang"]) and compiler["pybind11"])
    print("Build Readiness:")
    if can_build:
        print("  Ready to build")
    else:
        if not compiler["cmake"]:
            print("  cmake not found")
        if not compiler["gcc"] and not compiler["clang"]:
            print("  No C++ compiler found")
        if not compiler["pybind11"]:
            print("  WARNING: pybind11 not installed (pip install pybind11)")
    print()
    
    # Cached backends
    print("Cached Backends:")
    pkg_dir = Path(__file__).parent.parent
    backends_dir = pkg_dir / "_backends"
    vendor = "amd" if cpu["vendor"] == "AMD" else ("intel" if cpu["vendor"] == "Intel" else "generic")
    
    if backends_dir.exists():
        for arch in ["intel", "amd", "generic"]:
            arch_dir = backends_dir / arch
            so_file = arch_dir / "megadeth_accelerator.so"
            marker = "→" if arch == vendor else " "
            if so_file.exists():
                hash_file = arch_dir / "BUILD_HASH"
                if hash_file.exists():
                    try:
                        info = json.loads(hash_file.read_text())
                        print(f"  {marker} {arch:10} built {info.get('build_time', 'unknown')}")
                    except:
                        print(f"  {marker} {arch:10} built")
                else:
                    print(f"  {marker} {arch:10} built")
            else:
                print(f"  {marker} {arch:10} not built")
    else:
        print("  (no backends directory)")
    print()
    
    print("=" * 60)
    if can_build:
        print(f"Run: megadeth-accel build --arch {recommended}")
    else:
        print("Install missing dependencies before building.")
    print("=" * 60)


def cmd_build(args):
    """Build accelerator backend for specified architecture."""
    try:
        from megadeth.backend_loader import compile_backend, verify_build_hash
    except ImportError:
        print("ERROR: backend_loader not available")
        sys.exit(1)
    
    from pathlib import Path
    
    pkg_dir = Path(__file__).parent.parent
    backends_dir = pkg_dir / "_backends"
    src_dir = pkg_dir.parent / "accelerator_cpp"
    repo_dir = pkg_dir.parent
    backend_dir = backends_dir / args.arch
    
    print(f"Building MEGADETH accelerator for: {args.arch}")
    
    so_file = backend_dir / "megadeth_accelerator.so"
    if so_file.exists() and not args.force:
        if verify_build_hash(backend_dir, src_dir, repo_dir):
            print(f"Backend '{args.arch}' is up to date. Use --force to rebuild.")
            return
    
    success = compile_backend(src_dir, backend_dir, repo_dir, args.arch)
    if success:
        print(f"\nSuccessfully built {args.arch} backend")
    else:
        print(f"\nBuild failed for {args.arch}")
        sys.exit(1)


def cmd_clean(args):
    """Remove cached backends."""
    import shutil
    from pathlib import Path
    
    pkg_dir = Path(__file__).parent.parent
    backends_dir = pkg_dir / "_backends"
    
    if not backends_dir.exists():
        print("No backends to clean.")
        return
    
    if args.arch:
        arch_dir = backends_dir / args.arch
        if arch_dir.exists():
            shutil.rmtree(arch_dir)
            print(f"Removed {args.arch} backend")
        else:
            print(f"Backend {args.arch} not found")
    else:
        for arch in ["intel", "amd", "generic", "native"]:
            arch_dir = backends_dir / arch
            if arch_dir.exists():
                shutil.rmtree(arch_dir)
                print(f"Removed {arch} backend")
        lock_dir = backends_dir / "compilation.lock.d"
        if lock_dir.exists():
            shutil.rmtree(lock_dir)
            print("Removed stale lock")
    print("Clean complete.")


def main():
    """Main entry point for megadeth-accel CLI."""
    parser = argparse.ArgumentParser(
        prog="megadeth-accel",
        description="MEGADETH C++ accelerator management and diagnostics",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Legacy flags (for backward compat)
    parser.add_argument("--bench", "-b", action="store_true", help="Run benchmark")
    parser.add_argument("--version", "-v", action="store_true", help="Show version")
    
    # doctor
    doc_parser = subparsers.add_parser("doctor", help="Check environment and CPU features")
    
    # build
    build_parser = subparsers.add_parser("build", help="Build accelerator for architecture")
    build_parser.add_argument("--arch", choices=["native", "intel", "amd", "generic"], default="native")
    build_parser.add_argument("--force", "-f", action="store_true", help="Force rebuild")
    
    # clean
    clean_parser = subparsers.add_parser("clean", help="Remove cached backends")
    clean_parser.add_argument("--arch", choices=["intel", "amd", "generic", "native"])
    
    # status (existing)
    subparsers.add_parser("status", help="Show accelerator status")
    
    # bench (existing)
    subparsers.add_parser("bench", help="Run benchmark")
    
    args = parser.parse_args()
    
    # Handle legacy flags
    if args.version:
        from megadeth.analysis._accelerator import get_info
        info = get_info()
        print(f"megadeth-accelerator {info['version']}" if info["available"] else "not installed")
        return
    
    if args.bench:
        run_benchmark()
        return
    
    # Handle subcommands
    if args.command == "doctor":
        cmd_doctor()
    elif args.command == "build":
        cmd_build(args)
    elif args.command == "clean":
        cmd_clean(args)
    elif args.command == "status":
        print_status()
    elif args.command == "bench":
        run_benchmark()
    else:
        # Default: show status
        print_status()


if __name__ == "__main__":
    main()
