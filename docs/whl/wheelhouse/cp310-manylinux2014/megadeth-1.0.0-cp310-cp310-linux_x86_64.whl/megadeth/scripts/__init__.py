"""Command-line entrypoints for MEGADETH.

CLI modules are intentionally not imported here to avoid double-import warnings
when using `python -m megadeth.scripts.<module>` entry points.
"""

__all__: list[str] = []
