from __future__ import annotations

import argparse
from pathlib import Path

from megadeth.config.loader import load_config
from megadeth.execution.orchestrator import run_campaign
from megadeth.preflight import run_preflight


def main() -> None:
    parser = argparse.ArgumentParser(description="MEGADETH CLI")
    parser.add_argument("config", type=Path, help="Path to campaign YAML config")
    parser.add_argument(
        "--preflight-only", action="store_true", help="Run preflight checks only"
    )
    parser.add_argument(
        "--db",
        type=Path,
        default=None,
        help="Optional DuckDB output path (default: output/megadeth.duckdb)",
    )
    parser.add_argument(
        "--staging-strategy",
        choices=["batched", "per_job"],
        default=None,
        help="Override staging approach (batched shard run vs. legacy per-job isolation)",
    )
    args = parser.parse_args()

    cfg = load_config(args.config)
    if args.preflight_only:
        report = run_preflight(cfg)
        print("Preflight complete.")
        print(f"Warnings: {report.warnings}")
        print(f"Errors: {report.errors}")
        return

    result = run_campaign(
        cfg, db_path=args.db, staging_strategy=args.staging_strategy
    )
    print(f"Hypercube saved to: {result['npz_path']}")


def archive_export() -> None:
    """CLI entry point for exporting campaign archives."""
    parser = argparse.ArgumentParser(
        description="Export MEGADETH campaign(s) to a portable archive"
    )
    parser.add_argument(
        "db_path", type=Path, help="Path to source DuckDB database"
    )
    parser.add_argument(
        "-o", "--output", type=Path, required=True,
        help="Output archive path (e.g., my_campaign.megadeth.tar.gz)"
    )
    parser.add_argument(
        "-c", "--campaign", type=str, action="append", dest="campaigns",
        help="Campaign ID to export (can specify multiple). If omitted, exports all."
    )
    args = parser.parse_args()
    
    from megadeth.database.archive import export_campaign_archive
    
    manifest = export_campaign_archive(
        db_path=args.db_path,
        output_path=args.output,
        campaign_ids=args.campaigns,
    )
    print(f"\nArchive manifest:")
    print(f"  Version: {manifest.version}")
    print(f"  Campaigns: {len(manifest.campaign_ids)}")
    print(f"  NPZ files: {len(manifest.npz_files)}")
    print(f"  Size: {manifest.total_size_bytes / (1024**2):.1f} MB")


def archive_import() -> None:
    """CLI entry point for importing campaign archives."""
    parser = argparse.ArgumentParser(
        description="Import MEGADETH campaign archive"
    )
    parser.add_argument(
        "archive_path", type=Path, help="Path to .megadeth.tar.gz archive"
    )
    parser.add_argument(
        "-o", "--output-dir", type=Path, required=True,
        help="Directory to extract archive to"
    )
    parser.add_argument(
        "-t", "--target-db", type=Path, default=None,
        help="Append imported data into this existing DuckDB (optional)"
    )
    args = parser.parse_args()
    
    from megadeth.database.archive import import_campaign_archive
    
    manifest = import_campaign_archive(
        archive_path=args.archive_path,
        output_dir=args.output_dir,
        target_db_path=args.target_db,
    )
    print(f"\nImport complete:")
    print(f"  Campaigns: {len(manifest.campaign_ids)}")
    print(f"  NPZ files: {len(manifest.npz_files)}")


def archive_list() -> None:
    """CLI entry point for listing archive contents."""
    parser = argparse.ArgumentParser(
        description="List contents of a MEGADETH campaign archive"
    )
    parser.add_argument(
        "archive_path", type=Path, help="Path to .megadeth.tar.gz archive"
    )
    args = parser.parse_args()
    
    from megadeth.database.archive import list_archive_contents
    
    manifest = list_archive_contents(args.archive_path)
    print(f"Archive: {args.archive_path}")
    print(f"  Version: {manifest.version}")
    print(f"  Created: {manifest.created_at}")
    print(f"  Source DB: {manifest.source_db_path}")
    print(f"  Campaigns ({len(manifest.campaign_ids)}):")
    for cid in manifest.campaign_ids:
        print(f"    - {cid}")
    print(f"  NPZ files ({len(manifest.npz_files)}):")
    for path in list(manifest.npz_files.keys())[:10]:
        print(f"    - {path}")
    if len(manifest.npz_files) > 10:
        print(f"    ... and {len(manifest.npz_files) - 10} more")
    print(f"  Total size: {manifest.total_size_bytes / (1024**2):.1f} MB")


def help_command() -> None:
    """Display available MEGADETH commands with descriptions."""
    print("MEGADETH Command Reference")
    print("Systematic Assessment of Blast/Frag Round Effectiveness")
    print()
    
    commands = [
        ("megadeth-run", "Run a full MEGADETH campaign from YAML config",
         "megadeth-run campaign.yaml [--preflight-only] [--db OUTPUT.duckdb]"),
        
        ("megadeth-viz", "Generate static visualizations from NPZ results",
         "megadeth-viz results.npz [--discrete-all] [--isosurface]"),
        
        ("megadeth-dashboard", "Launch interactive Streamlit analytics dashboard",
         "megadeth-dashboard"),
        
        ("megadeth-help", "Display this help message with all available commands",
         "megadeth-help"),
        
        ("megadeth-docs", "Build Sphinx documentation and open in browser",
         "megadeth-docs [--no-open]"),
        
        ("", "─" * 75, ""),
        
        ("C++ Accelerator:", "", ""),
        
        ("megadeth-accel", "Show C++ accelerator status",
         "megadeth-accel [status]"),
        
        ("megadeth-accel doctor", "Check environment, CPU, and build readiness",
         "megadeth-accel doctor"),
        
        ("megadeth-accel build", "Compile accelerator for architecture",
         "megadeth-accel build --arch {native,intel,amd,generic}"),
        
        ("megadeth-accel bench", "Benchmark Python vs C++ performance",
         "megadeth-accel bench"),
        
        ("megadeth-accel clean", "Remove cached backend binaries",
         "megadeth-accel clean [--arch ARCH]"),
        
        ("", "─" * 75, ""),
        
        ("Archive Management:", "", ""),
        
        ("megadeth-archive-export", "Export campaign(s) to portable .tar.gz archive",
         "megadeth-archive-export megadeth.duckdb -o archive.megadeth.tar.gz"),
        
        ("megadeth-archive-import", "Import campaign archive into new/existing database",
         "megadeth-archive-import archive.megadeth.tar.gz -o ./imported/"),
        
        ("megadeth-archive-list", "List contents of a campaign archive",
         "megadeth-archive-list archive.megadeth.tar.gz"),
    ]
    
    for cmd, desc, usage in commands:
        if not cmd:
            print(desc)
            print()
            continue
        if desc.endswith(":"):
            print(f"\n{desc}")
            continue
        print(f"  {cmd}")
        print(f"    {desc}")
        if usage:
            print(f"    Usage: {usage}")
        print()
    
    print("Documentation:")
    print("  - Online Docs: Run 'megadeth-docs' to build and view")
    print("  - Docs Index: docs/source/index.rst")
    print("  - Quick Start: docs/source/quick_start.rst")
    print("  - User Guide: docs/source/user_guide/index.rst")
    print("  - Visualization API: docs/source/api/visualization.rst")
    print()
    print("For command-specific help, use: <command> --help")
    print()


def build_docs() -> None:
    """Build Sphinx documentation and serve via HTTP."""
    import subprocess
    import sys
    import os
    import http.server
    import socketserver
    import webbrowser
    from functools import partial
    
    parser = argparse.ArgumentParser(
        description="Build MEGADETH Sphinx documentation"
    )
    parser.add_argument(
        "--no-open", action="store_true",
        help="Build docs but don't open browser"
    )
    parser.add_argument(
        "--clean", action="store_true",
        help="Clean build directory before building"
    )
    parser.add_argument(
        "--port", type=int, default=8000,
        help="Port to serve documentation on (default: 8000)"
    )
    args = parser.parse_args()
    
    # Determine docs directory
    try:
        import megadeth
        megadeth_path = Path(megadeth.__file__).parent.parent
        docs_dir = megadeth_path / "docs"
    except Exception:
        # Fallback to relative path
        docs_dir = Path(__file__).parent.parent.parent / "docs"
    
    if not docs_dir.exists():
        print(f"Error: Documentation directory not found at {docs_dir}")
        sys.exit(1)
    
    print(f"Building documentation in {docs_dir}...")
    
    # Clean if requested
    if args.clean:
        print("  Cleaning build directory...")
        subprocess.run(["make", "clean"], cwd=docs_dir, check=False)
    
    # Build HTML docs
    print("  Running Sphinx build...")
    result = subprocess.run(
        ["make", "html"],
        cwd=docs_dir,
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0:
        print("Error building documentation:")
        print(result.stderr)
        sys.exit(1)
    
    print("  Documentation built successfully")
    
    html_dir = docs_dir / "build" / "html"
    if not html_dir.exists():
        print(f"Error: HTML directory not found at {html_dir}")
        sys.exit(1)

    # SERVE DOCUMENTATION
    os.chdir(html_dir)
    Handler = partial(http.server.SimpleHTTPRequestHandler, directory=str(html_dir))
    
    print(f"\nServing documentation at http://localhost:{args.port}")
    print("Press Ctrl+C to stop server")

    if not args.no_open:
        # Try to open, but don't crash if headless
        try:
            webbrowser.open(f"http://localhost:{args.port}")
        except Exception:
            pass

    try:
        with socketserver.TCPServer(("", args.port), Handler) as httpd:
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")


if __name__ == "__main__":
    main()
