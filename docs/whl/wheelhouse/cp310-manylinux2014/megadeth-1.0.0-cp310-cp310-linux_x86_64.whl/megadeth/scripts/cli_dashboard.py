#!/usr/bin/env python3
"""
CLI entry point to launch the MEGADETH Analytics Dashboard.

Usage:
    megadeth-dashboard
"""

import sys
import os
from pathlib import Path
import subprocess

def main():
    """Launch the Streamlit dashboard."""
    # Locate the dashboard.py file relative to this script
    # This script is in megadeth/scripts/, dashboard is in megadeth/
    package_dir = Path(__file__).parent.parent
    dashboard_path = package_dir / "dashboard.py"
    
    if not dashboard_path.exists():
        print(f"Error: Could not find dashboard at {dashboard_path}")
        sys.exit(1)
        
    print(f"Launching MEGADETH Dashboard from: {dashboard_path}")
    
    # Construct the streamlit command
    # We use sys.executable to ensure we use the same python environment
    cmd = [
        sys.executable,
        "-m", "streamlit",
        "run",
        str(dashboard_path),
        # Pass any additional arguments from the user to streamlit
    ] + sys.argv[1:]
    
    try:
        subprocess.run(cmd, check=True)
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
    except subprocess.CalledProcessError as e:
        print(f"Dashboard crashed with exit code {e.returncode}")
        sys.exit(e.returncode)

if __name__ == "__main__":
    main()
