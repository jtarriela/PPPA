from __future__ import annotations

import argparse
from pathlib import Path
from typing import List, Optional, Dict, Any

import numpy as np

from megadeth.visualization.plots import (
    create_blue_red_colormap,
    create_r2k_colormap,
    plot_salvo_boxplot,
    plot_pk_heatmap,
    compute_hob_mr_grid,
    detect_hypercube_format,
    normalize_hypercube_to_native,
    FIGSIZE_STANDARD,
    DPI_PRINT,
)

try:
    import matplotlib.pyplot as plt  # type: ignore
    from matplotlib import cm
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
except Exception as exc:
    raise RuntimeError("matplotlib is required for plotting; install with pip install matplotlib") from exc


def _load_npz(path: Path) -> Dict[str, Any]:
    data = np.load(path)
    return {k: data[k] for k in data.files}


# =============================================================================
# 3D Volume Visualization Functions
# =============================================================================

def plot_system_pk_heatmap(
    system_pk: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    output_dir: Path,
    aof_index: Optional[int] = None,
) -> List[Path]:
    """
    Plot System Pk as 2D heatmaps (HOB × Velocity) for each AOF slice.
    
    Uses shared plot_pk_heatmap from visualization.plots.
    
    Args:
        system_pk: 3D array shape (n_hob, n_vel, n_aof)
        hob_axis: HOB values in meters
        vel_axis: Velocity values in m/s
        aof_axis: AOF values in degrees
        output_dir: Output directory
        aof_index: If provided, plot only this AOF index; else plot all
        
    Returns:
        List of saved file paths
    """
    saved = []
    
    indices = [aof_index] if aof_index is not None else range(len(aof_axis))
    
    for i_aof in indices:
        pk_slice = system_pk[:, :, i_aof]  # (n_hob, n_vel)
        
        out_path = output_dir / f"system_pk_heatmap_aof{aof_axis[i_aof]:.0f}.png"
        
        plot_pk_heatmap(
            pk_slice=pk_slice,
            x_axis=vel_axis,
            y_axis=hob_axis,
            x_label="Terminal Velocity (m/s)",
            y_label="Height of Burst (m)",
            title=f"System Pk (Single-Shot) | AOF = {aof_axis[i_aof]:.0f}°",
            levels=20,
            contour_lines=[0.3, 0.5, 0.7, 0.9],
            cbar_label="Pk(system)",
            save_path=out_path,
            dpi=DPI_PRINT,
        )
        
        print(f"Saved {out_path}")
        saved.append(out_path)
    
    return saved


def plot_r2k_heatmap(
    rounds_to_kill: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    pk_thresholds: np.ndarray,
    output_dir: Path,
    threshold_index: int = 1,  # Default to Pk=0.5
    aof_index: Optional[int] = None,
) -> List[Path]:
    """
    Plot Rounds-to-Kill as 2D heatmaps.
    
    Uses shared plot_pk_heatmap with R2K colormap.
    
    Args:
        rounds_to_kill: 4D array shape (n_hob, n_vel, n_aof, n_thresholds)
        hob_axis, vel_axis, aof_axis: Axis values
        pk_thresholds: Pk threshold values
        output_dir: Output directory
        threshold_index: Which Pk threshold to plot
        aof_index: If provided, plot only this AOF; else plot all
        
    Returns:
        List of saved file paths
    """
    saved = []
    cmap = create_r2k_colormap()
    
    indices = [aof_index] if aof_index is not None else range(len(aof_axis))
    pk_thresh = pk_thresholds[threshold_index]
    
    for i_aof in indices:
        r2k_slice = rounds_to_kill[:, :, i_aof, threshold_index]  # (n_hob, n_vel)
        
        # Mask infinite values for better visualization
        r2k_masked = np.ma.masked_invalid(r2k_slice)
        finite_vals = r2k_slice[np.isfinite(r2k_slice)]
        vmax = min(np.nanmax(finite_vals), 20) if len(finite_vals) > 0 else 10
        
        out_path = output_dir / f"r2k_heatmap_pk{pk_thresh:.0%}_aof{aof_axis[i_aof]:.0f}.png"
        
        fig, ax = plt.subplots(figsize=FIGSIZE_STANDARD)
        vel_grid, hob_grid = np.meshgrid(vel_axis, hob_axis)
        
        cs = ax.contourf(vel_grid, hob_grid, r2k_masked, levels=np.arange(1, vmax+1, 1), cmap=cmap)
        ax.contour(vel_grid, hob_grid, r2k_masked, levels=[1, 2, 3, 5, 10], colors='k', linewidths=0.5)
        
        ax.set_xlabel("Terminal Velocity (m/s)", fontsize=12)
        ax.set_ylabel("Height of Burst (m)", fontsize=12)
        ax.set_title(f"Rounds to Pk≥{pk_thresh:.0%} | AOF = {aof_axis[i_aof]:.0f}°", fontsize=14)
        
        fig.colorbar(cs, ax=ax, label="Rounds Required")
        
        fig.savefig(out_path, dpi=DPI_PRINT, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
        saved.append(out_path)
    
    return saved


def plot_3d_isosurface(
    system_pk: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    output_dir: Path,
    pk_levels: List[float] = [0.3, 0.5, 0.7, 0.9],
) -> Optional[Path]:
    """
    Plot 3D isosurface visualization using plotly (interactive HTML).
    
    Falls back to matplotlib scatter plot if plotly not available.
    """
    try:
        import plotly.graph_objects as go
        
        fig = go.Figure()
        
        # Create meshgrid for 3D coordinates
        H, V, A = np.meshgrid(hob_axis, vel_axis, aof_axis, indexing='ij')
        
        colors = ['rgba(0,0,255,0.2)', 'rgba(0,255,0,0.3)', 'rgba(255,165,0,0.4)', 'rgba(255,0,0,0.5)']
        
        for i, level in enumerate(pk_levels):
            fig.add_trace(go.Isosurface(
                x=V.flatten(),
                y=H.flatten(),
                z=A.flatten(),
                value=system_pk.flatten(),
                isomin=level,
                isomax=level,
                opacity=0.3 + i*0.15,
                surface_count=1,
                colorscale=[[0, colors[i]], [1, colors[i]]],
                showscale=False,
                name=f"Pk ≥ {level:.0%}",
            ))
        
        fig.update_layout(
            title="System Pk Isosurfaces (3D Volume)",
            scene=dict(
                xaxis_title="Velocity (m/s)",
                yaxis_title="HOB (m)",
                zaxis_title="AOF (°)",
            ),
            width=900,
            height=700,
        )
        
        out_path = output_dir / "system_pk_3d_isosurface.html"
        fig.write_html(str(out_path))
        print(f"Saved {out_path} (open in browser for interactive 3D)")
        return out_path
        
    except ImportError:
        print("Plotly not available; using matplotlib 3D scatter fallback")
        return _plot_3d_scatter_fallback(system_pk, hob_axis, vel_axis, aof_axis, output_dir, pk_levels)


def _plot_3d_scatter_fallback(
    system_pk: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    output_dir: Path,
    pk_levels: List[float],
) -> Path:
    """Matplotlib 3D scatter plot fallback when plotly not available."""
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    H, V, A = np.meshgrid(hob_axis, vel_axis, aof_axis, indexing='ij')
    
    # Scatter plot with color = Pk value
    pk_flat = system_pk.flatten()
    mask = pk_flat > 0.1  # Only show points with meaningful Pk
    
    scatter = ax.scatter(
        V.flatten()[mask],
        H.flatten()[mask],
        A.flatten()[mask],
        c=pk_flat[mask],
        cmap=create_blue_red_colormap(),
        s=20,
        alpha=0.6,
        vmin=0,
        vmax=1,
    )
    
    ax.set_xlabel("Velocity (m/s)")
    ax.set_ylabel("HOB (m)")
    ax.set_zlabel("AOF (°)")
    ax.set_title("System Pk (3D Volume)")
    
    fig.colorbar(scatter, ax=ax, label="Pk(system)", shrink=0.6)
    
    out_path = output_dir / "system_pk_3d_scatter.png"
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out_path}")
    return out_path


def plot_slice_grid(
    system_pk: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    output_dir: Path,
    n_slices: int = 3,
) -> Path:
    """
    Plot a grid of 2D slices showing variation across all three axes.
    
    Creates a 3×n_slices grid:
    - Row 1: HOB slices (varying HOB, fixed mid vel/aof)
    - Row 2: Velocity slices (varying vel, fixed mid hob/aof)
    - Row 3: AOF slices (varying aof, fixed mid hob/vel)
    """
    cmap = create_blue_red_colormap()
    
    # Select slice indices evenly distributed
    def get_slice_indices(n_total, n_want):
        if n_total <= n_want:
            return list(range(n_total))
        step = (n_total - 1) / (n_want - 1)
        return [int(round(i * step)) for i in range(n_want)]
    
    hob_indices = get_slice_indices(len(hob_axis), n_slices)
    vel_indices = get_slice_indices(len(vel_axis), n_slices)
    aof_indices = get_slice_indices(len(aof_axis), n_slices)
    
    mid_hob = len(hob_axis) // 2
    mid_vel = len(vel_axis) // 2
    mid_aof = len(aof_axis) // 2
    
    fig, axes = plt.subplots(3, n_slices, figsize=(4*n_slices, 12))
    
    # Row 1: Vary HOB (show Vel × AOF slices)
    for col, i_hob in enumerate(hob_indices):
        ax = axes[0, col]
        pk_slice = system_pk[i_hob, :, :]  # (n_vel, n_aof)
        aof_grid, vel_grid = np.meshgrid(aof_axis, vel_axis)
        cs = ax.contourf(aof_grid, vel_grid, pk_slice, levels=15, cmap=cmap, vmin=0, vmax=1)
        ax.set_title(f"HOB = {hob_axis[i_hob]:.1f}m")
        ax.set_xlabel("AOF (°)")
        ax.set_ylabel("Vel (m/s)")
    
    # Row 2: Vary Velocity (show HOB × AOF slices)
    for col, i_vel in enumerate(vel_indices):
        ax = axes[1, col]
        pk_slice = system_pk[:, i_vel, :]  # (n_hob, n_aof)
        aof_grid, hob_grid = np.meshgrid(aof_axis, hob_axis)
        cs = ax.contourf(aof_grid, hob_grid, pk_slice, levels=15, cmap=cmap, vmin=0, vmax=1)
        ax.set_title(f"Vel = {vel_axis[i_vel]:.0f}m/s")
        ax.set_xlabel("AOF (°)")
        ax.set_ylabel("HOB (m)")
    
    # Row 3: Vary AOF (show HOB × Vel slices)
    for col, i_aof in enumerate(aof_indices):
        ax = axes[2, col]
        pk_slice = system_pk[:, :, i_aof]  # (n_hob, n_vel)
        vel_grid, hob_grid = np.meshgrid(vel_axis, hob_axis)
        cs = ax.contourf(vel_grid, hob_grid, pk_slice, levels=15, cmap=cmap, vmin=0, vmax=1)
        ax.set_title(f"AOF = {aof_axis[i_aof]:.0f}°")
        ax.set_xlabel("Vel (m/s)")
        ax.set_ylabel("HOB (m)")
    
    # Add colorbar
    fig.subplots_adjust(right=0.9)
    cbar_ax = fig.add_axes([0.92, 0.15, 0.02, 0.7])
    fig.colorbar(cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(0, 1)), cax=cbar_ax, label="Pk(system)")
    
    fig.suptitle("System Pk Slices Across Terminal Conditions", fontsize=14, y=0.98)
    
    out_path = output_dir / "system_pk_slice_grid.png"
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out_path}")
    return out_path


def plot_mean_pk_by_shot(
    mean_pk_by_shot: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    output_dir: Path,
) -> Path:
    """
    Plot accumulated Pk curves showing how Pk grows with number of rounds.
    
    Args:
        mean_pk_by_shot: 4D array shape (n_shots, n_hob, n_vel, n_aof)
    """
    n_shots = mean_pk_by_shot.shape[0]
    
    # Average across terminal conditions for overview
    mean_pk_avg = mean_pk_by_shot.mean(axis=(1, 2, 3))
    mean_pk_min = mean_pk_by_shot.min(axis=(1, 2, 3))
    mean_pk_max = mean_pk_by_shot.max(axis=(1, 2, 3))
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    shots = np.arange(1, n_shots + 1)
    ax.fill_between(shots, mean_pk_min, mean_pk_max, alpha=0.3, color='blue', label='Min-Max Range')
    ax.plot(shots, mean_pk_avg, 'b-o', linewidth=2, markersize=6, label='Mean Pk')
    
    # Add threshold lines
    for thresh in [0.5, 0.7, 0.9]:
        ax.axhline(y=thresh, color='gray', linestyle='--', alpha=0.5)
        ax.text(n_shots + 0.2, thresh, f'{thresh:.0%}', va='center', fontsize=9)
    
    ax.set_xlabel("Number of Rounds", fontsize=12)
    ax.set_ylabel("Accumulated Pk", fontsize=12)
    ax.set_title("Salvo Pk Accumulation (Survivor Rule)", fontsize=14)
    ax.set_xlim(0.5, n_shots + 0.5)
    ax.set_ylim(0, 1.05)
    ax.set_xticks(shots)
    ax.legend(loc='lower right')
    ax.grid(True, alpha=0.3)
    
    out_path = output_dir / "mean_pk_by_shot.png"
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out_path}")
    return out_path


def plot_sensitivity_map(
    sensitivity: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    output_dir: Path,
    aof_index: Optional[int] = None,
) -> List[Path]:
    """
    Plot sensitivity (gradient magnitude) showing regions of high Pk variability.
    """
    saved = []
    cmap = plt.cm.hot
    
    indices = [aof_index] if aof_index is not None else [len(aof_axis)//2]
    
    for i_aof in indices:
        sens_slice = sensitivity[:, :, i_aof]
        
        fig, ax = plt.subplots(figsize=(10, 8))
        vel_grid, hob_grid = np.meshgrid(vel_axis, hob_axis)
        
        cs = ax.contourf(vel_grid, hob_grid, sens_slice, levels=20, cmap=cmap)
        ax.contour(vel_grid, hob_grid, sens_slice, levels=10, colors='k', linewidths=0.3, alpha=0.5)
        
        ax.set_xlabel("Terminal Velocity (m/s)", fontsize=12)
        ax.set_ylabel("Height of Burst (m)", fontsize=12)
        ax.set_title(f"Pk Sensitivity (Gradient) | AOF = {aof_axis[i_aof]:.0f}°", fontsize=14)
        
        fig.colorbar(cs, ax=ax, label="∇Pk Magnitude")
        
        out_path = output_dir / f"sensitivity_map_aof{aof_axis[i_aof]:.0f}.png"
        fig.savefig(out_path, dpi=200, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
        saved.append(out_path)
    
    return saved


# =============================================================================
# Main CLI
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="MEGADETH Visualization CLI - Generate plots from hypercube and analysis NPZ files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Single Pk contour slice (default: middle indices)
  megadeth-viz pk_hypercube.npz

  # All Pk contour slices across terminal conditions
  megadeth-viz pk_hypercube.npz --plot-all

  # Discrete analysis visualizations
  megadeth-viz discrete_analysis_v3.npz --discrete-heatmap
  megadeth-viz discrete_analysis_v3.npz --isosurface
  megadeth-viz discrete_analysis_v3.npz --slice-grid
  megadeth-viz discrete_analysis_v3.npz --discrete-all

  # R2K analysis
  megadeth-viz discrete_analysis_v3.npz --r2k-heatmap --threshold-index 1
        """
    )
    parser.add_argument("npz", type=Path, help="Path to NPZ file (pk_hypercube.npz or discrete_analysis_v3.npz)")
    parser.add_argument("--output-dir", type=Path, default=Path("./viz_output"), help="Output directory for plots")
    
    # Pk contour options (original functionality)
    contour_group = parser.add_argument_group("Pk Contour Plots (from pk_hypercube.npz)")
    contour_group.add_argument("--plot-all", action="store_true", help="Generate all contour slices")
    contour_group.add_argument("--hob-index", type=int, default=None, help="HOB index to plot")
    contour_group.add_argument("--vel-index", type=int, default=None, help="Velocity index to plot")
    contour_group.add_argument("--aof-index", type=int, default=None, help="AOF index to plot")
    contour_group.add_argument("--levels", type=int, default=15, help="Contour level count")
    contour_group.add_argument("--interp-factor", type=float, default=1.0, help="Upsample factor for smoother plots")
    
    # Discrete analysis visualization options (new)
    discrete_group = parser.add_argument_group("Discrete Analysis Visualizations (from discrete_analysis_v3.npz)")
    discrete_group.add_argument("--discrete-heatmap", action="store_true", help="System Pk heatmap (HOB × Vel)")
    discrete_group.add_argument("--r2k-heatmap", action="store_true", help="Rounds-to-Kill heatmap")
    discrete_group.add_argument("--isosurface", action="store_true", help="3D Pk isosurface (requires plotly)")
    discrete_group.add_argument("--slice-grid", action="store_true", help="Multi-slice grid visualization")
    discrete_group.add_argument("--pk-by-shot", action="store_true", help="Accumulated Pk by shot count")
    discrete_group.add_argument("--sensitivity", action="store_true", help="Pk sensitivity/gradient map")
    discrete_group.add_argument("--discrete-all", action="store_true", help="Generate all discrete analysis plots")
    discrete_group.add_argument("--threshold-index", type=int, default=1, help="Pk threshold index for R2K (0=30%%, 1=50%%, 2=70%%, 3=90%%)")
    
    # Additional options
    parser.add_argument("--axis-npz", type=Path, default=None, help="Optional NPZ with axis data")
    
    args = parser.parse_args()
    
    data = _load_npz(args.npz)
    if args.axis_npz:
        data = {**_load_npz(args.axis_npz), **data}
    
    args.output_dir.mkdir(parents=True, exist_ok=True)
    
    # Extract common axis data (handle various naming conventions)
    def _get_axis(primary: str, *fallbacks: str):
        if primary in data:
            return data[primary]
        for fb in fallbacks:
            if fb in data:
                return data[fb]
        return None
    
    hob_axis = _get_axis("hob", "hob_axis")
    vel_axis = _get_axis("vel", "velocity", "vel_axis", "velocity_axis")
    aof_axis = _get_axis("aof", "aof_axis")
    miss_x_axis = _get_axis("miss_x", "miss_x_axis", "deflection_axis")
    miss_y_axis = _get_axis("miss_y", "miss_y_axis", "range_axis")
    
    saved: List[Path] = []
    
    # ===========================================
    # Discrete Analysis Visualizations
    # ===========================================
    system_pk = _get_axis("system_pk", "reliability")
    r2k = data.get("rounds_to_kill")
    pk_thresholds = data.get("pk_thresholds")
    mean_pk_by_shot = data.get("mean_pk_by_shot")
    sensitivity = data.get("sensitivity")
    
    if args.discrete_all:
        args.discrete_heatmap = True
        args.r2k_heatmap = True
        args.isosurface = True
        args.slice_grid = True
        args.pk_by_shot = True
        args.sensitivity = True
    
    if args.discrete_heatmap and system_pk is not None:
        saved.extend(plot_system_pk_heatmap(
            system_pk, hob_axis, vel_axis, aof_axis, args.output_dir, args.aof_index
        ))
    
    if args.r2k_heatmap and r2k is not None and pk_thresholds is not None:
        saved.extend(plot_r2k_heatmap(
            r2k, hob_axis, vel_axis, aof_axis, pk_thresholds,
            args.output_dir, args.threshold_index, args.aof_index
        ))
    
    if args.isosurface and system_pk is not None:
        result = plot_3d_isosurface(system_pk, hob_axis, vel_axis, aof_axis, args.output_dir)
        if result:
            saved.append(result)
    
    if args.slice_grid and system_pk is not None:
        saved.append(plot_slice_grid(system_pk, hob_axis, vel_axis, aof_axis, args.output_dir))
    
    if args.pk_by_shot and mean_pk_by_shot is not None:
        saved.append(plot_mean_pk_by_shot(mean_pk_by_shot, hob_axis, vel_axis, aof_axis, args.output_dir))
    
    if args.sensitivity and sensitivity is not None:
        saved.extend(plot_sensitivity_map(sensitivity, hob_axis, vel_axis, aof_axis, args.output_dir, args.aof_index))
    
    # ===========================================
    # Original Pk Contour Plots
    # ===========================================
    # Use explicit None checks since NumPy arrays can't be used with 'or'
    pk_det = data.get("pk_det")
    if pk_det is None:
        pk_det = data.get("pk_hypercube")
    if pk_det is None:
        pk_det = data.get("pk")
    
    if pk_det is not None and miss_x_axis is not None and miss_y_axis is not None:
        # Detect and normalize hypercube format
        axes = {
            "miss_x": miss_x_axis,
            "miss_y": miss_y_axis,
            "hob": hob_axis,
            "vel": vel_axis,
            "aof": aof_axis,
        }
        
        try:
            fmt = detect_hypercube_format(pk_det, axes)
            if fmt == "legacy":
                print(f"Detected legacy hypercube format, transposing to native...")
            pk_det = normalize_hypercube_to_native(pk_det, axes)
            print(f"Hypercube shape (native format): {pk_det.shape} = (miss_x, miss_y, hob, vel, aof)")
        except ValueError as e:
            print(f"Warning: Could not detect hypercube format: {e}")
        
        def _plot_slice(i_hob, i_vel, i_aof, seq_id: str):
            # pk_det shape (native): (n_miss_x, n_miss_y, n_hob, n_vel, n_aof)
            pk_slice = pk_det[:, :, i_hob, i_vel, i_aof]
            mx_axis = miss_x_axis
            my_axis = miss_y_axis

            if args.interp_factor and args.interp_factor > 1.0:
                try:
                    from scipy.ndimage import zoom
                    factor = float(args.interp_factor)
                    pk_slice = zoom(pk_slice, factor, order=1)
                    # After zoom, pk_slice shape is (n_miss_x * factor, n_miss_y * factor)
                    mx_axis = np.linspace(miss_x_axis[0], miss_x_axis[-1], pk_slice.shape[0])
                    my_axis = np.linspace(miss_y_axis[0], miss_y_axis[-1], pk_slice.shape[1])
                except Exception:
                    print("Interpolation requested but SciPy not available; using raw grid.")

            out_path = args.output_dir / f"contour_{seq_id}_hob{hob_axis[i_hob]:.1f}_vel{vel_axis[i_vel]:.0f}_aof{aof_axis[i_aof]:.0f}.png"
            
            # pk_slice shape is (n_miss_x, n_miss_y) matching mx_axis x my_axis
            # plot_pk_heatmap expects pk_slice shape (n_x, n_y) with meshgrid indexing="ij"
            plot_pk_heatmap(
                pk_slice=pk_slice,  # shape (n_miss_x, n_miss_y)
                x_axis=mx_axis,     # Miss-X (Deflection) on X-axis
                y_axis=my_axis,     # Miss-Y (Range) on Y-axis
                x_label="Miss Deflection (m)",
                y_label="Miss Range (m)",
                title=f"HOB={hob_axis[i_hob]:.1f}m, VEL={vel_axis[i_vel]:.0f}m/s, AOF={aof_axis[i_aof]:.0f}°",
                levels=args.levels,
                cbar_label="Pk",
                save_path=out_path,
                dpi=DPI_PRINT,
            )
            
            print(f"Saved {out_path}")
            return out_path

        if args.plot_all:
            seq = 0
            for i_h, _ in enumerate(hob_axis):
                for i_v, _ in enumerate(vel_axis):
                    for i_a, _ in enumerate(aof_axis):
                        seq += 1
                        saved.append(_plot_slice(i_h, i_v, i_a, f"{seq:04d}"))
        elif not any([args.discrete_heatmap, args.r2k_heatmap, args.isosurface, 
                      args.slice_grid, args.pk_by_shot, args.sensitivity, args.discrete_all]):
            # Default: single slice if no discrete options specified
            def _mid(axis): return len(axis)//2
            i_h = args.hob_index if args.hob_index is not None else _mid(hob_axis)
            i_v = args.vel_index if args.vel_index is not None else _mid(vel_axis)
            i_a = args.aof_index if args.aof_index is not None else _mid(aof_axis)
            saved.append(_plot_slice(i_h, i_v, i_a, "0001"))
    
    # R2K boxplot (legacy)
    r2k_simple = data.get("rounds_to_kill")
    if r2k_simple is not None and not args.r2k_heatmap and len(r2k_simple.shape) <= 3:
        flat = np.ravel(r2k_simple)
        flat = flat[np.isfinite(flat)]
        if len(flat) > 0:
            fig, ax = plot_salvo_boxplot(flat, title="Rounds to Kill Distribution")
            out_path = args.output_dir / "r2k_boxplot.png"
            fig.savefig(out_path, dpi=200, bbox_inches="tight")
            plt.close(fig)
            print(f"Saved {out_path}")
            saved.append(out_path)
    
    if saved:
        print(f"\nGenerated {len(saved)} visualization(s) in {args.output_dir}/")
    else:
        print("No visualizations generated. Check NPZ file contents and options.")


if __name__ == "__main__":
    main()
