from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Mapping, Optional, Union
from pathlib import Path
from megadeth.config.loader import _validate
from megadeth.config.schema import CampaignConfig
from megadeth.platform import PlatformAdapter, SystemResources, get_platform_adapter
from megadeth.physics.fullspray_wrapper import select_executable, get_data_directory
from megadeth.preflight.resource_estimator import (
    estimate_hypercube_size_mb,
    estimate_physics_runs,
    estimate_runtime_seconds,
    estimate_staging_requirement_mb,
)


@dataclass
class PreflightReport:
    resources: SystemResources
    io_benchmarks: Dict[str, float]
    total_physics_evals: int
    estimated_runtime_sec: float
    estimated_staging_mb: int
    estimated_output_mb: float
    checks_passed: bool
    warnings: List[str]
    errors: List[str]
    recommended_workers: int
    recommended_batch_size: int
    recommended_buffer_mb: int
    asset_checksums: Dict[str, str]
    machine_balance: Optional[float] = None


def _coerce_config(config: Union[CampaignConfig, Mapping]) -> CampaignConfig:
    if isinstance(config, CampaignConfig):
        return config
    return _validate(CampaignConfig, config)


def run_preflight(
    config: Union[CampaignConfig, Mapping],
    skip_io_benchmark: bool = False,
    skip_io_writability: bool = False,
    adapter: Optional[PlatformAdapter] = None,
) -> PreflightReport:
    """Execute platform-aware preflight checks."""
    cfg = _coerce_config(config)
    adapter = adapter or get_platform_adapter()
    warnings: List[str] = []
    errors: List[str] = []

    # 1. System probe
    resources = adapter.probe_system()
    # print(
    #     f"CPU: {resources.physical_cores} physical / "
    #     f"{resources.logical_cores} logical | "
    #     f"Memory: {resources.available_memory_gb:.1f}GB available"
    # )

    # 1b. Validate required files exist and are readable, and output/staging writable
    missing = []
    
    # Resolve FSM executable and CDRAG paths (use auto-detection if not specified)
    fsm_exe_path = Path(cfg.solver.fsm_exe_path) if cfg.solver.fsm_exe_path else select_executable()
    cdrag_path = Path(cfg.solver.cdrag_path) if cfg.solver.cdrag_path else get_data_directory() / "CDRAG1.DAT"
    
    if not fsm_exe_path.exists():
        missing.append(fsm_exe_path)
    if not cdrag_path.exists():
        missing.append(cdrag_path)
    for wh in cfg.warheads:
        if not Path(wh.zdata_path).exists():
            missing.append(wh.zdata_path)
    for tgt in cfg.targets:
        for p in (tgt.rcas_path, tgt.intrvc_path):
            if not Path(p).exists():
                missing.append(p)
    if missing:
        raise FileNotFoundError(f"Missing required files: {', '.join(str(m) for m in missing)}")

    # Writability checks (can be skipped for GA workers using node-local storage)
    def _assert_writable(path: Path):
        path.mkdir(parents=True, exist_ok=True)
        test_file = path / ".megadeth_write_test"
        try:
            test_file.write_text("ok")
            test_file.unlink(missing_ok=True)
        except Exception as exc:
            raise PermissionError(f"Path not writable: {path} ({exc})")

    if not skip_io_writability:
        _assert_writable(resources.output_path)
        _assert_writable(resources.staging_path.parent)

    # 1c. Compute asset checksums (best-effort)
    import hashlib

    def _sha256(path: Path) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    asset_checksums: Dict[str, str] = {}
    try:
        asset_checksums["fsm_exe"] = _sha256(fsm_exe_path)
        asset_checksums["cdrag"] = _sha256(cdrag_path)
    except Exception as exc:  # pragma: no cover
        warnings.append(f"Checksum computation failed: {exc}")

    # 2. IO benchmark
    io_benchmarks: Dict[str, float] = {}
    perform_benchmark = skip_io_benchmark is False and not cfg.execution.skip_io_benchmark
    if perform_benchmark:
        try:
            io_benchmarks = adapter.benchmark_io(
                resources.staging_path, resources.output_path
            )
            resources.disk_write_bandwidth_mbps = io_benchmarks.get(
                "disk_write_mbps", resources.disk_write_bandwidth_mbps
            )
            resources.disk_read_bandwidth_mbps = io_benchmarks.get(
                "disk_read_mbps", resources.disk_read_bandwidth_mbps
            )
        except Exception as exc:  # pragma: no cover - depends on platform IO
            warnings.append(f"IO benchmark failed: {exc}")
            io_benchmarks = {}

    # 3. Work estimation
    total_evals = estimate_physics_runs(cfg)
    buffer_mb = resources.staging_buffer_mb
    if cfg.execution.staging_buffer_mb and cfg.execution.staging_buffer_mb != "auto":
        buffer_mb = int(cfg.execution.staging_buffer_mb)
    estimated_staging_mb = estimate_staging_requirement_mb(total_evals, buffer_mb)
    estimated_output_mb = estimate_hypercube_size_mb(cfg)

    requested_workers = cfg.execution.max_parallel_workers
    recommended_workers = min(
        resources.max_parallel_workers, requested_workers or resources.max_parallel_workers
    )

    # Honor user-requested cap by clamping the probed resources. This ensures
    # downstream worker allocation and runtime estimates respect
    # execution.max_parallel_workers rather than always using physical cores.
    resources.max_parallel_workers = recommended_workers
    if cfg.execution.batch_size and cfg.execution.batch_size != "auto":
        recommended_batch_size = int(cfg.execution.batch_size)
    else:
        recommended_batch_size = (
            resources.recommended_batch_size
            or max(1, total_evals // max(1, recommended_workers))
        )
    estimated_runtime_sec = estimate_runtime_seconds(total_evals, recommended_workers)

    # 4. Validation checks
    staging_available_mb = resources.staging_available_gb * 1024
    if estimated_staging_mb > staging_available_mb:
        errors.append(
            f"Insufficient staging: need {estimated_staging_mb:.0f}MB, "
            f"available {staging_available_mb:.0f}MB"
        )

    io_ratio = None
    machine_balance = None
    if io_benchmarks.get("disk_write_mbps", 0) > 0:
        # Staging speedup ratio (how much faster RAM disk is than SSD)
        io_ratio = io_benchmarks.get("staging_write_mbps", 0) / max(
            io_benchmarks.get("disk_write_mbps", 1), 1e-6
        )
        # True machine balance: CPU throughput vs DB throughput
        # CPU: workers * (1/avg_eval_time) items/sec, assuming ~100ms per eval
        # DB: disk_write_mbps * 1024 / record_size_kb items/sec
        avg_eval_sec = 0.1
        db_record_size_kb = 2.0
        cpu_throughput = recommended_workers / avg_eval_sec
        db_throughput = (io_benchmarks.get("disk_write_mbps", 100) * 1024) / db_record_size_kb
        machine_balance = cpu_throughput / max(db_throughput, 1e-6)
        
        if io_ratio < 5:
            warnings.append(
                f"Staging not much faster than disk ({io_ratio:.1f}x); "
                "consider using /dev/shm or faster storage."
            )

    checks_passed = len(errors) == 0

    return PreflightReport(
        resources=resources,
        io_benchmarks=io_benchmarks,
        total_physics_evals=total_evals,
        estimated_runtime_sec=estimated_runtime_sec,
        estimated_staging_mb=estimated_staging_mb,
        estimated_output_mb=estimated_output_mb,
        checks_passed=checks_passed,
        warnings=warnings,
        errors=errors,
        recommended_workers=recommended_workers,
        recommended_batch_size=recommended_batch_size,
        recommended_buffer_mb=buffer_mb,
        asset_checksums=asset_checksums,
        machine_balance=machine_balance,
    )
