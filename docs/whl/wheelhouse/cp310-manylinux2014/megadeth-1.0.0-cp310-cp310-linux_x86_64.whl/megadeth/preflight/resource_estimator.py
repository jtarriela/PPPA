from __future__ import annotations

import math
from typing import Mapping, Union

from megadeth.config.loader import _validate
from megadeth.config.schema import CampaignConfig


def _coerce_config(config: Union[CampaignConfig, Mapping]) -> CampaignConfig:
    if isinstance(config, CampaignConfig):
        return config
    return _validate(CampaignConfig, config)


def estimate_physics_runs(config: Union[CampaignConfig, Mapping]) -> int:
    """Estimate the total number of FSM evaluations."""
    cfg = _coerce_config(config)
    tc = cfg.terminal_conditions
    n_hob = len(tc.hob.values)
    n_vel = len(tc.velocity.values)
    n_aof = len(tc.aof.values)
    return len(cfg.warheads) * len(cfg.targets) * n_hob * n_vel * n_aof


def estimate_hypercube_size_mb(config: Union[CampaignConfig, Mapping]) -> float:
    """
    Estimate output NPZ size for the full 5D Pk hypercube (float64).
    
    Note: Grid dimensions are now extracted from LAM2 output at runtime.
    We use the standard LAM2 grid size (80×40 mirrored to ~160×80) for estimation.
    """
    cfg = _coerce_config(config)
    tc = cfg.terminal_conditions
    
    # LAM2 native grid is 80×40, mirrored to approximately 160×80
    # Use these defaults since grid is deprecated and extracted at runtime
    if cfg.grid is not None and cfg.grid.miss_x_axis and cfg.grid.miss_y_axis:
        n_miss_x = len(cfg.grid.miss_x_axis)
        n_miss_y = len(cfg.grid.miss_y_axis)
    else:
        # Default LAM2 grid dimensions (mirrored)
        n_miss_x = 160  # Deflection axis (mirrored from 80)
        n_miss_y = 80   # Range axis (mirrored from 40)
    
    n_points = (
        len(tc.hob.values)
        * len(tc.velocity.values)
        * len(tc.aof.values)
        * n_miss_x
        * n_miss_y
    )
    bytes_total = n_points * 8  # float64
    return bytes_total / (1024**2)


def estimate_staging_requirement_mb(
    total_evals: int, buffer_mb: int = 512, lam2_kb: int = 15
) -> int:
    """
    Estimate staging requirement based on LAM2 outputs.
    
    Uses 15KB per physics run (LAM2.DAT) plus a buffer for scratch files.
    """
    lam2_mb = (total_evals * lam2_kb) / 1024
    return int(math.ceil(lam2_mb + buffer_mb))


def estimate_runtime_seconds(
    total_evals: int, workers: int, avg_eval_seconds: float = 0.1
) -> float:
    """Rough runtime estimate assuming fixed average per-eval cost."""
    workers = max(1, workers)
    return (total_evals * avg_eval_seconds) / workers
