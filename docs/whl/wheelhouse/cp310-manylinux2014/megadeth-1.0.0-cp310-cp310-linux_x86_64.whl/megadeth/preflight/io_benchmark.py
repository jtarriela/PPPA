from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path
from typing import Dict


def benchmark_path(path: Path, size_mb: int = 32) -> Dict[str, float]:
    """
    Benchmark sequential write/read throughput on the given path.

    The benchmark writes a temporary file of the requested size using 1MB
    chunks, then reads it back to measure throughput. Returns MB/s metrics.
    """
    chunk = os.urandom(1024 * 1024)
    total_bytes = size_mb * len(chunk)
    path.mkdir(parents=True, exist_ok=True)

    fd, tmp_name = tempfile.mkstemp(dir=path)
    tmp_path = Path(tmp_name)
    os.close(fd)

    try:
        start = time.perf_counter()
        with open(tmp_path, "wb") as f:
            for _ in range(size_mb):
                f.write(chunk)
            f.flush()
            os.fsync(f.fileno())
        write_time = max(time.perf_counter() - start, 1e-6)

        start = time.perf_counter()
        with open(tmp_path, "rb") as f:
            while f.read(len(chunk)):
                pass
        read_time = max(time.perf_counter() - start, 1e-6)

        return {
            "write_mbps": (total_bytes / write_time) / (1024**2),
            "read_mbps": (total_bytes / read_time) / (1024**2),
        }
    finally:
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass
