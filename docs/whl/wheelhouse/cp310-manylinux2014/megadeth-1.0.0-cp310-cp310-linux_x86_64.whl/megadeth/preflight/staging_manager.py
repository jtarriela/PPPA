from __future__ import annotations

from pathlib import Path

from megadeth.platform.base import PlatformAdapter


def prepare_staging(adapter: PlatformAdapter, estimated_size_mb: int) -> Path:
    """
    Ask the adapter to provision a staging area large enough for the campaign.
    
    This thin wrapper exists so higher-level code has a single place to apply
    cross-platform staging policies.
    """
    return adapter.prepare_staging_area(estimated_size_mb)
