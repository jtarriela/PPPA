"""
Campaign Archive Utilities

Provides functions to export and import complete campaign archives
containing DuckDB metadata and all associated NPZ files in a single
compressed archive.

Archive Format (.megadeth.tar.gz):
    campaign_archive/
    ├── metadata.json          # Archive manifest with paths and checksums
    ├── megadeth.duckdb           # Full database with all metadata
    └── data/
        ├── pk_hypercube_<uuid>.npz
        ├── discrete_results_<uuid>.npz
        └── ...

Usage:
    # Export
    from megadeth.database.archive import export_campaign_archive
    export_campaign_archive(
        db_path="./output/megadeth.duckdb",
        output_path="./my_campaign.megadeth.tar.gz",
        campaign_ids=["campaign-123"]  # Optional: export specific campaigns
    )
    
    # Import
    from megadeth.database.archive import import_campaign_archive
    import_campaign_archive(
        archive_path="./my_campaign.megadeth.tar.gz",
        output_dir="./imported_campaign",
        target_db_path="./master.duckdb"  # Optional: append into existing DB
    )
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tarfile
import tempfile
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

import duckdb


@dataclass
class ArchiveManifest:
    """Manifest describing archive contents."""
    version: str = "1.0"
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    source_db_path: str = ""
    campaign_ids: List[str] = field(default_factory=list)
    npz_files: Dict[str, str] = field(default_factory=dict)  # relative_path -> sha256
    total_size_bytes: int = 0
    
    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)
    
    @classmethod
    def from_json(cls, data: str) -> "ArchiveManifest":
        return cls(**json.loads(data))


def _sha256_file(path: Path) -> str:
    """Compute SHA256 checksum of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _collect_npz_paths(conn: duckdb.DuckDBPyConnection, campaign_ids: Optional[List[str]] = None) -> Set[Path]:
    """
    Collect all NPZ file paths referenced by campaigns in the database.
    
    Scans pk_hypercubes, discrete_analyses, and monte_carlo_analyses tables
    for npz_path columns.
    """
    npz_paths: Set[Path] = set()
    
    # Build WHERE clause for campaign filtering
    where_clause = ""
    params: List[str] = []
    if campaign_ids:
        placeholders = ", ".join(["?" for _ in campaign_ids])
        where_clause = f"WHERE campaign_id IN ({placeholders})"
        params = campaign_ids
    
    # pk_hypercubes.npz_path
    try:
        if campaign_ids:
            rows = conn.execute(
                f"SELECT npz_path FROM pk_hypercubes {where_clause}", params
            ).fetchall()
        else:
            rows = conn.execute("SELECT npz_path FROM pk_hypercubes").fetchall()
        for (path,) in rows:
            if path:
                npz_paths.add(Path(path))
    except Exception:
        pass  # Table may not exist
    
    # discrete_analyses - get hypercube_ids first, then paths
    try:
        if campaign_ids:
            rows = conn.execute(f"""
                SELECT da.system_pk_npz, da.reliability_npz, da.r2k_npz
                FROM discrete_analyses da
                JOIN pk_hypercubes ph ON da.hypercube_id = ph.hypercube_id
                {where_clause.replace('campaign_id', 'ph.campaign_id')}
            """, params).fetchall()
        else:
            rows = conn.execute("""
                SELECT system_pk_npz, reliability_npz, r2k_npz 
                FROM discrete_analyses
            """).fetchall()
        for row in rows:
            for path in row:
                if path:
                    npz_paths.add(Path(path))
    except Exception:
        pass
    
    # monte_carlo_analyses
    try:
        if campaign_ids:
            rows = conn.execute(f"""
                SELECT mc.results_npz_path
                FROM monte_carlo_analyses mc
                JOIN pk_hypercubes ph ON mc.hypercube_id = ph.hypercube_id
                {where_clause.replace('campaign_id', 'ph.campaign_id')}
            """, params).fetchall()
        else:
            rows = conn.execute("SELECT results_npz_path FROM monte_carlo_analyses").fetchall()
        for (path,) in rows:
            if path:
                npz_paths.add(Path(path))
    except Exception:
        pass
    
    return npz_paths


def export_campaign_archive(
    db_path: Path | str,
    output_path: Path | str,
    campaign_ids: Optional[List[str]] = None,
    include_all_campaigns: bool = True,
) -> ArchiveManifest:
    """
    Export campaign(s) to a single compressed archive.
    
    Args:
        db_path: Path to source DuckDB database
        output_path: Output archive path (should end in .megadeth.tar.gz)
        campaign_ids: Specific campaigns to export (None = all)
        include_all_campaigns: If True and campaign_ids is None, export all
        
    Returns:
        ArchiveManifest describing the archive contents
        
    Raises:
        FileNotFoundError: If database or referenced NPZ files not found
        ValueError: If no campaigns found to export
    """
    db_path = Path(db_path)
    output_path = Path(output_path)
    
    if not db_path.exists():
        raise FileNotFoundError(f"Database not found: {db_path}")
    
    # Connect to database with HPC-safe settings (no extension auto-install)
    _hpc_config = {"autoinstall_known_extensions": False, "autoload_known_extensions": False}
    conn = duckdb.connect(str(db_path), read_only=True, config=_hpc_config)
    
    # Get campaign IDs if not specified
    if campaign_ids is None and include_all_campaigns:
        rows = conn.execute("SELECT campaign_id FROM campaigns").fetchall()
        campaign_ids = [row[0] for row in rows]
    
    if not campaign_ids:
        raise ValueError("No campaigns found to export")
    
    # Collect all NPZ paths
    npz_paths = _collect_npz_paths(conn, campaign_ids)
    
    # Verify all NPZ files exist
    missing = [p for p in npz_paths if not p.exists()]
    if missing:
        print(f"[Archive] Warning: {len(missing)} NPZ files not found, skipping:")
        for p in missing[:5]:
            print(f"  - {p}")
        if len(missing) > 5:
            print(f"  ... and {len(missing) - 5} more")
        npz_paths = {p for p in npz_paths if p.exists()}
    
    conn.close()
    
    # Create archive
    manifest = ArchiveManifest(
        source_db_path=str(db_path),
        campaign_ids=campaign_ids,
    )
    
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        archive_root = tmpdir / "campaign_archive"
        data_dir = archive_root / "data"
        data_dir.mkdir(parents=True)
        
        # Copy database
        db_dest = archive_root / "megadeth.duckdb"
        shutil.copy2(db_path, db_dest)
        manifest.total_size_bytes += db_dest.stat().st_size
        
        # Copy NPZ files with checksums
        for npz_path in npz_paths:
            # Use consistent naming: data/<original_filename>
            dest_name = npz_path.name
            # Handle duplicates by adding parent dir
            if (data_dir / dest_name).exists():
                dest_name = f"{npz_path.parent.name}_{dest_name}"
            
            dest_path = data_dir / dest_name
            shutil.copy2(npz_path, dest_path)
            
            rel_path = f"data/{dest_name}"
            manifest.npz_files[rel_path] = _sha256_file(dest_path)
            manifest.total_size_bytes += dest_path.stat().st_size
        
        # Write manifest
        manifest_path = archive_root / "metadata.json"
        manifest_path.write_text(manifest.to_json())
        
        # Create tar.gz archive
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with tarfile.open(output_path, "w:gz") as tar:
            tar.add(archive_root, arcname="campaign_archive")
    
    print(f"[Archive] Created: {output_path}")
    print(f"[Archive] Campaigns: {len(campaign_ids)}")
    print(f"[Archive] NPZ files: {len(manifest.npz_files)}")
    print(f"[Archive] Total size: {manifest.total_size_bytes / (1024**2):.1f} MB")
    
    return manifest


def import_campaign_archive(
    archive_path: Path | str,
    output_dir: Path | str,
    target_db_path: Optional[Path | str] = None,
    update_npz_paths: bool = True,
) -> ArchiveManifest:
    """
    Import a campaign archive.
    
    Args:
        archive_path: Path to .megadeth.tar.gz archive
        output_dir: Directory to extract files to
        target_db_path: If provided, append imported data into this existing DB
        update_npz_paths: Update NPZ paths in DB to point to extracted location
        
    Returns:
        ArchiveManifest from the imported archive
        
    Raises:
        FileNotFoundError: If archive not found
        ValueError: If archive is invalid or corrupted
    """
    archive_path = Path(archive_path)
    output_dir = Path(output_dir)
    
    if not archive_path.exists():
        raise FileNotFoundError(f"Archive not found: {archive_path}")
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Extract archive
    with tarfile.open(archive_path, "r:gz") as tar:
        tar.extractall(output_dir)
    
    archive_root = output_dir / "campaign_archive"
    
    # Load manifest
    manifest_path = archive_root / "metadata.json"
    if not manifest_path.exists():
        raise ValueError("Invalid archive: missing metadata.json")
    
    manifest = ArchiveManifest.from_json(manifest_path.read_text())
    
    # Verify checksums
    print(f"[Archive] Verifying {len(manifest.npz_files)} NPZ files...")
    for rel_path, expected_hash in manifest.npz_files.items():
        file_path = archive_root / rel_path
        if not file_path.exists():
            print(f"[Archive] Warning: Missing file {rel_path}")
            continue
        actual_hash = _sha256_file(file_path)
        if actual_hash != expected_hash:
            print(f"[Archive] Warning: Checksum mismatch for {rel_path}")
    
    # Update NPZ paths in database if requested
    imported_db_path = archive_root / "megadeth.duckdb"
    if update_npz_paths and imported_db_path.exists():
        _update_npz_paths_in_db(imported_db_path, archive_root)
    
    # Append into existing database if requested
    if target_db_path:
        target_db_path = Path(target_db_path)
        _append_database_rows(imported_db_path, target_db_path)
        print(f"[Archive] Appended into: {target_db_path}")
    
    print(f"[Archive] Imported to: {archive_root}")
    print(f"[Archive] Campaigns: {len(manifest.campaign_ids)}")
    
    return manifest


def _update_npz_paths_in_db(db_path: Path, archive_root: Path) -> None:
    """Update NPZ paths in database to point to extracted location."""
    _hpc_config = {"autoinstall_known_extensions": False, "autoload_known_extensions": False}
    conn = duckdb.connect(str(db_path), config=_hpc_config)
    data_dir = archive_root / "data"
    
    # Get all NPZ files in data directory
    npz_files = {f.name: str(f.absolute()) for f in data_dir.glob("*.npz")}
    
    # Update pk_hypercubes
    try:
        rows = conn.execute("SELECT hypercube_id, npz_path FROM pk_hypercubes").fetchall()
        for hid, old_path in rows:
            if old_path:
                filename = Path(old_path).name
                if filename in npz_files:
                    conn.execute(
                        "UPDATE pk_hypercubes SET npz_path = ? WHERE hypercube_id = ?",
                        [npz_files[filename], hid]
                    )
    except Exception as e:
        print(f"[Archive] Warning updating pk_hypercubes paths: {e}")
    
    # Update discrete_analyses
    try:
        rows = conn.execute("""
            SELECT analysis_id, system_pk_npz, reliability_npz, r2k_npz 
            FROM discrete_analyses
        """).fetchall()
        for aid, sys_path, rel_path, r2k_path in rows:
            updates = {}
            for col, old_path in [("system_pk_npz", sys_path), 
                                   ("reliability_npz", rel_path),
                                   ("r2k_npz", r2k_path)]:
                if old_path:
                    filename = Path(old_path).name
                    if filename in npz_files:
                        updates[col] = npz_files[filename]
            if updates:
                set_clause = ", ".join(f"{k} = ?" for k in updates.keys())
                conn.execute(
                    f"UPDATE discrete_analyses SET {set_clause} WHERE analysis_id = ?",
                    list(updates.values()) + [aid]
                )
    except Exception as e:
        print(f"[Archive] Warning updating discrete_analyses paths: {e}")
    
    conn.close()


def _append_database_rows(source_db: Path, target_db: Path) -> None:
    """
    Append source database rows into target database.
    
    Handles conflicts by skipping duplicates (ON CONFLICT DO NOTHING).
    """
    if not target_db.exists():
        # Just copy if target doesn't exist
        shutil.copy2(source_db, target_db)
        return
    
    _hpc_config = {"autoinstall_known_extensions": False, "autoload_known_extensions": False}
    target_conn = duckdb.connect(str(target_db), config=_hpc_config)
    
    # Attach source database
    target_conn.execute(f"ATTACH '{source_db}' AS source_db (READ_ONLY)")
    
    # Tables to append in dependency order
    tables = [
        "campaigns",
        "warheads", 
        "targets",
        "physics_runs",
        "pk_hypercubes",
        "salvo_configurations",
        "monte_carlo_analyses",
        "discrete_analyses",
        "discrete_metrics",
    ]
    
    for table in tables:
        try:
            # Get columns from source
            cols = target_conn.execute(f"""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = '{table}' AND table_schema = 'source_db'
            """).fetchall()
            if not cols:
                continue
                
            col_list = ", ".join(c[0] for c in cols)
            
            # Insert with conflict handling
            target_conn.execute(f"""
                INSERT INTO {table} ({col_list})
                SELECT {col_list} FROM source_db.{table}
                ON CONFLICT DO NOTHING
            """)
            
            count = target_conn.execute(f"SELECT changes()").fetchone()[0]
            if count > 0:
                print(f"[Archive] Appended {count} rows into {table}")
                
        except Exception as e:
            print(f"[Archive] Warning appending {table}: {e}")
    
    target_conn.execute("DETACH source_db")
    target_conn.close()


def list_archive_contents(archive_path: Path | str) -> ArchiveManifest:
    """
    List contents of an archive without extracting.
    
    Args:
        archive_path: Path to .megadeth.tar.gz archive
        
    Returns:
        ArchiveManifest describing archive contents
    """
    archive_path = Path(archive_path)
    
    with tarfile.open(archive_path, "r:gz") as tar:
        # Find and extract manifest
        manifest_member = tar.getmember("campaign_archive/metadata.json")
        f = tar.extractfile(manifest_member)
        if f is None:
            raise ValueError("Invalid archive: cannot read metadata.json")
        manifest = ArchiveManifest.from_json(f.read().decode("utf-8"))
    
    return manifest
