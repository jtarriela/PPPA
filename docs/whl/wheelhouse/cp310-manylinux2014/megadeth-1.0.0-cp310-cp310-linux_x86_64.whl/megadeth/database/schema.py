from __future__ import annotations

from pathlib import Path
from typing import Optional


# DDL adapted from Architecture_Specification.md Section 4.
# 
# MATLAB Parity (2025-12-02): Coordinate convention matches MEGADETH SalvoAnalysis03x3.m:
#   - X-axis = Deflection (crossrange) - MATLAB PkDatabase{1}
#   - Y-axis = Range (downrange) - MATLAB PkDatabase{2}
#   - miss_x_axis / x_axis_m = Deflection
#   - miss_y_axis / y_axis_m = Range
#   - fixed_bias_deflection_m = X-axis bias (MATLAB Precision col 5)
#   - fixed_bias_range_m = Y-axis bias (MATLAB Precision col 6)
#
# Migration Date: 2025-12-02
# No data migration required - column names already match MATLAB semantics.
#
SCHEMA_DDL = r"""
-- Campaign & Configuration
CREATE TABLE IF NOT EXISTS campaigns (
    campaign_id VARCHAR PRIMARY KEY,
    name VARCHAR NOT NULL,
    description TEXT,
    config_yaml TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    status VARCHAR DEFAULT 'running',
    platform VARCHAR,
    hostname VARCHAR,
    cpu_count INTEGER,
    memory_gb DOUBLE,
    total_physics_evals BIGINT,
    total_runtime_sec DOUBLE
);

-- Warhead & Target Definitions
CREATE TABLE IF NOT EXISTS warheads (
    warhead_id INTEGER PRIMARY KEY,
    warhead_name VARCHAR NOT NULL UNIQUE,
    zdata_number INTEGER NOT NULL,
    zdata_path VARCHAR,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS targets (
    target_id INTEGER PRIMARY KEY,
    target_name VARCHAR NOT NULL UNIQUE,
    rcas_number INTEGER NOT NULL,
    centroid_height_ft DOUBLE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Physics Runs (Individual FullSpray Evaluations)
-- MATLAB Parity: miss_deflection_m = X-axis, miss_range_m = Y-axis
CREATE TABLE IF NOT EXISTS physics_runs (
    run_id UUID PRIMARY KEY,
    campaign_id VARCHAR REFERENCES campaigns(campaign_id),
    warhead_id INTEGER REFERENCES warheads(warhead_id),
    target_id INTEGER REFERENCES targets(target_id),
    hob_m DOUBLE NOT NULL,
    velocity_mps DOUBLE NOT NULL,
    aof_deg DOUBLE NOT NULL,
    miss_deflection_m DOUBLE NOT NULL,  -- X-axis (crossrange) - MATLAB convention
    miss_range_m DOUBLE NOT NULL,        -- Y-axis (downrange) - MATLAB convention
    pk_theoretical DOUBLE,
    solver_runtime_ms INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- LAM2 Grid Data (Per-Run Pk Maps)
-- MATLAB Parity: x_axis_m = Deflection (PkDatabase{1}), y_axis_m = Range (PkDatabase{2})
CREATE TABLE IF NOT EXISTS lam2_grids (
    grid_id UUID PRIMARY KEY,
    run_id UUID REFERENCES physics_runs(run_id),
    pbh_ft DOUBLE,
    omega_deg DOUBLE,
    velm_fps DOUBLE,
    zdata INTEGER,
    rcas INTEGER,
    x_axis_m DOUBLE[],   -- Deflection axis (crossrange) - MATLAB PkDatabase{1}
    y_axis_m DOUBLE[],   -- Range axis (downrange) - MATLAB PkDatabase{2}
    pk_values DOUBLE[],
    n_x INTEGER,         -- Number of deflection points
    n_y INTEGER,         -- Number of range points
    origin_offset_m DOUBLE,
    cell_size_m DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5D Hypercube Storage
-- MATLAB Parity: miss_x_axis = Deflection (PkDatabase{1}), miss_y_axis = Range (PkDatabase{2})
CREATE TABLE IF NOT EXISTS pk_hypercubes (
    hypercube_id UUID PRIMARY KEY,
    campaign_id VARCHAR REFERENCES campaigns(campaign_id),
    warhead_id INTEGER REFERENCES warheads(warhead_id),
    target_id INTEGER REFERENCES targets(target_id),
    hob_axis DOUBLE[],
    velocity_axis DOUBLE[],
    aof_axis DOUBLE[],
    miss_x_axis DOUBLE[],  -- Deflection axis (crossrange) - MATLAB PkDatabase{1}
    miss_y_axis DOUBLE[],  -- Range axis (downrange) - MATLAB PkDatabase{2}
    n_hob INTEGER,
    n_vel INTEGER,
    n_aof INTEGER,
    n_miss_x INTEGER,      -- Number of deflection points
    n_miss_y INTEGER,      -- Number of range points
    npz_path VARCHAR,
    npz_checksum VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Salvo Configurations
CREATE TABLE IF NOT EXISTS salvo_configurations (
    salvo_config_id UUID PRIMARY KEY,
    name VARCHAR NOT NULL UNIQUE,
    description TEXT,
    shots_per_salvo INTEGER NOT NULL DEFAULT 1,
    bias_pattern JSON,
    fixed_bias_deflection_m DOUBLE DEFAULT 0,
    fixed_bias_range_m DOUBLE DEFAULT 0,
    tle_radii_m DOUBLE[],
    tle_fractions DOUBLE[],
    cep_radii_m DOUBLE[],
    cep_fractions DOUBLE[],
    fixed_bias_axes_m DOUBLE[],
    variable_bias_radii_m DOUBLE[],
    variable_bias_fractions DOUBLE[],
    matlab_parity_sampling BOOLEAN DEFAULT FALSE,
    parity_plot_style BOOLEAN DEFAULT FALSE,
    coordinate_frame VARCHAR DEFAULT 'weapon',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Monte Carlo Analysis Results (MEGADETH Parity)
-- MATLAB Parity (2025-12-02): fixed_bias_deflection_m = X-axis (col 5), fixed_bias_range_m = Y-axis (col 6)
CREATE TABLE IF NOT EXISTS monte_carlo_analyses (
    analysis_id UUID PRIMARY KEY,
    hypercube_id UUID REFERENCES pk_hypercubes(hypercube_id),
    
    -- Sampling configuration
    n_salvos INTEGER,
    n_shots INTEGER,
    random_seed BIGINT,
    
    -- Precision configuration (4-source error model)
    -- MATLAB Parity: Deflection=X-axis (col 5), Range=Y-axis (col 6)
    precision_label VARCHAR,
    tle_radius_m DOUBLE,
    tle_fraction DOUBLE DEFAULT 0.90,
    cep_radius_m DOUBLE,
    cep_fraction DOUBLE DEFAULT 0.50,
    fixed_bias_deflection_m DOUBLE DEFAULT 0,  -- X-axis (crossrange) - MATLAB col 5
    fixed_bias_range_m DOUBLE DEFAULT 0,        -- Y-axis (downrange) - MATLAB col 6
    variable_bias_radius_m DOUBLE DEFAULT 0,
    variable_bias_fraction DOUBLE DEFAULT 0.50,
    
    -- Lethality thresholds
    pk_thresholds DOUBLE[],
    
    -- Summary statistics
    mean_single_shot_pk DOUBLE,
    mean_salvo_pk DOUBLE,
    
    -- Legacy fields (backwards compatibility)
    salvo_config_id UUID REFERENCES salvo_configurations(salvo_config_id),
    analysis_source VARCHAR,
    tle_sigma_m DOUBLE,
    cep_sigma_m DOUBLE,
    variable_bias_sigma_m DOUBLE DEFAULT 0,
    -- fixed_bias columns already defined above in precision configuration
    tle_radii_m DOUBLE[],
    tle_fractions DOUBLE[],
    cep_radii_m DOUBLE[],
    cep_fractions DOUBLE[],
    fixed_bias_axes_m DOUBLE[],
    variable_bias_radii_m DOUBLE[],
    variable_bias_fractions DOUBLE[],
    terminal_condition_labels TEXT[],
    pk_by_terminal_condition JSON,
    accumulated_pk_by_terminal_condition JSON,
    matlab_parity_sampling BOOLEAN DEFAULT FALSE,
    coordinate_frame VARCHAR DEFAULT 'weapon',
    sigma_combined_m DOUBLE,
    tle_z_sigma_m DOUBLE DEFAULT 0,
    cep_z_sigma_m DOUBLE DEFAULT 0,
    n_mc_samples INTEGER,
    n_salvos_simulated INTEGER DEFAULT 1,
    single_shot_pk_mean DOUBLE,
    single_shot_pk_std DOUBLE,
    single_shot_pk_median DOUBLE,
    single_shot_pk_ci_lower DOUBLE,
    single_shot_pk_ci_upper DOUBLE,
    single_shot_pk_p10 DOUBLE,
    single_shot_pk_p90 DOUBLE,
    per_shot_pk_values JSON,
    accumulated_pk_mean DOUBLE,
    accumulated_pk_std DOUBLE,
    accumulated_pk_median DOUBLE,
    accumulated_pk_ci_lower DOUBLE,
    accumulated_pk_ci_upper DOUBLE,
    accumulated_pk_by_round JSON,
    rounds_to_pk90 DOUBLE,
    rounds_to_pk95 DOUBLE,
    accumulated_pk_by_round_by_terminal_condition JSON,
    rounds_to_pk90_by_terminal_condition JSON,
    rounds_to_pk95_by_terminal_condition JSON,
    rounds_to_kill_grid_npz VARCHAR,
    rounds_to_kill_grid_checksum VARCHAR,
    rounds_to_kill_pk_threshold DOUBLE,
    rounds_to_kill_max_rounds INTEGER,
    result_npz VARCHAR,                   -- NPZ path containing MC result arrays
    result_npz_checksum VARCHAR,          -- SHA256 checksum
    draws_npz VARCHAR,                    -- NPZ path containing raw aimpoint/dispersion draws
    draws_npz_checksum VARCHAR,           -- SHA256 checksum
    runtime_sec DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Discrete Grid Analysis Results
CREATE TABLE IF NOT EXISTS discrete_analyses (
    analysis_id UUID PRIMARY KEY,
    hypercube_id UUID REFERENCES pk_hypercubes(hypercube_id),
    guidance_model_type VARCHAR,
    cep50_radius_m DOUBLE,
    tle90_radius_m DOUBLE,
    sigma_guid_m DOUBLE,
    sigma_hob_m DOUBLE,
    sigma_velocity_mps DOUBLE,
    sigma_aof_deg DOUBLE,
    kernel_width_sigma DOUBLE,
    pk_threshold DOUBLE,
    gradient_threshold DOUBLE,
    system_pk_npz VARCHAR,
    reliability_npz VARCHAR,
    sensitivity_npz VARCHAR,
    failure_prob_npz VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Discrete Metrics (Scalar Results)
CREATE TABLE IF NOT EXISTS discrete_metrics (
    metric_id UUID PRIMARY KEY,
    analysis_id UUID REFERENCES discrete_analyses(analysis_id),
    envelope_volume DOUBLE,
    integrated_kill_potential DOUBLE,
    robust_volume DOUBLE,
    effective_volume DOUBLE,
    envelope_cell_count INTEGER,
    robust_cell_count INTEGER,
    total_cells INTEGER,
    pk_sys_min DOUBLE,
    pk_sys_max DOUBLE,
    pk_sys_mean DOUBLE,
    pk_sys_std DOUBLE,
    reliability_min DOUBLE,
    reliability_max DOUBLE,
    reliability_mean DOUBLE,
    p_fail_median DOUBLE,
    p_fail_p90 DOUBLE,
    p_fail_p99 DOUBLE,
    gradient_max DOUBLE,
    gradient_mean DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


def _connect(db_path: Path, read_only: bool = False):
    """Connect to DuckDB with HPC-safe settings (no network access)."""
    try:
        import duckdb  # type: ignore
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise RuntimeError(
            "duckdb is required for database operations. "
            "Install it with `pip install duckdb`."
        ) from exc
    
    # Create connection with HPC-safe config (no network access for extensions)
    config = {
        "autoinstall_known_extensions": False,
        "autoload_known_extensions": False,
    }
    conn = duckdb.connect(str(db_path), read_only=read_only, config=config)
    return conn


def initialize_database(db_path: Path, ddl: str = SCHEMA_DDL):
    """
    Create the DuckDB database and apply schema DDL.

    Returns an open duckdb connection.
    """
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = _connect(db_path)
    conn.execute(ddl)
    return conn
