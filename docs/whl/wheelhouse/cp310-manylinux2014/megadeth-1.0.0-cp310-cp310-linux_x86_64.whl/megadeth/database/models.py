from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple


def _uuid_str() -> str:
    return str(uuid.uuid4())


@dataclass
class CampaignRecord:
    """Minimal campaign metadata for persistence."""

    campaign_id: str
    name: str
    description: Optional[str] = None
    config_yaml: Optional[str] = None
    status: str = "running"
    platform: Optional[str] = None
    hostname: Optional[str] = None
    cpu_count: Optional[int] = None
    memory_gb: Optional[float] = None
    total_physics_evals: Optional[int] = None
    total_runtime_sec: Optional[float] = None
    completed_at: Optional[str] = None

    columns: Tuple[str, ...] = (
        "campaign_id",
        "name",
        "description",
        "config_yaml",
        "status",
        "platform",
        "hostname",
        "cpu_count",
        "memory_gb",
        "total_physics_evals",
        "total_runtime_sec",
        "completed_at",
    )

    def as_tuple(self):
        return (
            self.campaign_id,
            self.name,
            self.description,
            self.config_yaml,
            self.status,
            self.platform,
            self.hostname,
            self.cpu_count,
            self.memory_gb,
            self.total_physics_evals,
            self.total_runtime_sec,
            self.completed_at,
        )


@dataclass
class WarheadRecord:
    """Warhead definition for metadata table."""

    warhead_id: int
    warhead_name: str
    zdata_number: int
    zdata_path: Optional[str] = None
    description: Optional[str] = None

    columns: Tuple[str, ...] = (
        "warhead_id",
        "warhead_name",
        "zdata_number",
        "zdata_path",
        "description",
    )

    def as_tuple(self):
        return (
            self.warhead_id,
            self.warhead_name,
            self.zdata_number,
            self.zdata_path,
            self.description,
        )


@dataclass
class TargetRecord:
    """Target definition for metadata table."""

    target_id: int
    target_name: str
    rcas_number: int
    centroid_height_ft: Optional[float] = None
    description: Optional[str] = None

    columns: Tuple[str, ...] = (
        "target_id",
        "target_name",
        "rcas_number",
        "centroid_height_ft",
        "description",
    )

    def as_tuple(self):
        return (
            self.target_id,
            self.target_name,
            self.rcas_number,
            self.centroid_height_ft,
            self.description,
        )


@dataclass
class PhysicsRunRecord:
    """Row for physics_runs table."""

    campaign_id: str
    warhead_id: int
    target_id: int
    hob_m: float
    velocity_mps: float
    aof_deg: float
    miss_deflection_m: float
    miss_range_m: float
    pk_theoretical: Optional[float] = None
    solver_runtime_ms: Optional[int] = None
    run_id: str = field(default_factory=_uuid_str)

    columns: Tuple[str, ...] = (
        "run_id",
        "campaign_id",
        "warhead_id",
        "target_id",
        "hob_m",
        "velocity_mps",
        "aof_deg",
        "miss_deflection_m",
        "miss_range_m",
        "pk_theoretical",
        "solver_runtime_ms",
    )

    def as_tuple(self):
        return (
            self.run_id,
            self.campaign_id,
            self.warhead_id,
            self.target_id,
            self.hob_m,
            self.velocity_mps,
            self.aof_deg,
            self.miss_deflection_m,
            self.miss_range_m,
            self.pk_theoretical,
            self.solver_runtime_ms,
        )


@dataclass
class LAM2GridRecord:
    """Row for lam2_grids table with flattened Pk grid."""

    run_id: str
    pbh_ft: float
    omega_deg: float
    velm_fps: float
    zdata: int
    rcas: int
    x_axis_m: Sequence[float]
    y_axis_m: Sequence[float]
    pk_values: Sequence[float]
    n_x: int
    n_y: int
    origin_offset_m: Optional[float] = None
    cell_size_m: Optional[float] = None
    grid_id: str = field(default_factory=_uuid_str)

    columns: Tuple[str, ...] = (
        "grid_id",
        "run_id",
        "pbh_ft",
        "omega_deg",
        "velm_fps",
        "zdata",
        "rcas",
        "x_axis_m",
        "y_axis_m",
        "pk_values",
        "n_x",
        "n_y",
        "origin_offset_m",
        "cell_size_m",
    )

    def as_tuple(self):
        return (
            self.grid_id,
            self.run_id,
            self.pbh_ft,
            self.omega_deg,
            self.velm_fps,
            self.zdata,
            self.rcas,
            list(self.x_axis_m),
            list(self.y_axis_m),
            list(self.pk_values),
            self.n_x,
            self.n_y,
            self.origin_offset_m,
            self.cell_size_m,
        )


@dataclass
class HypercubeRecord:
    """Row for pk_hypercubes table storing NPZ reference and axes."""

    campaign_id: str
    warhead_id: int
    target_id: int
    hob_axis: Sequence[float]
    velocity_axis: Sequence[float]
    aof_axis: Sequence[float]
    miss_x_axis: Sequence[float]
    miss_y_axis: Sequence[float]
    npz_path: str
    npz_checksum: str
    hypercube_id: str = field(default_factory=_uuid_str)

    columns: Tuple[str, ...] = (
        "hypercube_id",
        "campaign_id",
        "warhead_id",
        "target_id",
        "hob_axis",
        "velocity_axis",
        "aof_axis",
        "miss_x_axis",
        "miss_y_axis",
        "n_hob",
        "n_vel",
        "n_aof",
        "n_miss_x",
        "n_miss_y",
        "npz_path",
        "npz_checksum",
    )

    def as_tuple(self):
        return (
            self.hypercube_id,
            self.campaign_id,
            self.warhead_id,
            self.target_id,
            list(self.hob_axis),
            list(self.velocity_axis),
            list(self.aof_axis),
            list(self.miss_x_axis),
            list(self.miss_y_axis),
            len(self.hob_axis),
            len(self.velocity_axis),
            len(self.aof_axis),
            len(self.miss_x_axis),
            len(self.miss_y_axis),
            self.npz_path,
            self.npz_checksum,
        )


@dataclass
class MonteCarloAnalysisRecord:
    """Record for Monte Carlo analysis metadata and rounds-to-kill outputs."""

    hypercube_id: str

    # Sampling configuration
    n_salvos: Optional[int] = None
    n_shots: Optional[int] = None
    random_seed: Optional[int] = None

    # Precision configuration (4-source model)
    precision_label: Optional[str] = None
    tle_radius_m: Optional[float] = None
    tle_fraction: Optional[float] = None
    cep_radius_m: Optional[float] = None
    cep_fraction: Optional[float] = None
    fixed_bias_deflection_m: Optional[float] = None
    fixed_bias_range_m: Optional[float] = None
    variable_bias_radius_m: Optional[float] = None
    variable_bias_fraction: Optional[float] = None

    # Lethality thresholds
    pk_thresholds: Optional[Sequence[float]] = None

    # Summary statistics
    mean_single_shot_pk: Optional[float] = None
    mean_salvo_pk: Optional[float] = None

    # Legacy fields (for backwards compatibility)
    salvo_config_id: Optional[str] = None
    analysis_source: Optional[str] = None

    # Guidance model derived sigmas
    tle_sigma_m: Optional[float] = None
    cep_sigma_m: Optional[float] = None
    variable_bias_sigma_m: Optional[float] = None
    
    # Array-based legacy fields
    tle_radii_m: Optional[List[float]] = None
    tle_fractions: Optional[List[float]] = None
    cep_radii_m: Optional[List[float]] = None
    cep_fractions: Optional[List[float]] = None
    fixed_bias_axes_m: Optional[List[float]] = None
    variable_bias_radii_m: Optional[List[float]] = None
    variable_bias_fractions: Optional[List[float]] = None
    matlab_parity_sampling: Optional[bool] = None
    coordinate_frame: Optional[str] = None
    sigma_combined_m: Optional[float] = None
    tle_z_sigma_m: Optional[float] = None
    cep_z_sigma_m: Optional[float] = None

    # Execution metadata
    n_mc_samples: Optional[int] = None
    n_salvos_simulated: Optional[int] = None
    runtime_sec: Optional[float] = None

    # Results
    terminal_condition_labels: Optional[List[str]] = None
    pk_by_terminal_condition: Optional[object] = None
    accumulated_pk_by_terminal_condition: Optional[object] = None
    single_shot_pk_mean: Optional[float] = None
    single_shot_pk_std: Optional[float] = None
    single_shot_pk_median: Optional[float] = None
    single_shot_pk_ci_lower: Optional[float] = None
    single_shot_pk_ci_upper: Optional[float] = None
    single_shot_pk_p10: Optional[float] = None
    single_shot_pk_p90: Optional[float] = None
    per_shot_pk_values: Optional[object] = None
    accumulated_pk_mean: Optional[float] = None
    accumulated_pk_std: Optional[float] = None
    accumulated_pk_median: Optional[float] = None
    accumulated_pk_ci_lower: Optional[float] = None
    accumulated_pk_ci_upper: Optional[float] = None
    accumulated_pk_by_round: Optional[object] = None
    rounds_to_pk90: Optional[float] = None
    rounds_to_pk95: Optional[float] = None
    accumulated_pk_by_round_by_terminal_condition: Optional[object] = None
    rounds_to_pk90_by_terminal_condition: Optional[object] = None
    rounds_to_pk95_by_terminal_condition: Optional[object] = None

    # Rounds-to-kill grid assets
    rounds_to_kill_grid_npz: Optional[str] = None
    rounds_to_kill_grid_checksum: Optional[str] = None
    rounds_to_kill_pk_threshold: Optional[float] = None
    rounds_to_kill_max_rounds: Optional[int] = None

    # MC result NPZ artifact (contains accumulated_pk, r2k, etc.)
    result_npz: Optional[str] = None
    result_npz_checksum: Optional[str] = None
    
    # MC draw NPZ artifact (contains aimpoint_offsets, dispersion_offsets)
    draws_npz: Optional[str] = None
    draws_npz_checksum: Optional[str] = None

    analysis_id: str = field(default_factory=_uuid_str)

    columns: Tuple[str, ...] = (
        "analysis_id",
        "hypercube_id",
        "n_salvos",
        "n_shots",
        "random_seed",
        "precision_label",
        "tle_radius_m",
        "tle_fraction",
        "cep_radius_m",
        "cep_fraction",
        "fixed_bias_deflection_m",
        "fixed_bias_range_m",
        "variable_bias_radius_m",
        "variable_bias_fraction",
        "pk_thresholds",
        "mean_single_shot_pk",
        "mean_salvo_pk",
        "salvo_config_id",
        "analysis_source",
        "tle_sigma_m",
        "cep_sigma_m",
        "variable_bias_sigma_m",
        "tle_radii_m",
        "tle_fractions",
        "cep_radii_m",
        "cep_fractions",
        "fixed_bias_axes_m",
        "variable_bias_radii_m",
        "variable_bias_fractions",
        "terminal_condition_labels",
        "pk_by_terminal_condition",
        "accumulated_pk_by_terminal_condition",
        "matlab_parity_sampling",
        "coordinate_frame",
        "sigma_combined_m",
        "tle_z_sigma_m",
        "cep_z_sigma_m",
        "n_mc_samples",
        "n_salvos_simulated",
        "single_shot_pk_mean",
        "single_shot_pk_std",
        "single_shot_pk_median",
        "single_shot_pk_ci_lower",
        "single_shot_pk_ci_upper",
        "single_shot_pk_p10",
        "single_shot_pk_p90",
        "per_shot_pk_values",
        "accumulated_pk_mean",
        "accumulated_pk_std",
        "accumulated_pk_median",
        "accumulated_pk_ci_lower",
        "accumulated_pk_ci_upper",
        "accumulated_pk_by_round",
        "rounds_to_pk90",
        "rounds_to_pk95",
        "accumulated_pk_by_round_by_terminal_condition",
        "rounds_to_pk90_by_terminal_condition",
        "rounds_to_pk95_by_terminal_condition",
        "rounds_to_kill_grid_npz",
        "rounds_to_kill_grid_checksum",
        "rounds_to_kill_pk_threshold",
        "rounds_to_kill_max_rounds",
        "result_npz",
        "result_npz_checksum",
        "draws_npz",
        "draws_npz_checksum",
        "runtime_sec",
    )

    def as_tuple(self):
        return (
            self.analysis_id,
            self.hypercube_id,
            self.n_salvos,
            self.n_shots,
            self.random_seed,
            self.precision_label,
            self.tle_radius_m,
            self.tle_fraction,
            self.cep_radius_m,
            self.cep_fraction,
            self.fixed_bias_deflection_m,
            self.fixed_bias_range_m,
            self.variable_bias_radius_m,
            self.variable_bias_fraction,
            list(self.pk_thresholds) if self.pk_thresholds else None,
            self.mean_single_shot_pk,
            self.mean_salvo_pk,
            self.salvo_config_id,
            self.analysis_source,
            self.tle_sigma_m,
            self.cep_sigma_m,
            self.variable_bias_sigma_m,
            self.tle_radii_m,
            self.tle_fractions,
            self.cep_radii_m,
            self.cep_fractions,
            self.fixed_bias_axes_m,
            self.variable_bias_radii_m,
            self.variable_bias_fractions,
            self.terminal_condition_labels,
            self.pk_by_terminal_condition,
            self.accumulated_pk_by_terminal_condition,
            self.matlab_parity_sampling,
            self.coordinate_frame,
            self.sigma_combined_m,
            self.tle_z_sigma_m,
            self.cep_z_sigma_m,
            self.n_mc_samples,
            self.n_salvos_simulated,
            self.single_shot_pk_mean,
            self.single_shot_pk_std,
            self.single_shot_pk_median,
            self.single_shot_pk_ci_lower,
            self.single_shot_pk_ci_upper,
            self.single_shot_pk_p10,
            self.single_shot_pk_p90,
            self.per_shot_pk_values,
            self.accumulated_pk_mean,
            self.accumulated_pk_std,
            self.accumulated_pk_median,
            self.accumulated_pk_ci_lower,
            self.accumulated_pk_ci_upper,
            self.accumulated_pk_by_round,
            self.rounds_to_pk90,
            self.rounds_to_pk95,
            self.accumulated_pk_by_round_by_terminal_condition,
            self.rounds_to_pk90_by_terminal_condition,
            self.rounds_to_pk95_by_terminal_condition,
            self.rounds_to_kill_grid_npz,
            self.rounds_to_kill_grid_checksum,
            self.rounds_to_kill_pk_threshold,
            self.rounds_to_kill_max_rounds,
            self.result_npz,
            self.result_npz_checksum,
            self.draws_npz,
            self.draws_npz_checksum,
            self.runtime_sec,
        )


@dataclass
class DiscreteAnalysisRecord:
    """Row for discrete_analyses table."""

    analysis_id: str
    hypercube_id: str
    guidance_model_type: Optional[str] = None
    cep50_radius_m: Optional[float] = None
    tle90_radius_m: Optional[float] = None
    sigma_guid_m: Optional[float] = None
    sigma_hob_m: Optional[float] = None
    sigma_velocity_mps: Optional[float] = None
    sigma_aof_deg: Optional[float] = None
    kernel_width_sigma: Optional[float] = None
    pk_threshold: Optional[float] = None
    gradient_threshold: Optional[float] = None
    system_pk_npz: Optional[str] = None
    reliability_npz: Optional[str] = None
    sensitivity_npz: Optional[str] = None
    failure_prob_npz: Optional[str] = None

    columns: Tuple[str, ...] = (
        "analysis_id",
        "hypercube_id",
        "guidance_model_type",
        "cep50_radius_m",
        "tle90_radius_m",
        "sigma_guid_m",
        "sigma_hob_m",
        "sigma_velocity_mps",
        "sigma_aof_deg",
        "kernel_width_sigma",
        "pk_threshold",
        "gradient_threshold",
        "system_pk_npz",
        "reliability_npz",
        "sensitivity_npz",
        "failure_prob_npz",
    )

    def as_tuple(self):
        return (
            self.analysis_id,
            self.hypercube_id,
            self.guidance_model_type,
            self.cep50_radius_m,
            self.tle90_radius_m,
            self.sigma_guid_m,
            self.sigma_hob_m,
            self.sigma_velocity_mps,
            self.sigma_aof_deg,
            self.kernel_width_sigma,
            self.pk_threshold,
            self.gradient_threshold,
            self.system_pk_npz,
            self.reliability_npz,
            self.sensitivity_npz,
            self.failure_prob_npz,
        )


@dataclass
class DiscreteMetricsRecord:
    """Row for discrete_metrics table."""

    analysis_id: str
    envelope_volume: float
    integrated_kill_potential: float
    robust_volume: float
    effective_volume: float
    envelope_cell_count: int
    robust_cell_count: int
    total_cells: int
    pk_sys_min: float
    pk_sys_max: float
    pk_sys_mean: float
    pk_sys_std: float
    reliability_min: float
    reliability_max: float
    reliability_mean: float
    p_fail_median: float
    p_fail_p90: float
    p_fail_p99: float
    gradient_max: float
    gradient_mean: float
    metric_id: str = field(default_factory=_uuid_str)

    columns: Tuple[str, ...] = (
        "metric_id",
        "analysis_id",
        "envelope_volume",
        "integrated_kill_potential",
        "robust_volume",
        "effective_volume",
        "envelope_cell_count",
        "robust_cell_count",
        "total_cells",
        "pk_sys_min",
        "pk_sys_max",
        "pk_sys_mean",
        "pk_sys_std",
        "reliability_min",
        "reliability_max",
        "reliability_mean",
        "p_fail_median",
        "p_fail_p90",
        "p_fail_p99",
        "gradient_max",
        "gradient_mean",
    )

    def as_tuple(self):
        return (
            self.metric_id,
            self.analysis_id,
            self.envelope_volume,
            self.integrated_kill_potential,
            self.robust_volume,
            self.effective_volume,
            self.envelope_cell_count,
            self.robust_cell_count,
            self.total_cells,
            self.pk_sys_min,
            self.pk_sys_max,
            self.pk_sys_mean,
            self.pk_sys_std,
            self.reliability_min,
            self.reliability_max,
            self.reliability_mean,
            self.p_fail_median,
            self.p_fail_p90,
            self.p_fail_p99,
            self.gradient_max,
            self.gradient_mean,
        )
