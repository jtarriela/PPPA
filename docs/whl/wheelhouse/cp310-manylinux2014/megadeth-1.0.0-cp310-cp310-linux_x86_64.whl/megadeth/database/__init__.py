"""DuckDB schema and writer utilities."""

from .schema import SCHEMA_DDL, initialize_database
from .models import (
    CampaignRecord,
    HypercubeRecord,
    LAM2GridRecord,
    MonteCarloAnalysisRecord,
    PhysicsRunRecord,
    TargetRecord,
    DiscreteAnalysisRecord,
    DiscreteMetricsRecord,
    WarheadRecord,
)
from .writer import BatchedDBWriter
from .archive import (
    export_campaign_archive,
    import_campaign_archive,
    list_archive_contents,
    ArchiveManifest,
)

__all__ = [
    "SCHEMA_DDL",
    "initialize_database",
    "CampaignRecord",
    "PhysicsRunRecord",
    "LAM2GridRecord",
    "HypercubeRecord",
    "MonteCarloAnalysisRecord",
    "DiscreteAnalysisRecord",
    "DiscreteMetricsRecord",
    "TargetRecord",
    "WarheadRecord",
    "BatchedDBWriter",
    # Archive utilities
    "export_campaign_archive",
    "import_campaign_archive",
    "list_archive_contents",
    "ArchiveManifest",
]
