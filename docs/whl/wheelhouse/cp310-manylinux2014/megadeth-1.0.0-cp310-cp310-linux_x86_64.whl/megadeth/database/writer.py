from __future__ import annotations

import queue
import threading
from pathlib import Path
from typing import Iterable, List, Optional, Sequence

import pandas as pd
from duckdb import DuckDBPyConnection

from megadeth.database.models import (
    CampaignRecord,
    HypercubeRecord,
    LAM2GridRecord,
    MonteCarloAnalysisRecord,
    PhysicsRunRecord,
    TargetRecord,
    DiscreteMetricsRecord,
    DiscreteAnalysisRecord,
    WarheadRecord,
)
from megadeth.database.schema import initialize_database


def _ensure_duckdb_connection(db_path: Path):
    try:
        import duckdb  # type: ignore
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise RuntimeError(
            "duckdb is required for database operations. "
            "Install it with `pip install duckdb`."
        ) from exc
    return initialize_database(db_path)


class BatchedDBWriter:
    """High-throughput batched database writer with optional async flush."""

    def __init__(self, db_path: Path, batch_size: int = 2000, async_flush: bool = True):
        self.db_path = Path(db_path)
        self.conn: DuckDBPyConnection = _ensure_duckdb_connection(self.db_path)
        self.batch_size = batch_size
        self.async_flush = async_flush

        self._campaign_buffer: List[CampaignRecord] = []
        self._warhead_buffer: List[WarheadRecord] = []
        self._target_buffer: List[TargetRecord] = []
        self._physics_buffer: List[PhysicsRunRecord] = []
        self._lam2_buffer: List[LAM2GridRecord] = []
        self._hypercube_buffer: List[HypercubeRecord] = []
        self._mc_buffer: List[MonteCarloAnalysisRecord] = []
        self._discrete_metrics_buffer: List["DiscreteMetricsRecord"] = []
        self._discrete_analysis_buffer: List["DiscreteAnalysisRecord"] = []

        self._queue: Optional[queue.Queue] = None
        self._writer_thread: Optional[threading.Thread] = None
        if async_flush:
            self._queue = queue.Queue()
            self._writer_thread = threading.Thread(
                target=self._async_writer, daemon=True
            )
            self._writer_thread.start()

    # ──────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────
    def add_campaign(self, record: CampaignRecord):
        self._campaign_buffer.append(record)
        if len(self._campaign_buffer) >= self.batch_size:
            self._flush_campaigns()

    def add_warhead(self, record: WarheadRecord):
        self._warhead_buffer.append(record)
        if len(self._warhead_buffer) >= self.batch_size:
            self._flush_warheads()

    def add_target(self, record: TargetRecord):
        self._target_buffer.append(record)
        if len(self._target_buffer) >= self.batch_size:
            self._flush_targets()

    def add_physics_run(self, record: PhysicsRunRecord):
        self._physics_buffer.append(record)
        if len(self._physics_buffer) >= self.batch_size:
            self._flush_physics()

    def add_lam2_grid(self, record: LAM2GridRecord):
        self._lam2_buffer.append(record)
        if len(self._lam2_buffer) >= self.batch_size:
            self._flush_lam2()

    def add_hypercube(self, record: HypercubeRecord):
        self._hypercube_buffer.append(record)
        if len(self._hypercube_buffer) >= self.batch_size:
            self._flush_hypercubes()

    def add_monte_carlo(self, record: MonteCarloAnalysisRecord):
        self._mc_buffer.append(record)
        if len(self._mc_buffer) >= self.batch_size:
            self._flush_mc()

    def add_discrete_metrics(self, record: "DiscreteMetricsRecord"):
        self._discrete_metrics_buffer.append(record)
        if len(self._discrete_metrics_buffer) >= self.batch_size:
            self._flush_discrete_metrics()

    def add_discrete_analysis(self, record: "DiscreteAnalysisRecord"):
        self._discrete_analysis_buffer.append(record)
        if len(self._discrete_analysis_buffer) >= self.batch_size:
            self._flush_discrete_analysis()

    def flush(self):
        """Flush all pending buffers synchronously. Returns counts dict."""
        return {
            "campaigns": self._flush_campaigns(force=True),
            "warheads": self._flush_warheads(force=True),
            "targets": self._flush_targets(force=True),
            "physics": self._flush_physics(force=True),
            "lam2": self._flush_lam2(force=True),
            "hypercubes": self._flush_hypercubes(force=True),
            "mc": self._flush_mc(force=True),
            "discrete_analysis": self._flush_discrete_analysis(force=True),
            "discrete_metrics": self._flush_discrete_metrics(force=True),
        }

    def close(self):
        self.flush()
        if self._queue is not None:
            self._queue.put(None)
        if self._writer_thread is not None:
            self._writer_thread.join()
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    # ──────────────────────────────────────────────────────────
    # Internal flushing
    # ──────────────────────────────────────────────────────────
    def _async_writer(self):
        assert self._queue is not None
        while True:
            item = self._queue.get()
            if item is None:
                break
            fn, records = item
            fn(records)

    def _enqueue_or_run(self, fn, records: Sequence):
        if not records:
            return
        if self._queue is not None:
            self._queue.put((fn, records))
        else:
            fn(records)

    def _make_df(self, rows, columns):
        return pd.DataFrame(rows, columns=columns)

    def _insert_df(self, table: str, df, columns: Optional[Sequence[str]] = None):
        if columns is None:
            columns = df.columns
        col_list = ", ".join(columns)
        view_name = f"df_temp_{table}"
        self.conn.register(view_name, df)
        self.conn.execute("BEGIN")
        on_conflict = ""
        if table in ("warheads", "targets"):
            on_conflict = " ON CONFLICT DO NOTHING"
        self.conn.execute(f"INSERT INTO {table} ({col_list}) SELECT {col_list} FROM {view_name}{on_conflict}")
        self.conn.execute("END TRANSACTION")
        self.conn.unregister(view_name)

    def _flush_campaigns(self, force: bool = False) -> int:
        if not self._campaign_buffer:
            return 0
        if len(self._campaign_buffer) < self.batch_size and not force:
            return 0
        batch = self._campaign_buffer[:]
        self._campaign_buffer.clear()
        self._enqueue_or_run(self._write_campaign_batch, batch)
        return len(batch)

    def _flush_physics(self, force: bool = False) -> int:
        if not self._physics_buffer:
            return 0
        if len(self._physics_buffer) < self.batch_size and not force:
            return 0
        batch = self._physics_buffer[:]
        self._physics_buffer.clear()
        self._enqueue_or_run(self._write_physics_batch, batch)
        return len(batch)

    def _flush_lam2(self, force: bool = False) -> int:
        if not self._lam2_buffer:
            return 0
        if len(self._lam2_buffer) < self.batch_size and not force:
            return 0
        batch = self._lam2_buffer[:]
        self._lam2_buffer.clear()
        self._enqueue_or_run(self._write_lam2_batch, batch)
        return len(batch)

    def _flush_hypercubes(self, force: bool = False) -> int:
        if not self._hypercube_buffer:
            return 0
        if len(self._hypercube_buffer) < self.batch_size and not force:
            return 0
        batch = self._hypercube_buffer[:]
        self._hypercube_buffer.clear()
        self._enqueue_or_run(self._write_hypercube_batch, batch)
        return len(batch)

    def _flush_warheads(self, force: bool = False) -> int:
        if not self._warhead_buffer:
            return 0
        if len(self._warhead_buffer) < self.batch_size and not force:
            return 0
        batch = self._warhead_buffer[:]
        self._warhead_buffer.clear()
        self._enqueue_or_run(self._write_warhead_batch, batch)
        return len(batch)

    def _flush_targets(self, force: bool = False) -> int:
        if not self._target_buffer:
            return 0
        if len(self._target_buffer) < self.batch_size and not force:
            return 0
        batch = self._target_buffer[:]
        self._target_buffer.clear()
        self._enqueue_or_run(self._write_target_batch, batch)
        return len(batch)

    def _flush_mc(self, force: bool = False) -> int:
        if not self._mc_buffer:
            return 0
        if len(self._mc_buffer) < self.batch_size and not force:
            return 0
        batch = self._mc_buffer[:]
        self._mc_buffer.clear()
        self._enqueue_or_run(self._write_mc_batch, batch)
        return len(batch)

    def _flush_discrete_metrics(self, force: bool = False) -> int:
        if not getattr(self, "_discrete_metrics_buffer", None):
            self._discrete_metrics_buffer = []
        if not self._discrete_metrics_buffer:
            return 0
        if len(self._discrete_metrics_buffer) < self.batch_size and not force:
            return 0
        batch = self._discrete_metrics_buffer[:]
        self._discrete_metrics_buffer.clear()
        self._enqueue_or_run(self._write_discrete_metrics_batch, batch)
        return len(batch)

    def _flush_discrete_analysis(self, force: bool = False) -> int:
        if not getattr(self, "_discrete_analysis_buffer", None):
            self._discrete_analysis_buffer = []
        if not self._discrete_analysis_buffer:
            return 0
        if len(self._discrete_analysis_buffer) < self.batch_size and not force:
            return 0
        batch = self._discrete_analysis_buffer[:]
        self._discrete_analysis_buffer.clear()
        self._enqueue_or_run(self._write_discrete_analysis_batch, batch)
        return len(batch)

    # ──────────────────────────────────────────────────────────
    # SQL writers
    # ──────────────────────────────────────────────────────────
    def _write_campaign_batch(self, records: Iterable[CampaignRecord]):
        if records:
            df = pd.DataFrame([r.as_tuple() for r in records], columns=CampaignRecord.columns)
            self._insert_df("campaigns", df)

    def _write_physics_batch(self, records: Iterable[PhysicsRunRecord]):
        if records:
            df = pd.DataFrame([r.as_tuple() for r in records], columns=PhysicsRunRecord.columns)
            self._insert_df("physics_runs", df)
            #print(f"[DB] Inserted physics_runs batch via Arrow: {len(df)} rows")

    def _write_lam2_batch(self, records: Iterable[LAM2GridRecord]):
        if records:
            df = pd.DataFrame(
                [
                    {
                        "grid_id": r.grid_id,
                        "run_id": r.run_id,
                        "pbh_ft": r.pbh_ft,
                        "omega_deg": r.omega_deg,
                        "velm_fps": r.velm_fps,
                        "zdata": r.zdata,
                        "rcas": r.rcas,
                        "x_axis_m": r.x_axis_m,
                        "y_axis_m": r.y_axis_m,
                        "pk_values": r.pk_values,
                        "n_x": r.n_x,
                        "n_y": r.n_y,
                        "origin_offset_m": r.origin_offset_m,
                        "cell_size_m": r.cell_size_m,
                    }
                    for r in records
                ]
            )
            self.conn.register("df_temp_lam2", df)
            col_list = ", ".join(LAM2GridRecord.columns)
            self.conn.execute("BEGIN")
            self.conn.execute(f"INSERT INTO lam2_grids ({col_list}) SELECT {col_list} FROM df_temp_lam2")
            self.conn.execute("END TRANSACTION")
            self.conn.unregister("df_temp_lam2")
            #print(f"[DB] Inserted lam2_grids batch via Arrow: {len(df)} rows")

    def _write_hypercube_batch(self, records: Iterable[HypercubeRecord]):
        if records:
            df = self._make_df([r.as_tuple() for r in records], HypercubeRecord.columns)
            self._insert_df("pk_hypercubes", df)
            #print(f"[DB] Inserted pk_hypercubes batch via Arrow: {len(df)} rows")

    def _write_warhead_batch(self, records: Iterable[WarheadRecord]):
        if records:
            df = self._make_df([r.as_tuple() for r in records], WarheadRecord.columns)
            self._insert_df("warheads", df)
            #print(f"[DB] Inserted warheads batch via Arrow: {len(df)} rows")

    def _write_target_batch(self, records: Iterable[TargetRecord]):
        if records:
            df = self._make_df([r.as_tuple() for r in records], TargetRecord.columns)
            self._insert_df("targets", df)
            #print(f"[DB] Inserted targets batch via Arrow: {len(df)} rows")

    def _write_mc_batch(self, records: Iterable[MonteCarloAnalysisRecord]):
        if records:
            df = self._make_df([r.as_tuple() for r in records], MonteCarloAnalysisRecord.columns)
            self._insert_df("monte_carlo_analyses", df)
            #print(f"[DB] Inserted monte_carlo_analyses batch via Arrow: {len(df)} rows")

    def _write_discrete_metrics_batch(self, records: Iterable[DiscreteMetricsRecord]):
        if records:
            df = self._make_df([r.as_tuple() for r in records], DiscreteMetricsRecord.columns)
            self._insert_df("discrete_metrics", df)
            #print(f"[DB] Inserted discrete_metrics batch via Arrow: {len(df)} rows")

    def _write_discrete_analysis_batch(self, records: Iterable[DiscreteAnalysisRecord]):
        if records:
            df = self._make_df([r.as_tuple() for r in records], DiscreteAnalysisRecord.columns)
            self._insert_df("discrete_analyses", df)
            #print(f"[DB] Inserted discrete_analyses batch via Arrow: {len(df)} rows")
