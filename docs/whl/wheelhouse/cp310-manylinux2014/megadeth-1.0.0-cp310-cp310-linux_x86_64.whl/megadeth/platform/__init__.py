"""Platform abstraction layer."""

from .base import PlatformAdapter, SystemResources, WorkerAllocation, get_platform_adapter
from .linux import LinuxAdapter
from .windows import WindowsAdapter
from .mpi import scatter_work, gather_results

__all__ = [
    "PlatformAdapter",
    "SystemResources",
    "WorkerAllocation",
    "get_platform_adapter",
    "LinuxAdapter",
    "WindowsAdapter",
    "scatter_work",
    "gather_results",
]
