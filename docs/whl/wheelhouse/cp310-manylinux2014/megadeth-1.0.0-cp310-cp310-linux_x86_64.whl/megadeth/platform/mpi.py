from __future__ import annotations

from typing import Any, List, Optional

try:
    from mpi4py import MPI  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    MPI = None

_COMM = MPI.COMM_WORLD if MPI else None


def get_rank() -> int:
    return _COMM.Get_rank() if _COMM else 0


def get_size() -> int:
    return _COMM.Get_size() if _COMM else 1


def scatter_work(work_items: List[Any]) -> List[Any]:
    """Scatter work items across MPI ranks."""
    if _COMM is None:
        return work_items

    rank = get_rank()
    size = get_size()

    if rank == 0:
        chunks = [[] for _ in range(size)]
        for i, item in enumerate(work_items):
            chunks[i % size].append(item)
    else:
        chunks = None

    return _COMM.scatter(chunks, root=0)


def gather_results(local_results: List[Any]) -> Optional[List[Any]]:
    """Gather results from all MPI ranks to root."""
    if _COMM is None:
        return local_results

    all_results = _COMM.gather(local_results, root=0)
    if get_rank() == 0:
        return [item for chunk in all_results for item in chunk]
    return None
