from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

from megadeth.preflight.io_benchmark import benchmark_path

from .base import PlatformAdapter, SystemResources, WorkerAllocation


class LinuxAdapter(PlatformAdapter):
    """Linux-specific adapter for staging and worker allocation."""

    SHM_PATH = Path("/dev/shm")
    # STAGING_SUBDIR = "megadeth_staging"
    PURGE_THRESHOLD = 0.80  # Purge if >80% full

    def __init__(self, output_path: Optional[Path] = None):
        self.output_path = output_path or (Path.cwd() / "output")
        self.output_path.mkdir(parents=True, exist_ok=True)
        self._staging_root = self.SHM_PATH if self.SHM_PATH.exists() else Path(tempfile.gettempdir())
        
        # FIX: Append the Process ID (PID) here
        self.STAGING_SUBDIR = f"megadeth_staging_{os.getpid()}"

    def probe_system(self) -> SystemResources:
        physical = self._get_physical_core_count()
        logical = os.cpu_count() or physical
        cpu_affinity_available = hasattr(os, "sched_getaffinity")
        numa_nodes = self._get_numa_nodes()
        total_mem_gb, available_mem_gb = self._get_memory_info()

        shm_stat = os.statvfs(self._staging_root)
        staging_capacity_gb = (shm_stat.f_blocks * shm_stat.f_frsize) / (1024**3)
        staging_available_gb = (shm_stat.f_bavail * shm_stat.f_frsize) / (1024**3)

        staging_path = self._staging_root / self.STAGING_SUBDIR
        max_workers = max(1, physical or logical or 1)

        # Heuristic batch sizing: roughly one worker's worth of 64MB chunks.
        staging_mb = staging_available_gb * 1024
        recommended_batch_size = max(1, int(staging_mb // (max_workers * 64)) or 1)

        return SystemResources(
            physical_cores=physical,
            logical_cores=logical,
            numa_nodes=numa_nodes,
            cpu_affinity_available=cpu_affinity_available,
            total_memory_gb=total_mem_gb,
            available_memory_gb=available_mem_gb,
            staging_path=staging_path,
            staging_capacity_gb=staging_capacity_gb,
            staging_available_gb=staging_available_gb,
            output_path=self.output_path,
            max_parallel_workers=max_workers,
            recommended_batch_size=recommended_batch_size,
            staging_buffer_mb=512,
        )

    def benchmark_io(self, staging_path: Path, output_path: Path) -> Dict[str, float]:
        """Measure IO performance on staging and disk paths."""
        staging_path.mkdir(parents=True, exist_ok=True)
        output_path.mkdir(parents=True, exist_ok=True)

        staging_metrics = benchmark_path(staging_path)
        disk_metrics = benchmark_path(output_path)

        return {
            "staging_write_mbps": staging_metrics["write_mbps"],
            "staging_read_mbps": staging_metrics["read_mbps"],
            "disk_write_mbps": disk_metrics["write_mbps"],
            "disk_read_mbps": disk_metrics["read_mbps"],
        }

    def prepare_staging_area(self, size_mb: int) -> Path:
        """Prepare /dev/shm staging area (or temp fallback)."""
        staging_path = self._staging_root / self.STAGING_SUBDIR

        shm_stat = os.statvfs(self._staging_root)
        used_ratio = 1 - (shm_stat.f_bavail / shm_stat.f_blocks)

        if used_ratio > self.PURGE_THRESHOLD and staging_path.exists():
            shutil.rmtree(staging_path)
            print(f"[Preflight] Purged staging (shm was {used_ratio*100:.1f}% full)")

        available_mb = (shm_stat.f_bavail * shm_stat.f_frsize) / (1024**2)
        if available_mb < size_mb:
            raise RuntimeError(
                f"Insufficient staging: need {size_mb}MB, have {available_mb:.0f}MB"
            )

        staging_path.mkdir(parents=True, exist_ok=True)
        return staging_path

    def allocate_workers(
        self, total_work_items: int, resources: SystemResources
    ) -> List[WorkerAllocation]:
        """NUMA-aware work distribution with physical core pinning."""
        n_workers = max(1, resources.max_parallel_workers)
        core_list = self._get_physical_core_list()[:n_workers]

        allocations: List[WorkerAllocation] = []
        items_per_worker = total_work_items // n_workers
        remainder = total_work_items % n_workers
        work_start = 0

        for worker_id in range(n_workers):
            n_items = items_per_worker + (1 if worker_id < remainder else 0)
            allocations.append(
                WorkerAllocation(
                    worker_id=worker_id,
                    core_ids=[core_list[worker_id % len(core_list)]],
                    work_indices=list(range(work_start, work_start + n_items)),
                    sandbox_path=resources.staging_path / f"worker_{worker_id:03d}",
                    staging_path=resources.staging_path,
                )
            )
            work_start += n_items

        return allocations

    # ──────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────
    def _get_physical_core_count(self) -> int:
        try:
            import psutil

            return psutil.cpu_count(logical=False) or psutil.cpu_count(logical=True) or 1
        except Exception:
            if hasattr(os, "sched_getaffinity"):
                return len(os.sched_getaffinity(0))
            return os.cpu_count() or 1

    def _get_physical_core_list(self) -> List[int]:
        if hasattr(os, "sched_getaffinity"):
            try:
                return sorted(os.sched_getaffinity(0))
            except Exception:
                pass
        return list(range(self._get_physical_core_count()))

    def _get_numa_nodes(self) -> int:
        sys_nodes = Path("/sys/devices/system/node")
        if sys_nodes.exists():
            nodes = [p for p in sys_nodes.iterdir() if p.name.startswith("node")]
            return max(1, len(nodes))
        return 1

    def _get_memory_info(self) -> tuple[float, float]:
        try:
            import psutil

            vm = psutil.virtual_memory()
            return vm.total / (1024**3), vm.available / (1024**3)
        except Exception:
            page_size = os.sysconf("SC_PAGE_SIZE")
            phys_pages = os.sysconf("SC_PHYS_PAGES")
            avail_pages = os.sysconf("SC_AVPHYS_PAGES")
            total = (page_size * phys_pages) / (1024**3)
            available = (page_size * avail_pages) / (1024**3)
            return total, available
