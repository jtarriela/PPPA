from __future__ import annotations

import multiprocessing as mp
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SystemResources:
    """Detected system resources from preflight probe."""

    physical_cores: int
    logical_cores: int
    numa_nodes: int
    cpu_affinity_available: bool
    total_memory_gb: float
    available_memory_gb: float
    staging_path: Path
    staging_capacity_gb: float
    staging_available_gb: float
    output_path: Path
    disk_write_bandwidth_mbps: float = 0.0
    disk_read_bandwidth_mbps: float = 0.0
    max_parallel_workers: int = field(default_factory=lambda: max(1, mp.cpu_count() or 1))
    recommended_batch_size: int = 1
    staging_buffer_mb: int = 512


@dataclass
class WorkerAllocation:
    """Assignment of work to a specific core/process."""

    worker_id: int
    core_ids: list[int]
    work_indices: list[int]
    sandbox_path: Path
    staging_path: Path


class PlatformAdapter(ABC):
    """Abstract interface for platform-specific operations."""

    @abstractmethod
    def probe_system(self) -> SystemResources:
        """Detect available system resources."""

    @abstractmethod
    def benchmark_io(self, staging_path: Path, output_path: Path) -> dict[str, float]:
        """Measure IO performance."""

    @abstractmethod
    def prepare_staging_area(self, size_mb: int) -> Path:
        """Prepare fast staging area, purging if necessary."""

    @abstractmethod
    def allocate_workers(
        self, total_work_items: int, resources: SystemResources
    ) -> list[WorkerAllocation]:
        """Shard work across available cores."""


def get_platform_adapter() -> PlatformAdapter:
    """Factory to get appropriate platform adapter."""
    import platform

    system = platform.system()
    if system == "Linux":
        from .linux import LinuxAdapter

        return LinuxAdapter()
    if system == "Windows":
        from .windows import WindowsAdapter  # type: ignore

        return WindowsAdapter()
    raise NotImplementedError(f"Platform '{system}' not supported")
