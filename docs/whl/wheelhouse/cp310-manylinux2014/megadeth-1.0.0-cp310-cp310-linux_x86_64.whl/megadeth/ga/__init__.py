"""
GA-facing helpers and thin integration layer for MEGADETH.
"""

from .api import (
    GaStaticContext,
    DesignVector,
    TargetSpec,
    MatrixOverrides,
    PrecisionSpec,
    TargetResult,
    GaResult,
    run_ga_design,
)

__all__ = [
    "GaStaticContext",
    "DesignVector",
    "TargetSpec",
    "MatrixOverrides",
    "PrecisionSpec",
    "TargetResult",
    "GaResult",
    "run_ga_design",
]
