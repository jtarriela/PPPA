from __future__ import annotations

import shutil
import numpy as np
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from megadeth.config.schema import (
    AxisSpec,
    CampaignConfig,
    DiscreteGridConfig,
    ErrorModelConfig,
    ExecutionConfig,
    MatrixConfig,
    MCLethalityConfig,
    MCSamplingConfig,
    MonteCarloConfig,
    OutputConfig,
    PrecisionConfig,
    SolverConfig,
    TargetConfigModel,
    TerminalConditionConfig,
    WarheadConfigModel,
)
from megadeth.execution.orchestrator import run_campaign


@dataclass
class TargetSpec:
    """Target descriptor with paths OR bytes for RCAS, INTRVC, and CDRAG files.

    For each file type (RCAS, INTRVC, CDRAG), at least one of path or bytes
    must be provided. If both are provided, path takes precedence for
    backward compatibility.

    Attributes:
        rcas_number: RCAS file number identifier
        rcas_path: Path to target RCAS vulnerability file (optional if rcas_bytes provided)
        intrvc_path: Path to target INTRVC file (optional if intrvc_bytes provided)
        cdrag_path: Path to target CDRAG file (optional if cdrag_bytes provided)
        rcas_bytes: Raw bytes of RCAS file content (optional if rcas_path provided)
        intrvc_bytes: Raw bytes of INTRVC file content (optional if intrvc_path provided)
        cdrag_bytes: Raw bytes of CDRAG file content (optional if cdrag_path provided)
        target_id: Optional unique target identifier (defaults to rcas_number)
        centroid_height_ft: Optional target centroid height in feet

    Notes:
        All .DAT files are ASCII text with extensions for Fortran solver recognition.
        Bytes are passed through without transformation, preserving exact formatting.
    """
    rcas_number: int
    rcas_path: Optional[Path] = None
    intrvc_path: Optional[Path] = None
    cdrag_path: Optional[Path] = None
    rcas_bytes: Optional[bytes] = None
    intrvc_bytes: Optional[bytes] = None
    cdrag_bytes: Optional[bytes] = None
    target_id: Optional[int] = None
    centroid_height_ft: Optional[float] = None

    def __post_init__(self) -> None:
        """Validate that at least one source is provided for each file type."""
        if self.rcas_path is None and self.rcas_bytes is None:
            raise ValueError("TargetSpec requires either rcas_path or rcas_bytes")
        if self.intrvc_path is None and self.intrvc_bytes is None:
            raise ValueError("TargetSpec requires either intrvc_path or intrvc_bytes")
        if self.cdrag_path is None and self.cdrag_bytes is None:
            raise ValueError("TargetSpec requires either cdrag_path or cdrag_bytes")

    def get_target_id(self) -> int:
        """Return target_id if set, otherwise rcas_number."""
        return self.target_id if self.target_id is not None else self.rcas_number


@dataclass
class MatrixOverrides:
    """Optional overrides for IP.DAT impact matrix settings.

    Attributes:
        nx: Number of cells in deflection (X) direction
        ny: Number of cells in range (Y) direction
        cell_size_m: Cell size in meters
        range_offset_m: Range offset for matrix centering
    """
    nx: Optional[int] = 80
    ny: Optional[int] = 40
    cell_size_m: Optional[float] = 1.0
    range_offset_m: Optional[float] = 0.0


@dataclass
class PrecisionSpec:
    """4-source error model parameters for discrete and Monte Carlo analysis.

    MATLAB Parity: Maps to MEGADETH Precision input matrix (8 columns):
        [TLE_r, TLE_f, CEP_r, CEP_f, FixedBias_defl, FixedBias_range, VarBias_r, VarBias_f]

    Attributes:
        label: Human-readable label for this precision configuration
        tle_radius_m: Target Location Error containment radius (meters)
        tle_fraction: TLE containment probability (e.g., 0.90 for TLE90)
        cep_radius_m: Circular Error Probable radius (meters)
        cep_fraction: CEP containment probability (e.g., 0.50 for CEP50)
        fixed_bias_deflection_m: Fixed bias in deflection/crossrange (meters)
        fixed_bias_range_m: Fixed bias in range/downrange (meters)
        variable_bias_radius_m: Variable bias containment radius (meters)
        variable_bias_fraction: Variable bias containment probability
        tle_z_sigma_m: Vertical TLE sigma (meters, optional)
        cep_z_sigma_m: Vertical CEP sigma (meters, optional)
    """
    label: str = "default"
    tle_radius_m: float = 30.0
    tle_fraction: float = 0.90
    cep_radius_m: float = 5.0
    cep_fraction: float = 0.50
    fixed_bias_deflection_m: float = 0.0
    fixed_bias_range_m: float = 0.0
    variable_bias_radius_m: float = 0.0
    variable_bias_fraction: float = 0.50
    tle_z_sigma_m: float = 0.0
    cep_z_sigma_m: float = 0.0

    def to_model(self) -> PrecisionConfig:
        """Convert to internal PrecisionConfig schema model."""
        return PrecisionConfig(
            label=self.label,
            tle_radius_m=self.tle_radius_m,
            tle_fraction=self.tle_fraction,
            cep_radius_m=self.cep_radius_m,
            cep_fraction=self.cep_fraction,
            fixed_bias_deflection_m=self.fixed_bias_deflection_m,
            fixed_bias_range_m=self.fixed_bias_range_m,
            variable_bias_radius_m=self.variable_bias_radius_m,
            variable_bias_fraction=self.variable_bias_fraction,
            tle_z_sigma_m=self.tle_z_sigma_m,
            cep_z_sigma_m=self.cep_z_sigma_m,
        )


@dataclass
class DesignVector:
    """GA-provided warhead design inputs.

    At least one of zdata_path or zdata_bytes must be provided.
    If both are provided, zdata_path takes precedence for backward compatibility.

    Attributes:
        zdata_number: ZDATA file identifier number
        zdata_path: Path to warhead ZDATA file (optional if zdata_bytes provided)
        zdata_bytes: Raw bytes of ZDATA file content (optional if zdata_path provided)

    Notes:
        Use zdata_from_ga_chromosome() and zdata_to_bytes() from megadeth.physics.zdata
        to generate zdata_bytes from GA chromosome representation without disk I/O.

    Example:
        >>> from megadeth.physics.zdata import zdata_from_ga_chromosome, zdata_to_bytes
        >>> zdata = zdata_from_ga_chromosome(n_zones=15, ...)
        >>> design = DesignVector(zdata_number=42, zdata_bytes=zdata_to_bytes(zdata))
    """
    zdata_number: int
    zdata_path: Optional[Path] = None
    zdata_bytes: Optional[bytes] = None

    def __post_init__(self) -> None:
        """Validate that at least one source is provided."""
        if self.zdata_path is None and self.zdata_bytes is None:
            raise ValueError("DesignVector requires either zdata_path or zdata_bytes")


@dataclass
class GaStaticContext:
    """
    Cached, invariant inputs for GA-driven campaigns.

    Attributes:
        targets: List of target descriptors (RCAS bundle per target)
        axes: Terminal condition grids {"hob": [...], "vel": [...], "aof": [...]}
        fsm_exe_path: Path to FullSpray executable (auto-detected if None)
        base_output_dir: Root directory for per-target outputs
        staging_strategy: "batched" (default) or "per_job"
        max_parallel_workers: Number of parallel workers (default 1 for GA)
        enable_parallel_salvos: Enable parallel salvo execution (default False)
        matrix_overrides: Optional IP.DAT matrix overrides
        precisions: List of precision configurations for MC analysis
        backend: Physics backend: "fortran" (default) or "cpp" (gfs_physics)
    """
    targets: List[TargetSpec]
    axes: Dict[str, Sequence[float]]
    fsm_exe_path: Optional[Path] = None
    base_output_dir: Path = Path("output")
    staging_strategy: str = "batched"
    max_parallel_workers: int = 1
    enable_parallel_salvos: bool = False
    matrix_overrides: Optional[MatrixOverrides] = None
    precisions: List[PrecisionSpec] = field(default_factory=lambda: [PrecisionSpec()])
    backend: str = "fortran"  # "fortran" or "cpp"


@dataclass
class TargetResult:
    """Per-target analysis results from run_ga_design.

    Contains all discrete analysis outputs for a single target evaluation,
    including system Pk grids, scalar fitness metrics, and NPZ file paths.

    Attributes:
        target_id: Target identifier (from TargetSpec.get_target_id())
        system_pk: 3D system Pk grid [n_hob, n_vel, n_aof] (from discrete analysis)
        reliability: 3D reliability grid [n_hob, n_vel, n_aof]
        volume_at_threshold: Envelope volume where Pk >= threshold (scalar fitness metric)
        integrated_kill_potential: Sum of Pk over terminal condition space (scalar)
        sensitivity: 3D gradient magnitude grid [n_hob, n_vel, n_aof]
        npz_paths: Dict mapping output type to file path:
            - "pk": Path to pk_hypercube.npz (5D hypercube)
            - "discrete": Path to discrete_analysis_v3.npz (analysis results)
            - "mc": Path to mc_result_*.npz (Monte Carlo, if run_mc=True)
    """
    target_id: int
    system_pk: Optional[np.ndarray]
    reliability: Optional[np.ndarray]
    volume_at_threshold: Optional[float]
    integrated_kill_potential: Optional[float]
    sensitivity: Optional[np.ndarray]
    npz_paths: Dict[str, Optional[Path]]


@dataclass
class GaResult:
    """Return structure from run_ga_design.

    Contains per-target results and campaign metadata for GA fitness evaluation.

    Attributes:
        targets: List of TargetResult, one per target in GaStaticContext.targets
        metadata: Campaign metadata dict containing:
            - "pk_threshold": Pk threshold used for volume calculations
            - "axes": Terminal condition axes {"hob": [...], "vel": [...], "aof": [...]}
            - "precision_labels": Labels for configured precision configs
            - "matrix_overrides": MatrixOverrides dict if configured, else None

    Example:
        >>> result = run_ga_design(design, ctx, pk_threshold=0.3)
        >>> fitness = sum(t.integrated_kill_potential or 0 for t in result.targets)
    """
    targets: List[TargetResult]
    metadata: Dict[str, object]


def _axis_from_seq(values: Sequence[float]) -> AxisSpec:
    return AxisSpec(axis=[float(v) for v in values])


def _ensure_file(src: Path, dst: Path) -> None:
    """Copy file from src to dst if dst doesn't exist. Deprecated: use _ensure_file_or_bytes."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    shutil.copy2(src, dst)


def _ensure_file_or_bytes(
    src_path: Optional[Path],
    src_bytes: Optional[bytes],
    dst_dir: Path,
    default_name: str,
) -> Path:
    """
    Stage a file from path or bytes to destination directory.

    Path takes precedence if both are provided (backward compatibility).
    Idempotent: skips if destination file already exists.

    Args:
        src_path: Source file path (takes precedence if provided)
        src_bytes: Raw bytes to write if no src_path
        dst_dir: Destination directory
        default_name: Filename to use when writing from bytes

    Returns:
        Path to the staged file

    Raises:
        ValueError: If neither src_path nor src_bytes is provided
    """
    dst_dir.mkdir(parents=True, exist_ok=True)

    if src_path is not None:
        # Path-based: copy from source file
        dest_file = dst_dir / src_path.name
        if not dest_file.exists():
            shutil.copy2(src_path, dest_file)
        return dest_file
    elif src_bytes is not None:
        # Bytes-based: write directly (pass-through, preserves exact content)
        dest_file = dst_dir / default_name
        if not dest_file.exists():
            dest_file.write_bytes(src_bytes)
        return dest_file
    else:
        raise ValueError(f"Either src_path or src_bytes must be provided for {default_name}")


def _build_matrix_config(overrides: Optional[MatrixOverrides]) -> Optional[MatrixConfig]:
    if overrides is None:
        return None
    return MatrixConfig(
        nx=overrides.nx,
        ny=overrides.ny,
        cell_size_m=overrides.cell_size_m,
        range_offset_m=overrides.range_offset_m,
    )


def _build_terminal_axes(axis_map: Dict[str, Sequence[float]]) -> TerminalConditionConfig:
    try:
        hob = _axis_from_seq(axis_map["hob"])
        vel = _axis_from_seq(axis_map["vel"])
        aof = _axis_from_seq(axis_map["aof"])
    except KeyError as exc:  # pragma: no cover - defensive
        raise ValueError("axes must include hob, vel, and aof sequences") from exc
    return TerminalConditionConfig(hob=hob, velocity=vel, aof=aof)


def _precision_models(specs: List[PrecisionSpec]) -> List[PrecisionConfig]:
    if not specs:
        return [PrecisionSpec().to_model()]
    return [spec.to_model() for spec in specs]


def run_ga_design(
    design: DesignVector,
    static: GaStaticContext,
    *,
    pk_threshold: float,
    run_mc: bool = False,
) -> GaResult:
    """
    Thin GA-facing entrypoint for single-warhead, multi-target campaigns.

    Args:
        design: GA-provided warhead descriptor (zdata_number, zdata_path)
        static: Cached invariant inputs (targets, axes, solver paths, matrix overrides, precisions)
        pk_threshold: Pk threshold for discrete analysis volume calculations
        run_mc: Enable Monte Carlo analysis (default False)

    Returns:
        GaResult with per-target system Pk, volume, sensitivity, and NPZ paths

    Raises:
        ValueError: If targets list is empty

    Notes:
        - Single-worker execution (max_parallel_workers=1)
        - Batched staging strategy
        - Per-target output directories: {base_output_dir}/tgt{rcas}_zdata{zdata}_out
        - Each target gets isolated NPZ artifacts
    """
    # Validate inputs
    if not static.targets:
        raise ValueError("GaStaticContext.targets must contain at least one target")

    terminal_cfg = _build_terminal_axes(static.axes)
    matrix_cfg = _build_matrix_config(static.matrix_overrides)
    precision_models = _precision_models(static.precisions)

    target_results: List[TargetResult] = []
    for tgt in static.targets:
        target_out_dir = Path(static.base_output_dir) / f"tgt{tgt.rcas_number}_zdata{design.zdata_number}_out"
        target_out_dir.mkdir(parents=True, exist_ok=True)

        # Stage required inputs into the working folder for traceability
        # Each target's files are isolated: targets[i] → tgt{rcas_i}_*/
        # Supports both path-based and bytes-based input (bytes enables zero-copy GA workflow)
        rcas_staged = _ensure_file_or_bytes(
            tgt.rcas_path, tgt.rcas_bytes, target_out_dir, f"RCAS{tgt.rcas_number}.DAT"
        )
        intrvc_staged = _ensure_file_or_bytes(
            tgt.intrvc_path, tgt.intrvc_bytes, target_out_dir, f"INTRVC{tgt.rcas_number}.DAT"
        )
        cdrag_staged = _ensure_file_or_bytes(
            tgt.cdrag_path, tgt.cdrag_bytes, target_out_dir, "CDRAG1.DAT"
        )
        # Warhead ZDATA (shared across all targets, from DesignVector)
        zdata_staged = _ensure_file_or_bytes(
            design.zdata_path, design.zdata_bytes, target_out_dir, f"ZDATA{design.zdata_number}.DAT"
        )

        # Use staged paths for solver config
        solver_cfg = SolverConfig(
            fsm_exe_path=static.fsm_exe_path,
            cdrag_path=cdrag_staged,
            backend=static.backend,  # Pass through backend selection
        )
        exec_cfg = ExecutionConfig(
            max_parallel_workers=static.max_parallel_workers,
            staging_strategy=static.staging_strategy,
        )
        mc_cfg = MonteCarloConfig(
            enabled=run_mc,
            precisions=precision_models,
            sampling=MCSamplingConfig(),
            lethality=MCLethalityConfig(),
        )

        # Configure discrete analysis with error model from first precision config
        # This ensures consistent error modeling between MC and discrete analysis
        first_precision = precision_models[0] if precision_models else PrecisionSpec().to_model()
        error_model_cfg = ErrorModelConfig(
            tle_radius_m=first_precision.tle_radius_m,
            tle_fraction=first_precision.tle_fraction,
            cep_radius_m=first_precision.cep_radius_m,
            cep_fraction=first_precision.cep_fraction,
            fixed_bias_x_m=first_precision.fixed_bias_deflection_m,
            fixed_bias_y_m=first_precision.fixed_bias_range_m,
            variable_bias_radius_m=first_precision.variable_bias_radius_m,
            variable_bias_fraction=first_precision.variable_bias_fraction,
        )
        disc_cfg = DiscreteGridConfig(
            enabled=True,
            pk_threshold=pk_threshold,
            error_model=error_model_cfg,
        )

        warhead_cfg = WarheadConfigModel(
            zdata_number=design.zdata_number,
            zdata_path=zdata_staged,
        )
        target_cfg = TargetConfigModel(
            rcas_number=tgt.rcas_number,
            rcas_path=rcas_staged,
            intrvc_path=intrvc_staged,
            centroid_height_ft=tgt.centroid_height_ft,
        )

        campaign_name = f"tgt{tgt.rcas_number}_zdata{design.zdata_number}"
        campaign_cfg = CampaignConfig(
            name=campaign_name,
            terminal_conditions=terminal_cfg,
            warheads=[warhead_cfg],
            targets=[target_cfg],
            solver=solver_cfg,
            output=OutputConfig(directory=target_out_dir),
            execution=exec_cfg,
            matrix=matrix_cfg,
            monte_carlo=mc_cfg,
            discrete_analysis=disc_cfg,
        )

        # FIX: Pass a custom adapter with node-local output_path
        # This ensures preflight checks validate the local temp directory (target_out_dir)
        # instead of the default NFS mount, avoiding stale file handle errors in MPI setups
        from megadeth.platform import get_platform_adapter
        from megadeth.platform.linux import LinuxAdapter
        import platform as sys_platform

        if sys_platform.system() == "Linux":
            local_adapter = LinuxAdapter(output_path=target_out_dir)
        else:
            local_adapter = get_platform_adapter()

        run_result = run_campaign(
            campaign_cfg,
            adapter=local_adapter,
            skip_preflight_io=True,
            rounds_to_kill_pk_threshold=pk_threshold,
            staging_strategy=static.staging_strategy,
        )

        # Load post-processing outputs
        discrete_npz_path = target_out_dir / "discrete_analysis_v3.npz"
        metrics_path = target_out_dir / "discrete_metrics_v3.json"
        system_pk = None
        reliability = None
        sensitivity = None
        volume_at_threshold = None
        integrated_kill_potential = None
        if discrete_npz_path.exists():
            with np.load(discrete_npz_path) as data:  # type: ignore[attr-defined]
                system_pk = data.get("system_pk")
                reliability = data.get("reliability")
                sensitivity = data.get("sensitivity")
        if metrics_path.exists():
            try:
                import json

                with open(metrics_path, "r") as f:
                    meta = json.load(f)
                volume_at_threshold = meta.get("envelope_volume")
                integrated_kill_potential = meta.get("integrated_kill_potential")
            except Exception:
                pass

        mc_npz_path = None
        if run_mc and precision_models:
            mc_npz_path = target_out_dir / f"mc_result_{precision_models[0].label}.npz"

        target_results.append(
            TargetResult(
                target_id=tgt.get_target_id(),
                system_pk=system_pk,
                reliability=reliability,
                volume_at_threshold=volume_at_threshold,
                integrated_kill_potential=integrated_kill_potential,
                sensitivity=sensitivity,
                npz_paths={
                    "pk": Path(run_result["npz_path"]),
                    "discrete": discrete_npz_path if discrete_npz_path.exists() else None,
                    "mc": mc_npz_path if mc_npz_path and mc_npz_path.exists() else None,
                },
            )
        )

    return GaResult(
        targets=target_results,
        metadata={
            "pk_threshold": pk_threshold,
            "axes": {
                "hob": list(static.axes.get("hob", [])),
                "vel": list(static.axes.get("vel", [])),
                "aof": list(static.axes.get("aof", [])),
            },
            "precision_labels": [p.label for p in precision_models],
            "matrix_overrides": static.matrix_overrides.__dict__ if static.matrix_overrides else None,
        },
    )
