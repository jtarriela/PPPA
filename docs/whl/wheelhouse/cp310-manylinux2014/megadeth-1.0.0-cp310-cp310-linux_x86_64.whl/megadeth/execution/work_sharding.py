from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Mapping, Union

import numpy as np

from megadeth.config.loader import _validate
from megadeth.config.schema import CampaignConfig
from megadeth.physics import (
    TargetConfig,
    TerminalCondition,
    WarheadConfig,
    get_centroid_height_ft,
)


@dataclass
class WorkItem:
    """Single FullSpray execution work unit."""

    condition: TerminalCondition
    warhead: WarheadConfig
    target: TargetConfig
    work_id: int


def _coerce_config(config: Union[CampaignConfig, Mapping]) -> CampaignConfig:
    if isinstance(config, CampaignConfig):
        return config
    return _validate(CampaignConfig, config)


def generate_work_items(config: Union[CampaignConfig, Mapping]) -> List[WorkItem]:
    """
    Generate all work items from campaign configuration.

    Cartesian product of warheads × targets × HOBs × velocities × AOFs.
    """
    cfg = _coerce_config(config)
    work_items: List[WorkItem] = []
    work_id = 0

    hobs = np.array(cfg.terminal_conditions.hob.values)
    vels = np.array(cfg.terminal_conditions.velocity.values)
    aofs = np.array(cfg.terminal_conditions.aof.values)

    for wh in cfg.warheads:
        warhead = WarheadConfig(
            zdata_number=wh.zdata_number,
            zdata_path=Path(wh.zdata_path),
        )
        for tgt in cfg.targets:
            centroid_ft = tgt.centroid_height_ft or get_centroid_height_ft(
                tgt.rcas_number
            )
            target = TargetConfig(
                rcas_number=tgt.rcas_number,
                rcas_path=Path(tgt.rcas_path),
                intrvc_path=Path(tgt.intrvc_path),
                centroid_height_ft=centroid_ft,
            )
            for hob in hobs:
                for vel in vels:
                    for aof in aofs:
                        condition = TerminalCondition(
                            hob_m=float(hob),
                            velocity_mps=float(vel),
                            aof_deg=float(aof),
                        )
                        work_items.append(
                            WorkItem(
                                condition=condition,
                                warhead=warhead,
                                target=target,
                                work_id=work_id,
                            )
                        )
                        work_id += 1
    return work_items


def shard_work(work_items: List[WorkItem], n_workers: int) -> List[List[WorkItem]]:
    """Distribute work items evenly across workers."""
    if n_workers <= 0:
        raise ValueError("n_workers must be positive")
    shards: List[List[WorkItem]] = [[] for _ in range(n_workers)]
    for i, item in enumerate(work_items):
        shards[i % n_workers].append(item)
    return shards
