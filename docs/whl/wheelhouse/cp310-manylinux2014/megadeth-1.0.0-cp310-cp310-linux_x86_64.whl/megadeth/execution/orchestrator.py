from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Mapping, Optional, Union
import numpy as np
from concurrent.futures import ProcessPoolExecutor, as_completed
import logging
import time
import uuid

from megadeth.config.loader import _validate
from megadeth.config.schema import CampaignConfig, PrecisionConfig
from megadeth.execution.work_sharding import WorkItem, generate_work_items, shard_work
from megadeth.physics import HypercubeBuilder, MatrixSettings, WorkerSandbox
from megadeth.physics.fullspray_wrapper import select_executable, get_data_directory
from megadeth.physics.backend import PhysicsBackend, get_backend_from_config
from megadeth.analysis.discrete_grid import (
    DiscreteGridAnalyzer,
    DiscreteAnalysisResults,
    ErrorSigmas,
    compute_rounds_to_kill_grid,
)
from megadeth.analysis.monte_carlo import (
    MonteCarloAnalyzer,
    MonteCarloResults,
    GuidanceErrorModel,
    run_parallel_salvos,
)
from megadeth.platform import PlatformAdapter, get_platform_adapter
from megadeth.preflight import PreflightReport, run_preflight
from megadeth.database.writer import BatchedDBWriter
from megadeth.database.models import (
    CampaignRecord,
    HypercubeRecord,
    # LAM2GridRecord removed - grids stored in hypercube NPZ instead
    MonteCarloAnalysisRecord,
    PhysicsRunRecord,
    TargetRecord,
    DiscreteAnalysisRecord,
    DiscreteMetricsRecord,
    WarheadRecord,
)


def _coerce_config(config: Union[CampaignConfig, Mapping]) -> CampaignConfig:
    if isinstance(config, CampaignConfig):
        return config
    return _validate(CampaignConfig, config)


def precision_to_guidance_model(precision: PrecisionConfig) -> GuidanceErrorModel:
    """Convert a PrecisionConfig from schema to GuidanceErrorModel for MC analysis."""
    return GuidanceErrorModel(
        tle_radius_m=precision.tle_radius_m,
        tle_fraction=precision.tle_fraction,
        cep_radius_m=precision.cep_radius_m,
        cep_fraction=precision.cep_fraction,
        fixed_bias_deflection_m=precision.fixed_bias_deflection_m,
        fixed_bias_range_m=precision.fixed_bias_range_m,
        variable_bias_radius_m=precision.variable_bias_radius_m,
        variable_bias_fraction=precision.variable_bias_fraction,
        tle_z_sigma_m=precision.tle_z_sigma_m,
        cep_z_sigma_m=precision.cep_z_sigma_m,
    )


# =============================================================================
# Parallel Precision Analysis Support
# =============================================================================

# Type alias for the result tuple from worker process
from typing import Tuple
import hashlib

PrecisionAnalysisResult = Tuple[MonteCarloResults, Path, str, PrecisionConfig]


def _analyze_single_precision(
    pk_hypercube: np.ndarray,
    miss_x_axis: np.ndarray,
    miss_y_axis: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    precision_cfg: PrecisionConfig,
    n_salvos: int,
    n_shots: int,
    pk_thresholds: List[float],
    random_seed: int,
    store_detailed_results: bool,
    output_dir: Path,
    use_parallel_salvos: bool = False,
    parallel_salvo_workers: Optional[int] = None,
) -> PrecisionAnalysisResult:
    """
    Execute Monte Carlo analysis for a single precision configuration.
    
    This is a module-level pure function designed to be picklable for
    parallel execution via ProcessPoolExecutor. The worker performs the
    heavy math and saves the NPZ artifact, returning lightweight results
    to the main process for DB persistence.
    
    Memory Efficiency (Linux):
        On fork()-based systems, the pk_hypercube is shared via Copy-on-Write,
        making worker spawning fast and memory-efficient.
    
    Args:
        pk_hypercube: 5D Pk tensor [n_mx, n_my, n_hob, n_vel, n_aof]
        miss_x_axis: LAM2 deflection axis (meters)
        miss_y_axis: LAM2 range axis (meters)
        hob_axis: Height-of-burst axis values
        vel_axis: Velocity axis values
        aof_axis: Angle-of-fall axis values
        precision_cfg: Precision configuration (error model params)
        n_salvos: Number of Monte Carlo salvos
        n_shots: Shots per salvo
        pk_thresholds: Pk thresholds for rounds-to-kill computation
        random_seed: Base random seed (will be combined with precision label)
        store_detailed_results: Whether to store per-shot detailed results
        output_dir: Directory for NPZ output
        use_parallel_salvos: If True, parallelize at salvo level within this
                            precision config (useful for single-precision runs)
        parallel_salvo_workers: Number of workers for salvo parallelism
        
    Returns:
        Tuple of:
            - MonteCarloResults: Computed statistics
            - Path: Path to saved NPZ artifact
            - str: SHA256 checksum of NPZ file
            - PrecisionConfig: Original config (for DB record creation)
    """
    label = precision_cfg.label
    
    # Create analyzer for this precision config
    # Note: On Linux with fork(), the pk_hypercube array is shared via COW
    analyzer = MonteCarloAnalyzer(
        pk_hypercube,  # First positional arg (pk_hypercube_or_model)
        miss_x_axis=miss_x_axis,
        miss_y_axis=miss_y_axis,
        hob_axis=hob_axis,
        vel_axis=vel_axis,
        aof_axis=aof_axis,
    )
    
    guidance_model = precision_to_guidance_model(precision_cfg)
    
    # Run MC analysis - choose between parallel salvos or sequential
    if use_parallel_salvos and n_salvos >= 200:  # Only parallelize if worth it
        result = run_parallel_salvos(
            analyzer=analyzer,
            guidance_model=guidance_model,
            n_salvos=n_salvos,
            n_shots=n_shots,
            pk_thresholds=pk_thresholds,
            random_seed=random_seed,
            n_workers=parallel_salvo_workers,
        )
    else:
        result = analyzer.run(
            guidance_model=guidance_model,
            n_salvos=n_salvos,
            n_shots=n_shots,
            pk_thresholds=pk_thresholds,
            random_seed=random_seed,
        )
    
    # Save NPZ artifact (I/O - done in worker to avoid moving large arrays)
    precision_npz = output_dir / f"mc_result_{label}.npz"
    
    # Build NPZ data dict
    npz_data = {
        'hob_axis': result.hob_axis if hasattr(result, 'hob_axis') and result.hob_axis is not None else hob_axis,
        'vel_axis': result.vel_axis if hasattr(result, 'vel_axis') and result.vel_axis is not None else vel_axis,
        'aof_axis': result.aof_axis if hasattr(result, 'aof_axis') and result.aof_axis is not None else aof_axis,
        'pk_thresholds': result.pk_thresholds if hasattr(result, 'pk_thresholds') and result.pk_thresholds is not None else pk_thresholds,
        'mean_acc_pk_by_shot': result.mean_acc_pk_by_shot,
        'rounds_to_kill': result.rounds_to_kill,
        'precision_config': label,
    }
    
    # Include raw draws if available (for visualization/validation)
    if result.aimpoint_offsets is not None:
        npz_data['aimpoint_offsets'] = result.aimpoint_offsets
    if result.dispersion_offsets is not None:
        npz_data['dispersion_offsets'] = result.dispersion_offsets
    
    np.savez_compressed(precision_npz, **npz_data)
    
    # Compute checksum
    with open(precision_npz, "rb") as f:
        npz_checksum = hashlib.sha256(f.read()).hexdigest()
    
    return result, precision_npz, npz_checksum, precision_cfg


def run_monte_carlo_analysis(
    config: CampaignConfig,
    pk_hypercube: np.ndarray,
    miss_x_axis: np.ndarray,
    miss_y_axis: np.ndarray,
    output_dir: Path,
    hypercube_record: HypercubeRecord,
    db_writer: BatchedDBWriter,
    log: logging.Logger,
    max_workers: Optional[int] = None,
    enable_parallel_salvos: bool = True,
) -> Optional[List[MonteCarloResults]]:
    """
    Execute Monte Carlo analysis using MEGADETH-parity algorithm.

    Precision configurations are executed in parallel using ProcessPoolExecutor.
    Database writes are centralized in the main process for thread safety.
    
    Parallelism Strategy:
        - Multiple precisions: Parallelize at precision level (each worker runs one precision)
        - Single precision: Parallelize at salvo level (salvos split across workers)
        - enable_parallel_salvos=True enables salvo-level parallelism for single-precision runs
        - Salvo-level parallelism engages only when n_salvos >= 200; worker
          count is capped at min(cpu_count, 8) and trimmed if <100 salvos/worker.

    MATLAB Reference: SalvoAnalysis03x3.m

    Memory Efficiency:
        On Linux (fork-based), the pk_hypercube is shared via Copy-on-Write,
        making worker spawning fast and memory-efficient. On Windows, data is
        copied but computational cost usually dominates.

    Args:
        config: Campaign configuration with monte_carlo section
        pk_hypercube: 5D Pk tensor from HypercubeBuilder
        miss_x_axis: LAM2 native deflection axis (meters)
        miss_y_axis: LAM2 native range axis (meters)
        output_dir: Path for output artifacts
        hypercube_record: DB record for the hypercube
        db_writer: Database writer for persisting results
        log: Logger instance
        max_workers: Maximum number of parallel workers. None uses CPU count.
                     Set to 1 for sequential execution.
        enable_parallel_salvos: If True and single precision config, parallelize
                               at salvo level for full core utilization.

    Returns:
        List of MonteCarloResults (one per precision configuration) or None if disabled
    """
    mc_config = config.monte_carlo

    if not mc_config.enabled:
        log.info("Monte Carlo analysis disabled in configuration")
        return None

    n_precisions = len(mc_config.precisions)
    log.info(
        "Starting Monte Carlo analysis: %d precision configs, %d salvos, %d shots",
        n_precisions,
        mc_config.sampling.n_salvos,
        mc_config.sampling.n_shots,
    )

    # Extract axes as arrays for worker pickling
    hob_axis = np.array(config.terminal_conditions.hob.values)
    vel_axis = np.array(config.terminal_conditions.velocity.values)
    aof_axis = np.array(config.terminal_conditions.aof.values)

    # Determine parallelization strategy
    effective_workers = max_workers if max_workers is not None else None
    
    # Precision-level parallelism: multiple precisions across workers
    parallel_precision_mode = n_precisions > 1 and (max_workers is None or max_workers > 1)
    
    # Salvo-level parallelism: single precision, split salvos across workers
    # Only enable if explicitly requested and we have a single precision config
    use_salvo_parallelism = (
        enable_parallel_salvos and 
        n_precisions == 1 and 
        mc_config.sampling.n_salvos >= 200 and
        (max_workers is None or max_workers > 1)
    )
    
    if parallel_precision_mode:
        log.info(f"Parallel execution (precision-level): {n_precisions} configs, max_workers={effective_workers or 'auto'}")
    elif use_salvo_parallelism:
        log.info(f"Parallel execution (salvo-level): single precision, {mc_config.sampling.n_salvos} salvos")
    else:
        log.info("Sequential execution mode")

    results_list: List[MonteCarloResults] = []
    mc_start = time.perf_counter()

    if parallel_precision_mode:
        # Parallel execution using ProcessPoolExecutor at precision level
        # Workers perform heavy math and save NPZ; main process handles DB writes
        with ProcessPoolExecutor(max_workers=effective_workers) as executor:
            # Submit all precision configs
            futures = {
                executor.submit(
                    _analyze_single_precision,
                    pk_hypercube,
                    miss_x_axis,
                    miss_y_axis,
                    hob_axis,
                    vel_axis,
                    aof_axis,
                    precision_cfg,
                    mc_config.sampling.n_salvos,
                    mc_config.sampling.n_shots,
                    mc_config.lethality.pk_thresholds,
                    mc_config.sampling.random_seed,
                    mc_config.sampling.store_detailed_results,
                    output_dir,
                    False,  # use_parallel_salvos=False (already parallel at precision level)
                    None,   # parallel_salvo_workers
                ): (idx, precision_cfg.label)
                for idx, precision_cfg in enumerate(mc_config.precisions)
            }

            # Collect results as they complete
            for future in as_completed(futures):
                idx, label = futures[future]
                try:
                    result, npz_path, npz_checksum, precision_cfg = future.result()
                    
                    log.info(
                        f"  Precision '{label}' [#{idx+1}]: mean single-shot Pk={result.single_shot_pk_mean:.4f}, "
                        f"mean salvo Pk={result.accumulated_pk_mean:.4f}"
                    )
                    
                    results_list.append(result)
                    
                    # Persist to database (main process - thread safe)
                    mc_record = MonteCarloAnalysisRecord(
                        hypercube_id=hypercube_record.hypercube_id,
                        n_salvos=mc_config.sampling.n_salvos,
                        n_shots=mc_config.sampling.n_shots,
                        random_seed=mc_config.sampling.random_seed,
                        precision_label=label,
                        tle_radius_m=precision_cfg.tle_radius_m,
                        tle_fraction=precision_cfg.tle_fraction,
                        cep_radius_m=precision_cfg.cep_radius_m,
                        cep_fraction=precision_cfg.cep_fraction,
                        fixed_bias_deflection_m=precision_cfg.fixed_bias_deflection_m,
                        fixed_bias_range_m=precision_cfg.fixed_bias_range_m,
                        variable_bias_radius_m=precision_cfg.variable_bias_radius_m,
                        variable_bias_fraction=precision_cfg.variable_bias_fraction,
                        pk_thresholds=mc_config.lethality.pk_thresholds,
                        mean_single_shot_pk=result.single_shot_pk_mean,
                        mean_salvo_pk=result.accumulated_pk_mean,
                        rounds_to_kill_grid_npz=str(npz_path),
                        rounds_to_kill_grid_checksum=npz_checksum,
                        rounds_to_kill_pk_threshold=mc_config.lethality.pk_thresholds[0],
                        rounds_to_kill_max_rounds=mc_config.sampling.n_shots,
                        result_npz=str(npz_path),
                        result_npz_checksum=npz_checksum,
                        draws_npz=str(npz_path),  # Draws are in the same NPZ file
                        draws_npz_checksum=npz_checksum,
                        analysis_source="monte_carlo",
                    )
                    db_writer.add_monte_carlo(mc_record)
                    
                except Exception as exc:
                    log.error(f"Precision '{label}' failed: {exc}")
                    import traceback
                    log.error(traceback.format_exc())
    else:
        # Sequential precision execution (single precision or max_workers=1)
        # May use salvo-level parallelism within each precision if enabled
        for idx, precision_cfg in enumerate(mc_config.precisions):
            label = precision_cfg.label
            log.info(f"Running precision config [{idx+1}/{n_precisions}]: '{label}'")
            
            try:
                result, npz_path, npz_checksum, precision_cfg = _analyze_single_precision(
                    pk_hypercube,
                    miss_x_axis,
                    miss_y_axis,
                    hob_axis,
                    vel_axis,
                    aof_axis,
                    precision_cfg,
                    mc_config.sampling.n_salvos,
                    mc_config.sampling.n_shots,
                    mc_config.lethality.pk_thresholds,
                    mc_config.sampling.random_seed,
                    mc_config.sampling.store_detailed_results,
                    output_dir,
                    use_salvo_parallelism,  # Enable salvo parallelism if configured
                    effective_workers,       # Pass worker count for salvo parallelism
                )
                
                log.info(
                    f"  Precision '{label}': mean single-shot Pk={result.single_shot_pk_mean:.4f}, "
                    f"mean salvo Pk={result.accumulated_pk_mean:.4f}"
                )
                
                results_list.append(result)
                
                # Persist to database
                mc_record = MonteCarloAnalysisRecord(
                    hypercube_id=hypercube_record.hypercube_id,
                    n_salvos=mc_config.sampling.n_salvos,
                    n_shots=mc_config.sampling.n_shots,
                    random_seed=mc_config.sampling.random_seed,
                    precision_label=label,
                    tle_radius_m=precision_cfg.tle_radius_m,
                    tle_fraction=precision_cfg.tle_fraction,
                    cep_radius_m=precision_cfg.cep_radius_m,
                    cep_fraction=precision_cfg.cep_fraction,
                    fixed_bias_deflection_m=precision_cfg.fixed_bias_deflection_m,
                    fixed_bias_range_m=precision_cfg.fixed_bias_range_m,
                    variable_bias_radius_m=precision_cfg.variable_bias_radius_m,
                    variable_bias_fraction=precision_cfg.variable_bias_fraction,
                    pk_thresholds=mc_config.lethality.pk_thresholds,
                    mean_single_shot_pk=result.single_shot_pk_mean,
                    mean_salvo_pk=result.accumulated_pk_mean,
                    rounds_to_kill_grid_npz=str(npz_path),
                    rounds_to_kill_grid_checksum=npz_checksum,
                    rounds_to_kill_pk_threshold=mc_config.lethality.pk_thresholds[0],
                    rounds_to_kill_max_rounds=mc_config.sampling.n_shots,
                    result_npz=str(npz_path),
                    result_npz_checksum=npz_checksum,
                    draws_npz=str(npz_path),  # Draws are in the same NPZ file
                    draws_npz_checksum=npz_checksum,
                    analysis_source="monte_carlo",
                )
                db_writer.add_monte_carlo(mc_record)
                
            except Exception as exc:
                log.error(f"Precision '{label}' failed: {exc}")
                import traceback
                log.error(traceback.format_exc())

    mc_elapsed = time.perf_counter() - mc_start
    log.info(f"Monte Carlo analysis elapsed: {mc_elapsed:.2f}s ({n_precisions} precision configs)")

    # Save combined results (if we have results)
    if results_list:
        combined_npz = output_dir / "mc_analysis_combined.npz"
        np.savez_compressed(
            combined_npz,
            precision_labels=[p.label for p in mc_config.precisions],
            pk_thresholds=np.array(mc_config.lethality.pk_thresholds),
            hob_axis=hob_axis,
            vel_axis=vel_axis,
            aof_axis=aof_axis,
            # Stack results along a new axis
            mean_acc_pk_by_shot=np.stack(
                [r.mean_acc_pk_by_shot for r in results_list], axis=0
            ),
            rounds_to_kill=np.stack([r.rounds_to_kill for r in results_list], axis=0),
        )

        log.info(
            f"Monte Carlo analysis complete. {len(results_list)} precision configs processed. "
            f"Combined results saved to {combined_npz}"
        )

    return results_list if results_list else None


def run_discrete_analysis_v3(
    config: CampaignConfig,
    pk_hypercube: np.ndarray,
    miss_x_axis: np.ndarray,
    miss_y_axis: np.ndarray,
    output_dir: Path,
    hypercube_record: HypercubeRecord,
    db_writer: BatchedDBWriter,
    log: logging.Logger,
) -> Optional[DiscreteAnalysisResults]:
    """
    Run v3.0 discrete grid analysis with 4-source error model.
    
    This implements the full nested integration architecture from 
    docs/DISCRETE_ANALYSIS.md for MATLAB MEGADETH parity.
    
    Args:
        config: Campaign configuration with discrete_analysis settings
        pk_hypercube: 5D Pk tensor from HypercubeBuilder [n_mx, n_my, n_h, n_v, n_α]
                      Note: This is the native format from HypercubeBuilder with
                      miss grid axes first (deflection, range), then terminal
                      conditions (hob, velocity, aof).
        miss_x_axis: LAM2 native deflection axis (meters)
        miss_y_axis: LAM2 native range axis (meters)
        output_dir: Directory for output files
        hypercube_record: Parent hypercube record for DB FK
        db_writer: Database writer instance
        log: Logger instance
        
    Returns:
        DiscreteAnalysisResults or None if analysis fails/disabled
    """
    import json
    import hashlib
    
    # Check if discrete analysis is configured
    discrete_cfg = getattr(config, "discrete_analysis", None)
    if discrete_cfg is None or not getattr(discrete_cfg, "enabled", True):
        log.info("Discrete analysis v3.0 not configured or disabled, skipping.")
        return None
    
    # Extract error model parameters from config
    error_cfg = getattr(discrete_cfg, "error_model", None)
    if error_cfg is not None:
        error_sigmas = ErrorSigmas.from_error_model(
            tle_radius_m=getattr(error_cfg, "tle_radius_m", 0.0),
            tle_fraction=getattr(error_cfg, "tle_fraction", 0.5),
            cep_radius_m=getattr(error_cfg, "cep_radius_m", 0.0),
            cep_fraction=getattr(error_cfg, "cep_fraction", 0.5),
            fixed_bias_x_m=getattr(error_cfg, "fixed_bias_x_m", 0.0),
            fixed_bias_y_m=getattr(error_cfg, "fixed_bias_y_m", 0.0),
            variable_bias_radius_m=getattr(error_cfg, "variable_bias_radius_m", 0.0),
            variable_bias_fraction=getattr(error_cfg, "variable_bias_fraction", 0.5),
        )
    else:
        # Default: no error (deterministic)
        error_sigmas = ErrorSigmas(
            sigma_tle=0.0,
            sigma_cep=0.0,
            sigma_var_bias=0.0,
            sigma_salvo=0.0,
            fixed_bias=(0.0, 0.0),
        )
    
    # Extract integration parameters
    integ_cfg = getattr(discrete_cfg, "integration", None)
    integration_method = getattr(integ_cfg, "method", "hybrid_mc") if integ_cfg else "hybrid_mc"
    n_salvo_centers = getattr(integ_cfg, "n_salvo_centers", 31) if integ_cfg else 31
    n_salvos = getattr(integ_cfg, "n_salvos", 2001) if integ_cfg else 2001
    random_seed = getattr(integ_cfg, "random_seed", 314159) if integ_cfg else 314159
    use_convolution = getattr(integ_cfg, "use_convolution", True) if integ_cfg else True
    
    # Extract salvo parameters
    salvo_cfg = getattr(discrete_cfg, "salvo", None)
    max_shots = getattr(salvo_cfg, "max_shots", 10) if salvo_cfg else 10
    pk_thresholds = getattr(salvo_cfg, "pk_thresholds", [0.3, 0.5, 0.7, 0.9]) if salvo_cfg else [0.3, 0.5, 0.7, 0.9]
    
    # Extract delivery error parameters
    delivery_cfg = getattr(discrete_cfg, "delivery_error", None)
    delivery_sigmas = None
    if delivery_cfg is not None:
        delivery_sigmas = {
            "hob": getattr(delivery_cfg, "sigma_hob_m", 0.0),
            "vel": getattr(delivery_cfg, "sigma_velocity_mps", 0.0),
            "aof": getattr(delivery_cfg, "sigma_aof_deg", 0.0),
        }
        # Only use if non-zero
        if all(v == 0 for v in delivery_sigmas.values()):
            delivery_sigmas = None
    
    try:
        # Create analyzer and run full analysis
        # miss_x/y_axis now come from native LAM2 grid, not user-defined config
        analyzer = DiscreteGridAnalyzer(config)
        
        results = analyzer.run_full_analysis(
            pk_det=pk_hypercube,
            miss_x_axis=miss_x_axis,
            miss_y_axis=miss_y_axis,
            hob_axis=np.asarray(config.terminal_conditions.hob.values, dtype=float),
            vel_axis=np.asarray(config.terminal_conditions.velocity.values, dtype=float),
            aof_axis=np.asarray(config.terminal_conditions.aof.values, dtype=float),
            error_sigmas=error_sigmas,
            max_shots=max_shots,
            pk_thresholds=list(pk_thresholds),
            integration_method=integration_method,
            n_salvo_centers=n_salvo_centers,
            n_salvos=n_salvos,
            random_seed=random_seed,
            delivery_sigmas=delivery_sigmas,
            use_convolution=use_convolution,
        )
        
        # Save NPZ outputs
        discrete_npz = output_dir / "discrete_analysis_v3.npz"
        save_dict = {
            "system_pk": results.system_pk,
            "reliability": results.reliability,
            "sensitivity": results.sensitivity,
            "failure_prob": results.failure_prob,
            "hob_axis": results.hob_axis,
            "vel_axis": results.vel_axis,
            "aof_axis": results.aof_axis,
            "pk_thresholds": results.pk_thresholds,
        }
        if results.mean_pk_by_shot is not None:
            save_dict["mean_pk_by_shot"] = results.mean_pk_by_shot
        if results.rounds_to_kill is not None:
            save_dict["rounds_to_kill"] = results.rounds_to_kill
        
        np.savez_compressed(discrete_npz, **save_dict)
        
        # Compute checksum
        with open(discrete_npz, "rb") as f:
            npz_checksum = hashlib.sha256(f.read()).hexdigest()
        
        # Save metadata JSON
        meta_path = output_dir / "discrete_metrics_v3.json"
        with open(meta_path, "w") as f:
            json.dump(results.metadata, f, indent=2)
        
        log.info(
            f"Discrete v3.0 analysis complete: method={results.integration_method}, "
            f"shape={results.system_pk.shape}"
        )
        log.info(f"Discrete v3.0 metrics: {results.metadata}")
        
        # Create DB record
        discrete_analysis_id = str(uuid.uuid4())
        disc_analysis_record = DiscreteAnalysisRecord(
            analysis_id=discrete_analysis_id,
            hypercube_id=hypercube_record.hypercube_id,
            guidance_model_type=integration_method,
            sigma_guid_m=error_sigmas.sigma_salvo,
            sigma_hob_m=delivery_sigmas.get("hob", 0.0) if delivery_sigmas else 0.0,
            sigma_velocity_mps=delivery_sigmas.get("vel", 0.0) if delivery_sigmas else 0.0,
            sigma_aof_deg=delivery_sigmas.get("aof", 0.0) if delivery_sigmas else 0.0,
            kernel_width_sigma=n_salvo_centers,
            pk_threshold=analyzer.pk_threshold,
            gradient_threshold=analyzer.gradient_threshold,
            system_pk_npz=str(discrete_npz),
            reliability_npz=str(discrete_npz),
            sensitivity_npz=str(discrete_npz),
            failure_prob_npz=str(discrete_npz),
        )
        db_writer.add_discrete_analysis(disc_analysis_record)
        
        # Persist metrics record
        disc_metrics = DiscreteMetricsRecord(
            analysis_id=discrete_analysis_id,
            envelope_volume=results.metadata.get("envelope_volume", 0.0),
            integrated_kill_potential=float(results.metadata.get("integrated_kill_potential", 0.0)),
            robust_volume=results.metadata.get("robust_volume", 0.0),
            effective_volume=float(results.metadata.get("effective_volume", 0.0)),
            envelope_cell_count=results.metadata.get("envelope_cell_count", 0),
            robust_cell_count=results.metadata.get("robust_cell_count", 0),
            total_cells=results.metadata.get("total_cells", 0),
            pk_sys_min=float(np.nanmin(results.reliability)),
            pk_sys_max=float(np.nanmax(results.reliability)),
            pk_sys_mean=float(np.nanmean(results.reliability)),
            pk_sys_std=float(np.nanstd(results.reliability)),
            reliability_min=float(np.nanmin(results.reliability)),
            reliability_max=float(np.nanmax(results.reliability)),
            reliability_mean=float(np.nanmean(results.reliability)),
            p_fail_median=float(np.nanmedian(results.failure_prob)),
            p_fail_p90=float(np.nanpercentile(results.failure_prob, 90)),
            p_fail_p99=float(np.nanpercentile(results.failure_prob, 99)),
            gradient_max=float(np.nanmax(results.sensitivity)),
            gradient_mean=float(np.nanmean(results.sensitivity)),
        )
        db_writer.add_discrete_metrics(disc_metrics)
        
        return results
        
    except Exception as exc:
        log.error(f"Discrete v3.0 analysis failed: {exc}")
        import traceback
        log.error(traceback.format_exc())
        return None


def plan_campaign(
    config: Union[CampaignConfig, Mapping],
    adapter: Optional[PlatformAdapter] = None,
    skip_preflight_io: bool = False,
) -> Dict[str, object]:
    """Run preflight, stage work items, and compute worker allocations."""
    cfg = _coerce_config(config)
    preflight = run_preflight(cfg, skip_io_writability=skip_preflight_io, adapter=adapter)
    adapter = adapter or get_platform_adapter()

    staging_path = adapter.prepare_staging_area(preflight.estimated_staging_mb)
    work_items = generate_work_items(cfg)
    worker_allocations = adapter.allocate_workers(len(work_items), preflight.resources)
    shards = shard_work(work_items, len(worker_allocations))

    return {
        "preflight": preflight,
        "staging_path": staging_path,
        "work_items": work_items,
        "worker_allocations": worker_allocations,
        "shards": shards,
    }


def _worker_process_cpp(
    worker_id: int,
    shard: List[WorkItem],
    cdrag_path: Path,
    postprocess_threads: Optional[int] = None,
    matrix_settings: Optional[MatrixSettings] = None,
):
    """
    Execute a shard using C++ physics engine (gfs_physics).
    
    FULLY IN-MEMORY: No subprocess, no file I/O, no staging directory.
    Returns results in the same format as Fortran worker for hypercube builder.
    """
    from megadeth.physics.gfs_engine import GFSEngine
    from megadeth.physics.pfs_io import generate_ip_dat_content
    
    # Create engine and load static data
    engine = GFSEngine()
    engine.load_cdrag(cdrag_path)
    
    results = []
    ms = matrix_settings or MatrixSettings()
    
    # Process each work item - loop is more cache-friendly than huge batch
    for item in shard:
        cond = item.condition
        wh = item.warhead
        tgt = item.target
        
        # Load warhead/target data if not loaded
        if not engine._ctx.has_zdata(wh.zdata_number):
            engine.load_zdata(wh.zdata_number, wh.zdata_path)
        if not engine._ctx.has_rcas(tgt.rcas_number):
            engine.load_rcas(tgt.rcas_number, tgt.rcas_path, tgt.intrvc_path)
        
        # Generate IP.DAT content directly in memory (no temp file)
        tch_ft = getattr(tgt, 'centroid_height_ft', 0.0) or 0.0
        ip_content = generate_ip_dat_content(
            tgt.rcas_number, 
            wh.zdata_number, 
            cond, 
            tch_ft,
            matrix_settings=ms,
        )
        
        # Run through C++ engine - returns LAM2Result objects directly
        lam2_results = engine.run_batch(ip_content, [cond])
        
        # Extend results (each call returns list with 1 item)
        results.extend(lam2_results)
    
    return results


def _worker_process(
    worker_id: int,
    shard: List[WorkItem],
    staging_path: Path,
    fsm_exe_path: Path,
    cdrag_path: Path,
    staging_strategy: str = "batched",
    postprocess_threads: Optional[int] = None,
    save_ipdat_sample: bool = False,
    matrix_settings: Optional[MatrixSettings] = None,
    backend: PhysicsBackend = PhysicsBackend.FORTRAN,
):
    """Execute a shard of work items in an isolated worker sandbox."""
    # C++ backend path
    if backend == PhysicsBackend.CPP:
        return _worker_process_cpp(
            worker_id, shard, cdrag_path, 
            postprocess_threads, matrix_settings,
        )
    
    # Fortran backend (default)
    sandbox = WorkerSandbox(
        worker_id=worker_id,
        staging_path=staging_path,
        fsm_exe_path=fsm_exe_path,
        cdrag_path=cdrag_path,
        isolated_runs=staging_strategy == "per_job",
        save_ipdat_sample=save_ipdat_sample,
        matrix_settings=matrix_settings,
    )
    sandbox.initialize()

    results = []
    try:
        if staging_strategy == "per_job":
            for item in shard:
                sandbox.prepare_batch([item])
                success = sandbox.execute(timeout=30.0)  # Single item = 30s
                if success:
                    results.extend(
                        sandbox.extract_results([item], max_threads=postprocess_threads)
                    )
                sandbox.cleanup_run()
        else:
            sandbox.prepare_batch(shard)
            # Dynamic timeout: 30s base + 0.5s per work item (matches fullspray_wrapper pattern)
            dynamic_timeout = 30.0 + (len(shard) * 0.5)
            success = sandbox.execute(timeout=dynamic_timeout)
            if success:
                results = sandbox.extract_results(shard, max_threads=postprocess_threads)
            sandbox.cleanup_run()
    except Exception as exc:
        print(f"[Worker {worker_id}] Error on shard: {exc}")

    sandbox.destroy()
    return results


def run_campaign(
    config: Union[CampaignConfig, Mapping],
    adapter: Optional[PlatformAdapter] = None,
    skip_preflight_io: bool = False,
    db_path: Optional[Path] = None,
    rounds_to_kill_pk_threshold: float = 0.9,
    rounds_to_kill_max_rounds: int = 10,
    pk_sys: Optional[np.ndarray] = None,
    analysis_source: str = "deterministic",
    log_path: Optional[Path] = None,
    staging_strategy: Optional[str] = None,
) -> Dict[str, object]:
    """
    Main campaign orchestrator.

    Runs preflight, stages work, executes FullSpray in parallel, and builds NPZ.
    """
    cfg = _coerce_config(config)
    if len(cfg.warheads) != 1:
        raise ValueError(
            "run_campaign supports a single warhead per invocation. "
            "Use run_targets_separately or loop externally for multiple warheads."
        )
    if len(cfg.targets) != 1:
        raise ValueError(
            "run_campaign supports a single target per invocation. "
            "Use run_targets_separately to iterate targets."
        )
    effective_staging_strategy = (staging_strategy or cfg.execution.staging_strategy).lower()
    if effective_staging_strategy not in {"batched", "per_job"}:
        raise ValueError(
            f"Invalid staging strategy '{effective_staging_strategy}'. Use 'batched' or 'per_job'."
        )
    plan = plan_campaign(cfg, adapter=adapter, skip_preflight_io=skip_preflight_io)
    preflight: PreflightReport = plan["preflight"]  # type: ignore[assignment]

    staging_path: Path = plan["staging_path"]  # type: ignore[assignment]
    work_items: List[WorkItem] = plan["work_items"]  # type: ignore[assignment]
    worker_allocations = plan["worker_allocations"]
    shards: List[List[WorkItem]] = plan["shards"]  # type: ignore[assignment]

    output_dir = Path(cfg.output.directory)
    output_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_path or output_dir / "megadeth.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(),
        ],
    )
    log = logging.getLogger("megadeth")

    start_time = time.perf_counter()
    log.info("Preflight complete. Runtime est: %.1fs", preflight.estimated_runtime_sec)
    log.info("Total work items: %d | Workers: %d", len(work_items), len(worker_allocations))

    # Backend selection: cpp or fortran (default)
    backend = get_backend_from_config(cfg)
    
    fsm_exe_path = Path(cfg.solver.fsm_exe_path) if cfg.solver.fsm_exe_path else select_executable()
    cdrag_path = Path(cfg.solver.cdrag_path) if cfg.solver.cdrag_path else get_data_directory() / "CDRAG1.DAT"
    postprocess_threads = cfg.execution.postprocess_threads or os.cpu_count() or 1
    
    # Log appropriately based on backend
    if backend == PhysicsBackend.CPP:
        log.info("Physics backend: cpp (in-memory, no staging)")
    else:
        log.info("Staging: %s | Strategy: %s", staging_path, effective_staging_strategy)
        log.info("Physics backend: fortran (subprocess)")

    matrix_settings: Optional[MatrixSettings] = None
    if cfg.matrix is not None:
        ms = MatrixSettings()
        if cfg.matrix.nx or cfg.matrix.ny:
            nx = cfg.matrix.nx if cfg.matrix.nx is not None else ms.dimensions[0]
            ny = cfg.matrix.ny if cfg.matrix.ny is not None else ms.dimensions[1]
            ms.dimensions = (nx, ny)
        if cfg.matrix.cell_size_m is not None:
            ms.cell_size_m = cfg.matrix.cell_size_m
        if cfg.matrix.range_offset_m is not None:
            ms.range_offset_m = cfg.matrix.range_offset_m
        matrix_settings = ms

    # Compute true machine balance: CPU throughput vs DB write throughput
    # Goal: balance ≈ 1.0 means CPU and I/O are matched
    num_workers = len(worker_allocations)
    total_items = len(work_items)
    avg_eval_sec = 0.1  # ~100ms per FSM evaluation (from resource_estimator)
    
    # CPU throughput: items per second across all workers
    cpu_throughput_items_per_sec = num_workers / avg_eval_sec
    
    # DB throughput estimation: measure or estimate based on disk write speed
    # Each physics result is ~1-2 KB of DB data; use 2 KB as conservative estimate
    db_record_size_kb = 2.0
    disk_write_mbps = preflight.io_benchmarks.get("disk_write_mbps", 100.0)  # fallback 100 MB/s
    db_throughput_items_per_sec = (disk_write_mbps * 1024) / db_record_size_kb
    
    # True machine balance: how many times faster is CPU than DB?
    # balance > 1 means CPU faster than DB (rare - increase batch to reduce transaction overhead)
    # balance < 1 means DB faster than CPU (common - batch size less critical)
    true_balance = cpu_throughput_items_per_sec / max(db_throughput_items_per_sec, 1e-6)
    
    # Auto-tune batch size based on workload characteristics
    # For CPU-bound workloads (balance << 1): use moderate batches, DB can easily keep up
    # For I/O-bound workloads (balance >> 1): use large batches to reduce transaction overhead
    if true_balance < 0.1:
        # Very CPU-bound: DB is 10x+ faster than CPU production rate
        # Use batch size based on total work and runtime to minimize transactions.
        # Target: ~10-20 transactions total for smooth progress reporting
        db_batch_size = max(500, total_items // 20)
    elif true_balance < 1.0:
        # Moderately CPU-bound: scale batch with work size
        db_batch_size = max(500, total_items // 50)
    else:
        # I/O-bound: maximize batch to reduce transaction overhead
        db_batch_size = max(1000, int(500 * min(true_balance, 10.0)))
    
    # Clamp to reasonable bounds
    db_batch_size = max(100, min(db_batch_size, 5000))
    
    # Memory constraint: reduce if low memory
    if preflight.resources.available_memory_gb < 4:
        db_batch_size = max(100, db_batch_size // 2)
    
    log.info(
        "DB batch size selected: %d (cpu=%.1f items/s, db=%.1f items/s, balance=%.3f)",
        db_batch_size, cpu_throughput_items_per_sec, db_throughput_items_per_sec, true_balance
    )

    db_writer = BatchedDBWriter(
        db_path or Path(cfg.output.directory) / "megadeth.duckdb",
        async_flush=False,
        batch_size=db_batch_size,
    )

    campaign_id = getattr(cfg, "campaign_id", None) or f"{cfg.name}-{uuid.uuid4()}"

    # Register campaign/warheads/targets metadata (flush immediately to satisfy FKs)
    log.info("Inserting campaign metadata...")
    db_writer.add_campaign(
        CampaignRecord(
            campaign_id=campaign_id,
            name=cfg.name,
            description=cfg.description,
            config_yaml=None,
            status="completed",
        )
    )
    db_writer.flush()

    for idx, wh in enumerate(cfg.warheads):
        wid = int(getattr(wh, "warhead_id", wh.zdata_number))
        db_writer.add_warhead(
            WarheadRecord(
                warhead_id=wid,
                warhead_name=f"ZDATA{wh.zdata_number}",
                zdata_number=wh.zdata_number,
                zdata_path=str(wh.zdata_path),
            )
        )
    for idx, tgt in enumerate(cfg.targets):
        tid = int(getattr(tgt, "target_id", tgt.rcas_number))
        db_writer.add_target(
            TargetRecord(
                target_id=tid,
                target_name=f"RCAS{tgt.rcas_number}",
                rcas_number=tgt.rcas_number,
                centroid_height_ft=tgt.centroid_height_ft,
            )
        )
    db_writer.flush()

    all_results = []
    physics_records: List[PhysicsRunRecord] = []
    # lam2_records removed - redundant with hypercube NPZ
    success_count = 0
    fail_count = 0
    log.info("Sharding complete. Beginning execution...")
    if len(worker_allocations) <= 1:
        results = _worker_process(
            worker_id=0,
            shard=shards[0],
            staging_path=staging_path,
            fsm_exe_path=fsm_exe_path,
            cdrag_path=cdrag_path,
            staging_strategy=effective_staging_strategy,
            postprocess_threads=postprocess_threads,
            save_ipdat_sample=cfg.debug.save_ipdat_sample,
            matrix_settings=matrix_settings,
            backend=backend,
        )
        all_results.extend(results)
        success_count = len(results)
        fail_count = len(shards[0]) - len(results)
    else:
        exec_start = time.perf_counter()
        with ProcessPoolExecutor(max_workers=len(worker_allocations)) as executor:
            futures = {
                executor.submit(
                    _worker_process,
                    alloc.worker_id,
                    shards[i],
                    staging_path,
                    fsm_exe_path,
                    cdrag_path,
                    effective_staging_strategy,
                    postprocess_threads,
                    cfg.debug.save_ipdat_sample,
                    matrix_settings,
                    backend,
                ): alloc.worker_id
                for i, alloc in enumerate(worker_allocations)
            }
            for future in as_completed(futures):
                worker_id = futures[future]
                try:
                    results = future.result()
                    all_results.extend(results)
                    success_count += len(results)
                    shard_fail = len(shards[worker_id]) - len(results)
                    fail_count += shard_fail
                    log.info(
                        "Worker %d completed: %d results, failed: %d",
                        worker_id,
                        len(results),
                        shard_fail,
                    )
                except Exception as exc:
                    log.error("Worker %d failed: %s", worker_id, exc)
                    fail_count += len(shards[worker_id])
        log.info("Parallel execution elapsed: %.2fs", time.perf_counter() - exec_start)

    # Persist physics runs and LAM2 grids
    warhead_id_map = {wh.zdata_number: int(getattr(wh, "warhead_id", wh.zdata_number)) for wh in cfg.warheads}
    target_id_map = {tgt.rcas_number: int(getattr(tgt, "target_id", tgt.rcas_number)) for tgt in cfg.targets}

    for res in all_results:
        physics_records.append(
            PhysicsRunRecord(
                campaign_id=campaign_id,
                warhead_id=warhead_id_map.get(res.zdata, res.zdata),
                target_id=target_id_map.get(res.rcas, res.rcas),
                hob_m=res.condition.hob_m,
                velocity_mps=res.condition.velocity_mps,
                aof_deg=res.condition.aof_deg,
                miss_deflection_m=res.condition.miss_deflection_m,
                miss_range_m=res.condition.miss_range_m,
                pk_theoretical=None,
                solver_runtime_ms=None,
            )
        )
        # NOTE: LAM2 grid records are no longer built - they're redundant with
        # the hypercube NPZ and were causing ~890MB+ of slow DB inserts

    # Insert dependent records only once per campaign
    # NOTE: LAM2 grid inserts are skipped - individual grids are redundant with
    # the aggregated hypercube NPZ. This saves ~890MB+ of DB writes for large campaigns.
    log.info("Inserting physics runs (LAM2 grids skipped - using hypercube NPZ)...")
    for rec in physics_records:
        db_writer.add_physics_run(rec)
    # Skip LAM2 grid inserts - redundant with hypercube
    # for rec in lam2_records:
    #     db_writer.add_lam2_grid(rec)
    flush_counts = db_writer.flush()

    builder = HypercubeBuilder(
        hob_axis=cfg.terminal_conditions.hob.values,
        velocity_axis=cfg.terminal_conditions.velocity.values,
        aof_axis=cfg.terminal_conditions.aof.values,
        miss_x_axis=None,  # Use native LAM2 grid
        miss_y_axis=None,  # Use native LAM2 grid
        apply_shift_range=False,  # No shift in native mode
        use_native_lam2_grid=True,
    )

    for result in all_results:
        builder.add_lam2_result(result)
    
    # Extract miss axes from builder (populated from first LAM2 result)
    miss_x_axis = builder.axes.get("miss_x")
    miss_y_axis = builder.axes.get("miss_y")
    if miss_x_axis is None or miss_y_axis is None:
        log.error("Failed to extract native LAM2 grid axes")
        return None
    
    log.info(f"Using native LAM2 grid: {len(miss_x_axis)} × {len(miss_y_axis)}")

    output_dir = Path(cfg.output.directory)
    output_dir.mkdir(parents=True, exist_ok=True)
    npz_path = output_dir / "pk_hypercube.npz"
    checksum = builder.save_npz(npz_path)

    hypercube_record = HypercubeRecord(
        campaign_id=campaign_id,
        warhead_id=cfg.warheads[0].zdata_number,
        target_id=cfg.targets[0].rcas_number,
        hob_axis=cfg.terminal_conditions.hob.values,
        velocity_axis=cfg.terminal_conditions.velocity.values,
        aof_axis=cfg.terminal_conditions.aof.values,
        miss_x_axis=list(miss_x_axis),  # From native LAM2 grid
        miss_y_axis=list(miss_y_axis),  # From native LAM2 grid
        npz_path=str(npz_path),
        npz_checksum=checksum,
    )
    db_writer.add_hypercube(hypercube_record)

    # =========================================================================
    # Monte Carlo Analysis Path (MEGADETH Parity)
    # =========================================================================
    mc_results = None
    if cfg.monte_carlo.enabled:
        try:
            mc_results = run_monte_carlo_analysis(
                config=cfg,
                pk_hypercube=builder.pk_hypercube,
                miss_x_axis=np.asarray(miss_x_axis),
                miss_y_axis=np.asarray(miss_y_axis),
                output_dir=output_dir,
                hypercube_record=hypercube_record,
                db_writer=db_writer,
                log=log,
                max_workers=cfg.execution.max_parallel_workers,
                enable_parallel_salvos=(
                    cfg.execution.max_parallel_workers is None
                    or cfg.execution.max_parallel_workers > 1
                ),
            )
        except Exception as exc:
            log.error("Monte Carlo analysis failed: %s", exc)
            import traceback
            log.error(traceback.format_exc())

    # =========================================================================
    # Discrete Analysis v3.0 (4-source error model, nested integration)
    # =========================================================================
    discrete_results_v3 = None
    disc_enabled = (
        hasattr(cfg, "discrete_analysis") 
        and cfg.discrete_analysis is not None
        and getattr(cfg.discrete_analysis, "enabled", False)
    )
    if disc_enabled:
        discrete_results_v3 = run_discrete_analysis_v3(
            config=cfg,
            pk_hypercube=builder.pk_hypercube,
            miss_x_axis=np.asarray(miss_x_axis),
            miss_y_axis=np.asarray(miss_y_axis),
            output_dir=output_dir,
            hypercube_record=hypercube_record,
            db_writer=db_writer,
            log=log,
        )

    # Legacy discrete analysis fallback (for backwards compatibility)
    # Only run if discrete v3 didn't run AND MC is not enabled
    discrete_results = None
    discrete_analysis_id = None
    mc_enabled = cfg.monte_carlo.enabled if hasattr(cfg, 'monte_carlo') and cfg.monte_carlo else False
    run_legacy_discrete = discrete_results_v3 is None and not mc_enabled
    if run_legacy_discrete:
        try:
            analyzer = DiscreteGridAnalyzer(cfg)
            sigma_guid = 0.0
            sigma_hob = 0.0
            sigma_vel = 0.0
            sigma_aof = 0.0
            # Use native LAM2 grid axes extracted from builder
            discrete_results = analyzer.analyze(
                pk_det=builder.pk_hypercube,
                miss_x_axis=miss_x_axis,
                miss_y_axis=miss_y_axis,
                hob_axis=cfg.terminal_conditions.hob.values,
                vel_axis=cfg.terminal_conditions.velocity.values,
                aof_axis=cfg.terminal_conditions.aof.values,
                sigma_guid_m=sigma_guid,
                sigma_hob_m=sigma_hob,
                sigma_velocity_mps=sigma_vel,
                sigma_aof_deg=sigma_aof,
            )
            discrete_analysis_id = str(uuid.uuid4())
        except Exception as exc:
            log.error("Legacy discrete analysis failed: %s", exc)

    # Determine Pk source for rounds-to-kill computation
    pk_sys_used = pk_sys
    source_used = analysis_source
    if pk_sys_used is None and "pk_sys" in plan:
        pk_sys_used = plan["pk_sys"]  # type: ignore[index]
        source_used = getattr(plan, "analysis_source", source_used)
    if pk_sys_used is None and discrete_results_v3 is not None:
        pk_sys_used = discrete_results_v3.reliability
        source_used = "discrete_v3"
    if pk_sys_used is None and discrete_results is not None:
        pk_sys_used = discrete_results.reliability
        source_used = "discrete"
    if pk_sys_used is None:
        # fallback: deterministic mean across miss axes
        pk_sys_used = builder.pk_hypercube.mean(axis=(-2, -1))
        source_used = "deterministic_mean"

    # Save legacy discrete results if used (v3 saves within run_discrete_analysis_v3)
    if discrete_results is not None:
        discrete_npz = output_dir / "discrete_analysis.npz"
        np.savez_compressed(
            discrete_npz,
            system_pk=discrete_results.system_pk,
            reliability=discrete_results.reliability,
            sensitivity=discrete_results.sensitivity,
            failure_prob=discrete_results.failure_prob,
        )
        meta_path = output_dir / "discrete_metrics.json"
        import json

        with open(meta_path, "w") as f:
            json.dump(discrete_results.metadata, f, indent=2)
        log.info(
            "Discrete analysis metrics: %s",
            discrete_results.metadata,
        )
        disc_analysis_record = DiscreteAnalysisRecord(
            analysis_id=discrete_analysis_id or str(uuid.uuid4()),
            hypercube_id=hypercube_record.hypercube_id,
            guidance_model_type="gaussian",
            sigma_guid_m=sigma_guid,
            sigma_hob_m=sigma_hob,
            sigma_velocity_mps=sigma_vel,
            sigma_aof_deg=sigma_aof,
            kernel_width_sigma=None,
            pk_threshold=analyzer.pk_threshold,
            gradient_threshold=analyzer.gradient_threshold,
            system_pk_npz=str(discrete_npz),
            reliability_npz=str(discrete_npz),
            sensitivity_npz=str(discrete_npz),
            failure_prob_npz=str(discrete_npz),
        )
        db_writer.add_discrete_analysis(disc_analysis_record)
        # Persist discrete metrics in DB
        disc_record = DiscreteMetricsRecord(
            analysis_id=disc_analysis_record.analysis_id,
            envelope_volume=discrete_results.metadata.get("envelope_volume", 0.0),
            integrated_kill_potential=float(discrete_results.metadata.get("integrated_kill_potential", 0.0)),
            robust_volume=discrete_results.metadata.get("robust_volume", 0.0),
            effective_volume=float(discrete_results.metadata.get("effective_volume", 0.0)),
            envelope_cell_count=discrete_results.metadata.get("envelope_cell_count", 0),
            robust_cell_count=discrete_results.metadata.get("robust_cell_count", 0),
            total_cells=discrete_results.metadata.get("total_cells", 0),
            pk_sys_min=float(np.nanmin(discrete_results.reliability)),
            pk_sys_max=float(np.nanmax(discrete_results.reliability)),
            pk_sys_mean=float(np.nanmean(discrete_results.reliability)),
            pk_sys_std=float(np.nanstd(discrete_results.reliability)),
            reliability_min=float(np.nanmin(discrete_results.reliability)),
            reliability_max=float(np.nanmax(discrete_results.reliability)),
            reliability_mean=float(np.nanmean(discrete_results.reliability)),
            p_fail_median=float(np.nanmedian(discrete_results.failure_prob)),
            p_fail_p90=float(np.nanpercentile(discrete_results.failure_prob, 90)),
            p_fail_p99=float(np.nanpercentile(discrete_results.failure_prob, 99)),
            gradient_max=float(np.nanmax(discrete_results.sensitivity)),
            gradient_mean=float(np.nanmean(discrete_results.sensitivity)),
        )
        db_writer.add_discrete_metrics(disc_record)

    # Compute rounds-to-kill grid from Pk source
    try:
        pk_sys_used = np.nan_to_num(pk_sys_used, nan=0.0, posinf=1.0, neginf=0.0)
        r2k_grid = compute_rounds_to_kill_grid(
            pk_sys_used,
            pk_threshold=rounds_to_kill_pk_threshold,
            max_rounds=rounds_to_kill_max_rounds,
        )
        r2k_path = output_dir / "rounds_to_kill.npz"
        np.savez_compressed(r2k_path, rounds_to_kill=r2k_grid)
        with open(r2k_path, "rb") as f:
            import hashlib

            r2k_checksum = hashlib.sha256(f.read()).hexdigest()
        mc_record = MonteCarloAnalysisRecord(
            hypercube_id=hypercube_record.hypercube_id,
            rounds_to_kill_grid_npz=str(r2k_path),
            rounds_to_kill_grid_checksum=r2k_checksum,
            rounds_to_kill_pk_threshold=rounds_to_kill_pk_threshold,
            rounds_to_kill_max_rounds=rounds_to_kill_max_rounds,
            analysis_source=source_used,
            coordinate_frame="weapon",
            matlab_parity_sampling=getattr(getattr(cfg, "analysis", None), "matlab_parity_sampling", None),
            runtime_sec=time.perf_counter() - start_time,
        )
        db_writer.add_monte_carlo(mc_record)
    except Exception as exc:
        log.error("Rounds-to-kill computation failed: %s", exc)

    # Final flush after Monte Carlo and discrete metrics
    final_flush_counts = db_writer.flush()
    db_writer.close()

    log.info("Hypercube built from %d results.", len(all_results))
    log.info("Saved to %s (sha256: %s)", npz_path, checksum)
    log.info("Run summary: success=%d, failed=%d", success_count, fail_count)
    log.info("DB flush completed. Counts: %s %s", flush_counts, final_flush_counts)
    log.info("Total elapsed: %.2fs", time.perf_counter() - start_time)
    return {"npz_path": npz_path, "checksum": checksum, "staging_path": staging_path}


def run_targets_separately(
    config: Union[CampaignConfig, Mapping],
    base_output_dir: Optional[Path] = None,
    adapter: Optional[PlatformAdapter] = None,
    db_path: Optional[Path] = None,
    rounds_to_kill_pk_threshold: float = 0.9,
    rounds_to_kill_max_rounds: int = 10,
    analysis_source: str = "deterministic",
    log_path: Optional[Path] = None,
) -> List[Dict[str, object]]:
    """
    Convenience wrapper to execute one campaign per target.
    
    Ensures:
        - Exactly one warhead per run
        - Exactly one target per run
        - Output directory per target: ./tgt{rcas}_zdata{zdata}_out (under base_output_dir if provided)
        - Single-worker execution (max_parallel_workers = 1)
        - Batched staging strategy
    """
    cfg = _coerce_config(config)
    if len(cfg.warheads) != 1:
        raise ValueError("run_targets_separately requires exactly one warhead in the config.")
    
    results: List[Dict[str, object]] = []
    warhead = cfg.warheads[0]
    base_dir = Path(base_output_dir) if base_output_dir else Path(cfg.output.directory)
    
    for tgt in cfg.targets:
        cfg_copy: CampaignConfig = cfg.model_copy(deep=True)
        cfg_copy.warheads = [warhead]
        cfg_copy.targets = [tgt]
        campaign_stub = f"tgt{tgt.rcas_number}_zdata{warhead.zdata_number}"
        cfg_copy.name = campaign_stub
        cfg_copy.output.directory = base_dir / f"{campaign_stub}_out"
        cfg_copy.execution.max_parallel_workers = 1
        staging_strategy = "batched"
        
        run_result = run_campaign(
            config=cfg_copy,
            adapter=adapter,
            db_path=db_path,
            rounds_to_kill_pk_threshold=rounds_to_kill_pk_threshold,
            rounds_to_kill_max_rounds=rounds_to_kill_max_rounds,
            analysis_source=analysis_source,
            log_path=log_path,
            staging_strategy=staging_strategy,
        )
        results.append(
            {
                "target_id": tgt.rcas_number,
                "campaign_name": campaign_stub,
                "output_dir": cfg_copy.output.directory,
                "result": run_result,
            }
        )
    return results
