"""
MEGADETH Visualization Module - MEGADETH Parity

Implements visualization functions matching MATLAB MEGADETH legacy plots:
- MEGADETH_SalvoBoxPlot_v01h.m: Box plots for rounds-to-kill
- plotNRbox4.m: T/O stoplight grids
- plotSinglHobMR2a.m: HOB-MR contour plots

Reference: docs/MONTE_CARLO_ANALYSIS.md Section 6.1
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple, Union

import numpy as np


# =============================================================================
# Standard Styles and Constants
# =============================================================================

# Standard color palette for multi-method comparisons
MEGADETH_COLORS = {
    "matlab": "#1f77b4",
    "python_mc": "#ff7f0e", 
    "python_discrete": "#2ca02c",
    "primary": "#1f77b4",
    "secondary": "#ff7f0e",
    "tertiary": "#2ca02c",
}

# Standard markers and linestyles
MEGADETH_MARKERS = {"matlab": "o", "python_mc": "s", "python_discrete": "^"}
MEGADETH_LINESTYLES = {"matlab": "-", "python_mc": "--", "python_discrete": ":"}
MEGADETH_LABELS = {"matlab": "MATLAB", "python_mc": "Python MC", "python_discrete": "Python Discrete"}

# Standard figure sizes
FIGSIZE_STANDARD = (10, 8)
FIGSIZE_WIDE = (12, 6)
FIGSIZE_SMALL = (8, 6)

# Standard DPI
DPI_SCREEN = 150
DPI_PRINT = 200


def create_blue_red_colormap(n_levels: int = 101, legacy_white_red: bool = False):
    """blue_red colormap (white→blue→red) with legacy fallback.

    Args:
        n_levels: Number of discrete color levels (MATLAB default is 101).
        legacy_white_red: If True, return the previous white→red ramp.
    """

    try:
        import matplotlib.colors as mcolors  # type: ignore
    except Exception as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc

    if legacy_white_red:
        colors = [
            (1.0, 1.0, 1.0),
            (1.0, 0.9, 0.9),
            (1.0, 0.6, 0.6),
            (1.0, 0.3, 0.3),
            (0.7, 0.0, 0.0),
        ]
        return mcolors.LinearSegmentedColormap.from_list("blue_red_white_red", colors, N=max(3, n_levels))

    # MATLAB blue_red: white → blue → red, symmetric around mid-range.
    colors = [(1.0, 1.0, 1.0), (0.0, 0.2, 0.9), (0.9, 0.0, 0.0)]
    return mcolors.LinearSegmentedColormap.from_list("blue_red_wbr", colors, N=max(3, n_levels))


def create_r2k_colormap():
    """Green→Yellow→Red colormap for rounds-to-kill (inverted RdYlGn)."""
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc
    return plt.cm.RdYlGn_r


# =============================================================================
# Generic Pk Heatmap / Contour Functions (SHARED)
# =============================================================================

def plot_pk_heatmap(
    pk_slice: np.ndarray,
    x_axis: np.ndarray,
    y_axis: np.ndarray,
    x_label: str = "X",
    y_label: str = "Y",
    title: str = "Pk Heatmap",
    levels: int = 20,
    vmin: float = 0.0,
    vmax: float = 1.0,
    contour_lines: Optional[List[float]] = None,
    cbar_label: str = "Pk",
    figsize: Tuple[float, float] = FIGSIZE_STANDARD,
    cmap=None,
    show_colorbar: bool = True,
    crosshairs: bool = False,
    equal_aspect: bool = False,
    save_path: Optional[Path] = None,
    dpi: int = DPI_PRINT,
):
    """
    Generic 2D Pk heatmap/contour plot.
    
    This is the unified function for heatmaps used by both CLI and verification.
    
    Args:
        pk_slice: 2D array of Pk values, shape (n_x, n_y)
        x_axis: X-axis values
        y_axis: Y-axis values
        x_label: X-axis label
        y_label: Y-axis label
        title: Plot title
        levels: Number of contour levels
        vmin, vmax: Colormap range
        contour_lines: Optional list of Pk values for black contour lines
        cbar_label: Colorbar label
        figsize: Figure size tuple
        cmap: Colormap (defaults to blue_red)
        show_colorbar: Whether to show colorbar
        crosshairs: Whether to draw crosshairs at origin
        equal_aspect: Whether to use equal aspect ratio
        save_path: If provided, save to this path
        dpi: DPI for saving
        
    Returns:
        (fig, ax) tuple
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc
    
    if cmap is None:
        cmap = create_blue_red_colormap()
    
    fig, ax = plt.subplots(figsize=figsize)
    
    X, Y = np.meshgrid(x_axis, y_axis, indexing="ij")
    
    cs = ax.contourf(X, Y, pk_slice, levels=levels, cmap=cmap, vmin=vmin, vmax=vmax)
    
    if contour_lines:
        ax.contour(X, Y, pk_slice, levels=contour_lines, colors='k', linewidths=0.5)
    
    ax.set_xlabel(x_label, fontsize=12)
    ax.set_ylabel(y_label, fontsize=12)
    ax.set_title(title, fontsize=14)
    
    if show_colorbar:
        cbar = fig.colorbar(cs, ax=ax, label=cbar_label)
        # Add 50% reference line on colorbar
        if vmin <= 0.5 <= vmax:
            cbar.ax.axhline(y=0.5, color='white', linewidth=2, linestyle='--')
    
    if crosshairs:
        ax.axhline(0, color='k', linewidth=0.5, alpha=0.5)
        ax.axvline(0, color='k', linewidth=0.5, alpha=0.5)
    
    if equal_aspect:
        ax.set_aspect('equal')
    
    plt.tight_layout()
    
    if save_path:
        fig.savefig(save_path, dpi=dpi, bbox_inches='tight')
        plt.close(fig)
    
    return fig, ax


def plot_pk_pcolormesh(
    pk_slice: np.ndarray,
    x_axis: np.ndarray,
    y_axis: np.ndarray,
    x_label: str = "X",
    y_label: str = "Y",
    title: str = "Pk Heatmap",
    vmin: float = 0.0,
    vmax: float = 1.0,
    cbar_label: str = "Pk",
    figsize: Tuple[float, float] = FIGSIZE_STANDARD,
    cmap=None,
    crosshairs: bool = True,
    equal_aspect: bool = True,
    save_path: Optional[Path] = None,
    dpi: int = DPI_PRINT,
):
    """
    Pk heatmap using pcolormesh (for rectangular grids without interpolation).
    
    Use this for verification/comparison plots where exact grid values matter.
    
    Args:
        pk_slice: 2D array shape (n_x, n_y)
        x_axis, y_axis: Axis arrays
        ... (same as plot_pk_heatmap)
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc
    
    if cmap is None:
        cmap = create_blue_red_colormap()
    
    fig, ax = plt.subplots(figsize=figsize)
    
    X, Y = np.meshgrid(x_axis, y_axis, indexing="ij")
    
    im = ax.pcolormesh(X, Y, pk_slice, cmap=cmap, vmin=vmin, vmax=vmax, shading="auto")
    
    ax.set_xlabel(x_label, fontsize=12)
    ax.set_ylabel(y_label, fontsize=12)
    ax.set_title(title, fontsize=14)
    
    cbar = fig.colorbar(im, ax=ax, label=cbar_label, shrink=0.8)
    cbar.set_ticks([0, 0.25, 0.5, 0.75, 1.0])
    
    if crosshairs:
        ax.axhline(0, color='k', linewidth=0.5, alpha=0.5)
        ax.axvline(0, color='k', linewidth=0.5, alpha=0.5)
    
    if equal_aspect:
        ax.set_aspect('equal')
    
    plt.tight_layout()
    
    if save_path:
        fig.savefig(save_path, dpi=dpi, bbox_inches='tight')
        plt.close(fig)
    
    return fig, ax


# =============================================================================
# HOB-MR Radial Averaging (SHARED)
# =============================================================================

def compute_hob_mr_grid(
    pk_hypercube: np.ndarray,
    hob_axis: np.ndarray,
    deflection_axis: np.ndarray,
    range_axis: np.ndarray,
    i_vel: int,
    i_aof: int,
    n_mr_points: int = 50,
    n_angles: int = 36,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute HOB vs Miss-Range Pk grid by radial averaging.
    
    Takes a 5D hypercube slice at fixed VEL/AOF and computes the Pk
    as a function of HOB and radial miss distance by averaging over angles.
    
    Hypercube shape must be: (miss_x, miss_y, n_hob, n_vel, n_aof) [native format]
    
    Args:
        pk_hypercube: 5D Pk array, shape (miss_x, miss_y, n_hob, n_vel, n_aof)
        hob_axis: HOB values
        deflection_axis: Miss-X (deflection) axis
        range_axis: Miss-Y (range) axis
        i_vel: Velocity index
        i_aof: AOF index
        n_mr_points: Number of miss-range points
        n_angles: Number of angles for radial sampling
        
    Returns:
        (mr_axis, pk_hob_mr) where pk_hob_mr has shape (n_hob, n_mr)
    """
    # Compute max miss radius from axes
    max_range = max(np.abs(deflection_axis).max(), np.abs(range_axis).max())
    mr_axis = np.linspace(0, max_range, n_mr_points)
    
    pk_hob_mr = np.zeros((len(hob_axis), len(mr_axis)))
    angles = np.linspace(0, 2 * np.pi, n_angles, endpoint=False)
    
    for i_hob in range(len(hob_axis)):
        # Extract 2D slice: shape is (miss_x, miss_y)
        pk_2d = pk_hypercube[:, :, i_hob, i_vel, i_aof]
        
        for i_mr, mr in enumerate(mr_axis):
            if mr < 0.1:
                # Near origin - use center value
                i_center_x = len(deflection_axis) // 2
                i_center_y = len(range_axis) // 2
                pk_hob_mr[i_hob, i_mr] = pk_2d[i_center_x, i_center_y]
            else:
                # Sample around circle at this radius
                pk_samples = []
                for theta in angles:
                    x = mr * np.cos(theta)
                    y = mr * np.sin(theta)
                    i_x = np.argmin(np.abs(deflection_axis - x))
                    i_y = np.argmin(np.abs(range_axis - y))
                    if 0 <= i_x < pk_2d.shape[0] and 0 <= i_y < pk_2d.shape[1]:
                        pk_samples.append(pk_2d[i_x, i_y])
                pk_hob_mr[i_hob, i_mr] = np.mean(pk_samples) if pk_samples else 0.0
    
    return mr_axis, pk_hob_mr


# =============================================================================
# Hypercube Format Detection and Normalization
# =============================================================================

def detect_hypercube_format(pk_det: np.ndarray, axes: dict) -> str:
    """
    Detect whether hypercube is in 'native' or 'legacy' format.
    
    Native format: (miss_x, miss_y, n_hob, n_vel, n_aof)
    Legacy format: (n_hob, n_vel, n_aof, miss_x, miss_y)
    
    Args:
        pk_det: 5D Pk array
        axes: Dict with axis arrays (hob, vel, aof, miss_x, miss_y)
        
    Returns:
        'native' or 'legacy'
    """
    if pk_det.ndim != 5:
        raise ValueError(f"Expected 5D array, got {pk_det.ndim}D")
    
    n_miss_x = len(axes.get("miss_x", []))
    n_miss_y = len(axes.get("miss_y", []))
    n_hob = len(axes.get("hob", []))
    n_vel = len(axes.get("vel", []))
    n_aof = len(axes.get("aof", []))
    
    shape = pk_det.shape
    
    # Native: (miss_x, miss_y, hob, vel, aof)
    if shape == (n_miss_x, n_miss_y, n_hob, n_vel, n_aof):
        return "native"
    
    # Legacy: (hob, vel, aof, miss_x, miss_y)
    if shape == (n_hob, n_vel, n_aof, n_miss_x, n_miss_y):
        return "legacy"
    
    # Try to infer from dimension sizes
    # Miss grids are typically larger than terminal condition grids
    if shape[0] > shape[2] and shape[1] > shape[3]:
        return "native"
    elif shape[3] > shape[0] and shape[4] > shape[1]:
        return "legacy"
    
    # Default to native (current standard)
    return "native"


def normalize_hypercube_to_native(
    pk_det: np.ndarray,
    axes: dict,
) -> np.ndarray:
    """
    Ensure hypercube is in native format: (miss_x, miss_y, n_hob, n_vel, n_aof).
    
    If already native, returns as-is. If legacy, transposes to native.
    
    Args:
        pk_det: 5D Pk array
        axes: Dict with axis arrays
        
    Returns:
        Pk array in native format
    """
    fmt = detect_hypercube_format(pk_det, axes)
    
    if fmt == "native":
        return pk_det
    elif fmt == "legacy":
        # Legacy: (hob, vel, aof, miss_x, miss_y) → Native: (miss_x, miss_y, hob, vel, aof)
        return np.transpose(pk_det, (3, 4, 0, 1, 2))
    else:
        return pk_det


# =============================================================================
# MEGADETH Salvo Box Plots
# =============================================================================

def plot_salvo_boxplot(
    rounds_to_kill: Union[np.ndarray, Iterable[float]],
    title: str = "Rounds-to-Kill",
    pk_threshold: float = 0.9,
    max_rounds: int = 10,
    figsize: Tuple[float, float] = (8, 6),
    save_path: Optional[str] = None,
):
    """
    Basic boxplot for rounds-to-kill distribution.

    Args:
        rounds_to_kill: Array or iterable of rounds-to-kill values
        title: Plot title
        pk_threshold: Pk threshold used for R2K computation
        max_rounds: Maximum rounds (y-axis limit)
        figsize: Figure size (width, height)
        save_path: If provided, save figure to this path

    Returns:
        (fig, ax) tuple
    """
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc

    data = np.asarray(rounds_to_kill).flatten()
    data = data[~np.isnan(data)]

    fig, ax = plt.subplots(figsize=figsize)
    bp = ax.boxplot(data, vert=True, patch_artist=True)

    # Style the box
    for box in bp['boxes']:
        box.set(facecolor='lightblue', edgecolor='darkblue', linewidth=1.5)
    for whisker in bp['whiskers']:
        whisker.set(color='darkblue', linewidth=1.5)
    for cap in bp['caps']:
        cap.set(color='darkblue', linewidth=1.5)
    for median in bp['medians']:
        median.set(color='red', linewidth=2)

    ax.set_ylabel("Rounds to Kill", fontsize=12)
    ax.set_xlabel(f"Pk ≥ {pk_threshold:.0%}", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.set_ylim(0, max_rounds + 1)
    ax.grid(True, alpha=0.3)

    # Add statistics annotation
    if len(data) > 0:
        stats_text = (
            f"Median: {np.median(data):.2f}\n"
            f"Mean: {np.mean(data):.2f}\n"
            f"Std: {np.std(data):.2f}\n"
            f"N: {len(data)}"
        )
        ax.text(
            0.95, 0.95, stats_text,
            transform=ax.transAxes,
            verticalalignment='top',
            horizontalalignment='right',
            fontsize=10,
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8),
        )

    plt.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')

    return fig, ax


def plot_megadeth_boxplot(
    rounds_to_kill: np.ndarray,
    precision_labels: List[str],
    pk_thresholds: List[float],
    title: str = "MEGADETH Rounds-to-Kill Analysis",
    max_rounds: int = 10,
    figsize: Tuple[float, float] = (14, 8),
    save_path: Optional[str] = None,
):
    """
    Multi-precision box plot matching MEGADETH_SalvoBoxPlot_v01h.m

    MATLAB Reference: MEGADETH_SalvoBoxPlot_v01h.m
        Creates grouped box plots with multiple precision configurations
        and Pk thresholds.

    Args:
        rounds_to_kill: Array [n_precisions, n_hob, n_vel, n_aof, n_pk_thresholds]
        precision_labels: Labels for each precision configuration
        pk_thresholds: Pk threshold values
        title: Plot title
        max_rounds: Maximum rounds (y-axis limit)
        figsize: Figure size
        save_path: If provided, save figure to this path

    Returns:
        (fig, ax) tuple
    """
    try:
        import matplotlib.pyplot as plt  # type: ignore
        import matplotlib.patches as mpatches  # type: ignore
    except Exception as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc

    n_precisions = len(precision_labels)
    n_pk = len(pk_thresholds)

    fig, ax = plt.subplots(figsize=figsize)

    # Color palette for Pk thresholds
    colors = plt.cm.viridis(np.linspace(0.2, 0.8, n_pk))

    positions = []
    box_data = []
    box_colors = []

    group_width = 0.8
    box_width = group_width / (n_pk + 1)

    for p_idx, label in enumerate(precision_labels):
        for pk_idx, pk in enumerate(pk_thresholds):
            # Extract R2K values for this precision and Pk threshold
            r2k_slice = rounds_to_kill[p_idx, :, :, :, pk_idx].flatten()
            r2k_slice = r2k_slice[~np.isnan(r2k_slice)]

            if len(r2k_slice) > 0:
                box_data.append(r2k_slice)
            else:
                box_data.append([np.nan])

            pos = p_idx + (pk_idx - (n_pk - 1) / 2) * box_width
            positions.append(pos)
            box_colors.append(colors[pk_idx])

    bp = ax.boxplot(
        box_data,
        positions=positions,
        widths=box_width * 0.8,
        patch_artist=True,
    )

    # Apply colors
    for patch, color in zip(bp['boxes'], box_colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)

    # Styling
    for whisker in bp['whiskers']:
        whisker.set(color='gray', linewidth=1)
    for cap in bp['caps']:
        cap.set(color='gray', linewidth=1)
    for median in bp['medians']:
        median.set(color='black', linewidth=2)

    ax.set_xticks(range(n_precisions))
    ax.set_xticklabels(precision_labels, fontsize=11)
    ax.set_ylabel("Rounds to Kill", fontsize=12)
    ax.set_xlabel("Precision Configuration", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.set_ylim(0, max_rounds + 1)
    ax.grid(True, axis='y', alpha=0.3)

    # Legend for Pk thresholds
    legend_patches = [
        mpatches.Patch(color=colors[i], label=f"Pk ≥ {pk_thresholds[i]:.0%}")
        for i in range(n_pk)
    ]
    ax.legend(handles=legend_patches, loc='upper right', fontsize=10)

    plt.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')

    return fig, ax


def plot_salvo_histograms(
    aimpoint_draws: np.ndarray,
    dispersion_draws: np.ndarray,
    bias_draws: np.ndarray,
    bins: int = 25,
    link_axes: bool = True,
    legacy_style: bool = False,
):
    """Plot MATLAB-style histogram panels for aimpoint/dispersion/bias components."""

    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc

    fig, axes = plt.subplots(3, 2, figsize=(10, 8))
    components = [("Aimpoint (TLE)", aimpoint_draws), ("Dispersion (CEP)", dispersion_draws), ("Bias", bias_draws)]

    all_limits: Optional[Tuple[float, float]] = None
    if link_axes:
        stacked = np.concatenate([c[1].reshape(-1) for c in components if c[1].size])
        span = float(max(np.abs(stacked.max()), np.abs(stacked.min()))) if stacked.size else 1.0
        all_limits = (-span, span)

    for row, (label, draws) in enumerate(components):
        if draws.size == 0:
            axes[row, 0].set_visible(False)
            axes[row, 1].set_visible(False)
            continue
        # MATLAB Parity (2025-12-02): Index 0=X=Deflection, Index 1=Y=Range
        for col, axis_label in enumerate(["X (Deflection)", "Y (Range)"]):
            ax = axes[row, col]
            ax.hist(draws[..., col].reshape(-1), bins=bins, density=True, color="#d62728" if legacy_style else "#1f77b4")
            ax.set_title(f"{label} {axis_label} Draws")
            ax.set_xlabel("Meters")
            ax.set_ylabel("PDF")
            if all_limits:
                ax.set_xlim(all_limits)
    fig.tight_layout()
    return fig, axes


def plot_hob_mr_contour(
    hob_axis: np.ndarray,
    miss_range_axis: np.ndarray,
    pk_grid: np.ndarray,
    title: str = "HOB-MR Contour",
    levels: int = 15,
    legacy_colormap: bool = False,
):
    """
    Contour plot of Pk over HOB vs Miss Range.

    MATLAB Reference: plotSinglHobMR2a.m
        Creates contour plot showing Pk as a function of Height of Burst
        and Miss Range (radial distance from target).

    Args:
        hob_axis: Height of burst axis
        miss_range_axis: Miss range (radial) axis
        pk_grid: 2D Pk grid [n_hob, n_mr]
        title: Plot title
        levels: Number of contour levels
        figsize: Figure size
        save_path: If provided, save figure to this path

    Returns:
        (fig, ax) tuple
    """
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc

    H, R = np.meshgrid(hob_axis, miss_range_axis, indexing="ij")
    fig, ax = plt.subplots()
    cs = ax.contourf(R, H, pk_grid, levels=levels, cmap=create_blue_red_colormap(legacy_white_red=legacy_colormap))
    ax.set_xlabel("Miss Range (m)")
    ax.set_ylabel("HOB (m)")
    ax.set_title(title)
    fig.colorbar(cs, ax=ax, label="Pk")
    return fig, ax


def plot_bias_overlay(
    pk_grid: np.ndarray,
    miss_x_axis: Sequence[float],
    miss_y_axis: Sequence[float],
    bias_vector: Tuple[float, float] = (0.0, 0.0),
    mean_vector: Tuple[float, float] = (0.0, 0.0),
    title: str = "Miss Contour with Bias Overlay",
    contour_levels: int = 15,
    legacy_colormap: bool = False,
):
    """Draw a contour plot with bias/mean vectors overlaid for parity visualization."""

    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception as exc:
        raise RuntimeError("matplotlib is required for plotting") from exc

    X, Y = np.meshgrid(miss_x_axis, miss_y_axis, indexing="xy")
    fig, ax = plt.subplots()
    cs = ax.contourf(X, Y, pk_grid, levels=contour_levels, cmap=create_blue_red_colormap(legacy_white_red=legacy_colormap))
    ax.quiver(0, 0, bias_vector[0], bias_vector[1], angles="xy", scale_units="xy", scale=1, color="k", width=0.005)
    ax.quiver(0, 0, mean_vector[0], mean_vector[1], angles="xy", scale_units="xy", scale=1, color="tab:orange", width=0.005)
    ax.set_xlabel("Miss Deflection (m)")
    ax.set_ylabel("Miss Range (m)")
    ax.set_title(title)
    ax.axhline(0, color="k", linewidth=0.5)
    ax.axvline(0, color="k", linewidth=0.5)
    fig.colorbar(cs, ax=ax, label="Pk")
    return fig, ax
