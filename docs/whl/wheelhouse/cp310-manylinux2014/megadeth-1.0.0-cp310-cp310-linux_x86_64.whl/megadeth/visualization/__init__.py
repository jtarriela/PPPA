"""Visualization utilities (plots and colormaps) - MEGADETH Parity."""

from .plots import (
    create_blue_red_colormap,
    plot_bias_overlay,
    plot_hob_mr_contour,
    plot_salvo_boxplot,
    plot_salvo_histograms,
)

from .mc_draw_diagnostics import (
    DrawStatistics,
    plot_mc_draw_diagnostics,
    compare_draw_statistics,
    load_matlab_draw_data,
    generate_verification_plots,
)

__all__ = [
    "create_blue_red_colormap",
    "plot_salvo_boxplot",
    "plot_hob_mr_contour",
    "plot_salvo_histograms",
    "plot_bias_overlay",
    # MC draw diagnostics
    "DrawStatistics",
    "plot_mc_draw_diagnostics",
    "compare_draw_statistics",
    "load_matlab_draw_data",
    "generate_verification_plots",
]
