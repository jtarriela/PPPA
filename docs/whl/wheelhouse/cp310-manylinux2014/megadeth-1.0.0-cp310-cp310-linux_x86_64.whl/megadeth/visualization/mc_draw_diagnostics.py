"""
Monte Carlo Draw Visualization Module

Generates MATLAB-parity plots for TLE/CEP draw validation:
- Aimpoint scatter (TLE offsets from true target)
- Dispersion scatter (CEP offsets from aimpoints)
- X/Y axis histograms with PDF overlays
- Intended vs actual precision circles/lines

Coordinate Convention (MATLAB Parity 2025-12-02):
- X-axis (horizontal) = Deflection (crossrange/lateral)
- Y-axis (vertical)   = Range (downrange)
- Matches MEGADETH SalvoAnalysis03x3.m PkDatabase{1,2}

Reference: plotBasicSalvoHist.m
"""

import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any, List
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

# MATLAB-style dark theme colors
DARK_BG_COLOR = '#1a1a1a'  # Dark gray background
AXIS_BG_COLOR = '#2d2d2d'  # Slightly lighter for axes
GRID_COLOR = '#4d4d4d'     # Grid lines
TEXT_COLOR = 'white'       # Text color
SCATTER_COLOR = 'red'      # Scatter points
HIST_COLOR = 'steelblue'   # Histogram bars
PDF_COLOR = 'red'          # PDF curves
INTENDED_COLOR = 'black'   # Intended precision (but visible on dark bg)
ACTUAL_COLOR = '#4da6ff'   # Actual precision (blue dashed)


@dataclass
class DrawStatistics:
    """Statistics computed from random draws."""
    mean_x: float
    mean_y: float
    sigma_x: float
    sigma_y: float
    variance_x: float
    variance_y: float
    actual_precision_x: float  # Computed from data
    actual_precision_y: float
    actual_precision_radius: float  # Average of X/Y
    intended_radius: float
    intended_fraction: float
    
    @classmethod
    def from_data(cls, x_data: np.ndarray, y_data: np.ndarray, 
                  intended_radius: float, intended_fraction: float) -> 'DrawStatistics':
        """Compute statistics from X/Y offset data."""
        x_flat = x_data.flatten()
        y_flat = y_data.flatten()
        
        mean_x = float(np.mean(x_flat))
        mean_y = float(np.mean(y_flat))
        sigma_x = float(np.std(x_flat))
        sigma_y = float(np.std(y_flat))
        variance_x = float(np.var(x_flat))
        variance_y = float(np.var(y_flat))
        
        # Compute actual precision radius from sigma
        # r = sigma * sqrt(-2 * ln(1 - fraction))
        factor = np.sqrt(-2 * np.log(1 - intended_fraction))
        actual_precision_x = sigma_x * factor
        actual_precision_y = sigma_y * factor
        actual_precision_radius = (actual_precision_x + actual_precision_y) / 2
        
        return cls(
            mean_x=mean_x,
            mean_y=mean_y,
            sigma_x=sigma_x,
            sigma_y=sigma_y,
            variance_x=variance_x,
            variance_y=variance_y,
            actual_precision_x=actual_precision_x,
            actual_precision_y=actual_precision_y,
            actual_precision_radius=actual_precision_radius,
            intended_radius=intended_radius,
            intended_fraction=intended_fraction,
        )


def _setup_dark_style(ax, title: str = ""):
    """Configure axis with MATLAB-style dark theme."""
    ax.set_facecolor(AXIS_BG_COLOR)
    ax.tick_params(colors=TEXT_COLOR)
    ax.xaxis.label.set_color(TEXT_COLOR)
    ax.yaxis.label.set_color(TEXT_COLOR)
    ax.title.set_color(TEXT_COLOR)
    for spine in ax.spines.values():
        spine.set_color(GRID_COLOR)
    ax.grid(True, alpha=0.3, color=GRID_COLOR)
    if title:
        ax.set_title(title, color=TEXT_COLOR, fontsize=10)


def plot_mc_draw_diagnostics(
    aimpoint_offsets: np.ndarray,
    dispersion_offsets: np.ndarray,
    tle_radius: float,
    tle_fraction: float,
    cep_radius: float,
    cep_fraction: float,
    output_path: Optional[Path] = None,
    precision_label: str = "",
    show_plot: bool = False,
    dark_theme: bool = True,
) -> Tuple[Any, Dict[str, DrawStatistics]]:
    """
    Generate MATLAB-style diagnostic plots for MC random draws.
    
    Matches plotBasicSalvoHist.m layout:
    - Row 1: Scatter plots (X,Y) with precision circles + Y-axis histograms (rotated)
    - Row 2: X-axis histograms
    
    Args:
        aimpoint_offsets: TLE offsets [n_salvos, 2] or [n_salvos, 3] for X,Y(,Z)
        dispersion_offsets: CEP offsets [n_salvos, n_shots*2] or [n_salvos, n_shots*3]
        tle_radius: Intended TLE radius (e.g., TLE90 = 9.0m)
        tle_fraction: TLE fraction (e.g., 0.90 for TLE90)
        cep_radius: Intended CEP radius (e.g., CEP50 = 10.0m)
        cep_fraction: CEP fraction (e.g., 0.50 for CEP50)
        output_path: Path to save the figure
        precision_label: Label for the precision set (e.g., "low_error")
        show_plot: Whether to display the plot
        dark_theme: Use MATLAB-style dark theme (default True)
        
    Returns:
        (figure, statistics_dict) where statistics_dict has 'aimpoint' and 'dispersion' keys
    """
    import matplotlib.pyplot as plt
    
    # Extract X/Y components from aimpoint offsets
    # Format: [n_salvos, 3] with columns [X, Y, Z] or [n_salvos, 2] with [X, Y]
    if aimpoint_offsets.ndim == 2:
        aim_x = aimpoint_offsets[:, 0]
        aim_y = aimpoint_offsets[:, 1]
    else:
        aim_x = aimpoint_offsets.flatten()
        aim_y = np.zeros_like(aim_x)
    
    # Extract X/Y components from dispersion offsets
    # Format: [n_salvos, n_shots*3] with X at 0::3, Y at 1::3
    if dispersion_offsets.ndim == 2 and dispersion_offsets.shape[1] > 2:
        disp_x = dispersion_offsets[:, 0::3].flatten()
        disp_y = dispersion_offsets[:, 1::3].flatten()
    elif dispersion_offsets.ndim == 2:
        disp_x = dispersion_offsets[:, 0]
        disp_y = dispersion_offsets[:, 1]
    else:
        disp_x = dispersion_offsets.flatten()
        disp_y = np.zeros_like(disp_x)
    
    # Compute statistics
    aim_stats = DrawStatistics.from_data(aim_x, aim_y, tle_radius, tle_fraction)
    disp_stats = DrawStatistics.from_data(disp_x, disp_y, cep_radius, cep_fraction)
    
    # Determine common plot extents (MATLAB 'common' mode)
    aim_max_extent = max(np.abs(aim_x).max(), np.abs(aim_y).max()) if len(aim_x) > 0 else tle_radius
    disp_max_extent = max(np.abs(disp_x).max(), np.abs(disp_y).max()) if len(disp_x) > 0 else cep_radius
    max_extent = max(aim_max_extent, disp_max_extent) * 1.1  # 10% margin
    
    # Create figure with 2x4 subplots matching MATLAB layout
    # Row 1: [Aim Scatter] [Aim Y-hist] [Disp Scatter] [Disp Y-hist]
    # Row 2: [Aim X-hist]  [empty]      [Disp X-hist]  [empty]
    fig = plt.figure(figsize=(16, 10))
    
    if dark_theme:
        fig.patch.set_facecolor(DARK_BG_COLOR)
    
    hist_bins = 30
    theta = np.linspace(0, 2*np.pi, 100)
    x_vals = np.linspace(-max_extent, max_extent, 101)
    
    # Colors for precision lines
    intended_line_color = 'white' if dark_theme else 'black'
    actual_line_color = ACTUAL_COLOR
    
    # === AIMPOINT (TLE) PLOTS ===
    
    # 1. Aimpoint scatter (top-left)
    ax_aim_scatter = fig.add_subplot(2, 4, 1)
    if dark_theme:
        _setup_dark_style(ax_aim_scatter, 'Aimpoints (TLE Offsets from True)')
    else:
        ax_aim_scatter.set_title('Aimpoints (TLE Offsets from True)')
        ax_aim_scatter.grid(True, alpha=0.3)
    
    ax_aim_scatter.scatter(aim_x, aim_y, s=2, c=SCATTER_COLOR, alpha=0.5)
    ax_aim_scatter.set_xlim(-max_extent, max_extent)
    ax_aim_scatter.set_ylim(-max_extent, max_extent)
    ax_aim_scatter.set_xlabel('Deflection Offsets (m)')  # X = crossrange
    ax_aim_scatter.set_ylabel('Range Offsets (m)')       # Y = downrange
    ax_aim_scatter.set_aspect('equal')
    
    # Add precision circles - Intended (solid) and Actual (dashed)
    ax_aim_scatter.plot(tle_radius * np.cos(theta), tle_radius * np.sin(theta), 
                        color=intended_line_color, linestyle='-', linewidth=1.0,
                        label=f'Intended TLE{int(tle_fraction*100)}')
    ax_aim_scatter.plot(aim_stats.actual_precision_radius * np.cos(theta), 
                        aim_stats.actual_precision_radius * np.sin(theta),
                        color=actual_line_color, linestyle='--', linewidth=1.75,
                        label=f'Actual TLE{int(tle_fraction*100)}')
    ax_aim_scatter.legend(loc='upper right', fontsize=8, 
                          facecolor=AXIS_BG_COLOR if dark_theme else 'white',
                          labelcolor=TEXT_COLOR if dark_theme else 'black')
    
    # 2. Aimpoint Y-axis histogram (rotated - horizontal bars, matching Y axis)
    ax_aim_y_hist = fig.add_subplot(2, 4, 2)
    if dark_theme:
        _setup_dark_style(ax_aim_y_hist, 'Aimpoint (TLE) Range Draws')
    else:
        ax_aim_y_hist.set_title('Aimpoint (TLE) Range Draws')
    
    ax_aim_y_hist.hist(aim_y, bins=hist_bins, density=True, alpha=0.7, 
                       orientation='horizontal', color=HIST_COLOR, edgecolor='none')
    ax_aim_y_hist.set_ylim(-max_extent, max_extent)
    
    # Add PDF curve (horizontal orientation)
    pdf_y = np.exp(-(x_vals - aim_stats.mean_y)**2 / (2 * aim_stats.variance_y)) / \
            (aim_stats.sigma_y * np.sqrt(2 * np.pi)) if aim_stats.variance_y > 0 else np.zeros_like(x_vals)
    ax_aim_y_hist.plot(pdf_y, x_vals, color=PDF_COLOR, linewidth=1.0)
    
    # Add precision lines (horizontal)
    ax_aim_y_hist.axhline(tle_radius, color=intended_line_color, linewidth=1.0, linestyle='-')
    ax_aim_y_hist.axhline(-tle_radius, color=intended_line_color, linewidth=1.0, linestyle='-')
    ax_aim_y_hist.axhline(aim_stats.actual_precision_y, color=actual_line_color, linewidth=1.75, linestyle='--')
    ax_aim_y_hist.axhline(-aim_stats.actual_precision_y, color=actual_line_color, linewidth=1.75, linestyle='--')
    
    # 3. Dispersion scatter (top, 3rd column)
    ax_disp_scatter = fig.add_subplot(2, 4, 3)
    if dark_theme:
        _setup_dark_style(ax_disp_scatter, 'Dispersions (CEP Offsets from Aimpoints)')
    else:
        ax_disp_scatter.set_title('Dispersions (CEP Offsets from Aimpoints)')
        ax_disp_scatter.grid(True, alpha=0.3)

    ax_disp_scatter.scatter(disp_x, disp_y, s=2, c=SCATTER_COLOR, alpha=0.3)
    ax_disp_scatter.set_xlim(-max_extent, max_extent)
    ax_disp_scatter.set_ylim(-max_extent, max_extent)
    ax_disp_scatter.set_xlabel('Deflection Offsets (m)')  # X = crossrange
    ax_disp_scatter.set_ylabel('Range Offsets (m)')       # Y = downrange
    ax_disp_scatter.set_aspect('equal')
    
    # Add precision circles
    ax_disp_scatter.plot(cep_radius * np.cos(theta), cep_radius * np.sin(theta),
                         color=intended_line_color, linestyle='-', linewidth=1.0,
                         label=f'Intended CEP{int(cep_fraction*100)}')
    ax_disp_scatter.plot(disp_stats.actual_precision_radius * np.cos(theta),
                         disp_stats.actual_precision_radius * np.sin(theta),
                         color=actual_line_color, linestyle='--', linewidth=1.75,
                         label=f'Actual CEP{int(cep_fraction*100)}')
    ax_disp_scatter.legend(loc='upper right', fontsize=8,
                           facecolor=AXIS_BG_COLOR if dark_theme else 'white',
                           labelcolor=TEXT_COLOR if dark_theme else 'black')
    
    # 4. Dispersion Y-axis histogram
    ax_disp_y_hist = fig.add_subplot(2, 4, 4)
    if dark_theme:
        _setup_dark_style(ax_disp_y_hist, 'Dispersion (CEP) Range Draws')
    else:
        ax_disp_y_hist.set_title('Dispersion (CEP) Range Draws')
    
    ax_disp_y_hist.hist(disp_y, bins=hist_bins, density=True, alpha=0.7,
                        orientation='horizontal', color=HIST_COLOR, edgecolor='none')
    ax_disp_y_hist.set_ylim(-max_extent, max_extent)
    
    # Add PDF curve
    pdf_disp_y = np.exp(-(x_vals - disp_stats.mean_y)**2 / (2 * disp_stats.variance_y)) / \
                 (disp_stats.sigma_y * np.sqrt(2 * np.pi)) if disp_stats.variance_y > 0 else np.zeros_like(x_vals)
    ax_disp_y_hist.plot(pdf_disp_y, x_vals, color=PDF_COLOR, linewidth=1.0)
    
    # Add precision lines
    ax_disp_y_hist.axhline(cep_radius, color=intended_line_color, linewidth=1.0, linestyle='-')
    ax_disp_y_hist.axhline(-cep_radius, color=intended_line_color, linewidth=1.0, linestyle='-')
    ax_disp_y_hist.axhline(disp_stats.actual_precision_y, color=actual_line_color, linewidth=1.75, linestyle='--')
    ax_disp_y_hist.axhline(-disp_stats.actual_precision_y, color=actual_line_color, linewidth=1.75, linestyle='--')
    
    # 5. Aimpoint X-axis histogram (bottom-left)
    ax_aim_x_hist = fig.add_subplot(2, 4, 5)
    if dark_theme:
        _setup_dark_style(ax_aim_x_hist, 'Aimpoint (TLE) Deflection Draws')
    else:
        ax_aim_x_hist.set_title('Aimpoint (TLE) Deflection Draws')
    
    ax_aim_x_hist.hist(aim_x, bins=hist_bins, density=True, alpha=0.7, 
                       color=HIST_COLOR, edgecolor='none')
    ax_aim_x_hist.set_xlim(-max_extent, max_extent)
    
    # Add PDF curve
    pdf_x = np.exp(-(x_vals - aim_stats.mean_x)**2 / (2 * aim_stats.variance_x)) / \
            (aim_stats.sigma_x * np.sqrt(2 * np.pi)) if aim_stats.variance_x > 0 else np.zeros_like(x_vals)
    ax_aim_x_hist.plot(x_vals, pdf_x, color=PDF_COLOR, linewidth=1.0)
    
    # Add precision lines (vertical)
    ax_aim_x_hist.axvline(tle_radius, color=intended_line_color, linewidth=1.0, linestyle='-')
    ax_aim_x_hist.axvline(-tle_radius, color=intended_line_color, linewidth=1.0, linestyle='-')
    ax_aim_x_hist.axvline(aim_stats.actual_precision_x, color=actual_line_color, linewidth=1.75, linestyle='--')
    ax_aim_x_hist.axvline(-aim_stats.actual_precision_x, color=actual_line_color, linewidth=1.75, linestyle='--')
    
    # 6. Empty subplot placeholder (below Y-hist for aim)
    # Leave position 6 empty to match MATLAB layout
    
    # 7. Dispersion X-axis histogram
    ax_disp_x_hist = fig.add_subplot(2, 4, 7)
    if dark_theme:
        _setup_dark_style(ax_disp_x_hist, 'Dispersion (CEP) Deflection Draws')
    else:
        ax_disp_x_hist.set_title('Dispersion (CEP) Deflection Draws')
    
    ax_disp_x_hist.hist(disp_x, bins=hist_bins, density=True, alpha=0.7, 
                        color=HIST_COLOR, edgecolor='none')
    ax_disp_x_hist.set_xlim(-max_extent, max_extent)
    
    # Add PDF curve
    pdf_disp_x = np.exp(-(x_vals - disp_stats.mean_x)**2 / (2 * disp_stats.variance_x)) / \
                 (disp_stats.sigma_x * np.sqrt(2 * np.pi)) if disp_stats.variance_x > 0 else np.zeros_like(x_vals)
    ax_disp_x_hist.plot(x_vals, pdf_disp_x, color=PDF_COLOR, linewidth=1.0)
    
    # Add precision lines
    ax_disp_x_hist.axvline(cep_radius, color=intended_line_color, linewidth=1.0, linestyle='-')
    ax_disp_x_hist.axvline(-cep_radius, color=intended_line_color, linewidth=1.0, linestyle='-')
    ax_disp_x_hist.axvline(disp_stats.actual_precision_x, color=actual_line_color, linewidth=1.75, linestyle='--')
    ax_disp_x_hist.axvline(-disp_stats.actual_precision_x, color=actual_line_color, linewidth=1.75, linestyle='--')
    
    # 8. Empty subplot placeholder (below Y-hist for disp)
    # Leave position 8 empty to match MATLAB layout
    
    # Add summary text (MATLAB suptitle style)
    summary_text = (
        f"TLE Summary\n"
        f"Intended TLE{int(tle_fraction*100)}: {tle_radius} m\n"
        f"Generated TLE{int(tle_fraction*100)}: {aim_stats.actual_precision_radius:.5f} m)"
    )
    fig.suptitle(summary_text, fontsize=12, fontweight='bold', y=0.98,
                 color=TEXT_COLOR if dark_theme else 'black')
    
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    
    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(output_path, dpi=150, bbox_inches='tight', 
                    facecolor=fig.get_facecolor(), edgecolor='none')
        logger.info(f"Saved MC draw diagnostic plot to: {output_path}")
    
    if show_plot:
        plt.show()
    else:
        plt.close(fig)
    
    return fig, {'aimpoint': aim_stats, 'dispersion': disp_stats}


def compare_draw_statistics(
    matlab_stats: Dict[str, Any],
    python_stats: Dict[str, DrawStatistics],
    precision_label: str = "",
    output_path: Optional[Path] = None,
) -> str:
    """
    Generate comparison table of MATLAB vs Python draw statistics.
    
    Args:
        matlab_stats: Dictionary with MATLAB statistics (loaded from .mat file)
        python_stats: Dictionary with Python DrawStatistics objects
        precision_label: Label for the precision set
        output_path: Path to save the comparison table
        
    Returns:
        Formatted comparison string
    """
    lines = []
    lines.append("=" * 80)
    lines.append(f"  MC DRAW STATISTICS COMPARISON - {precision_label}")
    lines.append("=" * 80)
    lines.append("")
    
    # Aimpoint (TLE) comparison
    lines.append("AIMPOINT (TLE) STATISTICS")
    lines.append("-" * 60)
    lines.append(f"{'Metric':<30} {'MATLAB':>12} {'Python':>12} {'Diff':>12}")
    lines.append("-" * 60)
    
    aim_py = python_stats.get('aimpoint')
    if aim_py and matlab_stats:
        metrics = [
            ('Mean X (m)', matlab_stats.get('aim_mean_x', 0), aim_py.mean_x),
            ('Mean Y (m)', matlab_stats.get('aim_mean_y', 0), aim_py.mean_y),
            ('Sigma X intended (m)', matlab_stats.get('tleXsigma_m', 0), aim_py.intended_radius / np.sqrt(-2 * np.log(1 - aim_py.intended_fraction))),
            ('Sigma X actual (m)', matlab_stats.get('aim_sigma_x_actual', matlab_stats.get('tleXsigma_m', 0)), aim_py.sigma_x),
            ('Sigma Y actual (m)', matlab_stats.get('aim_sigma_y_actual', matlab_stats.get('tleYsigma_m', 0)), aim_py.sigma_y),
            ('Actual Precision X (m)', matlab_stats.get('aim_sigma_x_actual', 0) * np.sqrt(-2 * np.log(1 - aim_py.intended_fraction)), aim_py.actual_precision_x),
            ('Actual Precision Y (m)', matlab_stats.get('aim_sigma_y_actual', 0) * np.sqrt(-2 * np.log(1 - aim_py.intended_fraction)), aim_py.actual_precision_y),
        ]
        
        for name, ml_val, py_val in metrics:
            if ml_val == 0 and 'actual' in name.lower():
                # Use actual computed values if not provided
                continue
            diff = py_val - ml_val if ml_val != 0 else py_val
            lines.append(f"{name:<30} {ml_val:>12.6f} {py_val:>12.6f} {diff:>+12.6f}")
    
    lines.append("")
    
    # Dispersion (CEP) comparison
    lines.append("DISPERSION (CEP) STATISTICS")
    lines.append("-" * 60)
    lines.append(f"{'Metric':<30} {'MATLAB':>12} {'Python':>12} {'Diff':>12}")
    lines.append("-" * 60)
    
    disp_py = python_stats.get('dispersion')
    if disp_py and matlab_stats:
        metrics = [
            ('Mean X (m)', matlab_stats.get('disp_mean_x', 0), disp_py.mean_x),
            ('Mean Y (m)', matlab_stats.get('disp_mean_y', 0), disp_py.mean_y),
            ('Sigma X intended (m)', matlab_stats.get('dispXsigma_m', 0), disp_py.intended_radius / np.sqrt(-2 * np.log(1 - disp_py.intended_fraction))),
            ('Sigma X actual (m)', matlab_stats.get('disp_sigma_x_actual', matlab_stats.get('dispXsigma_m', 0)), disp_py.sigma_x),
            ('Sigma Y actual (m)', matlab_stats.get('disp_sigma_y_actual', matlab_stats.get('dispYsigma_m', 0)), disp_py.sigma_y),
            ('Actual Precision X (m)', matlab_stats.get('disp_sigma_x_actual', 0) * np.sqrt(-2 * np.log(1 - disp_py.intended_fraction)), disp_py.actual_precision_x),
            ('Actual Precision Y (m)', matlab_stats.get('disp_sigma_y_actual', 0) * np.sqrt(-2 * np.log(1 - disp_py.intended_fraction)), disp_py.actual_precision_y),
        ]
        
        for name, ml_val, py_val in metrics:
            if ml_val == 0 and 'actual' in name.lower():
                continue
            diff = py_val - ml_val if ml_val != 0 else py_val
            lines.append(f"{name:<30} {ml_val:>12.6f} {py_val:>12.6f} {diff:>+12.6f}")
    
    lines.append("")
    lines.append("=" * 80)
    
    output = "\n".join(lines)
    
    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            f.write(output)
        logger.info(f"Saved draw statistics comparison to: {output_path}")
    
    return output


def load_matlab_draw_data(mat_file: Path) -> Dict[str, Any]:
    """
    Load MATLAB RNG draw data from .mat file.
    
    Expected format from SalvoAnalysis03x3.m:
        - aimpointOffsets_m: [n_salvos, 3] - TLE offsets (X, Y, Z)
        - dispersionOffsets_m: [n_salvos, n_shots*3] - CEP offsets per shot
        - tleXsigma_m, tleYsigma_m: TLE sigma values
        - dispXsigma_m, dispYsigma_m: CEP sigma values
        - nSalvos, nShots: Dimensions
        - RandomSeed: RNG seed used
        - targetLocations_m: [3, n_shots, n_salvos] - hit locations
    
    Args:
        mat_file: Path to matlab_rand_draws_precN.mat file
        
    Returns:
        Dictionary with extracted data and statistics
    """
    import scipy.io as sio
    
    mat_file = Path(mat_file)
    data = {}
    
    # Try scipy.io first (v7 format, most common)
    try:
        mat = sio.loadmat(str(mat_file), squeeze_me=False)
        
        # Raw draw data
        data['aimpoint_offsets'] = mat['aimpointOffsets_m']  # [n_salvos, 3]
        data['dispersion_offsets'] = mat['dispersionOffsets_m']  # [n_salvos, n_shots*3]
        
        # Sigma values (intended precision parameters)
        data['tleXsigma_m'] = float(mat['tleXsigma_m'].flatten()[0])
        data['tleYsigma_m'] = float(mat['tleYsigma_m'].flatten()[0])
        data['dispXsigma_m'] = float(mat['dispXsigma_m'].flatten()[0])
        data['dispYsigma_m'] = float(mat['dispYsigma_m'].flatten()[0])
        
        # Dimensions
        data['n_salvos'] = int(mat['nSalvos'].flatten()[0])
        data['n_shots'] = int(mat['nShots'].flatten()[0])
        data['random_seed'] = int(mat['RandomSeed'].flatten()[0])
        
        # Target locations if available
        if 'targetLocations_m' in mat:
            # Shape: [3, n_shots, n_salvos] in MATLAB -> transpose to [n_salvos, n_shots, 3]
            data['target_locations'] = np.transpose(mat['targetLocations_m'], (2, 1, 0))
        
        # Bias offsets if available
        if 'biasOffsets_m' in mat:
            data['bias_offsets'] = mat['biasOffsets_m']
        
    except Exception as e:
        # Try h5py for HDF5/v7.3 format
        import h5py
        try:
            with h5py.File(mat_file, 'r') as f:
                data['aimpoint_offsets'] = np.array(f['aimpointOffsets_m'][:]).T
                data['dispersion_offsets'] = np.array(f['dispersionOffsets_m'][:]).T
                data['tleXsigma_m'] = float(f['tleXsigma_m'][0, 0])
                data['tleYsigma_m'] = float(f['tleYsigma_m'][0, 0])
                data['dispXsigma_m'] = float(f['dispXsigma_m'][0, 0])
                data['dispYsigma_m'] = float(f['dispYsigma_m'][0, 0])
                data['n_salvos'] = int(f['nSalvos'][0, 0])
                data['n_shots'] = int(f['nShots'][0, 0])
                data['random_seed'] = int(f['RandomSeed'][0, 0])
                
                if 'targetLocations_m' in f:
                    data['target_locations'] = np.transpose(f['targetLocations_m'][:], (2, 1, 0))
        except Exception as e2:
            raise ValueError(f"Could not load {mat_file}: scipy error={e}, h5py error={e2}")
    
    # Compute statistics from aimpoint (TLE) data
    aim_offsets = data['aimpoint_offsets']
    aim_x = aim_offsets[:, 0]
    aim_y = aim_offsets[:, 1] if aim_offsets.shape[1] > 1 else np.zeros_like(aim_x)
    
    data['aim_mean_x'] = float(np.mean(aim_x))
    data['aim_mean_y'] = float(np.mean(aim_y))
    data['aim_sigma_x_actual'] = float(np.std(aim_x))
    data['aim_sigma_y_actual'] = float(np.std(aim_y))
    
    # Compute statistics from dispersion (CEP) data
    # dispersion_offsets is [n_salvos, n_shots*3] with X at 0::3, Y at 1::3, Z at 2::3
    disp_offsets = data['dispersion_offsets']
    disp_x = disp_offsets[:, 0::3].flatten()
    disp_y = disp_offsets[:, 1::3].flatten()
    
    data['disp_mean_x'] = float(np.mean(disp_x))
    data['disp_mean_y'] = float(np.mean(disp_y))
    data['disp_sigma_x_actual'] = float(np.std(disp_x))
    data['disp_sigma_y_actual'] = float(np.std(disp_y))
    
    return data


def generate_verification_plots(
    matlab_dir: Path,
    python_aimpoint_offsets: np.ndarray,
    python_dispersion_offsets: np.ndarray,
    precision_configs: list,
    output_dir: Path,
) -> Dict[str, Any]:
    """
    Generate all verification plots comparing MATLAB and Python draws.
    
    Args:
        matlab_dir: Directory containing MATLAB .mat files
        python_aimpoint_offsets: Python-generated aimpoint offsets per precision [n_prec, n_salvos, 2/3]
        python_dispersion_offsets: Python-generated dispersion offsets [n_prec, n_salvos, n_shots*3]
        precision_configs: List of dicts with 'tle_radius', 'tle_fraction', 'cep_radius', 'cep_fraction'
        output_dir: Directory to save output files
        
    Returns:
        Dictionary with comparison results
    """
    matlab_dir = Path(matlab_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    results = {}
    all_comparisons = []
    
    for i, prec_cfg in enumerate(precision_configs):
        prec_num = i + 1
        prec_label = prec_cfg.get('name', f'precision_{prec_num}')
        
        # Load MATLAB data
        mat_file = matlab_dir / f'matlab_rand_draws_prec{prec_num}.mat'
        if mat_file.exists():
            matlab_data = load_matlab_draw_data(mat_file)
            
            # Generate MATLAB plot
            matlab_fig, matlab_stats = plot_mc_draw_diagnostics(
                aimpoint_offsets=matlab_data['aimpoint_offsets'],
                dispersion_offsets=matlab_data['dispersion_offsets'],
                tle_radius=prec_cfg['tle_radius'],
                tle_fraction=prec_cfg['tle_fraction'],
                cep_radius=prec_cfg['cep_radius'],
                cep_fraction=prec_cfg['cep_fraction'],
                output_path=output_dir / f'matlab_draws_prec{prec_num}.png',
                precision_label=f'MATLAB - {prec_label}',
            )
            
            results[f'matlab_prec{prec_num}'] = matlab_stats
        else:
            matlab_data = None
            matlab_stats = None
        
        # Generate Python plot if data provided
        if python_aimpoint_offsets is not None and i < len(python_aimpoint_offsets):
            py_aim = python_aimpoint_offsets[i] if python_aimpoint_offsets.ndim > 2 else python_aimpoint_offsets
            py_disp = python_dispersion_offsets[i] if python_dispersion_offsets.ndim > 2 else python_dispersion_offsets
            
            python_fig, python_stats = plot_mc_draw_diagnostics(
                aimpoint_offsets=py_aim,
                dispersion_offsets=py_disp,
                tle_radius=prec_cfg['tle_radius'],
                tle_fraction=prec_cfg['tle_fraction'],
                cep_radius=prec_cfg['cep_radius'],
                cep_fraction=prec_cfg['cep_fraction'],
                output_path=output_dir / f'python_draws_prec{prec_num}.png',
                precision_label=f'Python - {prec_label}',
            )
            
            results[f'python_prec{prec_num}'] = python_stats
            
            # Generate comparison
            if matlab_data:
                comparison = compare_draw_statistics(
                    matlab_stats=matlab_data,
                    python_stats=python_stats,
                    precision_label=prec_label,
                    output_path=output_dir / f'comparison_prec{prec_num}.txt',
                )
                all_comparisons.append(comparison)
                print(comparison)
    
    # Save combined comparison
    if all_comparisons:
        combined = "\n\n".join(all_comparisons)
        with open(output_dir / 'all_comparisons.txt', 'w') as f:
            f.write(combined)
    
    return results


if __name__ == "__main__":
    # Test with sample data matching screenshot (TLE90=9m)
    import sys
    
    # Example usage - parameters similar to screenshot
    np.random.seed(314159)
    n_salvos = 2000
    n_shots = 10
    
    # TLE90 = 9m (matching screenshot)
    tle_radius = 9.0
    tle_fraction = 0.90
    tle_sigma = tle_radius / np.sqrt(-2 * np.log(1 - tle_fraction))
    aim_offsets = np.random.normal(0, tle_sigma, (n_salvos, 3))
    
    # CEP50 ~ 10m (inferred from screenshot dispersion spread)
    cep_radius = 10.0
    cep_fraction = 0.50
    cep_sigma = cep_radius / np.sqrt(-2 * np.log(1 - cep_fraction))
    disp_offsets = np.random.normal(0, cep_sigma, (n_salvos, n_shots * 3))
    
    # Generate plot with dark theme
    fig, stats = plot_mc_draw_diagnostics(
        aimpoint_offsets=aim_offsets,
        dispersion_offsets=disp_offsets,
        tle_radius=tle_radius,
        tle_fraction=tle_fraction,
        cep_radius=cep_radius,
        cep_fraction=cep_fraction,
        output_path=Path('test_mc_draws.png'),
        precision_label='test',
        show_plot=True,
        dark_theme=True,
    )
    
    print(f"Aimpoint stats: {stats['aimpoint']}")
    print(f"Dispersion stats: {stats['dispersion']}")
