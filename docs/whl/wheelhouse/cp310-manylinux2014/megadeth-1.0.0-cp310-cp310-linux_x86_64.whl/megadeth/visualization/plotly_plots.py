"""
MEGADETH Visualization Module - Plotly Implementation

Implements interactive Plotly versions of the standard MEGADETH visualizations.
Designed to be used by the Dashboard and other interactive tools, matching
the style and logic of the Matplotlib-based `plots.py`.
"""

from __future__ import annotations

from typing import Optional, List, Tuple, Union, Iterable

import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from scipy.ndimage import map_coordinates
from skimage import measure

# =============================================================================
# Standard Styles
# =============================================================================

def get_colorscale(name: str = 'blue_red'):
    """Return standard Plotly colorscales matching MEGADETH styles."""
    if name == 'blue_red':
        # White -> Blue -> Red
        return [
            [0.0, "white"],
            [0.5, "blue"],
            [1.0, "red"]
        ]
    elif name == 'r2k':
        # Green (low) -> Yellow -> Red (high)
        return 'RdYlGn_r'
    elif name == 'jet':
        return 'Jet'
    return 'RdBu_r'

# =============================================================================
# Heatmaps / Contours
# =============================================================================

def plot_pk_heatmap_plotly(
    pk_slice: np.ndarray,
    x_axis: np.ndarray,
    y_axis: np.ndarray,
    x_label: str = "X",
    y_label: str = "Y",
    title: str = "Pk Heatmap",
    z_min: float = 0.0,
    z_max: float = 1.0,
    colorscale: str = 'blue_red',
    show_contours: bool = True,
    height: int = 600,
    colorbar_title: str = "Pk",
) -> go.Figure:
    """
    Generate interactive 2D Pk heatmap/contour using Plotly.
    Matches logic of `plots.plot_pk_heatmap`.
    
    Args:
        pk_slice: 2D array of Pk values
        x_axis: X-axis values
        y_axis: Y-axis values
        x_label: X-axis label
        y_label: Y-axis label
        title: Plot title
        z_min, z_max: Range for colorscale
        colorscale: 'blue_red', 'jet', etc.
        show_contours: Whether to show contour lines
        height: Plot height
        colorbar_title: Label for the colorbar
        
    Returns:
        plotly.graph_objects.Figure
    """
    # Transpose slice because Plotly Contour expects (y, x) logic or matching dimensions
    # If we pass x and y arrays, we usually need z to match.
    # Standard assumption: pk_slice[x_idx, y_idx].
    # Plotly expects z[y_idx][x_idx] usually, i.e. z corresponds to y rows.
    # So we typically transpose: z=pk_slice.T
    
    scale = get_colorscale(colorscale) if colorscale == 'blue_red' else colorscale
    
    fig = go.Figure(data=go.Contour(
        z=pk_slice.T,
        x=x_axis,
        y=y_axis,
        colorscale=scale,
        zmin=z_min,
        zmax=z_max,
        contours=dict(
            coloring='heatmap',
            showlabels=True,
            start=z_min,
            end=z_max,
        ) if show_contours else None,
        line_smoothing=0.85,
        colorbar=dict(title=colorbar_title),
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title=x_label,
        yaxis_title=y_label,
        height=height,
        margin=dict(l=50, r=50, t=50, b=50),
    )
    
    return fig


def plot_r2k_heatmap_plotly(
    r2k_slice: np.ndarray,
    x_axis: np.ndarray,
    y_axis: np.ndarray,
    x_label: str = "X",
    y_label: str = "Y",
    title: str = "Rounds to Kill",
    max_rounds: int = 20,
    height: int = 600,
) -> go.Figure:
    """
    Generate Rounds-to-Kill heatmap.
    Matches logic of `create_r2k_colormap`.
    """
    # Mask NaNs or Infs for display if needed, though Plotly handles them well (white/gap)
    
    fig = go.Figure(data=go.Heatmap(
        z=r2k_slice.T,
        x=x_axis,
        y=y_axis,
        colorscale='RdYlGn_r', # Green -> Red
        zmin=1,
        zmax=max_rounds,
        colorbar=dict(title='Rounds'),
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title=x_label,
        yaxis_title=y_label,
        height=height,
    )
    
    return fig

# =============================================================================
# HOB-MR Contours
# =============================================================================

def compute_hob_mr_grid(
    pk_hypercube: np.ndarray,
    hob_axis: np.ndarray,
    deflection_axis: np.ndarray,
    range_axis: np.ndarray,
    i_vel: int,
    i_aof: int,
    n_mr_points: int = 50,
    n_angles: int = 36,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute HOB vs Miss-Range Pk grid by radial averaging.
    
    Takes a 5D hypercube slice at fixed VEL/AOF and computes the Pk
    as a function of HOB and radial miss distance by averaging over angles.
    
    Hypercube shape must be: (miss_x, miss_y, n_hob, n_vel, n_aof) [native format]
    
    Args:
        pk_hypercube: 5D Pk array, shape (miss_x, miss_y, n_hob, n_vel, n_aof)
        hob_axis: HOB values
        deflection_axis: Miss-X (deflection) axis
        range_axis: Miss-Y (range) axis
        i_vel: Velocity index
        i_aof: AOF index
        n_mr_points: Number of miss-range points
        n_angles: Number of angles for radial sampling
        
    Returns:
        (mr_axis, pk_hob_mr) where pk_hob_mr has shape (n_hob, n_mr)
    """
    # Compute max miss radius from axes
    max_range = max(np.abs(deflection_axis).max(), np.abs(range_axis).max())
    mr_axis = np.linspace(0, max_range, n_mr_points)
    
    pk_hob_mr = np.zeros((len(hob_axis), len(mr_axis)))
    angles = np.linspace(0, 2 * np.pi, n_angles, endpoint=False)
    
    for i_hob in range(len(hob_axis)):
        # Extract 2D slice: shape is (miss_x, miss_y)
        pk_2d = pk_hypercube[:, :, i_hob, i_vel, i_aof]
        
        for i_mr, mr in enumerate(mr_axis):
            if mr < 0.1:
                # Near origin - use center value
                i_center_x = len(deflection_axis) // 2
                i_center_y = len(range_axis) // 2
                pk_hob_mr[i_hob, i_mr] = pk_2d[i_center_x, i_center_y]
            else:
                # Sample around circle at this radius
                pk_samples = []
                for theta in angles:
                    x = mr * np.cos(theta)
                    y = mr * np.sin(theta)
                    i_x = np.argmin(np.abs(deflection_axis - x))
                    i_y = np.argmin(np.abs(range_axis - y))
                    if 0 <= i_x < pk_2d.shape[0] and 0 <= i_y < pk_2d.shape[1]:
                        pk_samples.append(pk_2d[i_x, i_y])
                pk_hob_mr[i_hob, i_mr] = np.mean(pk_samples) if pk_samples else 0.0
    
    return mr_axis, pk_hob_mr


def plot_hob_mr_contour_plotly(
    hob_axis: np.ndarray,
    miss_range_axis: np.ndarray,
    pk_grid: np.ndarray,
    title: str = "HOB-MR Contour",
    levels: int = 15,
    height: int = 600,
) -> go.Figure:
    """
    Interactive HOB vs Miss Range contour.
    Matches `plots.plot_hob_mr_contour`.
    """
    fig = go.Figure(data=go.Contour(
        z=pk_grid.T, # pk_grid is [hob, mr], so transpose for z[y,x] where y=hob
        x=miss_range_axis,
        y=hob_axis,
        colorscale=get_colorscale('blue_red'),
        zmin=0.0,
        zmax=1.0,
        contours=dict(
            start=0,
            end=1,
            size=1.0/levels,
            showlabels=True,
        ),
        colorbar=dict(title='Pk')
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Miss Range (m)",
        yaxis_title="HOB (m)",
        height=height,
    )
    
    return fig

# =============================================================================
# 3D Volumes
# =============================================================================

def plot_3d_volume_plotly(
    system_pk: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    opacity: float = 0.3,
    surface_count: int = 5,
    height: int = 700,
    colorbar_title: str = 'Pk',
) -> go.Figure:
    """
    3D Isosurface plot of System Pk.
    Centralized version of dashboard's `plot_3d_volume`.
    """
    H, V, A = np.meshgrid(hob_axis, vel_axis, aof_axis, indexing='ij')
    
    # Auto-scale min/max based on data range if not Pk (0-1)
    d_min, d_max = float(np.min(system_pk)), float(np.max(system_pk))
    if colorbar_title == 'Pk':
        iso_min, iso_max = 0.1, 1.0
    else:
        # Dynamic range for gradients/curvature
        iso_min, iso_max = d_min, d_max

    fig = go.Figure(data=go.Isosurface(
        x=V.flatten(),
        y=H.flatten(),
        z=A.flatten(),
        value=system_pk.flatten(),
        isomin=iso_min,
        isomax=iso_max,
        opacity=opacity,
        surface_count=surface_count,
        colorscale='Jet',
        caps=dict(x_show=False, y_show=False),
        colorbar=dict(title=colorbar_title),
    ))
    
    fig.update_layout(
        title="3D System Pk Volume",
        scene=dict(
            xaxis_title='Velocity (m/s)',
            yaxis_title='HOB (m)',
            zaxis_title='AOF (deg)',
        ),
        margin=dict(l=0, r=0, b=0, t=30),
        height=height,
    )
    
    return fig


def plot_iso_mesh_colored_by_pk(
    iso_data: np.ndarray,
    color_data: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    level: float,
    opacity: float = 0.5,
    height: int = 700,
) -> go.Figure:
    """
    Generate 3D isosurface mesh of `iso_data` colored by `color_data`.
    Uses Marching Cubes to extract the mesh and interpolates color_data onto vertices.
    
    Args:
        iso_data: 3D array for geometry (e.g. Curvature, Sensitivity)
        color_data: 3D array for coloring (e.g. System Pk)
        hob_axis, vel_axis, aof_axis: Axis values
        level: Isosurface level for iso_data
        opacity: Mesh opacity
        height: Plot height
    """
    # Marching Cubes
    # Returns verts in (row, col, slice) which matches array indexing (i, j, k)
    # iso_data is [nH, nV, nA]
    try:
        verts, faces, normals, values = measure.marching_cubes(iso_data, level=level)
    except (ValueError, RuntimeError):
        # Fallback if no surface found at this level
        return go.Figure()

    # Interpolate color_data at vertex positions
    # map_coordinates expects (coords_dim1, coords_dim2, ...)
    color_vals = map_coordinates(color_data, verts.T, order=1)
    
    # Map vertices to physical coordinates
    # verts[:, 0] is index in dim 0 (HOB)
    # verts[:, 1] is index in dim 1 (Vel)
    # verts[:, 2] is index in dim 2 (AOF)
    
    # We need to map float index to physical value
    # Assuming uniform spacing for simplicity, or interp
    def map_axis(indices, axis):
        # Simple linear mapping: axis[0] + index * step
        # Ideally use interpolation if axes are non-uniform
        return np.interp(indices, np.arange(len(axis)), axis)

    phys_h = map_axis(verts[:, 0], hob_axis)
    phys_v = map_axis(verts[:, 1], vel_axis)
    phys_a = map_axis(verts[:, 2], aof_axis)
    
    fig = go.Figure(data=go.Mesh3d(
        x=phys_v, # Velocity (X)
        y=phys_h, # HOB (Y)
        z=phys_a, # AOF (Z)
        i=faces[:, 1], # Standard marching cubes face order needs check for Plotly?
        j=faces[:, 0], # Plotly expects i, j, k indices
        k=faces[:, 2], # Usually needs experimentation or alignment
        intensity=color_vals,
        colorscale='Jet',
        opacity=opacity,
        colorbar=dict(title='Pk'),
        cmin=0.0,
        cmax=1.0,
    ))
    
    fig.update_layout(
        title=f"Isosurface @ {level:.3f} Colored by Pk",
        scene=dict(
            xaxis_title='Velocity (m/s)',
            yaxis_title='HOB (m)',
            zaxis_title='AOF (deg)',
        ),
        margin=dict(l=0, r=0, b=0, t=30),
        height=height,
    )
    
    return fig

# =============================================================================
# Box Plots
# =============================================================================

def plot_salvo_boxplot_plotly(
    rounds_to_kill: Union[np.ndarray, Iterable[float]],
    title: str = "Rounds-to-Kill Distribution",
    pk_threshold: float = 0.9,
    max_rounds: int = 10,
    height: int = 600,
) -> go.Figure:
    """
    Interactive boxplot for R2K.
    Matches `plots.plot_salvo_boxplot`.
    """
    data = np.asarray(rounds_to_kill).flatten()
    data = data[~np.isnan(data)]
    
    fig = go.Figure()
    fig.add_trace(go.Box(
        y=data,
        name=f"Pk ≥ {pk_threshold:.0%}",
        boxpoints='outliers',
        jitter=0.3,
        pointpos=-1.8,
        marker=dict(color='rgb(7,40,89)'),
        line=dict(color='rgb(7,40,89)'),
        fillcolor='lightblue',
    ))
    
    fig.update_layout(
        title=title,
        yaxis_title="Rounds to Kill",
        yaxis_range=[0, max_rounds+1],
        height=height,
        showlegend=False,
    )
    
    # Add stats annotation similar to matplotlib version
    if len(data) > 0:
        stats_text = (
            f"Median: {np.median(data):.2f}<br>"
            f"Mean: {np.mean(data):.2f}<br>"
            f"Std: {np.std(data):.2f}<br>"
            f"N: {len(data)}"
        )
        fig.add_annotation(
            xref="paper", yref="paper",
            x=0.95, y=0.95,
            text=stats_text,
            showarrow=False,
            align="right",
            bgcolor="rgba(255, 255, 255, 0.8)",
            bordercolor="black",
            borderwidth=1,
        )
    
    return fig


# =============================================================================
# Stoplight Grid (MEGADETH plotNRbox4.m Parity)
# =============================================================================

def plot_stoplight_grid_plotly(
    pass_threshold: np.ndarray,
    pass_objective: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    title: str = "Threshold/Objective Stoplight",
    threshold_color: str = "rgb(144, 238, 144)",  # Light Green
    objective_color: str = "rgb(30, 144, 255)",   # Dodger Blue
    height: int = 500,
) -> go.Figure:
    """
    Stoplight grid showing T/O (Threshold/Objective) pass/fail status.
    
    MATLAB Reference: plotNRbox4.m
    Creates colored grid where each cell indicates whether the 
    Threshold (green) or Objective (blue) requirement is met.
    
    Args:
        pass_threshold: 2D boolean array [n_hob, n_vel] - meets Threshold nRounds
        pass_objective: 2D boolean array [n_hob, n_vel] - meets Objective nRounds
        hob_axis: Height of Burst axis values
        vel_axis: Velocity axis values
        title: Plot title
        threshold_color: RGB color for Threshold-only (green)
        objective_color: RGB color for Objective met (blue)
        height: Plot height
        
    Returns:
        plotly.graph_objects.Figure
    """
    fig = go.Figure()
    
    # Compute cell sizes
    d_hob = (hob_axis[-1] - hob_axis[0]) / (len(hob_axis) - 1) if len(hob_axis) > 1 else 1.0
    d_vel = (vel_axis[-1] - vel_axis[0]) / (len(vel_axis) - 1) if len(vel_axis) > 1 else 1.0
    
    # Threshold-Only cells (pass threshold but not objective)
    pass_threshold_only = np.logical_and(pass_threshold, ~pass_objective)
    
    # Add objective boxes (blue)
    obj_hob_idx, obj_vel_idx = np.where(pass_objective)
    for h_i, v_i in zip(obj_hob_idx, obj_vel_idx):
        fig.add_shape(
            type="rect",
            x0=vel_axis[v_i], x1=vel_axis[v_i] + d_vel,
            y0=hob_axis[h_i], y1=hob_axis[h_i] + d_hob,
            fillcolor=objective_color,
            line=dict(color="black", width=0.5),
        )
    
    # Add threshold-only boxes (green)
    thr_hob_idx, thr_vel_idx = np.where(pass_threshold_only)
    for h_i, v_i in zip(thr_hob_idx, thr_vel_idx):
        fig.add_shape(
            type="rect",
            x0=vel_axis[v_i], x1=vel_axis[v_i] + d_vel,
            y0=hob_axis[h_i], y1=hob_axis[h_i] + d_hob,
            fillcolor=threshold_color,
            line=dict(color="black", width=0.5),
        )
    
    # Add legend using dummy traces
    fig.add_trace(go.Scatter(
        x=[None], y=[None], mode='markers',
        marker=dict(size=15, color=objective_color, symbol='square'),
        name='Objective Met'
    ))
    fig.add_trace(go.Scatter(
        x=[None], y=[None], mode='markers',
        marker=dict(size=15, color=threshold_color, symbol='square'),
        name='Threshold Only'
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Velocity (m/s)",
        yaxis_title="HOB (m)",
        xaxis=dict(range=[vel_axis[0], vel_axis[-1] + d_vel]),
        yaxis=dict(range=[hob_axis[0], hob_axis[-1] + d_hob]),
        height=height,
        showlegend=True,
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
    )
    
    return fig


# =============================================================================
# Error Model PDF Visualization
# =============================================================================

def plot_error_model_pdf_plotly(
    tle_radius_m: float,
    tle_fraction: float,
    cep_radius_m: float,
    cep_fraction: float,
    bias_x_m: float = 0.0,
    bias_y_m: float = 0.0,
    n_points: int = 200,
    max_extent: Optional[float] = None,
    height: int = 500,
    show_sigma_ellipses: bool = True,
) -> go.Figure:
    """
    Visualize the 2D Gaussian error model PDF for discrete analysis.
    
    Shows the combined TLE + CEP error distribution as a 2D heatmap with
    optional 1-sigma, 2-sigma, and 3-sigma ellipses, plus bias vector.
    
    MATLAB Reference: plotBasicSalvoHist.m (adapted for 2D PDF view)
    
    Args:
        tle_radius_m: TLE radius (Rayleigh parameter conversion)
        tle_fraction: TLE fraction (typically 0.9)
        cep_radius_m: CEP radius
        cep_fraction: CEP fraction (typically 0.5)
        bias_x_m: Fixed bias in X (Deflection)
        bias_y_m: Fixed bias in Y (Range)
        n_points: Grid resolution
        max_extent: Max axis extent (auto-computed if None)
        height: Plot height
        show_sigma_ellipses: Whether to show 1σ, 2σ, 3σ ellipse contours
        
    Returns:
        plotly.graph_objects.Figure with 2D PDF heatmap
    """
    from scipy.stats import multivariate_normal
    
    # Convert radii to sigma using Rayleigh distribution relationship
    # For fraction p at radius r: sigma = r / sqrt(-2 * ln(1-p))
    def radius_to_sigma(radius: float, fraction: float) -> float:
        if fraction <= 0 or fraction >= 1 or radius <= 0:
            return 0.0
        return radius / np.sqrt(-2 * np.log(1 - fraction))
    
    sigma_tle = radius_to_sigma(tle_radius_m, tle_fraction)
    sigma_cep = radius_to_sigma(cep_radius_m, cep_fraction)
    
    # Combined sigma (RSS of TLE and CEP)
    sigma_total = np.sqrt(sigma_tle**2 + sigma_cep**2)
    
    if sigma_total < 1e-6:
        # No error - return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No error model configured (TLE/CEP = 0)",
            xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False
        )
        return fig
    
    # Compute axis extent
    if max_extent is None:
        max_extent = max(3.5 * sigma_total, abs(bias_x_m) + 3 * sigma_total, abs(bias_y_m) + 3 * sigma_total)
    
    # Create grid
    x = np.linspace(-max_extent, max_extent, n_points)
    y = np.linspace(-max_extent, max_extent, n_points)
    X, Y = np.meshgrid(x, y)
    pos = np.dstack((X, Y))
    
    # 2D Gaussian PDF (isotropic for simplicity)
    # Mean is at the bias point
    mean = [bias_x_m, bias_y_m]
    cov = [[sigma_total**2, 0], [0, sigma_total**2]]
    rv = multivariate_normal(mean, cov)
    Z = rv.pdf(pos)
    
    fig = go.Figure()
    
    # Add heatmap with reversed colorscale for dark mode (dark center, bright edges)
    fig.add_trace(go.Heatmap(
        x=x,
        y=y,
        z=Z,
        colorscale='Blues_r',  # Reversed: high values = dark blue, low = light
        showscale=True,
        colorbar=dict(title='PDF'),  # Moved inward
        zsmooth='best',  # Smooth interpolation
        name='Error PDF'
    ))
    
    # Add TLE and CEP radius circles (actual configured radii)
    if show_sigma_ellipses:
        theta = np.linspace(0, 2*np.pi, 100)
        
        # TLE radius circle (the configured radius at specified fraction)
        if tle_radius_m > 0:
            x_tle = bias_x_m + tle_radius_m * np.cos(theta)
            y_tle = bias_y_m + tle_radius_m * np.sin(theta)
            fig.add_trace(go.Scatter(
                x=x_tle, y=y_tle,
                mode='lines',
                line=dict(color='#00BFFF', width=2.5, dash='solid'),  # Deep sky blue
                name=f'TLE r={tle_radius_m:.1f}m (P={tle_fraction:.0%})',
                showlegend=True
            ))
            # Also show TLE 1-sigma
            x_tle_sig = bias_x_m + sigma_tle * np.cos(theta)
            y_tle_sig = bias_y_m + sigma_tle * np.sin(theta)
            fig.add_trace(go.Scatter(
                x=x_tle_sig, y=y_tle_sig,
                mode='lines',
                line=dict(color='#00BFFF', width=1.5, dash='dash'),
                name=f'TLE 1σ={sigma_tle:.2f}m',
                showlegend=True
            ))
        
        # CEP radius circle (the configured radius at specified fraction)
        if cep_radius_m > 0:
            x_cep = bias_x_m + cep_radius_m * np.cos(theta)
            y_cep = bias_y_m + cep_radius_m * np.sin(theta)
            fig.add_trace(go.Scatter(
                x=x_cep, y=y_cep,
                mode='lines',
                line=dict(color='#FFD700', width=2.5, dash='solid'),  # Gold
                name=f'CEP r={cep_radius_m:.1f}m (P={cep_fraction:.0%})',
                showlegend=True
            ))
            # Also show CEP 1-sigma
            x_cep_sig = bias_x_m + sigma_cep * np.cos(theta)
            y_cep_sig = bias_y_m + sigma_cep * np.sin(theta)
            fig.add_trace(go.Scatter(
                x=x_cep_sig, y=y_cep_sig,
                mode='lines',
                line=dict(color='#FFD700', width=1.5, dash='dash'),
                name=f'CEP 1σ={sigma_cep:.2f}m',
                showlegend=True
            ))
        
        # Combined 1-sigma circle (RSS of both)
        x_combined = bias_x_m + sigma_total * np.cos(theta)
        y_combined = bias_y_m + sigma_total * np.sin(theta)
        fig.add_trace(go.Scatter(
            x=x_combined, y=y_combined,
            mode='lines',
            line=dict(color='#FF4500', width=2, dash='dot'),  # Orange-red
            name=f'Combined 1σ={sigma_total:.2f}m',
            showlegend=True
        ))
    
    # Add bias vector if non-zero
    if abs(bias_x_m) > 0.1 or abs(bias_y_m) > 0.1:
        fig.add_annotation(
            x=bias_x_m, y=bias_y_m,
            ax=0, ay=0,
            xref='x', yref='y',
            axref='x', ayref='y',
            showarrow=True,
            arrowhead=2,
            arrowsize=1.5,
            arrowwidth=2,
            arrowcolor='#FF1744',  # Bright red
        )
        fig.add_trace(go.Scatter(
            x=[bias_x_m], y=[bias_y_m],
            mode='markers',
            marker=dict(size=12, color='#FF1744', symbol='x', line=dict(width=2)),
            name=f'Bias ({bias_x_m:.1f}, {bias_y_m:.1f})m'
        ))
    
    # Add crosshairs at origin - use lighter color for dark mode
    fig.add_hline(y=0, line_dash="dot", line_color="rgba(255,255,255,0.5)", line_width=1)
    fig.add_vline(x=0, line_dash="dot", line_color="rgba(255,255,255,0.5)", line_width=1)
    
    # Stats annotation - use semi-transparent dark background for dark mode
    stats_text = (
        f"<b>Error Model Components:</b><br>"
        f"TLE{tle_fraction*100:.0f}: σ={sigma_tle:.2f}m (r={tle_radius_m:.1f}m)<br>"
        f"CEP{cep_fraction*100:.0f}: σ={sigma_cep:.2f}m (r={cep_radius_m:.1f}m)<br>"
        f"Combined σ: {sigma_total:.2f}m<br>"
        f"Bias: ({bias_x_m:.1f}, {bias_y_m:.1f})m"
    )
    fig.add_annotation(
        xref="paper", yref="paper",
        x=0.12, y=0.92,  # Moved inward from edges
        text=stats_text,
        showarrow=False,
        align="left",
        bgcolor="rgba(30,30,30,0.85)",
        bordercolor="rgba(255,255,255,0.3)",
        borderwidth=1,
        font=dict(size=12, color="white")  # 23% larger (10 -> 12)
    )
    
    fig.update_layout(
        title="Delivery Error Model PDF (TLE + CEP)",
        xaxis_title="Deflection (m)",
        yaxis_title="Range (m)",
        xaxis=dict(
            constrain='domain',
        ),
        yaxis=dict(
            scaleanchor="x",
            scaleratio=1,
            constrain='domain',
        ),
        height=height,
        showlegend=True,
        legend=dict(yanchor="top", y=0.92, xanchor="right", x=0.88, font=dict(size=12)),  # Moved inward
        # Dark mode compatible - transparent backgrounds
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
    )
    
    return fig


def plot_pk_vs_vel_hob_plotly(
    pk_2d: np.ndarray,
    vel_axis: np.ndarray,
    hob_axis: np.ndarray,
    title: str = "System Pk (Vel vs HOB)",
    z_min: float = 0.0,
    z_max: float = 1.0,
    height: int = 600,
) -> go.Figure:
    """
    System Pk heatmap over Velocity vs HOB grid.
    
    MATLAB Reference: xAvgPk9.m - Pk averaged or sliced over terminal conditions.
    
    Args:
        pk_2d: 2D array [n_hob, n_vel] of System Pk values
        vel_axis: Velocity axis values
        hob_axis: HOB axis values
        title: Plot title
        z_min, z_max: Colorscale range
        height: Plot height
        
    Returns:
        plotly.graph_objects.Figure
    """
    fig = go.Figure(data=go.Contour(
        z=pk_2d,  # [n_hob, n_vel] - rows=HOB, cols=Vel
        x=vel_axis,
        y=hob_axis,
        colorscale=get_colorscale('blue_red'),
        zmin=z_min,
        zmax=z_max,
        contours=dict(
            coloring='heatmap',
            showlabels=True,
            labelfont=dict(size=10, color='black'),
            start=z_min,
            end=z_max,
            size=0.1,
        ),
        line_smoothing=0.85,
        colorbar=dict(title='Pk'),
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Velocity (m/s)",
        yaxis_title="HOB (m)",
        height=height,
        margin=dict(l=50, r=50, t=50, b=50),
    )
    
    return fig


def plot_r2k_stoplight_plotly(
    r2k_2d: np.ndarray,
    vel_axis: np.ndarray,
    hob_axis: np.ndarray,
    threshold_rounds: int = 3,
    objective_rounds: int = 2,
    title: str = "R2K Stoplight Grid",
    height: int = 500,
) -> go.Figure:
    """
    Rounds-to-Kill stoplight grid showing T/O compliance.
    
    MATLAB Reference: plotNRbox4.m - Threshold/Objective stoplight visualization.
    
    Args:
        r2k_2d: 2D array [n_hob, n_vel] of rounds-to-kill values
        vel_axis: Velocity axis values
        hob_axis: HOB axis values
        threshold_rounds: Max rounds for Threshold (green)
        objective_rounds: Max rounds for Objective (blue)
        title: Plot title
        height: Plot height
        
    Returns:
        plotly.graph_objects.Figure
    """
    pass_threshold = r2k_2d <= threshold_rounds
    pass_objective = r2k_2d <= objective_rounds
    
    return plot_stoplight_grid_plotly(
        pass_threshold=pass_threshold,
        pass_objective=pass_objective,
        hob_axis=hob_axis,
        vel_axis=vel_axis,
        title=title,
        height=height,
    )


def plot_multi_threshold_boxplot_plotly(
    r2k_data: np.ndarray,
    pk_thresholds: List[float],
    title: str = "Rounds-to-Kill by Pk Threshold",
    max_rounds: int = 10,
    height: int = 500,
) -> go.Figure:
    """
    Multi-threshold box plot for R2K across different Pk thresholds.
    
    MATLAB Reference: MEGADETH_SalvoBoxPlot_v01h.m
    
    Args:
        r2k_data: Array [n_hob, n_vel, n_aof, n_thresholds] or similar
        pk_thresholds: List of Pk threshold values
        title: Plot title
        max_rounds: Max rounds (y-axis limit)
        height: Plot height
        
    Returns:
        plotly.graph_objects.Figure
    """
    fig = go.Figure()
    
    colors = px.colors.qualitative.Plotly
    
    for i, pk_thresh in enumerate(pk_thresholds):
        # Extract data for this threshold
        if r2k_data.ndim == 4:
            data = r2k_data[:, :, :, i].flatten()
        elif r2k_data.ndim == 3:
            data = r2k_data[:, :, i].flatten()
        else:
            data = r2k_data.flatten()
        
        data = data[~np.isnan(data)]
        
        if len(data) > 0:
            fig.add_trace(go.Box(
                y=data,
                name=f"Pk ≥ {pk_thresh:.0%}",
                marker_color=colors[i % len(colors)],
                boxpoints='outliers',
            ))
    
    fig.update_layout(
        title=title,
        yaxis_title="Rounds to Kill",
        yaxis_range=[0, max_rounds + 1],
        height=height,
        showlegend=True,
    )
    
    return fig


def plot_mc_draw_diagnostics_plotly(
    aimpoint_offsets: np.ndarray,
    dispersion_offsets: np.ndarray,
    tle_1sigma: float,
    cep_1sigma: float,
    var_bias: Optional[Tuple[float, float]] = None,
    n_salvos: int = 1,
    n_shots_per_salvo: int = 1,
    title: str = "MC Draw Diagnostics",
    height: int = 700,
    width: int = 1200,
) -> go.Figure:
    """
    Create interactive Plotly visualization of MC draw diagnostics.
    
    Shows scatter plots of aimpoint (TLE) and dispersion (CEP) offsets
    with 1/2/3 sigma circles and marginal histograms.
    
    Parameters
    ----------
    aimpoint_offsets : np.ndarray
        Shape (n_salvos, 2) - TLE + VarBias offsets in [x, y] format (meters)
    dispersion_offsets : np.ndarray
        Shape (n_salvos, n_shots, 2) - CEP offsets in [x, y] format (meters)
    tle_1sigma : float
        TLE 1-sigma radius (meters)
    cep_1sigma : float
        CEP 1-sigma radius (meters)
    var_bias : tuple, optional
        (bias_x, bias_y) fixed bias component (meters)
    n_salvos : int
        Number of salvos for annotation
    n_shots_per_salvo : int
        Shots per salvo for annotation
    title : str
        Figure title
    height : int
        Figure height in pixels
    width : int
        Figure width in pixels
    
    Returns
    -------
    go.Figure
        Interactive Plotly figure with draw scatter plots and histograms
    """
    from plotly.subplots import make_subplots
    
    # Create 2x4 subplot layout similar to matplotlib version
    # Row 1: Aimpoint scatter | Aimpoint Y-hist | Dispersion scatter | Dispersion Y-hist
    # Row 2: Aimpoint X-hist  | (empty)         | Dispersion X-hist  | (empty)
    fig = make_subplots(
        rows=2, cols=4,
        column_widths=[0.35, 0.15, 0.35, 0.15],
        row_heights=[0.7, 0.3],
        horizontal_spacing=0.02,
        vertical_spacing=0.05,
        specs=[
            [{"type": "scatter"}, {"type": "histogram"}, {"type": "scatter"}, {"type": "histogram"}],
            [{"type": "histogram"}, None, {"type": "histogram"}, None],
        ],
    )
    
    # --- Aimpoint (TLE + VarBias) Scatter Plot ---
    aim_x = aimpoint_offsets[:, 0]
    aim_y = aimpoint_offsets[:, 1]
    
    # Determine axis limits for aimpoint
    aim_max = max(np.abs(aim_x).max(), np.abs(aim_y).max(), 3 * tle_1sigma) * 1.2
    
    # Scatter points
    fig.add_trace(
        go.Scatter(
            x=aim_x, y=aim_y,
            mode='markers',
            marker=dict(size=5, color='blue', opacity=0.6),
            name='Aimpoint Draws',
            hovertemplate='X: %{x:.2f}m<br>Y: %{y:.2f}m<extra></extra>',
        ),
        row=1, col=1
    )
    
    # Add sigma circles for TLE
    for sigma, dash in [(1, 'solid'), (2, 'dash'), (3, 'dot')]:
        theta = np.linspace(0, 2 * np.pi, 100)
        r = sigma * tle_1sigma
        fig.add_trace(
            go.Scatter(
                x=r * np.cos(theta), y=r * np.sin(theta),
                mode='lines',
                line=dict(color='red', width=1.5, dash=dash),
                name=f'{sigma}σ TLE ({r:.1f}m)',
                showlegend=True,
                hoverinfo='skip',
            ),
            row=1, col=1
        )
    
    # Add VarBias marker if present
    if var_bias is not None and (var_bias[0] != 0 or var_bias[1] != 0):
        fig.add_trace(
            go.Scatter(
                x=[var_bias[0]], y=[var_bias[1]],
                mode='markers',
                marker=dict(symbol='x', size=12, color='green', line=dict(width=2)),
                name=f'VarBias ({var_bias[0]:.1f}, {var_bias[1]:.1f})m',
            ),
            row=1, col=1
        )
    
    # --- Aimpoint Y-axis Histogram (horizontal) ---
    fig.add_trace(
        go.Histogram(
            y=aim_y,
            nbinsx=30,
            marker_color='blue',
            opacity=0.6,
            name='Aim Y',
            showlegend=False,
        ),
        row=1, col=2
    )
    
    # Add horizontal sigma lines to Y-histogram
    for sigma in [1, 2, 3]:
        for sign in [-1, 1]:
            fig.add_hline(
                y=sign * sigma * tle_1sigma,
                line=dict(color='red', width=1, dash='dot' if sigma == 3 else ('dash' if sigma == 2 else 'solid')),
                row=1, col=2,
            )
    
    # --- Aimpoint X-axis Histogram ---
    fig.add_trace(
        go.Histogram(
            x=aim_x,
            nbinsx=30,
            marker_color='blue',
            opacity=0.6,
            name='Aim X',
            showlegend=False,
        ),
        row=2, col=1
    )
    
    # Add vertical sigma lines to X-histogram
    for sigma in [1, 2, 3]:
        for sign in [-1, 1]:
            fig.add_vline(
                x=sign * sigma * tle_1sigma,
                line=dict(color='red', width=1, dash='dot' if sigma == 3 else ('dash' if sigma == 2 else 'solid')),
                row=2, col=1,
            )
    
    # --- Dispersion (CEP) Scatter Plot ---
    # Flatten dispersion offsets: (n_salvos, n_shots, 2) -> (n_total, 2)
    if dispersion_offsets.ndim == 3:
        disp_flat = dispersion_offsets.reshape(-1, 2)
    else:
        disp_flat = dispersion_offsets
    
    disp_x = disp_flat[:, 0]
    disp_y = disp_flat[:, 1]
    
    # Determine axis limits for dispersion
    disp_max = max(np.abs(disp_x).max(), np.abs(disp_y).max(), 3 * cep_1sigma) * 1.2
    
    # Scatter points
    fig.add_trace(
        go.Scatter(
            x=disp_x, y=disp_y,
            mode='markers',
            marker=dict(size=4, color='orange', opacity=0.5),
            name='Dispersion Draws',
            hovertemplate='X: %{x:.2f}m<br>Y: %{y:.2f}m<extra></extra>',
        ),
        row=1, col=3
    )
    
    # Add sigma circles for CEP
    for sigma, dash in [(1, 'solid'), (2, 'dash'), (3, 'dot')]:
        theta = np.linspace(0, 2 * np.pi, 100)
        r = sigma * cep_1sigma
        fig.add_trace(
            go.Scatter(
                x=r * np.cos(theta), y=r * np.sin(theta),
                mode='lines',
                line=dict(color='darkred', width=1.5, dash=dash),
                name=f'{sigma}σ CEP ({r:.1f}m)',
                showlegend=True,
                hoverinfo='skip',
            ),
            row=1, col=3
        )
    
    # --- Dispersion Y-axis Histogram (horizontal) ---
    fig.add_trace(
        go.Histogram(
            y=disp_y,
            nbinsx=30,
            marker_color='orange',
            opacity=0.6,
            name='Disp Y',
            showlegend=False,
        ),
        row=1, col=4
    )
    
    # Add horizontal sigma lines to Y-histogram
    for sigma in [1, 2, 3]:
        for sign in [-1, 1]:
            fig.add_hline(
                y=sign * sigma * cep_1sigma,
                line=dict(color='darkred', width=1, dash='dot' if sigma == 3 else ('dash' if sigma == 2 else 'solid')),
                row=1, col=4,
            )
    
    # --- Dispersion X-axis Histogram ---
    fig.add_trace(
        go.Histogram(
            x=disp_x,
            nbinsx=30,
            marker_color='orange',
            opacity=0.6,
            name='Disp X',
            showlegend=False,
        ),
        row=2, col=3
    )
    
    # Add vertical sigma lines to X-histogram
    for sigma in [1, 2, 3]:
        for sign in [-1, 1]:
            fig.add_vline(
                x=sign * sigma * cep_1sigma,
                line=dict(color='darkred', width=1, dash='dot' if sigma == 3 else ('dash' if sigma == 2 else 'solid')),
                row=2, col=3,
            )
    
    # --- Layout updates ---
    # Aimpoint scatter axes
    fig.update_xaxes(range=[-aim_max, aim_max], title_text="Deflection (m)", row=1, col=1)
    fig.update_yaxes(range=[-aim_max, aim_max], title_text="Range (m)", row=1, col=1, scaleanchor="x", scaleratio=1)
    
    # Aimpoint Y-histogram axes
    fig.update_xaxes(showticklabels=False, row=1, col=2)
    fig.update_yaxes(range=[-aim_max, aim_max], showticklabels=False, row=1, col=2)
    
    # Aimpoint X-histogram axes
    fig.update_xaxes(range=[-aim_max, aim_max], showticklabels=False, row=2, col=1)
    fig.update_yaxes(showticklabels=False, row=2, col=1)
    
    # Dispersion scatter axes
    fig.update_xaxes(range=[-disp_max, disp_max], title_text="Deflection (m)", row=1, col=3)
    fig.update_yaxes(range=[-disp_max, disp_max], title_text="Range (m)", row=1, col=3, scaleanchor="x3", scaleratio=1)
    
    # Dispersion Y-histogram axes
    fig.update_xaxes(showticklabels=False, row=1, col=4)
    fig.update_yaxes(range=[-disp_max, disp_max], showticklabels=False, row=1, col=4)
    
    # Dispersion X-histogram axes
    fig.update_xaxes(range=[-disp_max, disp_max], showticklabels=False, row=2, col=3)
    fig.update_yaxes(showticklabels=False, row=2, col=3)
    
    # Annotations for subplot titles
    fig.add_annotation(
        text=f"<b>Aimpoint Draws (TLE)</b><br>n={len(aim_x)} salvos, σ={tle_1sigma:.1f}m",
        xref="x domain", yref="y domain",
        x=0.5, y=1.12, xanchor="center", yanchor="bottom",
        showarrow=False, font=dict(size=12),
        row=1, col=1
    )
    
    fig.add_annotation(
        text=f"<b>Dispersion Draws (CEP)</b><br>n={len(disp_x)} shots, σ={cep_1sigma:.1f}m",
        xref="x3 domain", yref="y3 domain",
        x=0.5, y=1.12, xanchor="center", yanchor="bottom",
        showarrow=False, font=dict(size=12),
        row=1, col=3
    )
    
    # Main title and layout
    fig.update_layout(
        title=dict(
            text=f"<b>{title}</b><br><sup>{n_salvos} salvos × {n_shots_per_salvo} shots/salvo</sup>",
            x=0.5,
            xanchor='center',
        ),
        height=height,
        width=width,
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.15,
            xanchor="center",
            x=0.5,
        ),
        margin=dict(t=100, b=100),
    )
    
    return fig
