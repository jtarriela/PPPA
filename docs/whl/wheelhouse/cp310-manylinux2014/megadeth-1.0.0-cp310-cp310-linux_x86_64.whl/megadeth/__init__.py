"""
MEGADETH: Systematic Assessment of Blast/Frag Round Effectiveness.

This package provides high-performance lethality analysis tools for optimizing
warhead designs. Supports parallel execution via MPI and architecture-optimized
C++ accelerators.

C++ Accelerator:
    The C++ backend is built during `pip install` and uses target_clones
    for automatic EPYC/Skylake dispatch. No runtime compilation needed.
    
    Set MEGADETH_USE_CPP=0 to force Python fallback (for debugging).
"""
import os

__all__ = ["__version__", "has_accelerator"]
__version__ = "1.0.0"

# =============================================================================
# C++ Accelerator Import
# =============================================================================
# The accelerator is built at install time via scikit-build-core.
# Uses target_clones for automatic EPYC/Skylake/generic dispatch.
_accelerator_available = False

try:
    import megadeth_accelerator
    _accelerator_available = True
except ImportError:
    megadeth_accelerator = None
    if os.environ.get("MEGADETH_DEBUG", "0") == "1":
        import sys
        print("[MEGADETH] C++ accelerator not available, using Python fallback", 
              file=sys.stderr)


def has_accelerator() -> bool:
    """Check if C++ accelerator is available."""
    return _accelerator_available
