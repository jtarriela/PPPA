"""
Discrete Grid Analysis: v3.0 Implementation

Implements the 4-source error model with nested integration for multi-shot
salvo analysis, achieving MATLAB MEGADETH parity.

Key Features:
- 4-source error decomposition: TLE, CEP, Fixed Bias, Variable Bias
- Nested integration: CEP (inner) → Salvo Center (outer)
- MATLAB-parity rounds-to-kill with linear interpolation
- Hybrid execution: deterministic grid or MC salvo sampling

Reference: docs/DISCRETE_ANALYSIS.md (v3.0)
MATLAB Reference: SalvoAnalysis03x3.m, MEGADETH_vA0p9s_mod3.m
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Mapping, Optional, Tuple, Union

import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy.ndimage import gaussian_filter

from megadeth.config.loader import _validate
from megadeth.config.schema import CampaignConfig

# Import sigma conversion from monte_carlo for single source of truth
from megadeth.analysis.monte_carlo import circular_error_to_sigma

# C++ Accelerator (optional)
try:
    from megadeth.analysis._accelerator import (
        AVAILABLE as CPP_ACCEL_AVAILABLE,
        compute_multi_shot_nested as _cpp_multi_shot_nested,
        compute_rounds_to_kill as _cpp_r2k,
    )
except ImportError:
    CPP_ACCEL_AVAILABLE = False
    _cpp_multi_shot_nested = None
    _cpp_r2k = None

# Full C++ Backend Dispatch (ADR-003)
from megadeth.core import (
    use_cpp as use_cpp_backend,
    compute_multi_shot_hybrid as _cpp_multi_shot_hybrid,
    bilinear_interpolate_2d as _cpp_bilinear_interp,
)

logger = logging.getLogger(__name__)


def _transpose_hypercube_to_internal(pk_hypercube: np.ndarray) -> np.ndarray:
    """
    Transpose hypercube from HypercubeBuilder format to internal analysis format.
    
    HypercubeBuilder produces: [n_x, n_y, n_hob, n_vel, n_aof] - miss grid first
    Internal analysis expects: [n_hob, n_vel, n_aof, n_x, n_y] - terminal conditions first
    
    This enables efficient einsum operations like 'hvaxy,xy->hva' for 
    integrating over the miss grid while preserving terminal condition structure.
    
    Args:
        pk_hypercube: 5D array in [n_x, n_y, n_hob, n_vel, n_aof] format
        
    Returns:
        5D array transposed to [n_hob, n_vel, n_aof, n_x, n_y] format
    """
    # From [x, y, h, v, a] to [h, v, a, x, y]
    return np.transpose(pk_hypercube, (2, 3, 4, 0, 1))


# =============================================================================
# Data Structures (Story 1.7)
# =============================================================================

@dataclass
class ErrorSigmas:
    """
    Converted sigma values from 4-source error model.
    
    Uses Rayleigh CDF inversion: σ = R / sqrt(-2 * ln(1 - F))
    
    MATLAB Parity (2025-12-02): Coordinate convention matches MEGADETH SalvoAnalysis03x3.m:
        - X-axis (bias_x) = Deflection (crossrange) - MATLAB PkDatabase{1}
        - Y-axis (bias_y) = Range (downrange) - MATLAB PkDatabase{2}
    
    Attributes:
        sigma_tle: TLE standard deviation (meters)
        sigma_cep: CEP standard deviation (meters)  
        sigma_var_bias: Variable bias standard deviation (meters)
        sigma_salvo: Combined salvo-level sigma = sqrt(σ_TLE² + σ_var_bias²)
        fixed_bias: (bias_x, bias_y) constant offset in meters where X=Deflection, Y=Range
    """
    sigma_tle: float
    sigma_cep: float
    sigma_var_bias: float
    sigma_salvo: float
    fixed_bias: Tuple[float, float]
    
    @property
    def sigma_total(self) -> float:
        """RSS total for single-shot analysis only."""
        return np.sqrt(self.sigma_tle**2 + self.sigma_var_bias**2 + self.sigma_cep**2)
    
    @classmethod
    def from_error_model(
        cls,
        tle_radius_m: float,
        tle_fraction: float,
        cep_radius_m: float,
        cep_fraction: float,
        fixed_bias_x_m: float,
        fixed_bias_y_m: float,
        variable_bias_radius_m: float,
        variable_bias_fraction: float,
    ) -> "ErrorSigmas":
        """
        Create ErrorSigmas from 4-source error model parameters.
        
        MATLAB Parity: X=Deflection, Y=Range (no swap needed).
        
        Args:
            fixed_bias_x_m: Deflection bias (crossrange), MATLAB Precision column 5
            fixed_bias_y_m: Range bias (downrange), MATLAB Precision column 6
        
        Uses circular_error_to_sigma for Rayleigh CDF inversion.
        """
        sigma_tle = circular_error_to_sigma(tle_radius_m, tle_fraction) if tle_radius_m > 0 else 0.0
        sigma_cep = circular_error_to_sigma(cep_radius_m, cep_fraction) if cep_radius_m > 0 else 0.0
        sigma_var_bias = circular_error_to_sigma(variable_bias_radius_m, variable_bias_fraction) if variable_bias_radius_m > 0 else 0.0
        sigma_salvo = np.sqrt(sigma_tle**2 + sigma_var_bias**2)
        
        # MATLAB Parity: fixed_bias = (X=Deflection, Y=Range) - no swap
        return cls(
            sigma_tle=sigma_tle,
            sigma_cep=sigma_cep,
            sigma_var_bias=sigma_var_bias,
            sigma_salvo=sigma_salvo,
            fixed_bias=(fixed_bias_x_m, fixed_bias_y_m),
        )


@dataclass
class SalvoCenterGrid:
    """
    Precomputed Pk at grid of salvo centers for nested integration.
    
    Each salvo center represents a potential (TLE + VarBias + FixedBias) offset.
    At each center, CEP-only convolution has been applied.
    
    Attributes:
        pk_sys_grid: [n_cx, n_cy, n_h, n_v, n_α] - single-shot Pk at each salvo center
        cx_axis: Salvo center X coordinates
        cy_axis: Salvo center Y coordinates
        sigma_salvo: Combined salvo-level sigma used for grid extent
        fixed_bias: (bias_x, bias_y) center of the salvo distribution
    """
    pk_sys_grid: np.ndarray
    cx_axis: np.ndarray
    cy_axis: np.ndarray
    sigma_salvo: float
    fixed_bias: Tuple[float, float]
    
    @property
    def n_salvo_centers(self) -> int:
        """Number of salvo centers along each axis."""
        return len(self.cx_axis)


@dataclass
class DiscreteAnalysisResults:
    """
    Full discrete analysis outputs matching v3.0 specification.
    
    Supports both single-shot and multi-shot salvo analysis modes.
    """
    # Single-shot system Pk (from RSS or single-shot mode)
    system_pk: np.ndarray  # [h, v, α]
    
    # Multi-shot results (from nested/hybrid integration)
    mean_pk_by_shot: Optional[np.ndarray] = None  # [K, h, v, α]
    rounds_to_kill: Optional[np.ndarray] = None   # [h, v, α, n_thresholds]
    
    # Delivery-convolved results
    reliability: Optional[np.ndarray] = None  # [h, v, α]
    
    # Sensitivity and failure metrics
    sensitivity: Optional[np.ndarray] = None  # [h, v, α]
    failure_prob: Optional[np.ndarray] = None # [h, v, α]
    
    # Axes metadata for NPZ export
    hob_axis: Optional[np.ndarray] = None
    vel_axis: Optional[np.ndarray] = None
    aof_axis: Optional[np.ndarray] = None
    pk_thresholds: Optional[np.ndarray] = None
    
    # Scalar metrics
    metadata: Dict[str, float] = field(default_factory=dict)
    
    # Configuration used
    error_model: Optional[Dict[str, float]] = None
    integration_method: str = "single_shot_rss"


# Legacy compatibility alias
@dataclass
class DiscreteGridResults:
    """Legacy-compatible result structure."""
    system_pk: np.ndarray
    reliability: np.ndarray
    sensitivity: np.ndarray
    failure_prob: np.ndarray
    metadata: Dict[str, float]


# =============================================================================
# Main Analyzer Class
# =============================================================================

class DiscreteGridAnalyzer:
    """
    Discrete grid analysis with 4-source error model and MATLAB parity.
    
    Implements v3.0 specification with:
    - 4-source error decomposition (TLE, CEP, Fixed Bias, Variable Bias)
    - Nested integration for exact multi-shot salvo analysis
    - MATLAB-parity rounds-to-kill with linear interpolation
    - Hybrid execution mode for production efficiency
    
    Reference: docs/DISCRETE_ANALYSIS.md (v3.0)
    """

    def __init__(
        self,
        config: Optional[Union[CampaignConfig, Mapping]] = None,
        pk_threshold: float = 0.5,
        gradient_threshold: float = 0.05,
    ):
        """
        Initialize analyzer.
        
        Args:
            config: Campaign configuration (optional for standalone use)
            pk_threshold: Default Pk threshold for envelope metrics
            gradient_threshold: Default gradient threshold for robustness
        """
        self.cfg = _validate(CampaignConfig, config) if config else None
        self.pk_threshold = pk_threshold
        self.gradient_threshold = gradient_threshold
        
        # Cache for precomputed grids
        self._salvo_center_cache: Optional[SalvoCenterGrid] = None

    # =========================================================================
    # Core Gaussian Weights (Story 1.2)
    # =========================================================================

    def _gaussian_weights(
        self,
        miss_x: np.ndarray,
        miss_y: np.ndarray,
        sigma: float,
        bias_x: float = 0.0,
        bias_y: float = 0.0,
    ) -> np.ndarray:
        """
        2D Cartesian Gaussian PDF centered at fixed bias offset.
        
        Spec Reference: DISCRETE_ANALYSIS.md Section 3.2
        
        Args:
            miss_x: X coordinates grid (meshgrid output, "ij" indexing)
            miss_y: Y coordinates grid  
            sigma: Standard deviation for isotropic 2D Gaussian
            bias_x: Fixed bias X offset (center of distribution)
            bias_y: Fixed bias Y offset
            
        Returns:
            weights: Unnormalized Gaussian weights, same shape as miss_x
        """
        if sigma <= 0:
            # Delta function at bias location
            w = np.zeros_like(miss_x)
            # Find nearest grid point to bias
            dist = (miss_x - bias_x)**2 + (miss_y - bias_y)**2
            idx = np.unravel_index(np.argmin(dist), dist.shape)
            w[idx] = 1.0
            return w
        
        coeff = 1.0 / (2.0 * np.pi * sigma**2)
        r2 = (miss_x - bias_x)**2 + (miss_y - bias_y)**2
        return coeff * np.exp(-r2 / (2 * sigma**2))

    # =========================================================================
    # Stage 1: Single-Shot System Pk (Story 1.3)
    # =========================================================================

    def compute_single_shot_pk(
        self,
        pk_det: np.ndarray,
        miss_x_axis: np.ndarray,
        miss_y_axis: np.ndarray,
        error_sigmas: ErrorSigmas,
    ) -> np.ndarray:
        """
        Compute single-shot system Pk using RSS combination.
        
        Valid for SINGLE-SHOT ONLY because it combines all error sources
        into a single sigma, destroying the salvo-level correlation.
        
        Spec Reference: DISCRETE_ANALYSIS.md Section 3.1-3.5
        
        Args:
            pk_det: 5D Pk hypercube from HypercubeBuilder [n_mx, n_my, n_h, n_v, n_α]
                    Note: This is the native format from HypercubeBuilder with
                    miss grid axes first, then terminal conditions.
            miss_x_axis: Miss distance X coordinates (deflection)
            miss_y_axis: Miss distance Y coordinates (range)
            error_sigmas: Converted sigma values from error model
            
        Returns:
            pk_sys: 3D system Pk [n_h, n_v, n_α]
        """
        miss_x_axis = np.asarray(miss_x_axis, dtype=float)
        miss_y_axis = np.asarray(miss_y_axis, dtype=float)
        pk_det = np.asarray(pk_det, dtype=float)
        
        # Transpose from HypercubeBuilder format [x, y, h, v, a] to internal [h, v, a, x, y]
        pk_internal = _transpose_hypercube_to_internal(pk_det)
        
        # RSS combination is valid for single shot
        sigma_total = error_sigmas.sigma_total
        
        # Build 2D Gaussian weights centered at fixed bias
        mx, my = np.meshgrid(miss_x_axis, miss_y_axis, indexing="ij")
        b_x, b_y = error_sigmas.fixed_bias
        weights = self._gaussian_weights(mx, my, sigma_total, bias_x=b_x, bias_y=b_y)
        
        # Grid spacing
        dx = float(np.mean(np.diff(miss_x_axis))) if len(miss_x_axis) > 1 else 1.0
        dy = float(np.mean(np.diff(miss_y_axis))) if len(miss_y_axis) > 1 else 1.0
        
        # Normalize: sum * dx * dy = 1
        norm = np.sum(weights) * dx * dy
        g_norm = weights / norm if norm > 0 else weights
        
        # Integrate: Pk_sys[h,v,α] = Σ Pk_internal[h,v,α,mx,my] * g[mx,my] * dx * dy
        # pk_internal shape: [h, v, α, mx, my], weights shape: [mx, my]
        pk_sys = np.einsum('hvaxy,xy->hva', pk_internal, g_norm * dx * dy)
        
        return pk_sys

    # =========================================================================
    # Stage 1b: Salvo Center Grid Precomputation (Story 1.4)
    # =========================================================================

    def precompute_salvo_center_grid(
        self,
        pk_det: np.ndarray,
        miss_x_axis: np.ndarray,
        miss_y_axis: np.ndarray,
        error_sigmas: ErrorSigmas,
        n_salvo_centers: int = 31,
        use_convolution: bool = True,
    ) -> SalvoCenterGrid:
        """
        Precompute single-shot Pk at grid of salvo centers.
        
        Each salvo center represents a potential (TLE + VarBias + FixedBias) offset.
        At each center, we integrate only over CEP dispersion.
        
        Shapes:
            pk_det: [n_mx, n_my, n_h, n_v, n_α] (native HypercubeBuilder format)
            miss_x_axis / miss_y_axis: [n_mx], [n_my]
            output pk_sys_grid: [n_cx, n_cy, n_h, n_v, n_α]
        
        Spec Reference: DISCRETE_ANALYSIS.md Section 4.3-4.5
        
        Args:
            pk_det: 5D Pk hypercube from HypercubeBuilder [n_mx, n_my, n_h, n_v, n_α]
                    Note: This is the native format from HypercubeBuilder with
                    miss grid axes first, then terminal conditions.
            miss_x_axis: Miss distance X coordinates (deflection)
            miss_y_axis: Miss distance Y coordinates (range)
            error_sigmas: Converted sigma values from error model
            n_salvo_centers: Grid resolution for salvo centers (default 31×31)
            use_convolution: If True, use fast FFT convolution + interpolation (v3.1).
                            If False, use explicit einsum integration (v3.0 legacy).
            
        Returns:
            SalvoCenterGrid with pk_sys_grid[cx, cy, h, v, α]
        """
        pk_det = np.asarray(pk_det, dtype=float)
        miss_x_axis = np.asarray(miss_x_axis, dtype=float)
        miss_y_axis = np.asarray(miss_y_axis, dtype=float)
        
        # Transpose from HypercubeBuilder format [x, y, h, v, a] to internal [h, v, a, x, y]
        pk_internal = _transpose_hypercube_to_internal(pk_det)
        
        b_x, b_y = error_sigmas.fixed_bias
        sigma_salvo = error_sigmas.sigma_salvo
        sigma_cep = error_sigmas.sigma_cep
        
        # Build salvo center grid (±3σ coverage)
        half_width = 3 * sigma_salvo if sigma_salvo > 0 else max(np.ptp(miss_x_axis), np.ptp(miss_y_axis)) / 4
        if half_width < 1.0:
            half_width = max(np.ptp(miss_x_axis), np.ptp(miss_y_axis)) / 4
            
        cx_axis = np.linspace(b_x - half_width, b_x + half_width, n_salvo_centers)
        cy_axis = np.linspace(b_y - half_width, b_y + half_width, n_salvo_centers)
        
        # Grid spacing
        dx = float(np.mean(np.diff(miss_x_axis))) if len(miss_x_axis) > 1 else 1.0
        dy = float(np.mean(np.diff(miss_y_axis))) if len(miss_y_axis) > 1 else 1.0
        
        # Get dimensions from transposed array: [h, v, a, x, y]
        n_h, n_v, n_a = pk_internal.shape[:3]
        n_mx, n_my = pk_internal.shape[3:]
        
        logger.info(
            f"Precomputing salvo center grid: {n_salvo_centers}×{n_salvo_centers} centers, "
            f"sigma_CEP={sigma_cep:.2f}m, sigma_salvo={sigma_salvo:.2f}m"
            f"method={'convolution' if use_convolution else 'einsum'}"
        )
        
        if sigma_cep > 0 and use_convolution:
            # =================================================================
            # OPTIMIZED PATH (v3.1): FFT convolution + interpolation
            # =================================================================
            # Instead of computing a 4D weight matrix [n_cx, n_cy, n_mx, n_my],
            # we convolve the Pk grid with a Gaussian kernel once, then
            # interpolate at the requested salvo center coordinates.
            #
            # Complexity: O(H*V*A * Mx*My * log(Mx*My)) + O(C^2 * H*V*A)
            # vs O(C^2 * Mx * My * H*V*A) for einsum approach
            # =================================================================
            
            # Convert sigma from meters to grid indices
            sigma_x_idx = sigma_cep / dx
            sigma_y_idx = sigma_cep / dy
            
            # Convolve each terminal condition slice with the CEP Gaussian
            # pk_internal shape: [h, v, a, x, y]
            # gaussian_filter operates on the last two axes
            pk_convolved = gaussian_filter(
                pk_internal, 
                sigma=(0, 0, 0, sigma_x_idx, sigma_y_idx),
                mode='constant',
                cval=0.0,
            )
            
            # Build interpolator for the convolved grid
            # We need to interpolate at (cx, cy) for each (h, v, a)
            # Reshape for RegularGridInterpolator: needs [x, y, ...] with x, y as first axes
            # pk_convolved is [h, v, a, x, y], transpose to [x, y, h, v, a]
            pk_for_interp = pk_convolved.transpose(3, 4, 0, 1, 2)  # [x, y, h, v, a]
            
            # Flatten terminal conditions for vectorized interpolation
            n_terminal = n_h * n_v * n_a
            pk_flat = pk_for_interp.reshape(n_mx, n_my, n_terminal)
            
            interp = RegularGridInterpolator(
                (miss_x_axis, miss_y_axis),
                pk_flat,
                bounds_error=False,
                fill_value=0.0,
            )
            
            # Build query points for all salvo centers
            cx_mesh, cy_mesh = np.meshgrid(cx_axis, cy_axis, indexing='ij')
            query_points = np.column_stack([cx_mesh.ravel(), cy_mesh.ravel()])  # [n_cx*n_cy, 2]
            
            # Interpolate at all salvo centers
            pk_at_centers = interp(query_points)  # [n_cx*n_cy, n_terminal]
            
            # Reshape to [n_cx, n_cy, h, v, a]
            pk_sys_grid = pk_at_centers.reshape(n_salvo_centers, n_salvo_centers, n_h, n_v, n_a)
            
            logger.debug(
                f"Convolution optimization: sigma_idx=({sigma_x_idx:.2f}, {sigma_y_idx:.2f}), "
                f"memory saved ~{(n_salvo_centers**2 * n_mx * n_my * 8) / 1e6:.1f}MB"
            )
            
        elif sigma_cep > 0:
            # =================================================================
            # LEGACY PATH (v3.0): Explicit einsum integration
            # =================================================================
            # Kept for validation and edge cases where convolution may be less accurate
            mx_rel, my_rel = np.meshgrid(miss_x_axis, miss_y_axis, indexing="ij")
            
            # Broadcasting: cx_axis[:, None, None, None] against mx_rel[None, None, :, :]
            cx_4d = cx_axis[:, np.newaxis, np.newaxis, np.newaxis]  # [n_cx, 1, 1, 1]
            cy_4d = cy_axis[np.newaxis, :, np.newaxis, np.newaxis]  # [1, n_cy, 1, 1]
            mx_4d = mx_rel[np.newaxis, np.newaxis, :, :]  # [1, 1, n_mx, n_my]
            my_4d = my_rel[np.newaxis, np.newaxis, :, :]  # [1, 1, n_mx, n_my]
            
            # Compute squared distances and Gaussian weights
            r2 = (mx_4d - cx_4d)**2 + (my_4d - cy_4d)**2  # [n_cx, n_cy, n_mx, n_my]
            coeff = 1.0 / (2.0 * np.pi * sigma_cep**2)
            g_cep_all = coeff * np.exp(-r2 / (2 * sigma_cep**2))  # [n_cx, n_cy, n_mx, n_my]
            
            # Normalize each salvo center's weights
            norm_cep = np.sum(g_cep_all, axis=(-2, -1), keepdims=True) * dx * dy
            norm_cep = np.where(norm_cep > 0, norm_cep, 1.0)
            g_cep_norm = g_cep_all / norm_cep  # [n_cx, n_cy, n_mx, n_my]
            
            # Integrate: pk_sys_grid[cx, cy, h, v, a] = Σ Pk_internal[h, v, a, x, y] * g_cep[cx, cy, x, y]
            # Use einsum: 'hvaxy,ijxy->ijhva' where i=cx, j=cy
            pk_sys_grid = np.einsum('hvaxy,ijxy->ijhva', pk_internal, g_cep_norm * dx * dy)
        else:
            # Delta function: find nearest grid point to each salvo center
            mx_rel, my_rel = np.meshgrid(miss_x_axis, miss_y_axis, indexing="ij")
            pk_sys_grid = np.zeros((n_salvo_centers, n_salvo_centers, n_h, n_v, n_a))
            for i, cx in enumerate(cx_axis):
                for j, cy in enumerate(cy_axis):
                    # Find nearest grid point
                    dist = (mx_rel - cx)**2 + (my_rel - cy)**2
                    idx_x, idx_y = np.unravel_index(np.argmin(dist), dist.shape)
                    pk_sys_grid[i, j] = pk_internal[:, :, :, idx_x, idx_y]
        
        # Cache the result
        grid = SalvoCenterGrid(
            pk_sys_grid=pk_sys_grid,
            cx_axis=cx_axis,
            cy_axis=cy_axis,
            sigma_salvo=sigma_salvo,
            fixed_bias=error_sigmas.fixed_bias,
        )
        self._salvo_center_cache = grid
        
        return grid

    # =========================================================================
    # Stage 2: Multi-Shot Nested Integration (Story 1.5)
    # =========================================================================

    def compute_multi_shot_pk_nested(
        self,
        salvo_center_grid: SalvoCenterGrid,
        max_shots: int = 10,
    ) -> np.ndarray:
        """
        Compute multi-shot salvo Pk via nested grid integration.

        Fully deterministic, MATLAB-parity results.
        Uses C++ accelerator when available for improved performance.

        Spec Reference: DISCRETE_ANALYSIS.md Section 4.4-4.5

        Shapes:
            salvo_center_grid.pk_sys_grid: [n_cx, n_cy, n_h, n_v, n_α]
            return mean_pk: [K, n_h, n_v, n_α]

        Args:
            salvo_center_grid: Precomputed Pk at grid of salvo centers
            max_shots: Maximum shots per salvo (K)

        Returns:
            mean_pk: [K, n_h, n_v, n_α] - mean accumulated Pk after each shot count
        """
        pk_sys_grid = salvo_center_grid.pk_sys_grid  # [n_cx, n_cy, h, v, α]
        cx_axis = salvo_center_grid.cx_axis
        cy_axis = salvo_center_grid.cy_axis
        sigma_salvo = salvo_center_grid.sigma_salvo
        b_x, b_y = salvo_center_grid.fixed_bias

        # Use C++ accelerator if available
        if CPP_ACCEL_AVAILABLE and _cpp_multi_shot_nested is not None:
            logger.debug("Using C++ accelerator for multi-shot nested integration")
            return _cpp_multi_shot_nested(
                pk_sys_grid, cx_axis, cy_axis, sigma_salvo, b_x, b_y, max_shots
            )

        # Python fallback implementation
        n_cx, n_cy, n_h, n_v, n_a = pk_sys_grid.shape

        # Grid spacing
        dc_x = float(np.mean(np.diff(cx_axis))) if len(cx_axis) > 1 else 1.0
        dc_y = float(np.mean(np.diff(cy_axis))) if len(cy_axis) > 1 else 1.0

        # Build salvo center PDF (2D Gaussian centered at fixed bias)
        cx_mesh, cy_mesh = np.meshgrid(cx_axis, cy_axis, indexing="ij")
        g_salvo = self._gaussian_weights(cx_mesh, cy_mesh, sigma_salvo, b_x, b_y)

        # Normalize: sum * dc_x * dc_y = 1
        norm_salvo = np.sum(g_salvo) * dc_x * dc_y
        g_salvo_norm = g_salvo / norm_salvo if norm_salvo > 0 else g_salvo

        # Allocate output: [K, h, v, α]
        mean_pk = np.zeros((max_shots, n_h, n_v, n_a))

        logger.info(f"Computing multi-shot Pk via nested integration: K={max_shots}")

        # For each shot count, apply survivor rule at each salvo center
        for k in range(1, max_shots + 1):
            # Survivor rule at each salvo center: Pk_acc = 1 - (1 - Pk_sys)^k
            pk_acc_at_centers = 1.0 - (1.0 - pk_sys_grid) ** k  # [n_cx, n_cy, h, v, α]

            # Weight by salvo center probability and sum
            # g_salvo_norm is [n_cx, n_cy], pk_acc is [n_cx, n_cy, h, v, α]
            weighted = pk_acc_at_centers * g_salvo_norm[:, :, np.newaxis, np.newaxis, np.newaxis]

            # Integrate over salvo centers
            mean_pk[k - 1] = weighted.sum(axis=(0, 1)) * dc_x * dc_y

        return mean_pk

    # =========================================================================
    # Stage 2b: Hybrid MC Mode (Story 4.1)
    # =========================================================================

    def compute_multi_shot_pk_hybrid(
        self,
        salvo_center_grid: SalvoCenterGrid,
        max_shots: int = 10,
        n_salvos: int = 2001,
        random_seed: int = 314159,
    ) -> np.ndarray:
        """
        Compute multi-shot salvo Pk via hybrid MC sampling.
        
        Faster than nested grid, deterministic with fixed seed.
        Samples salvo centers via Monte Carlo, interpolates from precomputed grid.
        
        Spec Reference: DISCRETE_ANALYSIS.md Section 6.1
        
        Args:
            salvo_center_grid: Precomputed Pk at grid of salvo centers
            max_shots: Maximum shots per salvo (K)
            n_salvos: Number of MC salvo samples
            random_seed: RNG seed for reproducibility (MATLAB parity: 314159)
            
        Returns:
            mean_pk: [K, n_h, n_v, n_α] - mean accumulated Pk after each shot count
        
        Shapes:
            salvo_center_grid.pk_sys_grid: [n_cx, n_cy, n_h, n_v, n_α]
            sampled salvo_centers: [n_salvos, 2]
            return mean_pk: [K, n_h, n_v, n_α]
        """
        pk_sys_grid = salvo_center_grid.pk_sys_grid  # [n_cx, n_cy, h, v, α]
        cx_axis = salvo_center_grid.cx_axis
        cy_axis = salvo_center_grid.cy_axis
        sigma_salvo = salvo_center_grid.sigma_salvo
        b_x, b_y = salvo_center_grid.fixed_bias
        
        n_cx, n_cy, n_h, n_v, n_a = pk_sys_grid.shape

        # C++ Accelerator Dispatch (ADR-003)
        if use_cpp_backend() and _cpp_multi_shot_hybrid is not None:
            logger.info("Using C++ accelerator for multi-shot hybrid MC")
            return _cpp_multi_shot_hybrid(
                pk_sys_grid,
                cx_axis,
                cy_axis,
                sigma_salvo,
                b_x, b_y,
                max_shots,
                n_salvos,
                random_seed
            )
        
        # Initialize RNG with seed for reproducibility

        rng = np.random.default_rng(random_seed)
        
        logger.info(
            f"Computing multi-shot Pk via hybrid MC: K={max_shots}, "
            f"n_salvos={n_salvos}, seed={random_seed}"
        )
        
        # Sample salvo centers: c ~ N(b_fixed, σ_salvo²)
        if sigma_salvo > 0:
            salvo_centers_x = rng.normal(loc=b_x, scale=sigma_salvo, size=n_salvos)
            salvo_centers_y = rng.normal(loc=b_y, scale=sigma_salvo, size=n_salvos)
        else:
            # Delta function at fixed bias
            salvo_centers_x = np.full(n_salvos, b_x)
            salvo_centers_y = np.full(n_salvos, b_y)
        
        # VECTORIZED: Build single interpolator with vector-valued output
        # Reshape pk_sys_grid from [n_cx, n_cy, h, v, a] to [n_cx, n_cy, n_terminal]
        n_terminal = n_h * n_v * n_a
        pk_sys_flat = pk_sys_grid.reshape(n_cx, n_cy, n_terminal)
        
        # Build interpolator for all terminal conditions at once
        # RegularGridInterpolator supports vector-valued functions
        interp = RegularGridInterpolator(
            (cx_axis, cy_axis),
            pk_sys_flat,
            bounds_error=False,
            fill_value=0.0,
        )
        
        # Interpolate at all sampled salvo centers
        points = np.column_stack([salvo_centers_x, salvo_centers_y])  # [n_salvos, 2]
        pk_sys_at_centers = interp(points)  # [n_salvos, n_terminal]
        
        # Reshape back to [n_salvos, n_h, n_v, n_a]
        pk_sys_at_centers = pk_sys_at_centers.reshape(n_salvos, n_h, n_v, n_a)
        
        # VECTORIZED survivor rule for all k values at once
        # pk_acc[k] = 1 - (1 - pk_sys)^(k+1) for k in 0..max_shots-1
        # pk_sys_at_centers has shape [n_salvos, h, v, a]
        # k_values has shape [K]
        # We want to compute for each k and each salvo: [K, n_salvos, h, v, a]
        
        # Reshape for broadcasting:
        # pk_sys_at_centers: [n_salvos, h, v, a] -> [1, n_salvos, h, v, a]
        # k_values: [K] -> [K, 1, 1, 1, 1]
        k_values = np.arange(1, max_shots + 1)[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis]
        pk_sys_expanded = pk_sys_at_centers[np.newaxis, :, :, :, :]
        
        # Compute accumulated Pk for all k values at once: [K, n_salvos, h, v, a]
        pk_acc_all = 1.0 - (1.0 - pk_sys_expanded) ** k_values
        
        # Mean over salvos (axis=1): [K, h, v, a]
        mean_pk = np.mean(pk_acc_all, axis=1)
        
        return mean_pk

    # =========================================================================
    # Stage 3: Rounds-to-Kill (Story 1.6)
    # =========================================================================

    def compute_rounds_to_kill(
        self,
        mean_pk: np.ndarray,
        pk_thresholds: List[float],
    ) -> np.ndarray:
        """
        Compute fractional rounds-to-kill via MATLAB-parity linear interpolation.

        Uses C++ accelerator when available for improved performance.

        Spec Reference: DISCRETE_ANALYSIS.md Section 5.1-5.3
        MATLAB Reference: SalvoAnalysis03x3.m lines 688-750

        Args:
            mean_pk: [K, n_h, n_v, n_α] - mean accumulated Pk after each shot count
            pk_thresholds: List of Pk thresholds (e.g., [0.3, 0.5, 0.7, 0.9])

        Returns:
            r2k: [n_h, n_v, n_α, n_thresholds] - fractional rounds to achieve each threshold
        """
        # Use C++ accelerator if available
        if CPP_ACCEL_AVAILABLE and _cpp_r2k is not None:
            logger.debug("Using C++ accelerator for rounds-to-kill computation")
            return _cpp_r2k(mean_pk, pk_thresholds)

        # Python fallback implementation
        K, n_h, n_v, n_a = mean_pk.shape
        n_thresholds = len(pk_thresholds)
        r2k = np.full((n_h, n_v, n_a, n_thresholds), np.nan)

        for t, pk_req in enumerate(pk_thresholds):
            # Case 1: First shot achieves threshold
            first_pk = mean_pk[0]  # [h, v, a]
            first_achieves = first_pk >= pk_req
            
            # Fractional first shot: NR = Pk_req / Pk(1)
            with np.errstate(divide='ignore', invalid='ignore'):
                r2k_first = pk_req / np.maximum(first_pk, 1e-10)
            r2k[:, :, :, t] = np.where(first_achieves, r2k_first, np.nan)
            
            # Track which positions still need processing
            needs_more = ~first_achieves
            
            # Case 2: Find crossing point for remaining positions
            for shot in range(1, K):
                prev_pk = mean_pk[shot - 1]
                curr_pk = mean_pk[shot]
                
                # Positions where this shot crosses threshold
                crosses = needs_more & (prev_pk < pk_req) & (curr_pk >= pk_req)
                
                if np.any(crosses):
                    # Linear interpolation
                    delta_pk = np.maximum(curr_pk - prev_pk, 1e-10)
                    frac = (pk_req - prev_pk) / delta_pk
                    
                    # Round number is (shot+1) since we're 0-indexed
                    # But crossing happens between shot and shot+1
                    # MATLAB: NR = N + (Pk_req - Pk(N)) / (Pk(N+1) - Pk(N))
                    # where N is the last shot BELOW threshold (0-indexed: shot-1)
                    # so NR = shot + frac
                    r2k[:, :, :, t] = np.where(crosses, shot + frac, r2k[:, :, :, t])
                    
                    # Mark as processed
                    needs_more = needs_more & ~crosses
            
            # Case 3: Infeasible (max shots insufficient)
            infeasible = needs_more & (mean_pk[-1] < pk_req)
            r2k[:, :, :, t] = np.where(infeasible, K + 1, r2k[:, :, :, t])
            
            # Handle plateau case: if still nan but last shot >= threshold
            # This can happen if plateau was exactly at threshold
            still_nan = np.isnan(r2k[:, :, :, t])
            last_achieves = mean_pk[-1] >= pk_req
            plateau = still_nan & last_achieves
            r2k[:, :, :, t] = np.where(plateau, K, r2k[:, :, :, t])
        
        return r2k

    # =========================================================================
    # Delivery Integration (Stage 4)
    # =========================================================================

    def _delivery_convolution(
        self,
        pk_sys: np.ndarray,
        sigmas: Dict[str, float],
        axes: Dict[str, np.ndarray],
    ) -> np.ndarray:
        """
        Apply separable Gaussian smoothing over HOB/VEL/AOF dimensions.
        
        Spec Reference: DISCRETE_ANALYSIS.md Section 7
        
        Args:
            pk_sys: 3D system Pk [n_h, n_v, n_α]
            sigmas: Dict with 'hob', 'vel', 'aof' sigma values
            axes: Dict with 'hob', 'vel', 'aof' axis arrays
            
        Returns:
            reliability: Convolved Pk [n_h, n_v, n_α]
        """
        sigma_hob = sigmas.get("hob", 0.0)
        sigma_vel = sigmas.get("vel", 0.0)
        sigma_aof = sigmas.get("aof", 0.0)

        def _sigma_to_index(sig: float, axis: np.ndarray) -> float:
            if sig <= 0 or len(axis) < 2:
                return 0.0
            step = float(np.mean(np.diff(axis)))
            return sig / step if step > 0 else 0.0

        sigma_idx = (
            _sigma_to_index(sigma_hob, axes["hob"]),
            _sigma_to_index(sigma_vel, axes["vel"]),
            _sigma_to_index(sigma_aof, axes["aof"]),
        )
        
        # Use mode="constant" with cval=0 per spec (zero outside bounds)
        return gaussian_filter(pk_sys, sigma=sigma_idx, mode="constant", cval=0.0)

    # =========================================================================
    # Metrics Computation (Stage 5)
    # =========================================================================

    def _compute_metrics(
        self,
        pk_sys: np.ndarray,
        reliability: np.ndarray,
        hob_axis: np.ndarray,
        vel_axis: np.ndarray,
        aof_axis: np.ndarray,
    ) -> Dict[str, float]:
        """
        Compute scalar performance metrics.
        
        Spec Reference: DISCRETE_ANALYSIS.md Section 8
        """
        pk_threshold = self.pk_threshold
        gradient_threshold = self.gradient_threshold
        
        # Voxel volume
        voxel = 1.0
        for axis in (hob_axis, vel_axis, aof_axis):
            if len(axis) > 1:
                voxel *= float(np.mean(np.diff(axis)))
        
        # Envelope volume: cells where Pk >= threshold
        envelope_mask = reliability >= pk_threshold
        envelope_volume = float(envelope_mask.sum() * voxel)
        envelope_cell_count = int(envelope_mask.sum())
        
        # Integrated kill potential
        integrated_kill_potential = float((reliability * voxel).sum())
        
        # Gradient magnitude (sensitivity)
        # Handle edge cases where axes have only 1 element
        # np.gradient requires at least 2 elements per dimension
        can_compute_gradient = (
            reliability.size > 1 and 
            all(s >= 2 for s in reliability.shape)
        )
        if can_compute_gradient:
            grad = np.gradient(reliability)
            grad_mag = np.sqrt(sum(g**2 for g in grad))
        else:
            # When gradient can't be computed, use zero (no sensitivity info)
            grad_mag = np.zeros_like(reliability)
        
        # Robust volume: high Pk and low gradient
        robust_mask = envelope_mask & (grad_mag <= gradient_threshold)
        robust_volume = float(robust_mask.sum() * voxel)
        robust_cell_count = int(robust_mask.sum())
        
        # Effective volume under uncertainty
        effective_mask = reliability >= pk_threshold
        effective_volume = float((reliability * effective_mask * voxel).sum())
        
        return {
            "pk_threshold": pk_threshold,
            "gradient_threshold": gradient_threshold,
            "envelope_volume": envelope_volume,
            "envelope_cell_count": envelope_cell_count,
            "integrated_kill_potential": integrated_kill_potential,
            "robust_volume": robust_volume,
            "robust_cell_count": robust_cell_count,
            "effective_volume": effective_volume,
            "total_cells": int(reliability.size),
        }

    # =========================================================================
    # Main Analysis Entry Points
    # =========================================================================

    def analyze(
        self,
        pk_det: np.ndarray,
        miss_x_axis: np.ndarray,
        miss_y_axis: np.ndarray,
        hob_axis: np.ndarray,
        vel_axis: np.ndarray,
        aof_axis: np.ndarray,
        sigma_guid_m: float = 0.0,
        sigma_hob_m: float = 0.0,
        sigma_velocity_mps: float = 0.0,
        sigma_aof_deg: float = 0.0,
    ) -> DiscreteGridResults:
        """
        Legacy-compatible single-shot analysis (v2.0 API).
        
        Uses RSS sigma combination for single-shot Pk, then applies
        delivery convolution and computes metrics.
        
        Args:
            pk_det: 5D Pk hypercube from HypercubeBuilder [n_mx, n_my, n_h, n_v, n_α]
                    Note: This is the native format from HypercubeBuilder with
                    miss grid axes first, then terminal conditions.
            miss_x_axis: Miss distance X coordinates (deflection)
            miss_y_axis: Miss distance Y coordinates (range)
            hob_axis: HOB axis values
            vel_axis: Velocity axis values
            aof_axis: AOF axis values
            sigma_guid_m: Guidance sigma (RSS total)
            sigma_hob_m: HOB delivery error sigma
            sigma_velocity_mps: Velocity delivery error sigma
            sigma_aof_deg: AOF delivery error sigma
            
        Returns:
            DiscreteGridResults with system_pk, reliability, sensitivity, failure_prob
        """
        pk_det = np.asarray(pk_det, dtype=float)
        pk_det = np.nan_to_num(pk_det, nan=0.0, posinf=1.0, neginf=0.0)
        
        # Transpose from HypercubeBuilder format [x, y, h, v, a] to internal [h, v, a, x, y]
        pk_internal = _transpose_hypercube_to_internal(pk_det)
        
        miss_x_axis = np.asarray(miss_x_axis, dtype=float)
        miss_y_axis = np.asarray(miss_y_axis, dtype=float)
        hob_axis = np.asarray(hob_axis, dtype=float)
        vel_axis = np.asarray(vel_axis, dtype=float)
        aof_axis = np.asarray(aof_axis, dtype=float)
        
        # Stage 1: Guidance integration (miss grid → system Pk)
        mx, my = np.meshgrid(miss_x_axis, miss_y_axis, indexing="ij")
        weights = self._gaussian_weights(mx, my, sigma_guid_m, bias_x=0.0, bias_y=0.0)
        
        dx = float(np.mean(np.diff(miss_x_axis))) if len(miss_x_axis) > 1 else 1.0
        dy = float(np.mean(np.diff(miss_y_axis))) if len(miss_y_axis) > 1 else 1.0
        
        norm = np.sum(weights) * dx * dy
        norm = norm if norm > 0 else 1.0
        weights *= dx * dy
        # pk_internal shape: [h, v, a, x, y], weights shape: [x, y]
        # Sum over last two axes (x, y) to get system_pk[h, v, a]
        system_pk = (pk_internal * weights).sum(axis=(-2, -1)) / norm
        
        # Stage 2: Delivery error convolution
        sigmas = {"hob": sigma_hob_m, "vel": sigma_velocity_mps, "aof": sigma_aof_deg}
        axes = {"hob": hob_axis, "vel": vel_axis, "aof": aof_axis}
        system_pk = np.nan_to_num(system_pk, nan=0.0, posinf=1.0, neginf=0.0)
        reliability = self._delivery_convolution(system_pk, sigmas, axes)
        reliability = np.nan_to_num(reliability, nan=0.0, posinf=1.0, neginf=0.0)
        
        # Stage 3: Metrics
        metadata = self._compute_metrics(
            system_pk, reliability, hob_axis, vel_axis, aof_axis
        )
        
        # Sensitivity and failure probability
        grad = np.gradient(reliability)
        sensitivity = np.sqrt(sum(g**2 for g in grad))
        failure_prob = np.clip(1.0 - reliability, 0.0, 1.0)
        
        return DiscreteGridResults(
            system_pk=system_pk,
            reliability=reliability,
            sensitivity=sensitivity,
            failure_prob=failure_prob,
            metadata=metadata,
        )

    def run_full_analysis(
        self,
        pk_det: np.ndarray,
        miss_x_axis: np.ndarray,
        miss_y_axis: np.ndarray,
        hob_axis: np.ndarray,
        vel_axis: np.ndarray,
        aof_axis: np.ndarray,
        error_sigmas: ErrorSigmas,
        max_shots: int = 10,
        pk_thresholds: Optional[List[float]] = None,
        integration_method: str = "hybrid_mc",
        n_salvo_centers: int = 31,
        n_salvos: int = 2001,
        random_seed: int = 314159,
        delivery_sigmas: Optional[Dict[str, float]] = None,
        use_convolution: bool = True,
    ) -> DiscreteAnalysisResults:
        """
        Full v3.0 discrete analysis with 4-source error model.
        
        Implements the complete specification with nested integration,
        multi-shot survivor rule, and MATLAB-parity rounds-to-kill.
        
        Args:
            pk_det: 5D Pk hypercube from HypercubeBuilder [n_mx, n_my, n_h, n_v, n_α]
                    Note: This is the native format from HypercubeBuilder with
                    miss grid axes first, then terminal conditions (hob, vel, aof).
            miss_x_axis: Miss distance X coordinates (deflection)
            miss_y_axis: Miss distance Y coordinates (range)
            hob_axis: HOB axis values
            vel_axis: Velocity axis values
            aof_axis: AOF axis values
            error_sigmas: Converted sigma values from 4-source error model
            max_shots: Maximum shots per salvo (K)
            pk_thresholds: Thresholds for rounds-to-kill (default: [0.3, 0.5, 0.7, 0.9])
            integration_method: "nested_grid", "hybrid_mc", or "single_shot_only"
            n_salvo_centers: Grid resolution for nested/hybrid (default: 31)
            n_salvos: MC samples for hybrid mode (default: 2001)
            random_seed: RNG seed for hybrid mode (default: 314159)
            delivery_sigmas: Optional delivery error sigmas for Stage 4
            use_convolution: Use FFT convolution for salvo precomputation (default: True)
            
        Returns:
            DiscreteAnalysisResults with full multi-shot outputs
        """
        if pk_thresholds is None:
            pk_thresholds = [0.30, 0.50, 0.70, 0.90]
        
        pk_det = np.asarray(pk_det, dtype=float)
        pk_det = np.nan_to_num(pk_det, nan=0.0, posinf=1.0, neginf=0.0)
        
        miss_x_axis = np.asarray(miss_x_axis, dtype=float)
        miss_y_axis = np.asarray(miss_y_axis, dtype=float)
        hob_axis = np.asarray(hob_axis, dtype=float)
        vel_axis = np.asarray(vel_axis, dtype=float)
        aof_axis = np.asarray(aof_axis, dtype=float)
        
        logger.info(f"Running full discrete analysis: method={integration_method}, use_convolution={use_convolution}")
        
        # Single-shot system Pk (RSS - valid for single shot)
        system_pk = self.compute_single_shot_pk(
            pk_det, miss_x_axis, miss_y_axis, error_sigmas
        )
        
        # Multi-shot analysis
        mean_pk_by_shot = None
        rounds_to_kill = None
        
        if integration_method == "single_shot_only":
            # No multi-shot analysis
            pass
        else:
            # Precompute salvo center grid
            salvo_center_grid = self.precompute_salvo_center_grid(
                pk_det, miss_x_axis, miss_y_axis, error_sigmas, n_salvo_centers,
                use_convolution=use_convolution,
            )
            
            if integration_method == "nested_grid":
                mean_pk_by_shot = self.compute_multi_shot_pk_nested(
                    salvo_center_grid, max_shots
                )
            elif integration_method == "hybrid_mc":
                mean_pk_by_shot = self.compute_multi_shot_pk_hybrid(
                    salvo_center_grid, max_shots, n_salvos, random_seed
                )
            else:
                raise ValueError(f"Unknown integration method: {integration_method}")
            
            # Compute rounds-to-kill
            rounds_to_kill = self.compute_rounds_to_kill(mean_pk_by_shot, pk_thresholds)
        
        # Delivery integration (Stage 4)
        reliability = system_pk.copy()
        if delivery_sigmas:
            axes = {"hob": hob_axis, "vel": vel_axis, "aof": aof_axis}
            reliability = self._delivery_convolution(system_pk, delivery_sigmas, axes)
        
        # Metrics (Stage 5)
        metadata = self._compute_metrics(
            system_pk, reliability, hob_axis, vel_axis, aof_axis
        )
        
        # Sensitivity and failure probability
        # np.gradient requires at least 2 elements per dimension
        can_compute_gradient = (
            reliability.size > 1 and 
            all(s >= 2 for s in reliability.shape)
        )
        if can_compute_gradient:
            grad = np.gradient(reliability)
            sensitivity = np.sqrt(sum(g**2 for g in grad))
        else:
            sensitivity = np.zeros_like(reliability)
        failure_prob = np.clip(1.0 - reliability, 0.0, 1.0)
        
        # Build error model dict for metadata
        error_model_dict = {
            "sigma_tle": error_sigmas.sigma_tle,
            "sigma_cep": error_sigmas.sigma_cep,
            "sigma_var_bias": error_sigmas.sigma_var_bias,
            "sigma_salvo": error_sigmas.sigma_salvo,
            "sigma_total": error_sigmas.sigma_total,
            "fixed_bias_x": error_sigmas.fixed_bias[0],
            "fixed_bias_y": error_sigmas.fixed_bias[1],
        }
        
        return DiscreteAnalysisResults(
            system_pk=system_pk,
            mean_pk_by_shot=mean_pk_by_shot,
            rounds_to_kill=rounds_to_kill,
            reliability=reliability,
            sensitivity=sensitivity,
            failure_prob=failure_prob,
            hob_axis=hob_axis,
            vel_axis=vel_axis,
            aof_axis=aof_axis,
            pk_thresholds=np.array(pk_thresholds),
            metadata=metadata,
            error_model=error_model_dict,
            integration_method=integration_method,
        )


# =============================================================================
# Legacy Compatibility Functions
# =============================================================================

def compute_rounds_to_kill_grid(
    pk_sys: np.ndarray,
    pk_threshold: float = 0.9,
    max_rounds: int = 10,
) -> np.ndarray:
    """
    Legacy rounds-to-kill using closed-form formula.
    
    NOTE: This uses the simple log formula which assumes constant Pk per shot.
    For MATLAB-parity multi-shot analysis, use DiscreteGridAnalyzer.compute_rounds_to_kill()
    with proper mean_pk_by_shot tensor.
    
    Rounds = log(1 - threshold) / log(1 - pk), clipped to max_rounds.
    
    Args:
        pk_sys: System Pk array (any shape)
        pk_threshold: Target Pk threshold
        max_rounds: Maximum rounds cap
        
    Returns:
        rounds: Same shape as pk_sys, fractional rounds to achieve threshold
    """
    pk_clean = np.nan_to_num(pk_sys, nan=0.0, posinf=1.0, neginf=0.0)
    pk_clipped = np.clip(pk_clean, 1e-9, 1 - 1e-9)
    
    with np.errstate(divide='ignore', invalid='ignore'):
        rounds = np.log(1 - pk_threshold) / np.log(1 - pk_clipped)
    
    rounds = np.clip(rounds, 0, max_rounds)
    rounds = np.nan_to_num(rounds, nan=max_rounds, posinf=max_rounds, neginf=0)
    
    return rounds


def compute_rounds_to_kill_vectorized(
    mean_acc_pk: np.ndarray,
    pk_thresholds: List[float],
) -> np.ndarray:
    """
    Vectorized MATLAB-parity rounds-to-kill computation.
    
    Standalone function for use without DiscreteGridAnalyzer instance.
    
    Args:
        mean_acc_pk: [K, n_h, n_v, n_aof] - mean accumulated Pk by shot count
        pk_thresholds: List of Pk thresholds
        
    Returns:
        r2k: [n_h, n_v, n_aof, n_pk_thresholds]
    """
    analyzer = DiscreteGridAnalyzer()
    return analyzer.compute_rounds_to_kill(mean_acc_pk, pk_thresholds)
