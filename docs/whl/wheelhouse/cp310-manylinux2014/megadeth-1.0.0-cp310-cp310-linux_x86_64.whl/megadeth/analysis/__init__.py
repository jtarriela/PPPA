"""Analysis pipelines (Monte Carlo and discrete grid)."""

from ._accelerator import AVAILABLE as CPP_ACCELERATOR_AVAILABLE
from .monte_carlo import (
    # Core classes
    GuidanceErrorModel,
    MonteCarloAnalyzer,
    MonteCarloResults,
    SalvoConfig,
    ErrorSampleSet,
    # Core standalone functions (MATLAB parity API)
    circular_error_to_sigma,
    generate_error_samples,
    compute_hit_locations,
    transform_to_weapon_frame,
    accumulate_pk,
    accumulate_pk_vectorized,
    compute_rounds_to_kill,
    compute_rounds_to_kill_vectorized,
    # HOB-MR Analysis
    generate_radial_samples,
    compute_hob_mr_avg_pk,
    # Numba-accelerated (optional)
    NUMBA_AVAILABLE,
    accumulate_pk_numba,
    compute_rounds_to_kill_numba,
    run_parallel_salvos,
    # RNG parity utilities
    load_matlab_rng_draws,
)
from .discrete_grid import (
    DiscreteGridAnalyzer,
    DiscreteAnalysisResults,
    ErrorSigmas,
    SalvoCenterGrid,
    compute_rounds_to_kill_grid,
    compute_rounds_to_kill_vectorized as compute_rounds_to_kill_vectorized_discrete,
)

__all__ = [
    # C++ Accelerator
    "CPP_ACCELERATOR_AVAILABLE",
    # Monte Carlo Core
    "GuidanceErrorModel",
    "MonteCarloAnalyzer",
    "MonteCarloResults",
    "SalvoConfig",
    "ErrorSampleSet",
    # MC Standalone Functions (MATLAB parity)
    "circular_error_to_sigma",
    "generate_error_samples",
    "compute_hit_locations",
    "transform_to_weapon_frame",
    "accumulate_pk",
    "accumulate_pk_vectorized",
    "compute_rounds_to_kill",
    "compute_rounds_to_kill_vectorized",
    # HOB-MR Analysis
    "generate_radial_samples",
    "compute_hob_mr_avg_pk",
    # Numba-accelerated
    "NUMBA_AVAILABLE",
    "accumulate_pk_numba",
    "compute_rounds_to_kill_numba",
    "run_parallel_salvos",
    # RNG parity utilities
    "load_matlab_rng_draws",
    # Discrete Grid v3.0
    "DiscreteGridAnalyzer",
    "DiscreteAnalysisResults",
    "ErrorSigmas",
    "SalvoCenterGrid",
    "compute_rounds_to_kill_grid",
    "compute_rounds_to_kill_vectorized_discrete",
]
