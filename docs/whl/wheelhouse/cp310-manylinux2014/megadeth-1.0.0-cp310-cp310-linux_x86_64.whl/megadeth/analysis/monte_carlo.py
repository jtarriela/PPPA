"""
Monte Carlo Weapon Effectiveness Analysis

Implements MATLAB MEGADETH algorithm with 4-source error model sampling
and survivor rule accumulation for system Pk computation.

MATLAB PARITY:
- Uses same Rayleigh → σ conversion formulas (SalvoAnalysis03x3.m lines 335-340)
- Uses same survivor rule implementation (SalvoAnalysis03x3.m lines 643-650)
- Uses same frame transformation (SalvoAnalysis03x3.m lines 457-470)
- Uses configurable random seed for reproducibility (default: 314159)
- Note: MATLAB uses MT19937 ('twister'), Python uses PCG64 by default.
  While exact sequences differ, statistical properties match with same seed.

Reference: docs/MONTE_CARLO_ANALYSIS.md
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple, Union

import numpy as np
from numpy.random import Generator, MT19937
from scipy.interpolate import RegularGridInterpolator

logger = logging.getLogger(__name__)


def load_matlab_rng_draws(mat_file_path: str) -> Optional[Dict[str, np.ndarray]]:
    """
    Load MATLAB random number draws from .mat file for Python parity testing.
    
    When MATLAB's MEGADETH_MC_DEBUG_DIR is set, SalvoAnalysis03x3.m exports the
    random draws used for Monte Carlo analysis. This function loads those
    draws for use in Python to achieve exact numerical parity.
    
    Args:
        mat_file_path: Path to matlab_rand_draws_prec{N}.mat file
        
    Returns:
        Dictionary with keys:
            - hit_locations_weapon_frame: [n_salvos, n_shots, 2] in weapon frame
            - tle_sigmas: [2] TLE sigma values (x, y)
            - cep_sigmas: [2] CEP sigma values (x, y)
            - n_salvos: int
            - n_shots: int
            - random_seed: int
        Or None if file cannot be loaded.
    """
    from pathlib import Path
    
    mat_path = Path(mat_file_path)
    if not mat_path.exists():
        logger.warning(f"[RNG LOAD] MATLAB RNG draws file not found: {mat_file_path}")
        return None
    
    def _normalize_hit_locations(raw: np.ndarray, n_salvos_val: int, n_shots_val: int) -> Optional[np.ndarray]:
        raw = np.asarray(raw)
        if raw.ndim != 3:
            return None

        # Common variants observed:
        # - (n_salvos, n_shots, 2)
        # - (2, n_shots, n_salvos)
        # - (n_salvos, n_shots, 3) -> take first 2 cols
        if raw.shape == (n_salvos_val, n_shots_val, 2):
            return raw
        if raw.shape == (2, n_shots_val, n_salvos_val):
            return np.transpose(raw, (2, 1, 0))
        if raw.shape == (n_salvos_val, n_shots_val, 3):
            return raw[:, :, :2]
        if raw.shape == (3, n_shots_val, n_salvos_val):
            return np.transpose(raw[:2, :, :], (2, 1, 0))

        # Fallback heuristics
        if raw.shape[0] == 2 and raw.shape[1] == n_shots_val:
            return np.transpose(raw, (2, 1, 0))
        if raw.shape[-1] >= 2 and raw.shape[0] == n_salvos_val and raw.shape[1] == n_shots_val:
            return raw[:, :, :2]
        return None

    def _scalar_from(obj: object, default: float) -> float:
        try:
            arr = np.asarray(obj)
            if arr.size == 0:
                return float(default)
            return float(arr.reshape(-1)[0])
        except Exception:
            return float(default)

    def _load_v73_with_h5py() -> Optional[Dict[str, np.ndarray]]:
        try:
            import h5py  # type: ignore
        except Exception as e:
            logger.error(f"[RNG LOAD] h5py not available, cannot load v7.3 .mat: {e}")
            return None

        logger.info(f"[RNG LOAD] Detected MATLAB v7.3 file, loading via h5py: {mat_file_path}")
        with h5py.File(str(mat_path), "r") as f:
            n_salvos_val = int(_scalar_from(f.get("nSalvos"), 0) or 0)
            n_shots_val = int(_scalar_from(f.get("nShots"), 0) or 0)
            seed_val = int(_scalar_from(f.get("RandomSeed"), 314159))

            raw_hits = f.get("hitLocationsWeaponFrame")
            hit_locations = None
            if raw_hits is not None:
                hit_locations = _normalize_hit_locations(np.array(raw_hits), n_salvos_val, n_shots_val)
                if hit_locations is None:
                    logger.error(f"[RNG LOAD] Unrecognized hitLocationsWeaponFrame shape: {raw_hits.shape}")
                    return None
                logger.info(f"[RNG LOAD] hitLocationsWeaponFrame shape (normalized): {hit_locations.shape}")
            else:
                raw_targets = f.get("targetLocations_m")
                if raw_targets is None:
                    logger.error("[RNG LOAD] No valid hit location data found in v7.3 .mat file")
                    return None
                hit_locations = _normalize_hit_locations(np.array(raw_targets), n_salvos_val, n_shots_val)
                if hit_locations is None:
                    logger.error(f"[RNG LOAD] Unrecognized targetLocations_m shape: {raw_targets.shape}")
                    return None
                logger.info(f"[RNG LOAD] targetLocations_m shape (normalized): {hit_locations.shape}")

            # Sigmas (prefer explicit scalars, fallback to vectors)
            tle_x = _scalar_from(f.get("tleXsigma_m"), 0.0)
            tle_y = _scalar_from(f.get("tleYsigma_m"), 0.0)
            if tle_x == 0.0 and tle_y == 0.0 and f.get("tleSigmas") is not None:
                tle_vec = np.array(f["tleSigmas"]).reshape(-1)
                if tle_vec.size >= 2:
                    tle_x, tle_y = float(tle_vec[0]), float(tle_vec[1])

            cep_x = _scalar_from(f.get("dispXsigma_m"), 0.0)
            cep_y = _scalar_from(f.get("dispYsigma_m"), 0.0)
            if cep_x == 0.0 and cep_y == 0.0 and f.get("cepSigmas") is not None:
                cep_vec = np.array(f["cepSigmas"]).reshape(-1)
                if cep_vec.size >= 2:
                    cep_x, cep_y = float(cep_vec[0]), float(cep_vec[1])

            tle_sigmas = np.array([tle_x, tle_y], dtype=float)
            cep_sigmas = np.array([cep_x, cep_y], dtype=float)

            return {
                "hit_locations_weapon_frame": np.asarray(hit_locations, dtype=float),
                "tle_sigmas": tle_sigmas,
                "cep_sigmas": cep_sigmas,
                "n_salvos": int(n_salvos_val or hit_locations.shape[0]),
                "n_shots": int(n_shots_val or hit_locations.shape[1]),
                "random_seed": int(seed_val),
            }

    # First try SciPy (v7.2 and earlier). If that fails with v7.3 message, fallback to h5py.
    try:
        from scipy.io import loadmat

        logger.info(f"[RNG LOAD] Loading MATLAB RNG draws from: {mat_file_path}")
        mat_data = loadmat(str(mat_path), squeeze_me=False)

        # Extract metadata first (used for shape normalization)
        n_salvos_val = int(_scalar_from(mat_data.get("nSalvos"), 0))
        n_shots_val = int(_scalar_from(mat_data.get("nShots"), 0))
        seed_val = int(_scalar_from(mat_data.get("RandomSeed"), 314159))

        raw_hits = mat_data.get("hitLocationsWeaponFrame")
        hit_locations = None
        if raw_hits is not None:
            hit_locations = _normalize_hit_locations(np.array(raw_hits), n_salvos_val, n_shots_val)
        else:
            raw_targets = mat_data.get("targetLocations_m")
            if raw_targets is not None:
                hit_locations = _normalize_hit_locations(np.array(raw_targets), n_salvos_val, n_shots_val)

        if hit_locations is None:
            logger.error("[RNG LOAD] No valid hit location data found in .mat file")
            return None

        tle_sigmas = np.array([
            _scalar_from(mat_data.get("tleXsigma_m"), 0.0),
            _scalar_from(mat_data.get("tleYsigma_m"), 0.0),
        ])
        if float(tle_sigmas[0]) == 0.0 and float(tle_sigmas[1]) == 0.0 and isinstance(mat_data.get("tleSigmas"), np.ndarray):
            tle_vec = np.array(mat_data["tleSigmas"]).reshape(-1)
            if tle_vec.size >= 2:
                tle_sigmas = np.array([float(tle_vec[0]), float(tle_vec[1])], dtype=float)

        cep_sigmas = np.array([
            _scalar_from(mat_data.get("dispXsigma_m"), 0.0),
            _scalar_from(mat_data.get("dispYsigma_m"), 0.0),
        ])
        if float(cep_sigmas[0]) == 0.0 and float(cep_sigmas[1]) == 0.0 and isinstance(mat_data.get("cepSigmas"), np.ndarray):
            cep_vec = np.array(mat_data["cepSigmas"]).reshape(-1)
            if cep_vec.size >= 2:
                cep_sigmas = np.array([float(cep_vec[0]), float(cep_vec[1])], dtype=float)

        result = {
            "hit_locations_weapon_frame": np.asarray(hit_locations, dtype=float),
            "tle_sigmas": np.asarray(tle_sigmas, dtype=float),
            "cep_sigmas": np.asarray(cep_sigmas, dtype=float),
            "n_salvos": int(n_salvos_val or hit_locations.shape[0]),
            "n_shots": int(n_shots_val or hit_locations.shape[1]),
            "random_seed": int(seed_val),
        }

        logger.info("[RNG LOAD] Successfully loaded MATLAB RNG draws:")
        logger.info(f"  n_salvos={result['n_salvos']}, n_shots={result['n_shots']}, seed={result['random_seed']}")
        logger.info(f"  TLE sigmas: [{result['tle_sigmas'][0]:.4f}, {result['tle_sigmas'][1]:.4f}] m")
        logger.info(f"  CEP sigmas: [{result['cep_sigmas'][0]:.4f}, {result['cep_sigmas'][1]:.4f}] m")
        logger.info(
            "[RNG LOAD] First hit location (salvo 0, shot 0): X=%.4f, Y=%.4f m",
            result["hit_locations_weapon_frame"][0, 0, 0],
            result["hit_locations_weapon_frame"][0, 0, 1],
        )
        return result

    except ImportError:
        logger.error("[RNG LOAD] scipy not available, cannot load .mat files")
        return _load_v73_with_h5py()
    except Exception as e:
        # SciPy loader throws a clear message for MATLAB v7.3 files.
        if "matlab v7.3" in str(e).lower() or "hdf" in str(e).lower():
            try:
                result = _load_v73_with_h5py()
                if result is None:
                    return None
                logger.info("[RNG LOAD] Successfully loaded MATLAB RNG draws via h5py")
                logger.info(
                    "[RNG LOAD] First hit location (salvo 0, shot 0): X=%.4f, Y=%.4f m",
                    result["hit_locations_weapon_frame"][0, 0, 0],
                    result["hit_locations_weapon_frame"][0, 0, 1],
                )
                return result
            except Exception as exc:
                logger.error(f"[RNG LOAD] Failed to load MATLAB v7.3 RNG draws via h5py: {exc}")
                return None

        logger.error(f"[RNG LOAD] Failed to load MATLAB RNG draws: {e}")
        return None


def create_rng(seed: int, use_mt19937: bool = False) -> np.random.Generator:
    """
    Create a random number generator with the specified seed.
    
    Args:
        seed: Integer seed for reproducibility
        use_mt19937: If True, use Mersenne Twister (like MATLAB's 'twister')
                    If False, use PCG64 (NumPy default, faster)
    
    Returns:
        NumPy Generator instance
    
    Note:
        Even with MT19937, the generated sequences won't exactly match MATLAB
        due to different Box-Muller implementations for normal distribution.
        However, statistical properties will be equivalent.
    """
    if use_mt19937:
        return Generator(MT19937(seed))
    else:
        return np.random.default_rng(seed)


def circular_error_to_sigma(radius: float, fraction: float) -> float:
    """
    Convert circular error radius at given containment fraction to Gaussian sigma.

    Uses Rayleigh CDF inversion formula.
    
    MATLAB Reference: SalvoAnalysis03x3.m lines 335-340
        σ = sqrt((-1 * R²) / (2 * ln(1 - F)))

    Args:
        radius: Containment radius (meters)
        fraction: Probability mass contained within radius (e.g., 0.50 for CEP50)

    Returns:
        sigma: Standard deviation for isotropic 2D Gaussian
    """
    if radius <= 0:
        return 0.0
    if fraction <= 0 or fraction >= 1:
        raise ValueError(f"Fraction must be in (0, 1), got {fraction}")
    return math.sqrt((-1 * radius**2) / (2 * math.log(1 - fraction)))


# =============================================================================
# Data Structures
# =============================================================================

@dataclass
class GuidanceErrorModel:
    """
    Guidance error model with 4-source TLE/CEP/bias components.

    MATLAB Reference: Precision input matrix (8 columns)
        [TLE_r, TLE_f, CEP_r, CEP_f, FixedBias_x, FixedBias_y, VarBias_r, VarBias_f]
    """

    tle_radius_m: Union[float, Sequence[float]] = 0.0
    tle_fraction: Union[float, Sequence[float]] = 0.90
    cep_radius_m: Union[float, Sequence[float]] = 0.0
    cep_fraction: Union[float, Sequence[float]] = 0.50
    fixed_bias_deflection_m: Union[float, Sequence[float]] = 0.0
    fixed_bias_range_m: Union[float, Sequence[float]] = 0.0
    variable_bias_radius_m: Union[float, Sequence[float]] = 0.0
    variable_bias_fraction: Union[float, Sequence[float]] = 0.50
    tle_z_sigma_m: float = 0.0
    cep_z_sigma_m: float = 0.0

    def get_sigma_tle(self) -> Tuple[float, float, float]:
        """Return (sigma_x, sigma_y, sigma_z) for TLE."""
        sigma_xy = circular_error_to_sigma(self.tle_radius_m, self.tle_fraction) if self.tle_radius_m > 0 else 0.0
        return (sigma_xy, sigma_xy, self.tle_z_sigma_m)

    def get_sigma_cep(self) -> Tuple[float, float, float]:
        """Return (sigma_x, sigma_y, sigma_z) for CEP."""
        sigma_xy = circular_error_to_sigma(self.cep_radius_m, self.cep_fraction) if self.cep_radius_m > 0 else 0.0
        return (sigma_xy, sigma_xy, self.cep_z_sigma_m)

    def get_fixed_bias(self) -> Tuple[float, float, float]:
        """Return (bias_x, bias_y, bias_z) for fixed bias."""
        return (self.fixed_bias_deflection_m, self.fixed_bias_range_m, 0.0)

    def get_sigma_variable_bias(self) -> Tuple[float, float, float]:
        """Return (sigma_x, sigma_y, sigma_z) for variable bias."""
        sigma_xy = circular_error_to_sigma(self.variable_bias_radius_m, self.variable_bias_fraction) if self.variable_bias_radius_m > 0 else 0.0
        return (sigma_xy, sigma_xy, 0.0)


@dataclass
class SalvoConfig:
    """Legacy compatibility wrapper."""
    shots_per_salvo: int = 1
    bias_pattern: Optional[List[Dict[str, float]]] = None
    n_salvos: int = 1


@dataclass
class ErrorSampleSet:
    """
    Pre-computed error samples for all salvos and shots.

    Tensor Shapes (matching MATLAB structure):
        tle_offsets: [n_salvos, 3] - per-salvo TLE (X, Y, Z)
        cep_offsets: [n_salvos, n_shots, 3] - per-shot CEP
        fixed_bias: [3] - constant offset
        variable_bias_offsets: [n_salvos, 3] - per-salvo variable bias
    """

    tle_offsets: np.ndarray
    cep_offsets: np.ndarray
    fixed_bias: np.ndarray
    variable_bias_offsets: np.ndarray

    @property
    def n_salvos(self) -> int:
        return self.tle_offsets.shape[0]

    @property
    def n_shots(self) -> int:
        return self.cep_offsets.shape[1]


# =============================================================================
# Standalone Functions (MATLAB Parity API)
# =============================================================================

def generate_error_samples(
    n_salvos: int,
    n_shots: int,
    guidance_model: GuidanceErrorModel,
    random_seed: Optional[int] = None,
) -> ErrorSampleSet:
    """
    Generate error samples for all salvos and shots.

    MATLAB Reference: SalvoAnalysis03x3.m lines 290-450
    
    Shapes:
        tle_offsets: [n_salvos, 3]
        cep_offsets: [n_salvos, n_shots, 3]
        fixed_bias: [3]
        variable_bias_offsets: [n_salvos, 3]

    Args:
        n_salvos: Number of salvos
        n_shots: Shots per salvo
        guidance_model: Guidance error configuration
        random_seed: Optional random seed for reproducibility

    Returns:
        ErrorSampleSet with TLE, CEP, fixed bias, and variable bias samples
    """
    rng = np.random.default_rng(random_seed)

    # Get sigmas from model
    sigma_tle = guidance_model.get_sigma_tle()
    sigma_cep = guidance_model.get_sigma_cep()
    sigma_var_bias = guidance_model.get_sigma_variable_bias()
    fixed_bias = np.array(guidance_model.get_fixed_bias())

    # TLE: drawn once per salvo [n_salvos, 3]
    tle_offsets = rng.normal(
        loc=0.0,
        scale=sigma_tle,
        size=(n_salvos, 3),
    )

    # CEP: drawn per shot [n_salvos, n_shots, 3]
    cep_offsets = rng.normal(
        loc=0.0,
        scale=sigma_cep,
        size=(n_salvos, n_shots, 3),
    )

    # Variable bias: drawn once per salvo [n_salvos, 3]
    variable_bias_offsets = rng.normal(
        loc=0.0,
        scale=sigma_var_bias,
        size=(n_salvos, 3),
    )

    return ErrorSampleSet(
        tle_offsets=tle_offsets,
        cep_offsets=cep_offsets,
        fixed_bias=fixed_bias,
        variable_bias_offsets=variable_bias_offsets,
    )


def compute_hit_locations(error_samples: ErrorSampleSet) -> np.ndarray:
    """
    Compute hit locations from error samples in target frame.

    hit_location = TLE + VarBias + FixedBias + CEP

    MATLAB Reference: SalvoAnalysis03x3.m lines 520-650

    Args:
        error_samples: Pre-generated error samples

    Returns:
        hit_locations: [n_salvos, n_shots, 3] hit coordinates in target frame
    """
    n_salvos = error_samples.n_salvos
    n_shots = error_samples.n_shots

    # Salvo center = TLE + VarBias + FixedBias
    salvo_centers = (
        error_samples.tle_offsets
        + error_samples.variable_bias_offsets
        + error_samples.fixed_bias
    )  # [n_salvos, 3]

    # Hit locations = salvo center + per-shot CEP
    hit_locations = salvo_centers[:, np.newaxis, :] + error_samples.cep_offsets

    return hit_locations


def transform_to_weapon_frame(hit_locations: np.ndarray) -> np.ndarray:
    """
    Transform hit locations from target frame to weapon frame.

    Negates X and Y axes, preserves Z.

    MATLAB Reference: SalvoAnalysis03x3.m lines 457-470

    Args:
        hit_locations: [n_salvos, n_shots, 3] in target frame

    Returns:
        weapon_locations: [n_salvos, n_shots, 3] in weapon frame
    """
    weapon_locations = hit_locations.copy()
    weapon_locations[..., 0] *= -1  # Negate X
    weapon_locations[..., 1] *= -1  # Negate Y
    # Z preserved
    return weapon_locations


def accumulate_pk(shot_results: np.ndarray) -> np.ndarray:
    """
    Apply survivor rule accumulation across shots.

    accumulatedPk[0] = shotResults[0]
    accumulatedPk[k] = 1 - (1 - accumulatedPk[k-1]) * (1 - shotResults[k])

    MATLAB Reference: SalvoAnalysis03x3.m lines 643-650

    Args:
        shot_results: [n_shots, ...] per-shot Pk values

    Returns:
        accumulated_pk: Same shape as input, cumulative Pk
    """
    n_shots = shot_results.shape[0]
    accumulated_pk = np.zeros_like(shot_results)
    accumulated_pk[0] = shot_results[0]

    for k in range(1, n_shots):
        prev_pk = accumulated_pk[k - 1]
        here_pk = shot_results[k]
        accumulated_pk[k] = 1 - (1 - prev_pk) * (1 - here_pk)

    return accumulated_pk


def accumulate_pk_vectorized(shot_results: np.ndarray) -> np.ndarray:
    """
    Vectorized survivor rule using cumulative product.

    P_accum = 1 - prod(1 - P_shot)

    Args:
        shot_results: [n_shots, ...] per-shot Pk values

    Returns:
        accumulated_pk: Same shape as input, cumulative Pk
    """
    survival = np.cumprod(1 - shot_results, axis=0)
    return 1 - survival


def compute_rounds_to_kill(
    mean_acc_pk: np.ndarray,
    pk_thresholds: List[float],
) -> np.ndarray:
    """
    Compute fractional rounds-to-kill for each threshold using loop.

    MATLAB Reference: SalvoAnalysis03x3.m lines 690-750

    Args:
        mean_acc_pk: [n_shots, n_hob, n_vel, n_aof] mean accumulated Pk
        pk_thresholds: List of Pk thresholds

    Returns:
        r2k: [n_hob, n_vel, n_aof, n_pk] rounds-to-kill for each threshold
    """
    n_shots, n_hob, n_vel, n_aof = mean_acc_pk.shape
    n_pk = len(pk_thresholds)
    r2k = np.full((n_hob, n_vel, n_aof, n_pk), np.nan)

    for p, pk_req in enumerate(pk_thresholds):
        for i in range(n_hob):
            for j in range(n_vel):
                for l in range(n_aof):
                    pk_curve = mean_acc_pk[:, i, j, l]

                    if pk_curve[0] >= pk_req:
                        # First shot meets threshold
                        r2k[i, j, l, p] = pk_req / pk_curve[0]
                    else:
                        # Find crossing point
                        for n in range(1, n_shots):
                            if pk_curve[n] >= pk_req:
                                # Linear interpolation
                                delta_pk = pk_req - pk_curve[n - 1]
                                slope = pk_curve[n] - pk_curve[n - 1]
                                if slope > 1e-10:
                                    r2k[i, j, l, p] = n + delta_pk / slope
                                else:
                                    r2k[i, j, l, p] = n + 0.5
                                break
    return r2k


def compute_rounds_to_kill_vectorized(
    mean_acc_pk: np.ndarray,
    pk_thresholds: List[float],
) -> np.ndarray:
    """
    Vectorized rounds-to-kill computation.

    Args:
        mean_acc_pk: [n_shots, n_hob, n_vel, n_aof] mean accumulated Pk
        pk_thresholds: List of Pk thresholds

    Returns:
        r2k: [n_hob, n_vel, n_aof, n_pk] rounds-to-kill for each threshold
    """
    n_shots, n_hob, n_vel, n_aof = mean_acc_pk.shape
    n_pk = len(pk_thresholds)
    r2k = np.full((n_hob, n_vel, n_aof, n_pk), np.nan)

    for p, pk_req in enumerate(pk_thresholds):
        # Check if first shot meets threshold
        first_shot_meets = mean_acc_pk[0] >= pk_req
        r2k[..., p] = np.where(
            first_shot_meets,
            pk_req / np.maximum(mean_acc_pk[0], 1e-10),
            np.nan,
        )

        # For non-first-shot cases, find crossing
        for n in range(1, n_shots):
            prev_pk = mean_acc_pk[n - 1]
            curr_pk = mean_acc_pk[n]
            crosses = (prev_pk < pk_req) & (curr_pk >= pk_req)
            delta_pk = pk_req - prev_pk
            slope = curr_pk - prev_pk
            safe_slope = np.where(slope > 1e-10, slope, 1.0)
            interp_r2k = n + delta_pk / safe_slope

            # Update only where crossing and not already set
            update_mask = crosses & np.isnan(r2k[..., p])
            r2k[..., p] = np.where(update_mask, interp_r2k, r2k[..., p])

    return r2k


@dataclass
class MonteCarloResults:
    """MATLAB-parity MC results structure."""
    single_shot_pk_mean: float
    single_shot_pk_std: float
    single_shot_pk_ci_lower: float
    single_shot_pk_ci_upper: float
    accumulated_pk_mean: float
    accumulated_pk_std: float
    accumulated_pk_by_round: Dict[int, float]
    rounds_to_pk90: Optional[float]
    rounds_to_pk95: Optional[float]
    per_shot_pk_values: Optional[List[float]] = None
    accumulated_pk_by_terminal_condition: Optional[np.ndarray] = None
    terminal_condition_labels: Optional[List[str]] = None
    pk_by_terminal_condition: Optional[np.ndarray] = None
    accumulated_pk_by_round_by_terminal_condition: Optional[List[Dict[int, float]]] = None
    rounds_to_pk90_by_terminal_condition: Optional[List[Optional[float]]] = None
    rounds_to_pk95_by_terminal_condition: Optional[List[Optional[float]]] = None
    coordinate_frame: str = "weapon"
    # MATLAB parity extensions
    mean_acc_pk_by_shot: Optional[np.ndarray] = None  # [n_shots, n_hob, n_vel, n_aof]
    rounds_to_kill: Optional[np.ndarray] = None  # [n_hob, n_vel, n_aof, n_pk]
    # Raw draw storage for visualization/validation
    aimpoint_offsets: Optional[np.ndarray] = None  # [n_salvos, 2] TLE offsets (X, Y)
    dispersion_offsets: Optional[np.ndarray] = None  # [n_salvos, n_shots, 2] CEP offsets per shot


# =============================================================================
# Main Analyzer Class
# =============================================================================

def build_pk_interpolator(
    pk_hypercube: np.ndarray,
    miss_x_axis: np.ndarray,
    miss_y_axis: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
) -> RegularGridInterpolator:
    """
    Build a 5D interpolator for the Pk hypercube.

    Args:
        pk_hypercube: [n_mx, n_my, n_hob, n_vel, n_aof] Pk tensor
        miss_x_axis: Deflection axis (m)
        miss_y_axis: Range axis (m)
        hob_axis: Height-of-burst axis
        vel_axis: Velocity axis
        aof_axis: Angle-of-fall axis

    Returns:
        RegularGridInterpolator for 5D Pk lookup
    """
    return RegularGridInterpolator(
        (miss_x_axis, miss_y_axis, hob_axis, vel_axis, aof_axis),
        pk_hypercube,
        method='linear',
        bounds_error=False,
        fill_value=0.0,  # Out-of-bounds returns 0 (equivalent to no kill)
    )


class MonteCarloAnalyzer:
    """
    Monte Carlo system Pk computation with salvo support (MATLAB-parity path).

    Supports two initialization patterns:
    1. Hypercube-based (MATLAB MEGADETH parity):
       analyzer = MonteCarloAnalyzer(pk_hypercube, miss_x, miss_y, hob, vel, aof)
       results = analyzer.run(guidance_model, n_salvos=2001, n_shots=10)

    2. Legacy callable-based:
       analyzer = MonteCarloAnalyzer(guidance_model)
       results = analyzer.analyze(grid_lookup)
    """

    def __init__(
        self,
        pk_hypercube_or_model: Union[np.ndarray, GuidanceErrorModel],
        miss_x_axis: Optional[np.ndarray] = None,
        miss_y_axis: Optional[np.ndarray] = None,
        hob_axis: Optional[np.ndarray] = None,
        vel_axis: Optional[np.ndarray] = None,
        aof_axis: Optional[np.ndarray] = None,
        n_samples: int = 1000,
        salvo_config: Optional[SalvoConfig] = None,
        random_seed: Optional[int] = None,
        enable_z_axis: bool = False,
    ):
        # Detect initialization mode
        if isinstance(pk_hypercube_or_model, np.ndarray):
            # Hypercube-based mode (MATLAB parity)
            self.pk_hypercube = pk_hypercube_or_model
            self.miss_x_axis = np.asarray(miss_x_axis) if miss_x_axis is not None else None
            self.miss_y_axis = np.asarray(miss_y_axis) if miss_y_axis is not None else None
            self.hob_axis = np.asarray(hob_axis) if hob_axis is not None else None
            self.vel_axis = np.asarray(vel_axis) if vel_axis is not None else None
            self.aof_axis = np.asarray(aof_axis) if aof_axis is not None else None
            self.guidance_model = None
            self._mode = "hypercube"

            # Build interpolator
            if all(x is not None for x in [self.miss_x_axis, self.miss_y_axis,
                                            self.hob_axis, self.vel_axis, self.aof_axis]):
                self._interpolator = build_pk_interpolator(
                    self.pk_hypercube,
                    self.miss_x_axis,
                    self.miss_y_axis,
                    self.hob_axis,
                    self.vel_axis,
                    self.aof_axis,
                )
            else:
                self._interpolator = None
        else:
            # Legacy mode (GuidanceErrorModel)
            self.pk_hypercube = None
            self.miss_x_axis = None
            self.miss_y_axis = None
            self.hob_axis = None
            self.vel_axis = None
            self.aof_axis = None
            self.guidance_model = pk_hypercube_or_model
            self._mode = "legacy"
            self._interpolator = None

        self.n_samples = n_samples
        self.salvo_config = salvo_config or SalvoConfig()
        self.rng = np.random.default_rng(random_seed)
        self.enable_z_axis = enable_z_axis

    def run(
        self,
        guidance_model: GuidanceErrorModel,
        n_salvos: int = 2001,
        n_shots: int = 10,
        pk_thresholds: Optional[List[float]] = None,
        random_seed: int = 314159,
        use_mt19937: bool = False,
        matlab_hit_locations: Optional[np.ndarray] = None,
    ) -> MonteCarloResults:
        """
        Run full MATLAB-parity Monte Carlo analysis.

        MATLAB Reference: SalvoAnalysis03x3.m

        Args:
            guidance_model: Guidance error configuration
            n_salvos: Number of Monte Carlo salvos
            n_shots: Shots per salvo
            pk_thresholds: Pk thresholds for rounds-to-kill
            random_seed: Random seed for reproducibility (MATLAB uses 314159)
            use_mt19937: If True, use Mersenne Twister like MATLAB's 'twister'
            matlab_hit_locations: Optional pre-computed hit locations from MATLAB.
                Shape [n_salvos, n_shots, 2] in weapon frame (already negated).
                If provided, uses these instead of generating from guidance_model.

        Returns:
            MonteCarloResults with MATLAB-parity outputs
        """
        if self._mode != "hypercube" or self._interpolator is None:
            raise ValueError("run() requires hypercube-mode initialization with all axes")

        if pk_thresholds is None:
            pk_thresholds = [0.5, 0.9]

        # Get axis sizes
        n_hob = len(self.hob_axis)
        n_vel = len(self.vel_axis)
        n_aof = len(self.aof_axis)

        # Check if using MATLAB RNG draws
        if matlab_hit_locations is not None:
            logger.info("[RNG WIRING] Using pre-computed MATLAB hit locations for Python MC")
            logger.info(f"  Shape: {matlab_hit_locations.shape}")
            logger.info(f"  Expected: ({n_salvos}, {n_shots}, 2)")
            
            # Validate shape
            if matlab_hit_locations.shape != (n_salvos, n_shots, 2):
                logger.warning(f"  Shape mismatch! Adjusting n_salvos/n_shots to match MATLAB data")
                n_salvos = matlab_hit_locations.shape[0]
                n_shots = matlab_hit_locations.shape[1]
                logger.info(f"  Adjusted to: n_salvos={n_salvos}, n_shots={n_shots}")
            
            # Use MATLAB hit locations directly (already in weapon frame)
            weapon_locations = matlab_hit_locations
            
            # Log sample values for verification
            logger.info(f"  First salvo, first 3 shots X coords: "
                       f"{weapon_locations[0, 0, 0]:.4f}, {weapon_locations[0, 1, 0]:.4f}, {weapon_locations[0, 2, 0]:.4f}")
            logger.info(f"  First salvo, first 3 shots Y coords: "
                       f"{weapon_locations[0, 0, 1]:.4f}, {weapon_locations[0, 1, 1]:.4f}, {weapon_locations[0, 2, 1]:.4f}")
            
            # For MATLAB draws, aimpoint = salvo_center (first shot minus CEP component)
            # Store as-is for visualization (can't decompose TLE/VarBias)
            aimpoint_offsets_out = None  # Not available for MATLAB draws
            dispersion_offsets_out = None
        else:
            # Generate error samples using Python RNG
            rng = create_rng(random_seed, use_mt19937=use_mt19937)

            # Compute sigmas from guidance model
            sigma_tle = guidance_model.get_sigma_tle()
            sigma_cep = guidance_model.get_sigma_cep()
            sigma_var_bias = guidance_model.get_sigma_variable_bias()
            fixed_bias = np.array(guidance_model.get_fixed_bias())

            # Generate error samples: TLE (per-salvo), CEP (per-shot), VarBias (per-salvo)
            # MATLAB Reference: SalvoAnalysis03x3.m lines 404-432
            tle_offsets = rng.normal(loc=0.0, scale=sigma_tle[:2], size=(n_salvos, 2))
            cep_offsets = rng.normal(loc=0.0, scale=sigma_cep[:2], size=(n_salvos, n_shots, 2))
            var_bias_offsets = rng.normal(loc=0.0, scale=sigma_var_bias[:2], size=(n_salvos, 2))

            # Salvo centers = TLE + VarBias + FixedBias
            salvo_centers = tle_offsets + var_bias_offsets + fixed_bias[:2]  # [n_salvos, 2]

            # Hit locations = salvo center + CEP
            hit_locations = salvo_centers[:, np.newaxis, :] + cep_offsets  # [n_salvos, n_shots, 2]

            # Transform to weapon frame (negate X/Y)
            weapon_locations = -hit_locations  # [n_salvos, n_shots, 2]
            
            # Store raw draws for visualization (aimpoint = TLE+VarBias+FixedBias, dispersion = CEP)
            aimpoint_offsets_out = salvo_centers.copy()  # [n_salvos, 2]
            dispersion_offsets_out = cep_offsets.copy()  # [n_salvos, n_shots, 2]

        # Initialize result tensors
        # shot_results: [n_shots, n_salvos, n_hob, n_vel, n_aof]
        shot_results = np.zeros((n_shots, n_salvos, n_hob, n_vel, n_aof))

        # VECTORIZED: Evaluate Pk for all shots at all terminal conditions in one call
        # Build flat arrays for terminal conditions
        hob_grid, vel_grid, aof_grid = np.meshgrid(
            self.hob_axis, self.vel_axis, self.aof_axis, indexing='ij'
        )
        terminal_flat = np.column_stack([
            hob_grid.ravel(),
            vel_grid.ravel(),
            aof_grid.ravel(),
        ])  # [n_terminal, 3] where n_terminal = n_hob * n_vel * n_aof
        
        n_terminal = terminal_flat.shape[0]
        n_points_total = n_salvos * n_shots * n_terminal
        
        # Build all query points: [n_salvos, n_shots, n_terminal, 5]
        # Then reshape to [n_points_total, 5] for interpolator
        points = np.zeros((n_salvos, n_shots, n_terminal, 5))
        
        # Miss distances: broadcast weapon_locations to all terminal conditions
        # weapon_locations: [n_salvos, n_shots, 2]
        points[:, :, :, 0] = weapon_locations[:, :, 0:1]  # Deflection, broadcast to n_terminal
        points[:, :, :, 1] = weapon_locations[:, :, 1:2]  # Range, broadcast to n_terminal
        
        # Terminal conditions: broadcast to all salvos/shots
        # terminal_flat: [n_terminal, 3] -> broadcast to [n_salvos, n_shots, n_terminal]
        points[:, :, :, 2] = terminal_flat[:, 0]  # HOB
        points[:, :, :, 3] = terminal_flat[:, 1]  # Velocity
        points[:, :, :, 4] = terminal_flat[:, 2]  # AOF
        
        # Flatten for interpolator call
        points_flat = points.reshape(-1, 5)  # [n_points_total, 5]
        
        # Single interpolator call for all points
        pk_flat = self._interpolator(points_flat)  # [n_points_total]
        
        # Reshape back: [n_salvos, n_shots, n_terminal] -> [n_salvos, n_shots, n_hob, n_vel, n_aof]
        pk_shaped = pk_flat.reshape(n_salvos, n_shots, n_hob, n_vel, n_aof)
        
        # Transpose to [n_shots, n_salvos, n_hob, n_vel, n_aof] for shot_results
        shot_results = pk_shaped.transpose(1, 0, 2, 3, 4)

        # Apply survivor rule: accumulated_pk = 1 - prod(1 - shot_pk)
        accumulated_pk = accumulate_pk(shot_results)  # [n_shots, n_salvos, n_hob, n_vel, n_aof]

        # Compute mean over salvos (use nanmean for MATLAB parity with 'omitnan')
        mean_acc_pk = np.nanmean(accumulated_pk, axis=1)  # [n_shots, n_hob, n_vel, n_aof]

        # Compute rounds-to-kill
        r2k = compute_rounds_to_kill(mean_acc_pk, pk_thresholds)  # [n_hob, n_vel, n_aof, n_pk]

        # Compute summary statistics (use nanmean/nanstd for MATLAB parity)
        single_shot_pk_mean = float(np.nanmean(shot_results[0]))
        single_shot_pk_std = float(np.nanstd(shot_results[0]))
        ci_half = 1.96 * single_shot_pk_std / math.sqrt(max(1, np.sum(~np.isnan(shot_results[0]))))

        acc_mean = float(np.nanmean(accumulated_pk[-1]))
        acc_std = float(np.nanstd(accumulated_pk[-1]))

        # Build accumulated_pk_by_round from mean_acc_pk
        # Use sequential nanmean for MATLAB parity (handles NaN at each step)
        rounds_curve = {
            k: float(np.nanmean(np.nanmean(np.nanmean(mean_acc_pk[k - 1], axis=0), axis=0), axis=0))
            for k in range(1, n_shots + 1)
        }

        # Find rounds to Pk90/Pk95 from mean curve
        # MATLAB: mean(mean(mean(meanAccPkByShotNum, 2, 'omitnan'), 3, 'omitnan'), 4, 'omitnan')
        # Sequential nanmean over HOB (axis=1), VEL (now axis=1), AOF (now axis=1)
        mean_curve = np.nanmean(np.nanmean(np.nanmean(mean_acc_pk, axis=1), axis=1), axis=1)
        rounds_to_pk90 = self._fractional_rounds_to_pk_static(mean_curve, 0.90)
        rounds_to_pk95 = self._fractional_rounds_to_pk_static(mean_curve, 0.95)

        return MonteCarloResults(
            single_shot_pk_mean=single_shot_pk_mean,
            single_shot_pk_std=single_shot_pk_std,
            single_shot_pk_ci_lower=single_shot_pk_mean - ci_half,
            single_shot_pk_ci_upper=single_shot_pk_mean + ci_half,
            accumulated_pk_mean=acc_mean,
            accumulated_pk_std=acc_std,
            accumulated_pk_by_round=rounds_curve,
            rounds_to_pk90=rounds_to_pk90,
            rounds_to_pk95=rounds_to_pk95,
            mean_acc_pk_by_shot=mean_acc_pk,
            rounds_to_kill=r2k,
            coordinate_frame="weapon",
            aimpoint_offsets=aimpoint_offsets_out,
            dispersion_offsets=dispersion_offsets_out,
        )

    @staticmethod
    def _fractional_rounds_to_pk_static(mean_curve: np.ndarray, threshold: float) -> Optional[float]:
        """Static version of fractional rounds-to-kill computation."""
        if mean_curve.size == 0:
            return None

        if mean_curve[0] >= threshold and mean_curve[0] > 0:
            return float(threshold / mean_curve[0])

        failing = np.where(mean_curve < threshold)[0]
        if failing.size == mean_curve.size:
            return None

        last_fail = failing[-1] if failing.size else -1
        rounds_at_fail = last_fail + 1
        next_index = rounds_at_fail

        if next_index >= mean_curve.size:
            return None

        pk_fail = mean_curve[last_fail] if last_fail >= 0 else 0.0
        pk_success = mean_curve[next_index]
        if pk_success <= pk_fail:
            return None

        delta_pk_needed = threshold - pk_fail
        slope = 1.0 / (pk_success - pk_fail)
        delta_rounds = delta_pk_needed * slope
        return float(rounds_at_fail + delta_rounds)

    @staticmethod
    def _sigma_from_radius(radius: float, fraction: float) -> float:
        if radius <= 0 or fraction <= 0 or fraction >= 1:
            return 0.0
        return radius / math.sqrt(-2 * math.log(1 - fraction))

    @staticmethod
    def _broadcast_axes(values: Union[float, Sequence[float]], n_axes: int) -> np.ndarray:
        array = np.asarray(values, dtype=float)
        if array.ndim == 0:
            array = np.repeat(array, n_axes)
        elif array.size < n_axes:
            array = np.resize(array, n_axes)
        return array

    def _sigmas_from_radii(
        self,
        radii: Union[float, Sequence[float]],
        fractions: Union[float, Sequence[float]],
        n_axes: int,
        z_sigma_override: Optional[float] = None,
    ) -> np.ndarray:
        radii_arr = self._broadcast_axes(radii, n_axes)
        fractions_arr = self._broadcast_axes(fractions, n_axes)
        radii_arr = radii_arr[:n_axes]
        fractions_arr = fractions_arr[:n_axes]
        sigmas = np.array(
            [self._sigma_from_radius(r, f) for r, f in zip(radii_arr, fractions_arr)],
            dtype=float,
        )
        if n_axes > 2 and z_sigma_override is not None:
            sigmas[2] = z_sigma_override
        return sigmas

    def _draw_miss_samples(
        self,
        n_terminal_conditions: int,
        n_trials: int,
        n_salvos: int,
        n_shots: int,
        n_axes: int,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        sigma_tle = self._sigmas_from_radii(
            self.guidance_model.tle_radius_m,
            self.guidance_model.tle_fraction,
            n_axes,
            z_sigma_override=self.guidance_model.tle_z_sigma_m,
        )
        sigma_cep = self._sigmas_from_radii(
            self.guidance_model.cep_radius_m,
            self.guidance_model.cep_fraction,
            n_axes,
            z_sigma_override=self.guidance_model.cep_z_sigma_m,
        )
        sigma_var_bias = self._sigmas_from_radii(
            self.guidance_model.variable_bias_radius_m,
            self.guidance_model.variable_bias_fraction,
            n_axes,
        )

        # MATLAB’s deployed SalvoAnalysis03x3 omits Z; when enabled here, the
        # third-axis sigmas mirror the same Gaussian mapping so that a 3D PK grid
        # can be exercised without changing the XY math.

        shape = (n_terminal_conditions, n_trials, n_salvos, n_shots, n_axes)
        aimpoint_offsets = self.rng.normal(loc=0.0, scale=sigma_tle, size=shape)
        dispersion_offsets = self.rng.normal(loc=0.0, scale=sigma_cep, size=shape)
        variable_bias_offsets = self.rng.normal(loc=0.0, scale=sigma_var_bias, size=shape)

        # MATLAB Parity (2025-12-02): Coordinate convention matches MEGADETH SalvoAnalysis03x3.m
        # Index 0 (X-axis) = Deflection (crossrange) - MATLAB PkDatabase{1}
        # Index 1 (Y-axis) = Range (downrange) - MATLAB PkDatabase{2}
        deflection = self._broadcast_axes(self.guidance_model.fixed_bias_deflection_m, n_axes)
        range_bias = self._broadcast_axes(self.guidance_model.fixed_bias_range_m, n_axes)
        fixed_bias = np.zeros(n_axes)
        fixed_bias[0] = deflection[0]  # X = Deflection
        if n_axes > 1:
            fixed_bias[1] = range_bias[0]  # Y = Range
        if n_axes > 2:
            fixed_bias[2] = (deflection[2] if deflection.size > 2 else 0.0) + (
                range_bias[2] if range_bias.size > 2 else 0.0
            )

        bias_pattern = self.salvo_config.bias_pattern or []
        salvo_bias = np.zeros((n_salvos, n_axes))
        for idx, bias in enumerate(bias_pattern[:n_salvos]):
            pattern = [bias.get("dx", 0.0), bias.get("dy", 0.0)]
            if n_axes > 2:
                pattern.append(bias.get("dz", 0.0))
            salvo_bias[idx, : len(pattern)] = pattern

        total_bias = fixed_bias.reshape(1, 1, 1, 1, n_axes) + salvo_bias.reshape(1, 1, n_salvos, 1, n_axes)
        total_offsets = aimpoint_offsets + dispersion_offsets + variable_bias_offsets + total_bias
        return total_offsets, dispersion_offsets, variable_bias_offsets

    @staticmethod
    def _infer_bounds_from_interpolator(
        interpolator: RegularGridInterpolator, n_axes: int
    ) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        try:
            grid = interpolator.grid
        except AttributeError:
            return None
        mins = np.array([np.min(axis) for axis in grid[:n_axes]])
        maxs = np.array([np.max(axis) for axis in grid[:n_axes]])
        return mins, maxs

    @staticmethod
    def _infer_bounds_from_axes(
        grid_axes: Optional[Dict[str, Iterable[float]]], n_axes: int
    ) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        if not grid_axes:
            return None
        try:
            keys = ["miss_x", "miss_y", "miss_z"][:n_axes]
            mins = np.array([np.min(grid_axes[key]) for key in keys])
            maxs = np.array([np.max(grid_axes[key]) for key in keys])
        except Exception:
            return None
        return mins, maxs

    def _vectorized_pk_lookup(
        self,
        grid_lookup: Callable,
        offsets: np.ndarray,
        grid_axes: Optional[Dict[str, Iterable[float]]] = None,
    ) -> np.ndarray:
        n_axes = offsets.shape[-1]
        flat_offsets = offsets.reshape(-1, n_axes)
        mins_maxs = None

        if isinstance(grid_lookup, RegularGridInterpolator):
            mins_maxs = self._infer_bounds_from_interpolator(grid_lookup, n_axes)
        if mins_maxs is None:
            mins_maxs = self._infer_bounds_from_axes(grid_axes, n_axes)

        if mins_maxs:
            mins, maxs = mins_maxs
            # MATLAB zeroes out-of-bounds contributions before interpolation; mask
            # here to mirror that boundary handling and avoid NaNs from SciPy.
            in_bounds = np.all((flat_offsets[:, :n_axes] >= mins) & (flat_offsets[:, :n_axes] <= maxs), axis=1)
        else:
            in_bounds = np.ones(len(flat_offsets), dtype=bool)

        pk = np.zeros(len(flat_offsets), dtype=float)

        if np.any(in_bounds):
            active_points = flat_offsets[in_bounds, :n_axes]
            try:
                pk_values = grid_lookup(active_points)
            except TypeError:
                try:
                    if n_axes == 2:
                        pk_values = grid_lookup(active_points[:, 0], active_points[:, 1])
                    else:
                        pk_values = grid_lookup(active_points[:, 0], active_points[:, 1], active_points[:, 2])
                except Exception:
                    pk_values = np.array([grid_lookup(*coords) for coords in active_points])

            pk[in_bounds] = np.asarray(pk_values, dtype=float).reshape(-1)

        return pk.reshape(offsets.shape[:-1])

    @staticmethod
    def _fractional_rounds_to_pk(mean_curve: np.ndarray, threshold: float) -> Optional[float]:
        """Replicate MATLAB fractional rounds-to-kill interpolation."""

        if mean_curve.size == 0:
            return None

        # MATLAB logic (SalvoAnalysis03x3.m 640-678): if the first round clears the
        # threshold, return fractional rounds = threshold / pk_round1 (can be < 1).
        if mean_curve[0] >= threshold and mean_curve[0] > 0:
            return float(threshold / mean_curve[0])

        # Otherwise, find the last failing round and interpolate to the next.
        failing = np.where(mean_curve < threshold)[0]
        if failing.size == mean_curve.size:
            return None

        last_fail = failing[-1] if failing.size else -1
        rounds_at_fail = last_fail + 1  # convert 0-index → 1-index for MATLAB parity
        next_index = rounds_at_fail  # 0-index of first succeeding round

        if next_index >= mean_curve.size:
            return None

        pk_fail = mean_curve[last_fail] if last_fail >= 0 else 0.0
        pk_success = mean_curve[next_index]
        if pk_success <= pk_fail:
            return None

        delta_pk_needed = threshold - pk_fail
        slope = 1.0 / (pk_success - pk_fail)
        delta_rounds = delta_pk_needed * slope
        return float(rounds_at_fail + delta_rounds)

    def analyze(
        self,
        grid_lookup: Union[Callable, Sequence[Callable]],
        terminal_conditions: Optional[Sequence[Dict[str, float]]] = None,
        grid_axes: Optional[Dict[str, Iterable[float]]] = None,
        matlab_parity_sampling: bool = True,
    ) -> MonteCarloResults:
        terminal_conditions = list(terminal_conditions) if terminal_conditions is not None else [None]
        n_terminal = len(terminal_conditions)
        n_trials = max(1, self.n_samples)
        n_salvos = max(1, self.salvo_config.n_salvos)
        n_shots = max(1, self.salvo_config.shots_per_salvo)
        bias_has_z = any((bias.get("dz") is not None) for bias in (self.salvo_config.bias_pattern or []))
        # MATLAB defaults: XY-only sampling/lookup on LMA2 grids. Z dispersion is
        # an optional future enhancement; when enabled, we keep per-axis sigmas
        # and expect a 3D PK grid. Otherwise we intentionally truncate to XY to
        # mirror MATLAB’s deployed behavior.
        n_axes = 2
        if self.enable_z_axis and (
            np.size(self.guidance_model.tle_radius_m) >= 3
            or np.size(self.guidance_model.cep_radius_m) >= 3
            or self.guidance_model.tle_z_sigma_m > 0
            or self.guidance_model.cep_z_sigma_m > 0
            or bias_has_z
        ):
            n_axes = 3

        if not matlab_parity_sampling:
            samples = self.rng.normal(loc=0.0, scale=1.0, size=(self.n_samples, 2))
            pk_shot = self._vectorized_pk_lookup(
                grid_lookup if not isinstance(grid_lookup, Sequence) else grid_lookup[0], samples, grid_axes
            )
            single_mean = float(pk_shot.mean())
            single_std = float(pk_shot.std())
            ci_half = 1.96 * single_std / math.sqrt(max(1, len(pk_shot)))
            accumulated_pk = 1 - (1 - pk_shot) ** n_shots
            acc_mean = float(accumulated_pk.mean())
            acc_std = float(accumulated_pk.std())
            rounds_curve = {i: float(1 - (1 - single_mean) ** i) for i in range(1, n_shots + 1)}
            rounds_to_pk90 = next((i for i, v in rounds_curve.items() if v >= 0.90), None)
            rounds_to_pk95 = next((i for i, v in rounds_curve.items() if v >= 0.95), None)

            return MonteCarloResults(
                single_shot_pk_mean=single_mean,
                single_shot_pk_std=single_std,
                single_shot_pk_ci_lower=single_mean - ci_half,
                single_shot_pk_ci_upper=single_mean + ci_half,
                accumulated_pk_mean=acc_mean,
                accumulated_pk_std=acc_std,
                accumulated_pk_by_round=rounds_curve,
                rounds_to_pk90=rounds_to_pk90,
                rounds_to_pk95=rounds_to_pk95,
                per_shot_pk_values=pk_shot.tolist() if n_shots > 1 else None,
            )

        offsets, _, _ = self._draw_miss_samples(
            n_terminal_conditions=n_terminal,
            n_trials=n_trials,
            n_salvos=n_salvos,
            n_shots=n_shots,
            n_axes=n_axes,
        )

        # MATLAB swaps into a weapon-centric frame by negating X/Y.
        offsets[..., 0:2] *= -1

        total_miss = offsets[..., :n_axes]

        if isinstance(grid_lookup, Sequence):
            lookup_list = list(grid_lookup)
        else:
            lookup_list = [grid_lookup] * n_terminal

        if isinstance(grid_axes, Sequence) and not isinstance(grid_axes, dict):
            grid_axes_list = list(grid_axes)
        else:
            grid_axes_list = [grid_axes] * n_terminal

        pk_by_condition = []
        for idx in range(n_terminal):
            pk_condition = self._vectorized_pk_lookup(
                lookup_list[min(idx, len(lookup_list) - 1)],
                total_miss[idx],
                grid_axes_list[min(idx, len(grid_axes_list) - 1)],
            )
            pk_by_condition.append(pk_condition)

        pk_shot = np.stack(pk_by_condition, axis=0)

        single_mean = float(pk_shot.mean())
        single_std = float(pk_shot.std())
        ci_half = 1.96 * single_std / math.sqrt(max(1, pk_shot.size))

        survival = np.cumprod(1 - pk_shot, axis=3 if pk_shot.ndim == 4 else -1)
        accumulated_pk = 1 - survival
        mean_accumulated_by_condition = accumulated_pk.mean(axis=(1, 2))
        acc_mean = float(accumulated_pk.mean())
        acc_std = float(accumulated_pk.std())

        rounds_curve_by_condition: List[Dict[int, float]] = []
        rounds_to_pk90_by_condition: List[Optional[float]] = []
        rounds_to_pk95_by_condition: List[Optional[float]] = []
        for condition_idx in range(n_terminal):
            mean_curve = mean_accumulated_by_condition[condition_idx]
            curve = {i: float(mean_curve[i - 1]) for i in range(1, n_shots + 1)}
            rounds_curve_by_condition.append(curve)
            rounds_to_pk90_by_condition.append(self._fractional_rounds_to_pk(mean_curve, 0.90))
            rounds_to_pk95_by_condition.append(self._fractional_rounds_to_pk(mean_curve, 0.95))

        rounds_curve = {
            i: float(max(curve[i] for curve in rounds_curve_by_condition)) for i in range(1, n_shots + 1)
        }

        # Mirror MATLAB: report the slowest (largest fractional) terminal-condition
        # requirement for overall rounds-to-kill to stay conservative.
        valid_pk90 = [v for v in rounds_to_pk90_by_condition if v is not None]
        valid_pk95 = [v for v in rounds_to_pk95_by_condition if v is not None]
        rounds_to_pk90 = max(valid_pk90) if valid_pk90 else None
        rounds_to_pk95 = max(valid_pk95) if valid_pk95 else None

        terminal_labels = []
        for tc in terminal_conditions:
            if not tc:
                terminal_labels.append("legacy")
                continue
            label = ", ".join(f"{k}={v}" for k, v in tc.items())
            terminal_labels.append(label)

        return MonteCarloResults(
            single_shot_pk_mean=single_mean,
            single_shot_pk_std=single_std,
            single_shot_pk_ci_lower=single_mean - ci_half,
            single_shot_pk_ci_upper=single_mean + ci_half,
            accumulated_pk_mean=acc_mean,
            accumulated_pk_std=acc_std,
            accumulated_pk_by_round=rounds_curve,
            rounds_to_pk90=rounds_to_pk90,
            rounds_to_pk95=rounds_to_pk95,
            per_shot_pk_values=pk_shot.reshape(-1).tolist() if n_shots > 1 else None,
            accumulated_pk_by_terminal_condition=mean_accumulated_by_condition,
            terminal_condition_labels=terminal_labels,
            pk_by_terminal_condition=pk_shot.mean(axis=1),
            accumulated_pk_by_round_by_terminal_condition=rounds_curve_by_condition,
            rounds_to_pk90_by_terminal_condition=rounds_to_pk90_by_condition,
            rounds_to_pk95_by_terminal_condition=rounds_to_pk95_by_condition,
            coordinate_frame="weapon",
        )

    def run_multi_precision(
        self,
        precision_sets: List[GuidanceErrorModel],
        n_salvos: int = 2001,
        n_shots: int = 10,
        pk_thresholds: Optional[List[float]] = None,
        random_seed: int = 314159,
    ) -> List[MonteCarloResults]:
        """
        Run analysis for multiple precision configurations.

        MATLAB Reference: SalvoAnalysis03x3.m outer loop over nPrecisionRows

        Args:
            precision_sets: List of guidance error models
            n_salvos: Number of salvos per analysis
            n_shots: Shots per salvo
            pk_thresholds: Pk thresholds for rounds-to-kill
            random_seed: Base RNG seed

        Returns:
            List of MonteCarloResults, one per precision set
        """
        results = []
        for idx, guidance_model in enumerate(precision_sets):
            logger.info(f"Running precision set {idx + 1}/{len(precision_sets)}")
            result = self.run(
                guidance_model=guidance_model,
                n_salvos=n_salvos,
                n_shots=n_shots,
                pk_thresholds=pk_thresholds,
                random_seed=random_seed,  # Same seed for each set (MATLAB parity)
            )
            results.append(result)
        return results


# =============================================================================
# HOB-MR Analysis (Height of Burst vs Miss Radius)
# =============================================================================

def generate_radial_samples(
    max_radius_m: float,
    radius_step_m: float = 0.5,
    samples_per_radius: int = 360,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generate uniformly distributed points around each miss radius.

    MATLAB Reference: hobmrdbgen2.m lines 100-130
        angles_rad = linspace(0, 2*pi, samplesPerRadius+1)
        xyRadialPoints_m = [cos(angles_rad); sin(angles_rad)]
        targetLocations = xyRadialPoints_m .* missRadii_m

    Args:
        max_radius_m: Maximum miss radius
        radius_step_m: Step between radii
        samples_per_radius: Number of angles to sample per radius

    Returns:
        radii: [n_radii] - radius values
        xy_points: [n_radii, samples_per_radius, 2] - (x, y) coordinates
    """
    # Generate radii (excluding 0, handled separately)
    radii = np.arange(radius_step_m, max_radius_m + radius_step_m, radius_step_m)
    n_radii = len(radii)

    # Generate angles (0 to 2π, excluding endpoint)
    angles = np.linspace(0, 2 * np.pi, samples_per_radius + 1)[:-1]

    # Compute xy coordinates for each radius and angle
    xy_points = np.zeros((n_radii, samples_per_radius, 2))
    for i, r in enumerate(radii):
        xy_points[i, :, 0] = r * np.cos(angles)
        xy_points[i, :, 1] = r * np.sin(angles)

    return radii, xy_points


def compute_hob_mr_avg_pk(
    pk_hypercube: np.ndarray,
    miss_x_axis: np.ndarray,
    miss_y_axis: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    max_radius_m: Optional[float] = None,
    radius_step_m: float = 0.5,
    samples_per_radius: int = 360,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute average Pk at each miss radius for all terminal conditions.

    MATLAB Reference: hobmrdbgen2.m

    Args:
        pk_hypercube: 5D Pk tensor
        miss_x_axis, miss_y_axis: Grid axes
        hob_axis, vel_axis, aof_axis: Terminal condition axes
        max_radius_m: Maximum radius (defaults to max(miss_y_axis))
        radius_step_m: Radius step size
        samples_per_radius: Angular samples per radius

    Returns:
        radii: [n_radii+1] - radius values (including 0)
        avg_pk: [n_radii+1, n_hob, n_vel, n_aof] - average Pk at each radius
    """
    if max_radius_m is None:
        max_radius_m = max(abs(miss_y_axis.max()), abs(miss_y_axis.min()))

    # Generate radial samples
    radii, xy_points = generate_radial_samples(
        max_radius_m, radius_step_m, samples_per_radius
    )
    n_radii = len(radii)
    n_hob = len(hob_axis)
    n_vel = len(vel_axis)
    n_aof = len(aof_axis)

    # Build interpolator
    interp = build_pk_interpolator(
        pk_hypercube, miss_x_axis, miss_y_axis, hob_axis, vel_axis, aof_axis
    )

    # Initialize output (including center point)
    avg_pk = np.zeros((n_radii + 1, n_hob, n_vel, n_aof))

    logger.info(
        f"Computing HOB-MR: {n_radii} radii × {samples_per_radius} angles × "
        f"{n_hob * n_vel * n_aof} terminal conditions"
    )

    # Evaluate center point (r=0)
    for i, hob in enumerate(hob_axis):
        for j, vel in enumerate(vel_axis):
            for k, aof in enumerate(aof_axis):
                center_point = np.array([[0.0, 0.0, hob, vel, aof]])
                avg_pk[0, i, j, k] = interp(center_point)[0]

    # Evaluate each radius
    for r_idx, radius in enumerate(radii):
        xy = xy_points[r_idx]  # [samples_per_radius, 2]

        for i, hob in enumerate(hob_axis):
            for j, vel in enumerate(vel_axis):
                for k, aof in enumerate(aof_axis):
                    # Build points for this terminal condition
                    points = np.zeros((samples_per_radius, 5))
                    points[:, 0] = xy[:, 0]
                    points[:, 1] = xy[:, 1]
                    points[:, 2] = hob
                    points[:, 3] = vel
                    points[:, 4] = aof

                    # Interpolate and average
                    pk_values = interp(points)
                    avg_pk[r_idx + 1, i, j, k] = pk_values.mean()

    # Prepend 0 to radii array
    radii_with_center = np.concatenate([[0.0], radii])

    return radii_with_center, avg_pk


# =============================================================================
# Numba-Accelerated Functions (Optional Optimization)
# =============================================================================

# Check if Numba is available
try:
    from numba import njit, prange
    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False
    # Provide fallback decorators
    def njit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator if len(args) == 0 or callable(args[0]) is False else args[0]

    def prange(*args, **kwargs):
        return range(*args, **kwargs)


@njit(cache=True)
def _survivor_rule_numba(shot_results: np.ndarray) -> np.ndarray:
    """
    Numba-accelerated survivor rule.

    Args:
        shot_results: [n_shots, n_salvos, n_hob, n_vel, n_aof]

    Returns:
        accumulated_pk: same shape as input
    """
    n_shots = shot_results.shape[0]
    n_salvos = shot_results.shape[1]
    n_hob = shot_results.shape[2]
    n_vel = shot_results.shape[3]
    n_aof = shot_results.shape[4]

    accumulated_pk = np.zeros_like(shot_results)

    for s in range(n_salvos):
        for i in range(n_hob):
            for j in range(n_vel):
                for k in range(n_aof):
                    # First shot
                    accumulated_pk[0, s, i, j, k] = shot_results[0, s, i, j, k]
                    # Subsequent shots
                    for n in range(1, n_shots):
                        prev = accumulated_pk[n - 1, s, i, j, k]
                        here = shot_results[n, s, i, j, k]
                        accumulated_pk[n, s, i, j, k] = 1.0 - (1.0 - prev) * (1.0 - here)

    return accumulated_pk


@njit(parallel=True, cache=True)
def _survivor_rule_parallel(shot_results: np.ndarray) -> np.ndarray:
    """
    Parallelized Numba survivor rule using prange.

    Parallelizes over the salvo dimension for better performance on
    multi-core systems.
    """
    n_shots = shot_results.shape[0]
    n_salvos = shot_results.shape[1]
    n_hob = shot_results.shape[2]
    n_vel = shot_results.shape[3]
    n_aof = shot_results.shape[4]

    accumulated_pk = np.zeros_like(shot_results)

    for s in prange(n_salvos):
        for i in range(n_hob):
            for j in range(n_vel):
                for k in range(n_aof):
                    accumulated_pk[0, s, i, j, k] = shot_results[0, s, i, j, k]
                    for n in range(1, n_shots):
                        prev = accumulated_pk[n - 1, s, i, j, k]
                        here = shot_results[n, s, i, j, k]
                        accumulated_pk[n, s, i, j, k] = 1.0 - (1.0 - prev) * (1.0 - here)

    return accumulated_pk


def accumulate_pk_numba(shot_results: np.ndarray, parallel: bool = True) -> np.ndarray:
    """
    Numba-accelerated survivor rule wrapper.

    Falls back to vectorized version if Numba not available.

    Args:
        shot_results: [n_shots, n_salvos, n_hob, n_vel, n_aof]
        parallel: Use parallel implementation if True

    Returns:
        accumulated_pk: same shape as input
    """
    if not NUMBA_AVAILABLE:
        logger.debug("Numba not available, using vectorized fallback")
        return accumulate_pk_vectorized(shot_results)

    if parallel:
        return _survivor_rule_parallel(shot_results)
    else:
        return _survivor_rule_numba(shot_results)


@njit(cache=True)
def _generate_gaussian_samples_numba(
    n_samples: int,
    sigma_x: float,
    sigma_y: float,
    seed: int,
) -> np.ndarray:
    """
    Numba-accelerated Gaussian sample generation.

    Uses Box-Muller transform for exact Gaussian samples.
    """
    np.random.seed(seed)
    samples = np.zeros((n_samples, 2))

    for i in range(n_samples):
        u1 = np.random.random()
        u2 = np.random.random()
        # Box-Muller transform
        r = np.sqrt(-2.0 * np.log(u1))
        theta = 2.0 * np.pi * u2
        samples[i, 0] = r * np.cos(theta) * sigma_x
        samples[i, 1] = r * np.sin(theta) * sigma_y

    return samples


@njit(cache=True)
def _compute_r2k_numba(
    mean_acc_pk: np.ndarray,
    pk_threshold: float,
) -> np.ndarray:
    """
    Numba-accelerated rounds-to-kill computation for a single threshold.

    Args:
        mean_acc_pk: [n_shots, n_hob, n_vel, n_aof]
        pk_threshold: Target Pk threshold

    Returns:
        r2k: [n_hob, n_vel, n_aof]
    """
    n_shots = mean_acc_pk.shape[0]
    n_hob = mean_acc_pk.shape[1]
    n_vel = mean_acc_pk.shape[2]
    n_aof = mean_acc_pk.shape[3]

    r2k = np.full((n_hob, n_vel, n_aof), np.nan)

    for i in range(n_hob):
        for j in range(n_vel):
            for k in range(n_aof):
                pk_curve = mean_acc_pk[:, i, j, k]

                # First shot meets threshold
                if pk_curve[0] >= pk_threshold:
                    r2k[i, j, k] = pk_threshold / pk_curve[0]
                    continue

                # Find crossing point
                for n in range(1, n_shots):
                    if pk_curve[n] >= pk_threshold:
                        # Linear interpolation
                        delta_pk = pk_threshold - pk_curve[n - 1]
                        slope = pk_curve[n] - pk_curve[n - 1]
                        if slope > 1e-10:
                            delta_nr = delta_pk / slope
                            r2k[i, j, k] = n + delta_nr
                        else:
                            r2k[i, j, k] = n + 0.5
                        break

    return r2k


def compute_rounds_to_kill_numba(
    mean_acc_pk: np.ndarray,
    pk_thresholds: List[float],
) -> np.ndarray:
    """
    Numba-accelerated rounds-to-kill for multiple thresholds.

    Falls back to vectorized version if Numba not available.

    Args:
        mean_acc_pk: [n_shots, n_hob, n_vel, n_aof]
        pk_thresholds: List of Pk thresholds

    Returns:
        r2k: [n_hob, n_vel, n_aof, n_pk_thresholds]
    """
    if not NUMBA_AVAILABLE:
        return compute_rounds_to_kill_vectorized(mean_acc_pk, pk_thresholds)

    n_hob, n_vel, n_aof = mean_acc_pk.shape[1:]
    n_pk = len(pk_thresholds)
    r2k = np.zeros((n_hob, n_vel, n_aof, n_pk))

    for p, pk in enumerate(pk_thresholds):
        r2k[:, :, :, p] = _compute_r2k_numba(mean_acc_pk, pk)

    return r2k


# =============================================================================
# Parallel Salvo Execution with Concurrent Futures
# =============================================================================

# Module-level worker function for pickling compatibility with ProcessPoolExecutor
def _parallel_salvo_worker(
    pk_hypercube: np.ndarray,
    miss_x_axis: np.ndarray,
    miss_y_axis: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    guidance_model_dict: dict,
    n_salvos: int,
    n_shots: int,
    random_seed: int,
) -> dict:
    """
    Worker function for parallel salvo execution.
    
    This is a module-level function (not a method) for pickle compatibility.
    Each worker processes a chunk of salvos and returns raw results for aggregation.
    
    Memory Efficiency (Linux):
        On fork()-based systems, pk_hypercube is shared via Copy-on-Write.
    
    Shapes:
        pk_hypercube: [n_mx, n_my, n_hob, n_vel, n_aof]
        miss_x_axis / miss_y_axis: [n_mx], [n_my]
        outputs['shot_results']: [n_shots, n_salvos, n_hob, n_vel, n_aof]
        outputs['accumulated_pk']: same shape as shot_results
    
    Args:
        pk_hypercube: 5D Pk tensor (shared via COW on Linux)
        miss_x_axis, miss_y_axis: Grid axes
        hob_axis, vel_axis, aof_axis: Terminal condition axes
        guidance_model_dict: GuidanceErrorModel attributes as dict (for pickling)
        n_salvos: Number of salvos for this worker
        n_shots: Shots per salvo
        random_seed: Worker-specific seed
        
    Returns:
        Dict with shot_results, accumulated_pk tensors and metadata
    """
    from scipy.interpolate import RegularGridInterpolator
    
    # Reconstruct GuidanceErrorModel from dict
    guidance_model = GuidanceErrorModel(**guidance_model_dict)
    
    # Build interpolator (shared hypercube via COW)
    interpolator = RegularGridInterpolator(
        (miss_x_axis, miss_y_axis, hob_axis, vel_axis, aof_axis),
        pk_hypercube,
        method='linear',
        bounds_error=False,
        fill_value=0.0,
    )
    
    n_hob = len(hob_axis)
    n_vel = len(vel_axis)
    n_aof = len(aof_axis)
    
    # Generate error samples
    rng = np.random.default_rng(random_seed)
    
    sigma_tle = guidance_model.get_sigma_tle()
    sigma_cep = guidance_model.get_sigma_cep()
    sigma_var_bias = guidance_model.get_sigma_variable_bias()
    fixed_bias = np.array(guidance_model.get_fixed_bias())
    
    tle_offsets = rng.normal(loc=0.0, scale=sigma_tle[:2], size=(n_salvos, 2))
    cep_offsets = rng.normal(loc=0.0, scale=sigma_cep[:2], size=(n_salvos, n_shots, 2))
    var_bias_offsets = rng.normal(loc=0.0, scale=sigma_var_bias[:2], size=(n_salvos, 2))
    
    salvo_centers = tle_offsets + var_bias_offsets + fixed_bias[:2]
    hit_locations = salvo_centers[:, np.newaxis, :] + cep_offsets
    weapon_locations = -hit_locations  # Transform to weapon frame
    
    # Build terminal condition grid
    hob_grid, vel_grid, aof_grid = np.meshgrid(
        hob_axis, vel_axis, aof_axis, indexing='ij'
    )
    terminal_flat = np.column_stack([
        hob_grid.ravel(),
        vel_grid.ravel(),
        aof_grid.ravel(),
    ])
    n_terminal = terminal_flat.shape[0]
    
    # Vectorized Pk lookup
    points = np.zeros((n_salvos, n_shots, n_terminal, 5))
    points[:, :, :, 0] = weapon_locations[:, :, 0:1]
    points[:, :, :, 1] = weapon_locations[:, :, 1:2]
    points[:, :, :, 2] = terminal_flat[:, 0]
    points[:, :, :, 3] = terminal_flat[:, 1]
    points[:, :, :, 4] = terminal_flat[:, 2]
    
    points_flat = points.reshape(-1, 5)
    pk_flat = interpolator(points_flat)
    pk_shaped = pk_flat.reshape(n_salvos, n_shots, n_hob, n_vel, n_aof)
    shot_results = pk_shaped.transpose(1, 0, 2, 3, 4)
    
    # Apply survivor rule
    accumulated_pk = accumulate_pk(shot_results)
    
    return {
        'shot_results': shot_results,
        'accumulated_pk': accumulated_pk,
        'n_salvos': n_salvos,
        # Include raw draws for visualization/validation
        'aimpoint_offsets': salvo_centers,  # TLE + VarBias combined (n_salvos, 2)
        'dispersion_offsets': cep_offsets,  # CEP per shot (n_salvos, n_shots, 2)
    }


def run_parallel_salvos(
    analyzer: MonteCarloAnalyzer,
    guidance_model: GuidanceErrorModel,
    n_salvos: int,
    n_shots: int,
    pk_thresholds: List[float],
    random_seed: int,
    n_workers: Optional[int] = None,
) -> MonteCarloResults:
    """
    Run Monte Carlo analysis with parallel salvo batches.

    Splits salvos across workers for parallel execution on multi-core systems.
    Each worker processes a chunk of salvos independently, then results are
    aggregated in the main process.
    
    Parallelism heuristics:
        - Worker count defaults to min(cpu_count, 8) unless overridden.
        - Requires at least 100 salvos per worker; otherwise the pool size is
          reduced and may fall back to sequential.
    
    Memory Efficiency (Linux):
        On fork()-based systems (Linux default), the pk_hypercube array is
        shared via Copy-on-Write, making worker spawning memory-efficient.
        On Windows (spawn), data is pickled and copied to each worker.

    Args:
        analyzer: MonteCarloAnalyzer instance (must be in hypercube mode)
        guidance_model: Guidance error model
        n_salvos: Total number of salvos
        n_shots: Shots per salvo
        pk_thresholds: Pk thresholds for rounds-to-kill
        random_seed: Base RNG seed
        n_workers: Number of parallel workers (default: CPU count, max 8)

    Returns:
        MonteCarloResults with combined results from all workers
    """
    import os
    from concurrent.futures import ProcessPoolExecutor, as_completed

    if analyzer._mode != "hypercube" or analyzer._interpolator is None:
        raise ValueError("run_parallel_salvos requires hypercube-mode analyzer")

    if n_workers is None:
        n_workers = min(os.cpu_count() or 1, 8)

    # Minimum salvos per worker to justify parallelism overhead
    min_salvos_per_worker = 100
    if n_salvos < n_workers * min_salvos_per_worker:
        n_workers = max(1, n_salvos // min_salvos_per_worker)

    if n_workers <= 1:
        logger.debug("Falling back to sequential execution (n_workers=%d)", n_workers)
        return analyzer.run(
            guidance_model=guidance_model,
            n_salvos=n_salvos,
            n_shots=n_shots,
            pk_thresholds=pk_thresholds,
            random_seed=random_seed,
        )

    # Split salvos across workers
    salvos_per_worker = n_salvos // n_workers
    remainder = n_salvos % n_workers

    logger.info(
        "Parallel MC: %d workers × ~%d salvos (total %d)",
        n_workers, salvos_per_worker, n_salvos
    )

    # Prepare worker configs with offset seeds
    worker_configs = []
    for i in range(n_workers):
        worker_salvos = salvos_per_worker + (1 if i < remainder else 0)
        # Offset seed to ensure independent streams (large offset to avoid overlap)
        worker_seed = random_seed + i * 1_000_000
        worker_configs.append((worker_salvos, worker_seed))

    # Convert guidance model to dict for pickling
    guidance_dict = {
        'tle_radius_m': guidance_model.tle_radius_m,
        'tle_fraction': guidance_model.tle_fraction,
        'cep_radius_m': guidance_model.cep_radius_m,
        'cep_fraction': guidance_model.cep_fraction,
        'fixed_bias_deflection_m': guidance_model.fixed_bias_deflection_m,
        'fixed_bias_range_m': guidance_model.fixed_bias_range_m,
        'variable_bias_radius_m': guidance_model.variable_bias_radius_m,
        'variable_bias_fraction': guidance_model.variable_bias_fraction,
        'tle_z_sigma_m': guidance_model.tle_z_sigma_m,
        'cep_z_sigma_m': guidance_model.cep_z_sigma_m,
    }

    # Extract arrays for worker pickling
    pk_hypercube = analyzer.pk_hypercube
    miss_x_axis = analyzer.miss_x_axis
    miss_y_axis = analyzer.miss_y_axis
    hob_axis = analyzer.hob_axis
    vel_axis = analyzer.vel_axis
    aof_axis = analyzer.aof_axis

    # Submit workers
    worker_results = []
    with ProcessPoolExecutor(max_workers=n_workers) as executor:
        futures = {
            executor.submit(
                _parallel_salvo_worker,
                pk_hypercube,
                miss_x_axis,
                miss_y_axis,
                hob_axis,
                vel_axis,
                aof_axis,
                guidance_dict,
                worker_salvos,
                n_shots,
                worker_seed,
            ): i
            for i, (worker_salvos, worker_seed) in enumerate(worker_configs)
        }

        for future in as_completed(futures):
            worker_id = futures[future]
            try:
                result = future.result()
                worker_results.append(result)
                logger.debug("Worker %d completed: %d salvos", worker_id, result['n_salvos'])
            except Exception as exc:
                logger.error("Worker %d failed: %s", worker_id, exc)
                raise

    # Aggregate results from all workers
    # Concatenate along salvo axis (axis=1 for shot_results shape [n_shots, n_salvos, ...])
    all_shot_results = np.concatenate(
        [r['shot_results'] for r in worker_results], axis=1
    )
    all_accumulated_pk = np.concatenate(
        [r['accumulated_pk'] for r in worker_results], axis=1
    )
    total_salvos = sum(r['n_salvos'] for r in worker_results)
    
    # Aggregate draws (concatenate along salvo axis)
    all_aimpoint_offsets = np.concatenate(
        [r['aimpoint_offsets'] for r in worker_results], axis=0
    )  # Shape: (total_salvos, 2)
    all_dispersion_offsets = np.concatenate(
        [r['dispersion_offsets'] for r in worker_results], axis=0
    )  # Shape: (total_salvos, n_shots, 2)

    logger.info("Aggregated %d salvos from %d workers", total_salvos, len(worker_results))

    # Compute statistics (same as MonteCarloAnalyzer.run)
    n_hob = len(hob_axis)
    n_vel = len(vel_axis)
    n_aof = len(aof_axis)

    mean_acc_pk = np.nanmean(all_accumulated_pk, axis=1)  # [n_shots, n_hob, n_vel, n_aof]
    r2k = compute_rounds_to_kill(mean_acc_pk, pk_thresholds)

    single_shot_pk_mean = float(np.nanmean(all_shot_results[0]))
    single_shot_pk_std = float(np.nanstd(all_shot_results[0]))
    ci_half = 1.96 * single_shot_pk_std / math.sqrt(max(1, np.sum(~np.isnan(all_shot_results[0]))))

    acc_mean = float(np.nanmean(all_accumulated_pk[-1]))
    acc_std = float(np.nanstd(all_accumulated_pk[-1]))

    rounds_curve = {
        k: float(np.nanmean(np.nanmean(np.nanmean(mean_acc_pk[k - 1], axis=0), axis=0), axis=0))
        for k in range(1, n_shots + 1)
    }

    mean_curve = np.nanmean(np.nanmean(np.nanmean(mean_acc_pk, axis=1), axis=1), axis=1)
    rounds_to_pk90 = MonteCarloAnalyzer._fractional_rounds_to_pk_static(mean_curve, 0.90)
    rounds_to_pk95 = MonteCarloAnalyzer._fractional_rounds_to_pk_static(mean_curve, 0.95)

    return MonteCarloResults(
        single_shot_pk_mean=single_shot_pk_mean,
        single_shot_pk_std=single_shot_pk_std,
        single_shot_pk_ci_lower=single_shot_pk_mean - ci_half,
        single_shot_pk_ci_upper=single_shot_pk_mean + ci_half,
        accumulated_pk_mean=acc_mean,
        accumulated_pk_std=acc_std,
        accumulated_pk_by_round=rounds_curve,
        rounds_to_pk90=rounds_to_pk90,
        rounds_to_pk95=rounds_to_pk95,
        mean_acc_pk_by_shot=mean_acc_pk,
        rounds_to_kill=r2k,
        coordinate_frame="weapon",
        aimpoint_offsets=all_aimpoint_offsets,
        dispersion_offsets=all_dispersion_offsets,
    )
