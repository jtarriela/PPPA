"""
Optional C++ accelerator for MEGADETH analysis functions.

This module provides a Python interface to the compiled C++ extension
(megadeth_accelerator) with automatic fallback to pure Python/NumPy when
the extension is not available.

Usage:
    from megadeth.analysis._accelerator import AVAILABLE, compute_multi_shot_nested

    if AVAILABLE:
        result = compute_multi_shot_nested(pk_grid, cx, cy, sigma, bx, by, K)
    else:
        # Use Python fallback
        ...

The C++ accelerator is built automatically when installing MEGADETH:
    pip install -e .

To verify installation:
    megadeth-accel
"""

import logging
from typing import List, Tuple

import numpy as np

logger = logging.getLogger(__name__)

# Module-level availability flag
AVAILABLE = False
HAS_OPENMP = False
VERSION = "0.0.0"

try:
    import megadeth_accelerator as _cpp

    AVAILABLE = True
    HAS_OPENMP = getattr(_cpp, "HAS_OPENMP", False)
    VERSION = getattr(_cpp, "__version__", "unknown")
    logger.debug(
        "C++ accelerator loaded (version=%s, OpenMP=%s)",
        VERSION,
        HAS_OPENMP,
    )
except ImportError as e:
    logger.debug("C++ accelerator not available: %s", e)
    _cpp = None


def compute_multi_shot_nested(
    pk_grid: np.ndarray,
    cx_axis: np.ndarray,
    cy_axis: np.ndarray,
    sigma_salvo: float,
    bias_x: float,
    bias_y: float,
    max_shots: int,
) -> np.ndarray:
    """
    Compute multi-shot Pk via nested grid integration.

    Uses C++ accelerator if available, otherwise raises RuntimeError.
    For automatic fallback, use the DiscreteGridAnalyzer class directly.

    Args:
        pk_grid: 5D array [n_cx, n_cy, n_h, n_v, n_a] - Pk at salvo centers
        cx_axis: 1D array - salvo center X coordinates
        cy_axis: 1D array - salvo center Y coordinates
        sigma_salvo: Salvo center distribution sigma
        bias_x: Fixed bias X component
        bias_y: Fixed bias Y component
        max_shots: Maximum number of shots (K)

    Returns:
        4D array [K, n_h, n_v, n_a] - mean accumulated Pk

    Raises:
        RuntimeError: If C++ accelerator is not available
    """
    if not AVAILABLE:
        raise RuntimeError(
            "C++ accelerator not available. Install with: pip install -e . "
            "or use DiscreteGridAnalyzer.compute_multi_shot_pk_nested() for Python fallback."
        )

    # Ensure C-contiguous arrays for zero-copy C++ access
    pk_c = np.ascontiguousarray(pk_grid, dtype=np.float64)
    cx_c = np.ascontiguousarray(cx_axis, dtype=np.float64)
    cy_c = np.ascontiguousarray(cy_axis, dtype=np.float64)

    return _cpp.compute_multi_shot_nested(
        pk_c, cx_c, cy_c, float(sigma_salvo), float(bias_x), float(bias_y), int(max_shots)
    )


def compute_rounds_to_kill(
    mean_pk: np.ndarray,
    thresholds: List[float],
) -> np.ndarray:
    """
    Compute fractional rounds-to-kill via MATLAB-parity linear interpolation.

    Uses C++ accelerator if available, otherwise raises RuntimeError.

    Args:
        mean_pk: 4D array [K, n_h, n_v, n_a] - mean Pk by shot count
        thresholds: List of Pk thresholds (e.g., [0.3, 0.5, 0.7, 0.9])

    Returns:
        4D array [n_h, n_v, n_a, n_thresholds] - fractional R2K

    Raises:
        RuntimeError: If C++ accelerator is not available
    """
    if not AVAILABLE:
        raise RuntimeError(
            "C++ accelerator not available. Install with: pip install -e . "
            "or use DiscreteGridAnalyzer.compute_rounds_to_kill() for Python fallback."
        )

    pk_c = np.ascontiguousarray(mean_pk, dtype=np.float64)
    thresh_list = [float(t) for t in thresholds]

    return _cpp.compute_rounds_to_kill(pk_c, thresh_list)


def build_gaussian_weights(
    cx_axis: np.ndarray,
    cy_axis: np.ndarray,
    sigma: float,
    bias_x: float,
    bias_y: float,
) -> np.ndarray:
    """
    Build 2D Gaussian weight grid for salvo center distribution.

    Args:
        cx_axis: 1D array - X coordinates
        cy_axis: 1D array - Y coordinates
        sigma: Distribution sigma
        bias_x: Center X
        bias_y: Center Y

    Returns:
        2D array [n_cx, n_cy] - Gaussian weights (unnormalized)

    Raises:
        RuntimeError: If C++ accelerator is not available
    """
    if not AVAILABLE:
        raise RuntimeError("C++ accelerator not available")

    cx_c = np.ascontiguousarray(cx_axis, dtype=np.float64)
    cy_c = np.ascontiguousarray(cy_axis, dtype=np.float64)

    return _cpp.build_gaussian_weights(cx_c, cy_c, float(sigma), float(bias_x), float(bias_y))


def parse_floats_fast(content: bytes) -> np.ndarray:
    """
    Fast parsing of numeric data from LAM2.DAT content.

    Uses fast_float library for high-performance string-to-float conversion.

    Args:
        content: Raw bytes content of the file

    Returns:
        1D numpy array of parsed floats

    Raises:
        RuntimeError: If C++ accelerator is not available
    """
    if not AVAILABLE:
        raise RuntimeError("C++ accelerator not available")

    return _cpp.parse_floats_fast(content)


def parse_lam2_block_fast(lines: List[str]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Parse a LAM2 data block (x-axis line + y-index/data rows).

    Args:
        lines: List of lines (first is x-axis, rest are y-index + data)

    Returns:
        Tuple of (x_indices, y_indices, pk_grid 2D)

    Raises:
        RuntimeError: If C++ accelerator is not available
    """
    if not AVAILABLE:
        raise RuntimeError("C++ accelerator not available")

    return _cpp.parse_lam2_block_fast(lines)


def get_info() -> dict:
    """
    Get information about the accelerator status.

    Returns:
        Dict with keys: available, version, has_openmp
    """
    return {
        "available": AVAILABLE,
        "version": VERSION,
        "has_openmp": HAS_OPENMP,
    }


# =============================================================================
# TESTING FUNCTIONS - DO NOT USE IN PRODUCTION
# =============================================================================

def compute_multi_shot_hybrid_with_samples(
    pk_grid: np.ndarray,
    cx_axis: np.ndarray,
    cy_axis: np.ndarray,
    salvo_centers_x: np.ndarray,
    salvo_centers_y: np.ndarray,
    max_shots: int,
) -> np.ndarray:
    """
    [TESTING ONLY] Compute multi-shot Pk with pre-sampled salvo centers.

    WARNING: This function exists solely for parity testing between C++
    and Python backends. DO NOT use in production code.

    By accepting pre-sampled salvo centers, tests can inject identical
    samples into both C++ and Python implementations.

    Args:
        pk_grid: 5D array [n_cx, n_cy, n_h, n_v, n_a]
        cx_axis: Salvo center X coordinates
        cy_axis: Salvo center Y coordinates
        salvo_centers_x: Pre-sampled X coordinates [n_salvos]
        salvo_centers_y: Pre-sampled Y coordinates [n_salvos]
        max_shots: Maximum number of shots

    Returns:
        4D array [max_shots, n_h, n_v, n_a] - mean accumulated Pk

    Raises:
        RuntimeError: If C++ accelerator is not available
    """
    if not AVAILABLE:
        raise RuntimeError("C++ accelerator not available for testing function")

    pk_c = np.ascontiguousarray(pk_grid, dtype=np.float64)
    cx_c = np.ascontiguousarray(cx_axis, dtype=np.float64)
    cy_c = np.ascontiguousarray(cy_axis, dtype=np.float64)
    sx_c = np.ascontiguousarray(salvo_centers_x, dtype=np.float64)
    sy_c = np.ascontiguousarray(salvo_centers_y, dtype=np.float64)

    return _cpp.compute_multi_shot_hybrid_with_samples(
        pk_c, cx_c, cy_c, sx_c, sy_c, int(max_shots)
    )

