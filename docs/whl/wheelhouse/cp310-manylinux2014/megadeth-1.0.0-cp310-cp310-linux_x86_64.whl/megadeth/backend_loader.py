# DEPRECATED
# This file is deprecated and scheduled for deletion.
# Lazy compilation has been removed in favor of a single multi-arch binary.
# See ADR-003.
