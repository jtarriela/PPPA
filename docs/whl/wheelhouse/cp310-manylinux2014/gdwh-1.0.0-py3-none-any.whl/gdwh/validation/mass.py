"""Vectorized mass calculation for warhead designs."""

import numpy as np
from dataclasses import dataclass
from typing import Tuple

from ..config import WarheadConfig


@dataclass
class MassBatch:
    """Mass computation results for a batch of designs."""

    frag_masses: np.ndarray  # shape: (n_designs,) - fragment mass (= case mass)
    charge_masses: np.ndarray  # shape: (n_designs,) - explosive mass
    total_masses: np.ndarray  # shape: (n_designs,)


class MassCalculator:
    """Vectorized mass calculator for design populations."""

    def __init__(self, warhead_config: WarheadConfig, bin_edges: np.ndarray):
        """
        Initialize mass calculator.

        Args:
            warhead_config: Warhead configuration
            bin_edges: Fragment size bin edges in grams (length n_bins + 1)
        """
        self.warhead_config = warhead_config
        self.bin_edges = np.array(bin_edges)
        self.n_zones = warhead_config.n_zones
        self.n_bins = len(bin_edges) - 1

        # Mass constraints
        self.total_mass_kg = warhead_config.mass_constraints.total_mass_kg
        self.max_frag_mass_kg = warhead_config.mass_constraints.fragment_mass_kg

        # Pre-compute bin center masses (average of edges)
        self.bin_centers_g = (bin_edges[:-1] + bin_edges[1:]) / 2.0

    def compute_batch(self, X: np.ndarray) -> MassBatch:
        """
        Compute masses for a batch of designs using Inverse Gurney.
        Charge mass is derived from the requested VELOCITY.
        """
        n_designs = X.shape[0]

        # Extract design variables
        frag_sizes, frag_quantities, zone_velocities = self._extract_variables(X)

        # 1. Compute Fragment Mass (Metal)
        # frag_mass[i] = sum(size * quantity)
        frag_masses_kg = np.sum(frag_sizes * frag_quantities, axis=(1, 2)) / 1000.0

        # 2. Determine Peak Velocity per Design (The driving requirement)
        # We assume the charge must be sufficient to drive the FASTEST zone
        if zone_velocities.shape[1] > 0:
            max_vel_mps = np.max(zone_velocities, axis=1)
        else:
            max_vel_mps = np.zeros(n_designs)

        # 3. Calculate Required Charge Mass (Inverse Gurney - Cylinder)
        # V = sqrt(2E) * sqrt( R / (1 + 0.5R) )  where R = C/M
        # Let K = (V / sqrt(2E))^2
        # K = R / (1 + 0.5R)  =>  K(1 + 0.5R) = R  =>  K = R(1 - 0.5K)
        # R = K / (1 - 0.5K)
        # C = M * R
        
        sqrt_2e = self.warhead_config.physics.gurney_constant_sqrt2e
        
        # Avoid division by zero or invalid roots
        with np.errstate(divide='ignore', invalid='ignore'):
            K = (max_vel_mps / sqrt_2e) ** 2
            
            # Singularity check: if V >= sqrt(2) * sqrt(2E), R -> infinity
            # Limit K to slightly less than 2.0 to avoid explosion
            K = np.minimum(K, 1.99)
            
            R = K / (1.0 - 0.5 * K)
            
            # Handle zero velocity case
            R = np.where(max_vel_mps > 0, R, 0.0)
            
            charge_masses_kg = frag_masses_kg * R

        # 4. Compute Total Mass (Variable!)
        # Total = Frag + Charge + Case(implicit/fixed if any)
        # Assuming Frag Mass IS Case Mass based on your previous notes
        total_masses_kg = frag_masses_kg + charge_masses_kg

        return MassBatch(
            frag_masses=frag_masses_kg,
            charge_masses=charge_masses_kg,
            total_masses=total_masses_kg,
        )

    def _extract_variables(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Extract structured design variables from flat array.

        Args:
            X: Design matrix, shape (n_designs, n_vars)

        Returns:
            frag_sizes: shape (n_designs, n_zones, n_bins)
            frag_quantities: shape (n_designs, n_zones, n_bins)
            zone_velocities: shape (n_designs, n_zones)
        """
        n_designs = X.shape[0]
        n_zones_bins = self.n_zones * self.n_bins

        # Extract flattened arrays
        frag_sizes_flat = X[:, :n_zones_bins]
        frag_quantities_flat = X[:, n_zones_bins : 2 * n_zones_bins]
        zone_velocities = X[:, 2 * n_zones_bins :]

        # Reshape to structured arrays
        frag_sizes = frag_sizes_flat.reshape(n_designs, self.n_zones, self.n_bins)
        frag_quantities = frag_quantities_flat.reshape(n_designs, self.n_zones, self.n_bins)

        return frag_sizes, frag_quantities, zone_velocities

    def check_mass_constraints(self, mass_batch: MassBatch) -> np.ndarray:
        feasible = np.ones(len(mass_batch.frag_masses), dtype=bool)

        # 1. Total Mass Constraint (NEW PRIMARY CHECK)
        # Ensures the calculated [Frag + Charge] fits in the vehicle
        feasible &= mass_batch.total_masses <= self.total_mass_kg + 1e-6

        # 2. Fragment Mass Constraint (Existing)
        feasible &= mass_batch.frag_masses <= self.max_frag_mass_kg

        # 3. Charge Mass positive (Existing)
        feasible &= mass_batch.charge_masses >= 0

        # (Optional) Max charge limit if set
        if self.warhead_config.mass_constraints.charge_mass_kg is not None:
            max_charge = self.warhead_config.mass_constraints.charge_mass_kg
            feasible &= mass_batch.charge_masses <= max_charge

        return feasible