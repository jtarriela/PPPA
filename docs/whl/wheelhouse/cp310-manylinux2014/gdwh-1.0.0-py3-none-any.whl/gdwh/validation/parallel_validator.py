"""Parallel validation of design populations."""

import numpy as np
from dataclasses import dataclass
from typing import List, Optional

from ..config import WarheadConfig, VariablesConfig
from ..utils import get_logger
from .mass import MassCalculator, MassBatch
from .gurney import GurneyCalculator, GurneyLimits


@dataclass
class ValidationBatch:
    """Validation results for a batch of designs."""

    feasibility_mask: np.ndarray  # Boolean array, shape (n_designs,)
    frag_masses: np.ndarray  # shape (n_designs,)
    charge_masses: np.ndarray  # shape (n_designs,)
    total_masses: np.ndarray  # shape (n_designs,)
    gurney_limits: np.ndarray  # shape (n_designs,)
    violation_reasons: List[Optional[str]]  # Reason for infeasibility per design

    def get_feasible_indices(self) -> np.ndarray:
        """Get indices of feasible designs."""
        return np.where(self.feasibility_mask)[0]

    def get_infeasible_indices(self) -> np.ndarray:
        """Get indices of infeasible designs."""
        return np.where(~self.feasibility_mask)[0]

    def count_feasible(self) -> int:
        """Count feasible designs."""
        return np.sum(self.feasibility_mask)

    def count_infeasible(self) -> int:
        """Count infeasible designs."""
        return np.sum(~self.feasibility_mask)


class ParallelValidator:
    """
    Validate design populations in parallel using vectorized operations.

    Checks:
    1. Fragment mass constraints
    2. Charge mass positivity
    3. Gurney velocity limits
    """

    def __init__(self, warhead_config: WarheadConfig, variables_config: VariablesConfig):
        """
        Initialize parallel validator.

        Args:
            warhead_config: Warhead configuration
            variables_config: Design variables configuration
        """
        self.warhead_config = warhead_config
        self.variables_config = variables_config
        self.logger = get_logger("gdwh.validation.parallel")

        # Initialize calculators
        bin_edges = np.array(variables_config.fragment_sizes.bin_edges_grams)
        n_bins = len(bin_edges) - 1
        self.mass_calc = MassCalculator(warhead_config, bin_edges)
        self.gurney_calc = GurneyCalculator(warhead_config, n_bins=n_bins)

    def validate_batch(self, X: np.ndarray) -> ValidationBatch:
        """
        Validate a batch of designs (fully vectorized).

        Args:
            X: Design matrix, shape (n_designs, n_vars)

        Returns:
            ValidationBatch with feasibility results
        """
        # Check for NaN/Inf in input
        if not np.isfinite(X).all():
            self.logger.warning(
                f"ParallelValidator received {np.sum(~np.isfinite(X))} non-finite values in design matrix"
            )

        n_designs = X.shape[0]

        # Step 1: Compute masses (vectorized)
        mass_batch = self.mass_calc.compute_batch(X)

        # Step 2: Check mass constraints (vectorized)
        mass_feasible = self.mass_calc.check_mass_constraints(mass_batch)

        # Step 3: Compute Gurney limits (vectorized)
        gurney_limits = self.gurney_calc.compute_limits_batch(
            mass_batch.frag_masses, mass_batch.charge_masses
        )

        # Step 4: Check velocity constraints (vectorized)
        velocity_feasible = self.gurney_calc.check_velocities_batch(X, gurney_limits)

        # Step 5: Combine feasibility (vectorized AND)
        feasibility_mask = mass_feasible & velocity_feasible

        # Step 6: Generate violation reasons
        violation_reasons = self._generate_violation_reasons(
            X, n_designs, mass_feasible, velocity_feasible, mass_batch, gurney_limits
        )

        return ValidationBatch(
            feasibility_mask=feasibility_mask,
            frag_masses=mass_batch.frag_masses,
            charge_masses=mass_batch.charge_masses,
            total_masses=mass_batch.total_masses,
            gurney_limits=gurney_limits.v_max,
            violation_reasons=violation_reasons,
        )

    def _generate_violation_reasons(
        self,
        X: np.ndarray,
        n_designs: int,
        mass_feasible: np.ndarray,
        velocity_feasible: np.ndarray,
        mass_batch: MassBatch,
        gurney_limits: GurneyLimits,
    ) -> List[Optional[str]]:
        """Generate human-readable violation reasons."""
        reasons = []

        for i in range(n_designs):
            if mass_feasible[i] and velocity_feasible[i]:
                reasons.append(None)
                continue

            violations = []

            if not mass_feasible[i]:
                # Check Total Mass violation
                if mass_batch.total_masses[i] > self.mass_calc.total_mass_kg + 1e-6:
                    violations.append(
                        f"Total mass {mass_batch.total_masses[i]:.2f} kg exceeds limit "
                        f"{self.mass_calc.total_mass_kg:.2f} kg"
                    )
                if mass_batch.frag_masses[i] > self.mass_calc.max_frag_mass_kg:
                    violations.append(
                        f"Fragment mass {mass_batch.frag_masses[i]:.2f} kg exceeds limit "
                        f"{self.mass_calc.max_frag_mass_kg:.2f} kg"
                    )
                if mass_batch.charge_masses[i] <= 0:
                    violations.append(
                        f"Charge mass {mass_batch.charge_masses[i]:.2f} kg is non-positive"
                    )

            if not velocity_feasible[i]:
                # Extract max velocity for this design
                n_zones_bins = self.warhead_config.n_zones * self.mass_calc.n_bins
                zone_velocities = X[i, 2 * n_zones_bins:]
                max_vel = np.max(zone_velocities) if zone_velocities.size > 0 else 0.0

                violations.append(
                    f"Max zone velocity {max_vel:.1f} m/s exceeds Gurney limit "
                    f"{gurney_limits.v_max[i]:.1f} m/s"
                )

            reasons.append("; ".join(violations))

        return reasons

    def get_statistics(self, validation_batch: ValidationBatch) -> dict:
        """Get validation statistics."""
        return {
            "n_designs": len(validation_batch.feasibility_mask),
            "n_feasible": validation_batch.count_feasible(),
            "n_infeasible": validation_batch.count_infeasible(),
            "feasibility_rate": validation_batch.count_feasible()
            / len(validation_batch.feasibility_mask),
            "mean_frag_mass_kg": np.mean(validation_batch.frag_masses),
            "mean_charge_mass_kg": np.mean(validation_batch.charge_masses),
            "mean_gurney_limit_mps": np.mean(validation_batch.gurney_limits),
        }
