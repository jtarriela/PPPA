"""Gurney velocity calculations and constraint checking."""

import numpy as np
from dataclasses import dataclass

from ..config import WarheadConfig
from .mass import MassBatch


@dataclass
class GurneyLimits:
    """Gurney velocity limits for a batch of designs."""

    v_max: np.ndarray  # Maximum allowable velocity per design, shape (n_designs,)
    sqrt_2e: float  # Gurney constant


class GurneyCalculator:
    """Calculate Gurney velocity limits and check constraints."""

    def __init__(self, warhead_config: WarheadConfig, n_bins: int = 7):
        """
        Initialize Gurney calculator.

        Args:
            warhead_config: Warhead configuration
            n_bins: Number of fragment size bins
        """
        self.sqrt_2e = warhead_config.physics.gurney_constant_sqrt2e
        self.n_zones = warhead_config.n_zones
        self.n_bins = n_bins

    def compute_limits_batch(
        self, frag_masses: np.ndarray, charge_masses: np.ndarray
    ) -> GurneyLimits:
        """
        Compute Gurney velocity limits for a batch (vectorized).

        Gurney equation for cylinders (Mott formula):
            v_max = sqrt(2E) * sqrt((C/M) / (1 + 0.5 * C/M))

        where:
            sqrt(2E) = Gurney constant (m/s)
            C = charge mass (kg)
            M = fragment mass (kg)
            0.5 = geometry constant for cylinders (accounts for gas mass acceleration)

        Args:
            frag_masses: Fragment masses, shape (n_designs,)
            charge_masses: Charge masses, shape (n_designs,)

        Returns:
            GurneyLimits with maximum velocities
        """
        # Avoid division by zero
        with np.errstate(divide='ignore', invalid='ignore'):
            ratio = charge_masses / frag_masses

            # Standard Gurney Equation for Cylinders
            # V = sqrt(2E) * sqrt( (C/M) / (1 + 0.5 * C/M) )
            # This accounts for the mass of the gas (0.5 factor)
            v_max = self.sqrt_2e * np.sqrt(ratio / (1.0 + 0.5 * ratio))

        # Handle invalid cases (zero or negative masses)
        v_max = np.where(np.isfinite(v_max), v_max, 0.0)

        return GurneyLimits(v_max=v_max, sqrt_2e=self.sqrt_2e)

    def check_velocities_batch(
        self, X: np.ndarray, gurney_limits: GurneyLimits
    ) -> np.ndarray:
        """
        Check if zone velocities satisfy Gurney limits (vectorized).

        Args:
            X: Design matrix, shape (n_designs, n_vars)
            gurney_limits: Pre-computed Gurney limits

        Returns:
            Boolean array (n_designs,) where True = feasible
        """
        n_designs = X.shape[0]
        n_zones_bins = self.n_zones * self.n_bins

        # Extract zone velocities from design matrix
        zone_velocities = X[:, 2 * n_zones_bins :]  # shape: (n_designs, n_zones)

        # Check if maximum velocity in each design is within Gurney limit
        if zone_velocities.shape[1] > 0:
            max_velocity_per_design = np.max(zone_velocities, axis=1)  # shape: (n_designs,)
        else:
            max_velocity_per_design = np.zeros(n_designs)

        # Feasible if max velocity <= Gurney limit
        feasible = max_velocity_per_design <= gurney_limits.v_max

        return feasible

    def compute_velocity_margin(
        self, zone_velocities: np.ndarray, v_max: float
    ) -> np.ndarray:
        """
        Compute velocity margin (how close to Gurney limit).

        Args:
            zone_velocities: Zone velocities, shape (n_zones,)
            v_max: Gurney velocity limit

        Returns:
            Margin values per zone (v_max - v_zone)
        """
        return v_max - zone_velocities

    def suggest_max_velocity(self, charge_mass_kg: float, frag_mass_kg: float) -> float:
        """
        Suggest maximum zone velocity based on Gurney equation for cylinders.

        Args:
            charge_mass_kg: Charge mass in kg
            frag_mass_kg: Fragment mass in kg

        Returns:
            Maximum allowable velocity in m/s
        """
        if frag_mass_kg <= 0:
            return 0.0

        ratio = charge_mass_kg / frag_mass_kg
        v_max = self.sqrt_2e * np.sqrt(ratio / (1.0 + 0.5 * ratio))

        return v_max
