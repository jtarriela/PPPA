"""Main CLI entry point for GDWH."""

import argparse
import sys
import subprocess
import shutil
import webbrowser
from pathlib import Path

from ..config import ConfigLoader
from ..utils import setup_logger
from ..ga.optimizer import GWDHOptimizer
from ..scripts.load_external_designs import run_import as run_frag_import
from ..parallel.resources import detect_resources


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="GWDH-NG: Next Generation Warhead Optimization Framework",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run optimization campaign
  gdwh run campaign.yaml

  # Validate configuration
  gdwh validate campaign.yaml

  # Build and view documentation
  gdwh docs
  gdwh docs --overwrite

  # Launch visualization dashboard
  gdwh dashboard output/optimization.duckdb

For more information, see the documentation in docs/
        """,
    )

    parser.add_argument("--version", action="version", version="%(prog)s 1.0.0")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Run command
    run_parser = subparsers.add_parser("run", help="Run optimization campaign")
    run_parser.add_argument("config", type=Path, help="Campaign configuration YAML file")
    run_parser.add_argument(
        "--resume", type=int, metavar="GEN", help="Resume from generation number"
    )

    # Validate command
    validate_parser = subparsers.add_parser("validate", help="Validate configuration")
    validate_parser.add_argument("config", type=Path, help="Campaign configuration YAML file")

    # Info command
    info_parser = subparsers.add_parser("info", help="Show campaign information")
    info_parser.add_argument("config", type=Path, help="Campaign configuration YAML file")

    # Docs command
    docs_parser = subparsers.add_parser("docs", help="Build and view documentation")
    docs_parser.add_argument(
        "--build", action="store_true", help="Force rebuild documentation"
    )

    # Dashboard command
    dash_parser = subparsers.add_parser("dashboard", help="Launch visualization dashboard")
    dash_parser.add_argument(
        "database",
        nargs="?",
        default="output/optimization.duckdb",
        help="Path to DuckDB database (default: output/optimization.duckdb)"
    )

    # Run-queue command (ADR-006)
    queue_parser = subparsers.add_parser(
        "run-queue",
        help="Run MEGADETH queue processor for on-demand hypercube regeneration"
    )
    queue_parser.add_argument(
        "--db-path",
        type=Path,
        default=Path("output/optimization.duckdb"),
        help="Path to DuckDB database (default: output/optimization.duckdb)"
    )
    queue_parser.add_argument(
        "--max-workers",
        type=int,
        default=1,
        help="Number of parallel workers (1=sequential, default: 1)"
    )
    queue_parser.add_argument(
        "--batch-size",
        type=int,
        default=10,
        help="Items to process per batch (default: 10)"
    )
    queue_parser.add_argument(
        "--poll-interval",
        type=float,
        default=5.0,
        help="Seconds to wait between empty polls (default: 5.0)"
    )

    # Progress command (ADR-011)
    progress_parser = subparsers.add_parser(
        "progress",
        help="Launch live progress monitor for an active optimization run"
    )
    progress_parser.add_argument(
        "output_dir",
        nargs="?",
        type=Path,
        default=Path("output"),
        help="Path to output directory (default: output/)"
    )
    progress_parser.add_argument(
        "--port",
        type=int,
        default=8502,
        help="Streamlit port (default: 8502 to avoid conflict with main dashboard)"
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    # Execute command
    if args.command == "run":
        run_campaign(args)
    elif args.command == "validate":
        validate_config(args)
    elif args.command == "info":
        show_info(args)
    elif args.command == "docs":
        build_docs(args)
    elif args.command == "dashboard":
        launch_dashboard(args)
    elif args.command == "run-queue":
        run_queue(args)
    elif args.command == "progress":
        launch_progress(args)


def run_campaign(args):
    """Run optimization campaign."""
    # --- EARLY MPI RANK DETECTION ---
    resources = detect_resources()
    is_worker = resources.mpi_available and resources.mpi_rank is not None and resources.mpi_rank > 0
    
    # Workers should be quiet
    log_level = "WARNING" if is_worker else "INFO"
    logger = setup_logger("gdwh.cli", level=log_level)

    if not is_worker:
        logger.info(f"Loading configuration from {args.config}")

    try:
        config = ConfigLoader.from_yaml(args.config)
    except Exception as e:
        logger.error(f"Failed to load configuration: {e}")
        sys.exit(1)

    if not is_worker:
        logger.info(f"Campaign: {config.name}")
        logger.info(f"Targets: {len(config.targets)}")
        logger.info(f"Design variables: {config.count_variables()}")
        logger.info(f"Objectives: {config.count_objectives()}")
        logger.info(f"Population size: {config.ga.population_size}")
        logger.info(f"Max generations: {config.ga.max_generations}")

    # Short-circuit to fragment import mode if requested (master only)
    if not is_worker and getattr(config, "execution", None) and config.execution.mode == "frag_import":
        csv_path = config.execution.frag_csv_path
        if not csv_path:
            logger.error("execution.mode is 'frag_import' but execution.frag_csv_path is not set")
            sys.exit(1)

        db_path = config.storage.database
        logger.info(f"Running fragment import from {csv_path} into {db_path}")

        try:
            run_frag_import(
                config_path=args.config,
                csv_path=csv_path,
                database_path=db_path,
                campaign_id=None,
                logger=logger,
            )
        except Exception as e:
            logger.error(f"Fragment import failed: {e}")
            sys.exit(1)
        sys.exit(0)

    # Initialize optimizer (works for both master and workers)
    optimizer = GWDHOptimizer(config)

    try:
        if args.resume:
            # Only master can resume
            if is_worker:
                logger.warning("Worker cannot resume - waiting for master")
                optimizer.run()  # Will enter worker loop
            else:
                checkpoint_dir = config.storage.checkpoints.path
                checkpoint_path = checkpoint_dir / f"gen_{args.resume:04d}.pkl"
                
                if not checkpoint_path.exists():
                    logger.error(f"Checkpoint not found: {checkpoint_path}")
                    sys.exit(1)
                    
                optimizer.resume(checkpoint_path)
        else:
            optimizer.run()
            
    except KeyboardInterrupt:
        logger.info("Optimization interrupted by user")
        optimizer.cleanup()
        sys.exit(130)
    except Exception as e:
        logger.error(f"Optimization failed: {e}")
        optimizer.cleanup()
        sys.exit(1)


def validate_config(args):
    """Validate configuration file."""
    logger = setup_logger("gdwh.cli", level="INFO")

    logger.info(f"Validating configuration: {args.config}")

    try:
        config = ConfigLoader.from_yaml(args.config)
        logger.info("Configuration is valid")
        logger.info(f"  Campaign: {config.name}")
        logger.info(f"  Targets: {len(config.targets)}")
        logger.info(f"  Variables: {config.count_variables()}")
        logger.info(f"  Objectives: {config.count_objectives()}")
    except Exception as e:
        logger.error(f"Configuration validation failed: {e}")
        sys.exit(1)


def show_info(args):
    """Show campaign information."""
    logger = setup_logger("gdwh.cli", level="INFO")

    try:
        config = ConfigLoader.from_yaml(args.config)
    except Exception as e:
        logger.error(f"Failed to load configuration: {e}")
        sys.exit(1)

    # Display campaign info
    print(f"\nCampaign: {config.name}")
    print(f"Version: {config.version}")
    print(f"\nWarhead Configuration:")
    print(f"  Zones: {config.warhead.n_zones}")
    print(f"  ZDATA number: {config.warhead.zdata_number}")
    print(f"  Total mass: {config.warhead.mass_constraints.total_mass_kg} kg")
    print(f"  Fragment mass: {config.warhead.mass_constraints.fragment_mass_kg} kg")

    print(f"\nDesign Variables:")
    print(f"  Total: {config.count_variables()}")
    print(f"  Fragment sizes: {config.warhead.n_zones} × {len(config.variables.fragment_sizes.bin_edges_grams)-1}")
    print(f"  Fragment quantities: {config.warhead.n_zones} × {len(config.variables.fragment_sizes.bin_edges_grams)-1}")
    print(f"  Zone velocities: {config.warhead.n_zones}")

    print(f"\nTargets:")
    for target in config.targets:
        print(f"  - {target.name} (RCAS {target.rcas_number})")

    print(f"\nObjectives:")
    print(f"  Total: {config.count_objectives()}")
    if config.objectives.integrated_kill_potential.enabled:
        print(f"  - Integrated Kill Potential ({'per-target' if config.objectives.integrated_kill_potential.per_target else 'aggregate'})")
    if config.objectives.volume_at_threshold.enabled:
        print(f"  - Volume at Threshold ({'per-target' if config.objectives.volume_at_threshold.per_target else 'aggregate'})")
    if config.objectives.total_mass.enabled:
        print(f"  - Total Mass (minimize)")
    if config.objectives.fragment_mass.enabled:
        print(f"  - Fragment Mass (minimize)")

    print(f"\nGA Configuration:")
    print(f"  Algorithm: {config.ga.algorithm}")
    print(f"  Population size: {config.ga.population_size}")
    print(f"  Max generations: {config.ga.max_generations}")

    print(f"\nMEGADETH Configuration:")
    print(f"  Terminal conditions: {len(config.megadeth.axes.hob_m)} HOB × {len(config.megadeth.axes.vel_mps)} vel × {len(config.megadeth.axes.aof_deg)} AOF")
    print(f"  Pk threshold: {config.megadeth.pk_threshold}")
    print(f"  Monte Carlo: {'enabled' if config.megadeth.run_mc else 'disabled'}")

    print(f"\nStorage:")
    print(f"  Database: {config.storage.database}")
    print(f"  HDF5 directory: {config.storage.hdf5.consolidated_dir}")
    print()


def build_docs(args):
    """Build and view documentation."""
    logger = setup_logger("gdwh.cli", level="INFO")

    # Resolve paths relative to installation
    repo_root = Path(__file__).resolve().parent.parent.parent
    docs_dir = repo_root / "docs"
    source_dir = docs_dir / "source"
    build_dir = docs_dir / "build"
    index_path = build_dir / "html" / "index.html"

    if not source_dir.exists():
        logger.error(f"Documentation source not found at {source_dir}")
        logger.error("Ensure you are running from a development install where docs are present.")
        sys.exit(1)

    # Determine if build is needed
    should_build = args.build or not index_path.exists()

    if should_build:
        # Clean build directory if forcing build
        if args.build and build_dir.exists():
            logger.info("Cleaning build directory...")
            shutil.rmtree(build_dir)

        # Copy README.md to docs/source/README.md
        readme_src = repo_root / "README.md"
        readme_dst = source_dir / "README.md"
        if readme_src.exists():
            logger.info("Copying README.md to docs/source/...")
            shutil.copy(readme_src, readme_dst)

        # 1. Generate API docs
        logger.info("Generating API documentation...")
        gdwh_pkg_dir = repo_root / "gdwh"
        try:
            subprocess.run(
                ["sphinx-apidoc", "-o", str(source_dir), str(gdwh_pkg_dir), "--force"],
                check=True,
                capture_output=True
            )
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to generate API docs: {e}")
            # Continue anyway, might just be missing modules

        # 2. Build HTML
        logger.info("Building HTML documentation...")
        try:
            subprocess.run(
                ["sphinx-build", "-b", "html", str(source_dir), str(build_dir / "html")],
                check=True
            )
        except subprocess.CalledProcessError as e:
            logger.error(f"Documentation build failed: {e}")
            sys.exit(1)

    # 3. Open in browser
    if index_path.exists():
        logger.info(f"Opening documentation: {index_path}")
        webbrowser.open(index_path.resolve().as_uri())
    else:
        logger.error("Build succeeded but index.html not found")


def launch_dashboard(args):
    """Launch Streamlit dashboard."""
    logger = setup_logger("gdwh.cli", level="INFO")
    
    dashboard_script = Path(__file__).parent.parent / "visualization" / "dashboard.py"
    
    if not dashboard_script.exists():
        logger.error(f"Dashboard script not found at {dashboard_script}")
        sys.exit(1)
        
    logger.info(f"Launching dashboard for database: {args.database}")
    
    try:
        # Check if streamlit is installed
        subprocess.run(["streamlit", "--version"], check=True, capture_output=True)
        
        # Run dashboard
        subprocess.run(
            ["streamlit", "run", str(dashboard_script), "--", args.database],
            check=True
        )
    except FileNotFoundError:
        logger.error("Streamlit not found. Please install it: pip install streamlit")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        logger.error(f"Dashboard crashed: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("Dashboard stopped")


def launch_progress(args):
    """Launch live progress monitor for an active optimization run (ADR-011)."""
    logger = setup_logger("gdwh.cli", level="INFO")
    
    progress_script = Path(__file__).parent.parent / "visualization" / "progress_dashboard.py"
    
    if not progress_script.exists():
        logger.error(f"Progress dashboard script not found at {progress_script}")
        sys.exit(1)
    
    output_dir = Path(args.output_dir)
    if not output_dir.exists():
        logger.error(f"Output directory not found: {output_dir}")
        sys.exit(1)
    
    logger.info(f"Launching progress monitor for: {output_dir}")
    logger.info("  Reading from Parquet sidecar files (no database lock)")
    logger.info(f"  Port: {args.port}")
    
    try:
        # Check if streamlit is installed
        subprocess.run(["streamlit", "--version"], check=True, capture_output=True)
        
        # Run progress dashboard
        subprocess.run(
            [
                "streamlit", "run", str(progress_script),
                "--server.port", str(args.port),
                "--", str(output_dir.absolute())
            ],
            check=True
        )
    except FileNotFoundError:
        logger.error("Streamlit not found. Please install it: pip install streamlit")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        logger.error(f"Progress dashboard crashed: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("Progress dashboard stopped")


def run_queue(args):
    """Run MEGADETH queue processor for on-demand hypercube regeneration (ADR-006)."""
    logger = setup_logger("gdwh.cli", level="INFO")

    if not args.db_path.exists():
        logger.error(f"Database not found: {args.db_path}")
        sys.exit(1)

    logger.info(f"Starting queue processor for: {args.db_path}")
    logger.info(f"  max_workers: {args.max_workers}")
    logger.info(f"  batch_size: {args.batch_size}")
    logger.info(f"  poll_interval: {args.poll_interval}s")

    from ..queue.processor import QueueProcessor, QueueConfig, load_campaign_config_from_db

    queue_config = QueueConfig(
        max_workers=args.max_workers,
        batch_size=args.batch_size,
        poll_interval_s=args.poll_interval,
    )

    # Create config loader bound to this database
    def config_loader(campaign_id: str):
        return load_campaign_config_from_db(args.db_path, campaign_id)

    processor = QueueProcessor(
        db_path=args.db_path,
        config_loader=config_loader,
        queue_config=queue_config,
    )

    try:
        processor.start()
    except KeyboardInterrupt:
        logger.info("Queue processor interrupted by user")
        processor.stop()
    except Exception as e:
        logger.error(f"Queue processor failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
