"""Load external fragment CSV designs into the GDWH database."""

import argparse
import json
import time
from pathlib import Path
from typing import Optional, Tuple

import duckdb
import numpy as np
import yaml

from gdwh.config import CampaignConfig, ConfigLoader, WarheadConfig, VariablesConfig
from gdwh.importers import FragFileImporter
from gdwh.storage import DatabaseSchema
from gdwh.utils import compute_bytes_checksum, setup_logger
from gdwh.zdata.generator import ZDATAGenerator


def parse_args() -> argparse.Namespace:
    """Command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Import legacy fragment CSVs and persist them as evaluations.",
    )
    parser.add_argument("--csv", required=True, type=Path, help="Path to fragment CSV input")
    parser.add_argument("--config", required=True, type=Path, help="Campaign YAML to drive physics context")
    parser.add_argument(
        "--database",
        type=Path,
        help="Optional override for DuckDB path (defaults to config.storage.database)",
    )
    parser.add_argument(
        "--campaign-id",
        type=str,
        help="Optional campaign id (defaults to imported_<timestamp>)",
    )
    return parser.parse_args()


def load_campaign_config(config_path: Path, logger) -> Tuple[Optional[CampaignConfig], Optional[dict], str]:
    """Load campaign configuration, with a graceful fallback to raw YAML."""
    config_text = config_path.read_text()
    try:
        config = ConfigLoader.from_yaml(config_path)
        return config, None, config_text
    except Exception as exc:  # pragma: no cover - defensive fallback
        logger.warning(f"ConfigLoader failed ({exc}); falling back to raw YAML parsing")
        raw_dict = yaml.safe_load(config_text)

        # Attempt to hydrate CampaignConfig without file validation to enable downstream metadata.
        try:
            resolved = ConfigLoader._resolve_paths(dict(raw_dict), config_path.parent)
            ConfigLoader._transform_terminal_conditions(resolved)
            config_model = CampaignConfig(**resolved)
        except Exception:
            config_model = None

        return config_model, raw_dict, config_text


def reconcile_bin_edges(n_bins: int, base_edges: Optional[list]) -> list:
    """Ensure bin edges count matches CSV-derived bin count."""
    if base_edges and len(base_edges) - 1 == n_bins:
        return list(base_edges)
    start = base_edges[0] if base_edges else 0.0
    # Simple monotonic placeholder edges when CSV bins differ from config
    return [float(start + i) for i in range(n_bins + 1)]


def build_generator(n_zones: int, n_bins: int, config: Optional[CampaignConfig], raw: Optional[dict]) -> ZDATAGenerator:
    """Construct ZDATAGenerator with CSV-derived geometry."""
    if config is not None:
        warhead_base = config.warhead
        variables_base = config.variables
    elif raw is not None:
        warhead_base = WarheadConfig(**raw["warhead"])
        variables_base = VariablesConfig(**raw["variables"])
    else:
        raise ValueError("Campaign configuration is required to build generator context")

    fragment_edges = reconcile_bin_edges(n_bins, variables_base.fragment_sizes.bin_edges_grams)
    fragment_sizes_cfg = variables_base.fragment_sizes.model_copy(update={"bin_edges_grams": fragment_edges})
    zone_vel_cfg = variables_base.zone_velocities.model_copy(update={"strategy": "nodal"})
    variables_cfg = variables_base.model_copy(
        update={
            "fragment_sizes": fragment_sizes_cfg,
            "zone_velocities": zone_vel_cfg,
        }
    )

    warhead_cfg = warhead_base.model_copy(update={"n_zones": n_zones})

    return ZDATAGenerator(warhead_cfg, variables_cfg)


def resolve_db_path(args_db: Optional[Path], config: Optional[CampaignConfig], raw: Optional[dict]) -> Path:
    """Pick database path from args, config, or default."""
    if args_db is not None:
        return args_db
    if config is not None:
        return Path(config.storage.database)
    if raw is not None:
        storage_cfg = raw.get("storage", {})
        db_path = storage_cfg.get("database", "output/optimization.duckdb")
        return Path(db_path)
    return Path("output/optimization.duckdb")


def get_next_id(conn: duckdb.DuckDBPyConnection, table: str, column: str) -> int:
    """Compute next integer identifier for a table column."""
    row = conn.execute(f"SELECT COALESCE(MAX({column}), 0) + 1 FROM {table}").fetchone()
    return int(row[0]) if row else 1


def insert_campaign(
    conn: duckdb.DuckDBPyConnection,
    campaign_id: str,
    name: str,
    config_yaml: str,
    n_generations: int,
    n_variables: int,
    n_objectives: Optional[int],
    population_size: int,
    total_evaluations: int,
):
    """Insert campaign metadata."""
    conn.execute(
        """
        INSERT INTO campaigns
        (campaign_id, name, config_yaml, status, n_generations, n_variables,
         n_objectives, population_size, total_evaluations)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            campaign_id,
            name,
            config_yaml,
            "imported",
            n_generations,
            n_variables,
            n_objectives,
            population_size,
            total_evaluations,
        ],
    )


def insert_generation(
    conn: duckdb.DuckDBPyConnection, campaign_id: str, gen_num: int, pop_size: int, n_feasible: int
) -> int:
    """Insert a single generation row and return its gen_id."""
    gen_id = get_next_id(conn, "generations", "gen_id")
    conn.execute(
        """
        INSERT INTO generations
        (gen_id, campaign_id, gen_num, pop_size, n_feasible, n_infeasible, hypervolume, pareto_size, best_ikp, best_volume)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            gen_id,
            campaign_id,
            gen_num,
            pop_size,
            n_feasible,
            0,
            None,
            None,
            None,
            None,
        ],
    )
    return gen_id


def insert_zdata(conn: duckdb.DuckDBPyConnection, zdata_id: int, design_uuid: str, zdata_bytes: bytes):
    """Persist zdata bytes with checksum."""
    checksum = compute_bytes_checksum(zdata_bytes)
    conn.execute(
        """
        INSERT OR REPLACE INTO zdata_store (zdata_id, design_uuid, zdata_bytes, checksum)
        VALUES (?, ?, ?, ?)
        """,
        [zdata_id, design_uuid, zdata_bytes, checksum],
    )


def insert_evaluation(
    conn: duckdb.DuckDBPyConnection,
    eval_id: int,
    gen_id: int,
    design_uuid: str,
    frag_sizes: np.ndarray,
    frag_counts: np.ndarray,
    zone_velocities: np.ndarray,
    frag_mass_kg: float,
    charge_mass_kg: Optional[float],
    total_mass_kg: Optional[float],
    metadata: dict,
):
    """Insert evaluation row."""
    frag_sizes_flat = frag_sizes.flatten().tolist()
    frag_quantities_flat = frag_counts.flatten().tolist()
    zone_velocities_list = zone_velocities.tolist()

    conn.execute(
        """
        INSERT INTO evaluations
        (eval_id, gen_id, design_uuid, feasible, violation, frag_sizes, frag_quantities,
         zone_velocities, frag_mass_kg, charge_mass_kg, total_mass_kg, metadata,
         is_pareto, pareto_rank, eval_time_s)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            eval_id,
            gen_id,
            design_uuid,
            True,
            None,
            frag_sizes_flat,
            frag_quantities_flat,
            zone_velocities_list,
            frag_mass_kg,
            charge_mass_kg,
            total_mass_kg,
            json.dumps(metadata),
            False,
            None,
            0.0,
        ],
    )


def main():
    args = parse_args()
    run_import(
        config_path=args.config,
        csv_path=args.csv,
        database_path=args.database,
        campaign_id=args.campaign_id,
        logger=None,
    )


def run_import(
    config_path: Path,
    csv_path: Path,
    database_path: Optional[Path] = None,
    campaign_id: Optional[str] = None,
    logger=None,
):
    """Shared entry point for fragment CSV imports."""
    _logger = logger or setup_logger("gdwh.import_csv", level="INFO")

    config, raw_config, config_text = load_campaign_config(config_path, _logger)
    importer = FragFileImporter(str(csv_path))
    designs = importer.parse()

    if not designs:
        _logger.error("No designs parsed from CSV; aborting.")
        return

    n_zones = designs[0].n_zones
    n_bins = designs[0].n_bins
    n_variables = n_zones * n_bins * 2 + (n_zones + 1)
    n_objectives = config.count_objectives() if config is not None else None

    db_path = resolve_db_path(database_path, config, raw_config)
    DatabaseSchema.create_schema(db_path)
    conn = DatabaseSchema.get_connection(db_path, read_only=False)

    campaign_id = campaign_id or f"imported_{int(time.time())}"
    campaign_name = (
        config.name if config is not None else (raw_config.get("name") if raw_config else campaign_id)
    )

    try:
        generator = build_generator(n_zones, n_bins, config, raw_config)
    except Exception as exc:
        _logger.error(f"Failed to build ZDATA generator: {exc}")
        raise

    try:
        insert_campaign(
            conn,
            campaign_id=campaign_id,
            name=campaign_name,
            config_yaml=config_text,
            n_generations=1,
            n_variables=n_variables,
            n_objectives=n_objectives,
            population_size=len(designs),
            total_evaluations=len(designs),
        )

        gen_id = insert_generation(conn, campaign_id, gen_num=1, pop_size=len(designs), n_feasible=len(designs))

        next_eval_id = get_next_id(conn, "evaluations", "eval_id")
        next_zdata_id = get_next_id(conn, "zdata_store", "zdata_id")

        for design in designs:
            design_vector = np.concatenate(
                [design.frag_sizes.flatten(), design.frag_counts.flatten(), design.velocities_nodal]
            )

            zdata_bytes = generator.to_bytes(design_vector)
            insert_zdata(conn, next_zdata_id, design.design_uuid, zdata_bytes)

            charge_mass = (
                config.warhead.mass_constraints.charge_mass_kg if config is not None else None
            )
            total_mass = design.total_frag_mass_kg + (charge_mass or 0.0) if charge_mass is not None else design.total_frag_mass_kg

            insert_evaluation(
                conn,
                eval_id=next_eval_id,
                gen_id=gen_id,
                design_uuid=design.design_uuid,
                frag_sizes=design.frag_sizes,
                frag_counts=design.frag_counts,
                zone_velocities=design.velocities_nodal,
                frag_mass_kg=design.total_frag_mass_kg,
                charge_mass_kg=charge_mass,
                total_mass_kg=total_mass,
                metadata={"source": "csv_import", "original_eval_id": design.original_id},
            )

            next_eval_id += 1
            next_zdata_id += 1

        conn.commit()
        _logger.info(f"Imported {len(designs)} designs into campaign '{campaign_id}' at {db_path}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
