"""Utility scripts for GDWH."""
