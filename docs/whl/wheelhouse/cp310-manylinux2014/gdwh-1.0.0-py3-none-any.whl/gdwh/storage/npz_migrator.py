"""NPZ file migration utility.

Relocates NPZ files to a new directory and updates the database registry.
Useful for moving data to different storage locations or fixing path issues.

Usage:
    python -m gdwh.storage.npz_migrator <db_path> <new_npz_dir> [--dry-run]
    python -m gdwh.storage.npz_migrator <db_path> <new_npz_dir> --update-only

Examples:
    # Dry run to see what would be moved
    python -m gdwh.storage.npz_migrator output/optimization.duckdb /data/npz --dry-run

    # Actually migrate files
    python -m gdwh.storage.npz_migrator output/optimization.duckdb /data/npz

    # Update paths only (files already moved externally via rsync etc.)
    python -m gdwh.storage.npz_migrator output/optimization.duckdb /data/npz --update-only
"""

import argparse
import shutil
from pathlib import Path
from typing import Optional

import duckdb


def migrate_npz_files(
    db_path: Path,
    new_npz_dir: Path,
    old_base_dir: Optional[Path] = None,
    dry_run: bool = False,
) -> dict:
    """
    Migrate NPZ files to new directory and update database registry.

    Args:
        db_path: Path to DuckDB database
        new_npz_dir: Target directory for NPZ files
        old_base_dir: Base directory to resolve relative paths (defaults to db parent)
        dry_run: If True, show what would be done without making changes

    Returns:
        Dict with migration statistics
    """
    stats = {'moved': 0, 'skipped': 0, 'failed': 0, 'not_found': 0}

    db_path = Path(db_path).resolve()
    if old_base_dir is None:
        old_base_dir = db_path.parent

    new_npz_dir = Path(new_npz_dir).resolve()
    if not dry_run:
        new_npz_dir.mkdir(parents=True, exist_ok=True)

    conn = duckdb.connect(str(db_path), read_only=dry_run)

    # Get all NPZ registry entries
    rows = conn.execute(
        "SELECT npz_uuid, consolidated_path, original_path FROM npz_registry"
    ).fetchall()

    print(f"Found {len(rows)} NPZ entries in registry")

    for npz_uuid, consolidated_path, original_path in rows:
        # Resolve old path
        old_path = Path(consolidated_path)
        if not old_path.is_absolute():
            old_path = old_base_dir / consolidated_path

        # If still not found, try common variations
        if not old_path.exists():
            # Try stripping 'output/' prefix
            path_parts = Path(consolidated_path).parts
            if path_parts and path_parts[0] == 'output':
                stripped = Path(*path_parts[1:])
                old_path = old_base_dir / stripped

        new_path = new_npz_dir / f"{npz_uuid}.npz"

        if not old_path.exists():
            print(f"NOT FOUND: {npz_uuid} at {consolidated_path}")
            stats['not_found'] += 1
            continue

        if new_path.exists():
            print(f"SKIP (exists): {npz_uuid}")
            stats['skipped'] += 1
            continue

        print(f"{'[DRY-RUN] ' if dry_run else ''}MOVE: {old_path} -> {new_path}")

        if not dry_run:
            try:
                shutil.move(str(old_path), str(new_path))
                # Update database with absolute path
                conn.execute(
                    "UPDATE npz_registry SET consolidated_path = ? WHERE npz_uuid = ?",
                    [str(new_path), npz_uuid]
                )
                stats['moved'] += 1
            except Exception as e:
                print(f"FAILED: {npz_uuid} - {e}")
                stats['failed'] += 1
        else:
            stats['moved'] += 1

    if not dry_run:
        conn.commit()
    conn.close()

    return stats


def update_npz_paths(
    db_path: Path,
    new_npz_dir: Path,
    verify_exists: bool = True,
) -> dict:
    """
    Update NPZ registry paths without moving files.

    Use this when files have been moved externally (rsync, etc.)

    Args:
        db_path: Path to DuckDB database
        new_npz_dir: Directory where NPZ files now reside
        verify_exists: If True, only update paths for files that exist

    Returns:
        Dict with update statistics
    """
    stats = {'updated': 0, 'not_found': 0}

    db_path = Path(db_path).resolve()
    conn = duckdb.connect(str(db_path))
    new_npz_dir = Path(new_npz_dir).resolve()

    rows = conn.execute("SELECT npz_uuid FROM npz_registry").fetchall()

    print(f"Found {len(rows)} NPZ entries in registry")

    for (npz_uuid,) in rows:
        new_path = new_npz_dir / f"{npz_uuid}.npz"

        if verify_exists and not new_path.exists():
            print(f"NOT FOUND: {new_path}")
            stats['not_found'] += 1
            continue

        conn.execute(
            "UPDATE npz_registry SET consolidated_path = ? WHERE npz_uuid = ?",
            [str(new_path), npz_uuid]
        )
        stats['updated'] += 1

    conn.commit()
    conn.close()

    return stats


def main():
    parser = argparse.ArgumentParser(
        description="Migrate NPZ files to new location and update database registry",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument("db_path", type=Path, help="Path to DuckDB database")
    parser.add_argument("new_npz_dir", type=Path, help="Target directory for NPZ files")
    parser.add_argument(
        "--old-base-dir",
        type=Path,
        help="Base directory for resolving relative paths (default: db parent)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes"
    )
    parser.add_argument(
        "--update-only",
        action="store_true",
        help="Only update database paths (files already moved externally)"
    )
    parser.add_argument(
        "--no-verify",
        action="store_true",
        help="With --update-only, don't verify files exist at new location"
    )

    args = parser.parse_args()

    if args.update_only:
        stats = update_npz_paths(
            args.db_path,
            args.new_npz_dir,
            verify_exists=not args.no_verify,
        )
        print(f"\nPath update complete: {stats}")
    else:
        stats = migrate_npz_files(
            args.db_path,
            args.new_npz_dir,
            old_base_dir=args.old_base_dir,
            dry_run=args.dry_run,
        )
        print(f"\nMigration complete: {stats}")


if __name__ == "__main__":
    main()
