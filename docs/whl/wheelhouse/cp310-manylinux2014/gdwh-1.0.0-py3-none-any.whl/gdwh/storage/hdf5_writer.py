"""HDF5-based storage for evaluation results.

Replaces NPZConsolidator with a single HDF5 file per campaign,
improving Lustre performance by reducing metadata operations.
"""

import fcntl
import io
import os
import h5py
import numpy as np
import duckdb
from pathlib import Path
from typing import Optional, Dict, Any, List, IO
from datetime import datetime

# Try to use blosc compression (10x faster than gzip, multi-threaded)
try:
    import hdf5plugin
    BLOSC_AVAILABLE = True
except ImportError:
    BLOSC_AVAILABLE = False
    hdf5plugin = None


def _get_compression_opts() -> dict:
    """Get optimal compression options based on available libraries."""
    if BLOSC_AVAILABLE:
        # blosc with lz4: clevel=1 for speed (~3x faster than clevel=5, ~10% larger)
        return {
            **hdf5plugin.Blosc(cname='lz4', clevel=1, shuffle=hdf5plugin.Blosc.SHUFFLE),
        }
    else:
        # Fallback to gzip (slower but always available)
        return {
            'compression': 'gzip',
            'compression_opts': 4,
        }


class HDF5Writer:
    """
    Append-mode HDF5 writer for streaming evaluation results.
    
    Keeps the HDF5 file open for the duration of the campaign to minimize
    open/close overhead. Call flush() periodically and close() at shutdown.
    
    Example:
        writer = HDF5Writer(Path("campaign_123.h5"), db_conn)
        writer.add_from_bytes("uuid1", 1, "discrete", npz_bytes)
        writer.add_from_bytes("uuid1", 1, "pk", npz_bytes)
        writer.flush()
        writer.close()
    """
    
    def __init__(
        self,
        h5_path: Path,
        db_conn: Optional[duckdb.DuckDBPyConnection] = None,
        campaign_id: Optional[str] = None,
        flush_interval: int = 10,
    ):
        """
        Initialize HDF5 writer.

        Args:
            h5_path: Path to HDF5 file (created if not exists)
            db_conn: DuckDB connection for registry (optional)
            campaign_id: Campaign ID for metadata
            flush_interval: Flush to disk every N items (0 to disable)
        """
        self.h5_path = Path(h5_path)
        self.db_conn = db_conn
        self.campaign_id = campaign_id
        self.flush_interval = flush_interval
        self._h5_file: Optional[h5py.File] = None
        self._lock_file: Optional[IO] = None
        self._items_written = 0

    def _ensure_open(self) -> h5py.File:
        """Ensure HDF5 file is open, creating if needed.

        Uses file locking (fcntl.flock) to prevent concurrent writes
        from multiple processes (e.g., GA run + queue processor).
        """
        if self._h5_file is None:
            # Ensure parent directory exists
            self.h5_path.parent.mkdir(parents=True, exist_ok=True)

            # Acquire exclusive lock before opening HDF5
            # This prevents corruption from concurrent writes (ADR-006)
            lock_path = self.h5_path.with_suffix('.h5.lock')
            self._lock_file = open(lock_path, 'w')
            fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_EX)

            # Open in append mode (creates if not exists)
            self._h5_file = h5py.File(self.h5_path, 'a')

            # Add metadata on first open
            if 'metadata' not in self._h5_file:
                meta = self._h5_file.create_group('metadata')
                meta.attrs['version'] = '1.0'
                meta.attrs['created_at'] = datetime.now().isoformat()
                if self.campaign_id:
                    meta.attrs['campaign_id'] = self.campaign_id

        return self._h5_file
    
    def add_from_bytes(
        self,
        design_uuid: str,
        target_id: int,
        npz_type: str,  # 'pk', 'discrete', 'mc'
        data: bytes,
    ) -> str:
        """
        Write NPZ bytes to HDF5 and optionally register in DB.
        
        NPZ bytes are unpacked and each array is written as a separate
        dataset with gzip compression.
        
        Args:
            design_uuid: Design UUID
            target_id: Target ID
            npz_type: Type of data ('pk', 'discrete', 'mc')
            data: Raw NPZ bytes
            
        Returns:
            HDF5 path within file (e.g., 'designs/abc123/targets/1/discrete')
        """
        h5 = self._ensure_open()
        
        # HDF5 hierarchy: /designs/{uuid}/targets/{tid}/{type}
        group_path = f"designs/{design_uuid}/targets/{target_id}/{npz_type}"
        
        # Create or get the group
        if group_path in h5:
            grp = h5[group_path]
            # Clear existing datasets for overwrite
            for key in list(grp.keys()):
                del grp[key]
        else:
            grp = h5.require_group(group_path)
        
        # Unpack NPZ and write each array
        total_size = 0
        compression_opts = _get_compression_opts()
        with io.BytesIO(data) as buf:
            with np.load(buf) as npz:
                for key in npz.files:
                    arr = npz[key]
                    # Use compression for all numeric arrays (including uint, bool)
                    if np.issubdtype(arr.dtype, np.number) or arr.dtype == np.bool_:
                        grp.create_dataset(
                            key,
                            data=arr,
                            fletcher32=True,
                            **compression_opts,
                        )
                    else:
                        # Only skip compression for object/string arrays
                        grp.create_dataset(key, data=arr)
                    total_size += arr.nbytes
        
        # Add metadata
        grp.attrs['created_at'] = datetime.now().isoformat()
        grp.attrs['original_size_bytes'] = len(data)
        
        # Register in database
        if self.db_conn is not None:
            self._register(design_uuid, target_id, npz_type, group_path, total_size)

        self._items_written += 1

        # Periodic flush to spread blosc compression load
        if self.flush_interval > 0 and self._items_written % self.flush_interval == 0:
            if self._h5_file is not None:
                self._h5_file.flush()

        return group_path
    
    def _register(
        self,
        design_uuid: str,
        target_id: int,
        data_type: str,
        h5_path: str,
        size_bytes: int,
    ):
        """Register entry in hdf5_entries table."""
        self.db_conn.execute(
            """
            INSERT OR REPLACE INTO hdf5_entries
            (design_uuid, target_id, data_type, h5_path, h5_file, size_bytes)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [design_uuid, target_id, data_type, h5_path, 
             str(self.h5_path), size_bytes],
        )
    
    def flush(self) -> None:
        """Flush HDF5 buffers to disk."""
        if self._h5_file is not None:
            self._h5_file.flush()

    def close(self) -> None:
        """Close HDF5 file handle and release lock."""
        if self._h5_file is not None:
            self._h5_file.close()
            self._h5_file = None

        # Release file lock (ADR-006)
        if self._lock_file is not None:
            try:
                fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_UN)
                self._lock_file.close()
            except Exception:
                pass  # Best-effort unlock
            self._lock_file = None

    @property
    def items_written(self) -> int:
        """Number of items written since opening."""
        return self._items_written
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - close file."""
        self.close()
        return False


class HDF5Reader:
    """
    Read-only access to HDF5 result files.

    Example:
        with HDF5Reader(Path("campaign_123.h5")) as reader:
            data = reader.load_data("uuid1", 1, "discrete")
            print(data['system_pk'].shape)
    """

    def __init__(self, h5_path: Path):
        """
        Initialize HDF5 reader.

        Args:
            h5_path: Path to HDF5 file
        """
        self.h5_path = Path(h5_path)
        self._h5_file: Optional[h5py.File] = None

    def _ensure_open(self) -> h5py.File:
        """Ensure HDF5 file is open for reading."""
        if self._h5_file is None:
            if not self.h5_path.exists():
                raise FileNotFoundError(f"HDF5 file not found: {self.h5_path}")
            self._h5_file = h5py.File(self.h5_path, 'r')
        return self._h5_file

    def load_data(
        self,
        design_uuid: str,
        target_id: int,
        data_type: str = 'discrete',
    ) -> Optional[Dict[str, np.ndarray]]:
        """
        Load data for a specific design/target/type.

        Args:
            design_uuid: Design UUID
            target_id: Target ID
            data_type: Type of data ('pk', 'discrete', 'mc')

        Returns:
            Dictionary of numpy arrays, or None if not found
        """
        h5 = self._ensure_open()
        group_path = f"designs/{design_uuid}/targets/{target_id}/{data_type}"

        if group_path not in h5:
            return None

        grp = h5[group_path]
        return {key: grp[key][:] for key in grp.keys()}

    def list_designs(self) -> list:
        """List all design UUIDs in the file."""
        h5 = self._ensure_open()
        if 'designs' not in h5:
            return []
        return list(h5['designs'].keys())

    def has_design(self, design_uuid: str) -> bool:
        """Check if a design exists in the file."""
        h5 = self._ensure_open()
        return f"designs/{design_uuid}" in h5

    def close(self) -> None:
        """Close HDF5 file handle."""
        if self._h5_file is not None:
            self._h5_file.close()
            self._h5_file = None

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - close file."""
        self.close()
        return False


def consolidate_batch_files(
    batch_files: List[Path],
    output_path: Path,
    delete_source: bool = False,
) -> int:
    """
    Consolidate multiple batch HDF5 files into a single file.

    Copies all design groups from source files to output file.

    Args:
        batch_files: List of batch HDF5 file paths
        output_path: Path for consolidated output file
        delete_source: If True, delete source files after consolidation

    Returns:
        Number of designs consolidated
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    designs_copied = 0

    with h5py.File(output_path, 'w') as out:
        # Add metadata
        meta = out.create_group('metadata')
        meta.attrs['version'] = '1.0'
        meta.attrs['created_at'] = datetime.now().isoformat()
        meta.attrs['source_files'] = [str(f) for f in batch_files]

        # Ensure designs group exists
        designs_grp = out.require_group('designs')

        for batch_file in batch_files:
            if not batch_file.exists():
                continue

            with h5py.File(batch_file, 'r') as src:
                if 'designs' not in src:
                    continue

                # Copy each design group
                for design_uuid in src['designs'].keys():
                    src.copy(
                        f'designs/{design_uuid}',
                        designs_grp,
                        name=design_uuid,
                    )
                    designs_copied += 1

    # Clean up source files if requested
    if delete_source:
        for batch_file in batch_files:
            if batch_file.exists():
                batch_file.unlink()

    return designs_copied


def create_vds_index(
    batch_files: List[Path],
    output_path: Path,
) -> None:
    """
    Create a Virtual Dataset (VDS) index file that presents batch files as one.

    This is a lightweight alternative to consolidation - no data copy needed.
    The VDS file contains external links to the actual data in batch files.

    Note: Requires batch files to remain in place for VDS to work.

    Args:
        batch_files: List of batch HDF5 file paths
        output_path: Path for VDS index file
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with h5py.File(output_path, 'w') as vds:
        # Add metadata
        meta = vds.create_group('metadata')
        meta.attrs['version'] = '1.0'
        meta.attrs['type'] = 'vds_index'
        meta.attrs['created_at'] = datetime.now().isoformat()
        meta.attrs['source_files'] = [str(f) for f in batch_files]

        # Create external links to each batch file's designs
        designs_grp = vds.create_group('designs')

        for batch_file in batch_files:
            if not batch_file.exists():
                continue

            # Get design UUIDs from this batch
            with h5py.File(batch_file, 'r') as src:
                if 'designs' not in src:
                    continue

                for design_uuid in src['designs'].keys():
                    # Create external link to design in batch file
                    designs_grp[design_uuid] = h5py.ExternalLink(
                        str(batch_file),
                        f'/designs/{design_uuid}',
                    )
