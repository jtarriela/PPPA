"""DuckDB database schema for GWDH optimization storage."""

import duckdb
from pathlib import Path


class DatabaseSchema:
    """DuckDB schema for GWDH optimization campaigns."""

    # Define Sequences for Auto-Increment behavior in DuckDB
    SEQUENCES = [
        "CREATE SEQUENCE IF NOT EXISTS gen_id_seq;",
        "CREATE SEQUENCE IF NOT EXISTS eval_id_seq;",
        "CREATE SEQUENCE IF NOT EXISTS result_id_seq;",
        "CREATE SEQUENCE IF NOT EXISTS zdata_id_seq;",
        "CREATE SEQUENCE IF NOT EXISTS file_id_seq;",
        "CREATE SEQUENCE IF NOT EXISTS checkpoint_id_seq;",
        "CREATE SEQUENCE IF NOT EXISTS entry_id_seq;",
        "CREATE SEQUENCE IF NOT EXISTS queue_id_seq;",
        "CREATE SEQUENCE IF NOT EXISTS genfile_id_seq;",
    ]

    # SQL DDL statements
    CAMPAIGNS_TABLE = """
    CREATE TABLE IF NOT EXISTS campaigns (
        campaign_id VARCHAR PRIMARY KEY,
        name VARCHAR NOT NULL,
        config_yaml TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed_at TIMESTAMP,
        status VARCHAR DEFAULT 'running',
        n_generations INTEGER,
        n_variables INTEGER,
        n_objectives INTEGER,
        population_size INTEGER,
        total_evaluations BIGINT,
        total_runtime_sec DOUBLE
    );
    """

    # Note: generations usually managed manually in your writer, but adding default is safe
    GENERATIONS_TABLE = """
    CREATE TABLE IF NOT EXISTS generations (
        gen_id INTEGER PRIMARY KEY DEFAULT nextval('gen_id_seq'),
        campaign_id VARCHAR REFERENCES campaigns(campaign_id),
        gen_num INTEGER NOT NULL,
        pop_size INTEGER NOT NULL,
        n_feasible INTEGER,
        n_infeasible INTEGER,
        hypervolume DOUBLE,
        pareto_size INTEGER,
        best_ikp DOUBLE,
        best_volume DOUBLE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """

    EVALUATIONS_TABLE = """
    CREATE TABLE IF NOT EXISTS evaluations (
        eval_id INTEGER PRIMARY KEY DEFAULT nextval('eval_id_seq'),
        gen_id INTEGER REFERENCES generations(gen_id),
        design_uuid VARCHAR NOT NULL,
        feasible BOOLEAN,
        violation VARCHAR,
        frag_sizes DOUBLE[],
        frag_quantities DOUBLE[],
        zone_velocities DOUBLE[],
        frag_mass_kg DOUBLE,
        charge_mass_kg DOUBLE,
        total_mass_kg DOUBLE,
        metadata JSON,
        is_pareto BOOLEAN DEFAULT FALSE,
        pareto_rank INTEGER,
        eval_time_s DOUBLE,
        evaluated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """

    TARGET_RESULTS_TABLE = """
    CREATE TABLE IF NOT EXISTS target_results (
        result_id INTEGER PRIMARY KEY DEFAULT nextval('result_id_seq'),
        eval_id INTEGER,
        target_id INTEGER NOT NULL,
        target_name VARCHAR,
        integrated_kill_potential DOUBLE,
        volume_at_threshold DOUBLE,
        pk_npz_uuid VARCHAR,
        discrete_npz_uuid VARCHAR
    );
    """

    ZDATA_STORE_TABLE = """
    CREATE TABLE IF NOT EXISTS zdata_store (
        zdata_id INTEGER PRIMARY KEY DEFAULT nextval('zdata_id_seq'),
        design_uuid VARCHAR UNIQUE NOT NULL,
        zdata_bytes BLOB,
        checksum VARCHAR,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """

    INPUT_FILES_TABLE = """
    CREATE TABLE IF NOT EXISTS input_files (
        file_id INTEGER PRIMARY KEY DEFAULT nextval('file_id_seq'),
        campaign_id VARCHAR REFERENCES campaigns(campaign_id),
        rcas_number INTEGER,
        file_type VARCHAR,
        file_bytes BLOB,
        checksum VARCHAR
    );
    """

    NPZ_REGISTRY_TABLE = """
    CREATE TABLE IF NOT EXISTS npz_registry (
        npz_uuid VARCHAR PRIMARY KEY,
        original_path VARCHAR,
        consolidated_path VARCHAR,
        npz_type VARCHAR,
        size_bytes BIGINT,
        checksum VARCHAR,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """

    CHECKPOINTS_TABLE = """
    CREATE TABLE IF NOT EXISTS checkpoints (
        checkpoint_id INTEGER PRIMARY KEY DEFAULT nextval('checkpoint_id_seq'),
        campaign_id VARCHAR REFERENCES campaigns(campaign_id),
        gen_num INTEGER,
        checkpoint_path VARCHAR,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """

    HDF5_ENTRIES_TABLE = """
    CREATE TABLE IF NOT EXISTS hdf5_entries (
        entry_id INTEGER PRIMARY KEY DEFAULT nextval('entry_id_seq'),
        design_uuid VARCHAR,
        target_id INTEGER,
        data_type VARCHAR,
        h5_path VARCHAR,
        h5_file VARCHAR,
        size_bytes BIGINT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """

    MEGADETH_QUEUE_TABLE = """
    CREATE TABLE IF NOT EXISTS megadeth_queue (
        queue_id INTEGER PRIMARY KEY DEFAULT nextval('queue_id_seq'),
        design_uuid VARCHAR NOT NULL,
        campaign_id VARCHAR NOT NULL,
        target_id INTEGER,
        data_types VARCHAR[] DEFAULT ['pk'],
        status VARCHAR DEFAULT 'pending',
        priority INTEGER DEFAULT 0,
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        started_at TIMESTAMP,
        completed_at TIMESTAMP,
        error_message VARCHAR,
        worker_id VARCHAR,
        UNIQUE(design_uuid, campaign_id, target_id)
    );
    """

    # ADR-009: Per-generation HDF5 file tracking
    GENERATION_FILES_TABLE = """
    CREATE TABLE IF NOT EXISTS generation_files (
        genfile_id INTEGER PRIMARY KEY DEFAULT nextval('genfile_id_seq'),
        campaign_id VARCHAR NOT NULL,
        generation INT NOT NULL,
        hdf5_path VARCHAR NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        designs_count INT,
        file_size_bytes BIGINT,
        UNIQUE(campaign_id, generation)
    );
    """

    # Create indexes
    CREATE_INDEXES = [
        "CREATE INDEX IF NOT EXISTS idx_evaluations_gen ON evaluations(gen_id);",
        "CREATE INDEX IF NOT EXISTS idx_evaluations_uuid ON evaluations(design_uuid);",
        # ADR-016: Composite index for efficient temp ID mapping in flush()
        "CREATE INDEX IF NOT EXISTS idx_evaluations_gen_uuid ON evaluations(gen_id, design_uuid);",
        "CREATE INDEX IF NOT EXISTS idx_evaluations_pareto ON evaluations(is_pareto);",
        "CREATE INDEX IF NOT EXISTS idx_target_results_eval ON target_results(eval_id);",
        "CREATE INDEX IF NOT EXISTS idx_zdata_uuid ON zdata_store(design_uuid);",
        "CREATE INDEX IF NOT EXISTS idx_generations_campaign ON generations(campaign_id);",
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_evaluations_gen_uuid ON evaluations(gen_id, design_uuid);",
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_target_results_eval_target ON target_results(eval_id, target_id);",
        "CREATE INDEX IF NOT EXISTS idx_hdf5_entries_uuid ON hdf5_entries(design_uuid);",
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_hdf5_entries ON hdf5_entries(design_uuid, target_id, data_type);",
        # ADR-019: Covering index for dashboard Pk availability lookup
        "CREATE INDEX IF NOT EXISTS idx_hdf5_entries_pk_lookup ON hdf5_entries(data_type, design_uuid);",
        "CREATE INDEX IF NOT EXISTS idx_queue_status ON megadeth_queue(status, priority DESC);",
        "CREATE INDEX IF NOT EXISTS idx_queue_campaign ON megadeth_queue(campaign_id);",
        # ADR-009: Index for generation file lookups
        "CREATE INDEX IF NOT EXISTS idx_generation_files_campaign ON generation_files(campaign_id);",
    ]

    @staticmethod
    def create_schema(db_path: Path):
        """
        Create complete database schema.

        Args:
            db_path: Path to DuckDB database file
        """
        # Ensure parent directory exists
        db_path.parent.mkdir(parents=True, exist_ok=True)

        # Connect and create schema
        conn = duckdb.connect(str(db_path))

        try:
            # Create Sequences first
            for seq_sql in DatabaseSchema.SEQUENCES:
                conn.execute(seq_sql)

            # Create tables
            conn.execute(DatabaseSchema.CAMPAIGNS_TABLE)
            conn.execute(DatabaseSchema.GENERATIONS_TABLE)
            conn.execute(DatabaseSchema.EVALUATIONS_TABLE)
            conn.execute(DatabaseSchema.TARGET_RESULTS_TABLE)
            conn.execute(DatabaseSchema.ZDATA_STORE_TABLE)
            conn.execute(DatabaseSchema.INPUT_FILES_TABLE)
            conn.execute(DatabaseSchema.NPZ_REGISTRY_TABLE)
            conn.execute(DatabaseSchema.CHECKPOINTS_TABLE)
            conn.execute(DatabaseSchema.HDF5_ENTRIES_TABLE)
            conn.execute(DatabaseSchema.MEGADETH_QUEUE_TABLE)
            conn.execute(DatabaseSchema.GENERATION_FILES_TABLE)

            # Create indexes
            for index_sql in DatabaseSchema.CREATE_INDEXES:
                conn.execute(index_sql)

            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def get_connection(db_path: Path, read_only: bool = False) -> duckdb.DuckDBPyConnection:
        """
        Get database connection.

        Args:
            db_path: Path to database file
            read_only: Open in read-only mode

        Returns:
            DuckDB connection
        """
        return duckdb.connect(str(db_path), read_only=read_only)