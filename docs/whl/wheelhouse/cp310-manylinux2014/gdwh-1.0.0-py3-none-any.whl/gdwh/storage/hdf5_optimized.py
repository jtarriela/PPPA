"""Optimized HDF5 read/write utilities.

This module wraps the existing HDF5 storage implementation with:
- Optional key filtering and slicing on read (lazy loading)
- Metadata-only dataset inspection
- Chunking hints for large datasets on write (better partial reads)

Used by the Streamlit dashboard to avoid loading multi-GB datasets eagerly.
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any, Dict, List, Optional

import h5py
import numpy as np

from . import hdf5_writer as legacy


class HDF5Writer(legacy.HDF5Writer):
    """Drop-in replacement for :class:`gdwh.storage.hdf5_writer.HDF5Writer` with chunking hints."""

    def add_from_bytes(
        self,
        design_uuid: str,
        target_id: int,
        npz_type: str,  # 'pk', 'discrete', 'mc'
        data: bytes,
    ) -> str:
        """
        Write NPZ bytes to HDF5 and optionally register in DB.

        Enables HDF5 chunking auto-layout for large datasets to support efficient
        partial reads later (ADR-020).
        """
        h5 = self._ensure_open()

        group_path = f"designs/{design_uuid}/targets/{target_id}/{npz_type}"

        if group_path in h5:
            grp = h5[group_path]
            for key in list(grp.keys()):
                del grp[key]
        else:
            grp = h5.require_group(group_path)

        total_size = 0
        compression_opts = legacy._get_compression_opts()

        with io.BytesIO(data) as buf:
            with np.load(buf) as npz:
                for key in npz.files:
                    arr = npz[key]

                    # Hint chunking for large arrays so later partial reads are efficient.
                    # With compression enabled, h5py will chunk anyway; this forces auto-chunking
                    # even when defaults might otherwise be suboptimal.
                    use_chunks = bool(arr.ndim > 0 and arr.nbytes > 10_000_000)

                    create_kwargs: Dict[str, Any] = {}
                    if use_chunks:
                        create_kwargs["chunks"] = True

                    if np.issubdtype(arr.dtype, np.number) or arr.dtype == np.bool_:
                        grp.create_dataset(
                            key,
                            data=arr,
                            fletcher32=True,
                            **create_kwargs,
                            **compression_opts,
                        )
                    else:
                        grp.create_dataset(key, data=arr, **create_kwargs)

                    total_size += arr.nbytes

        grp.attrs["created_at"] = legacy.datetime.now().isoformat()
        grp.attrs["original_size_bytes"] = len(data)

        if self.db_conn is not None:
            self._register(design_uuid, target_id, npz_type, group_path, total_size)

        self._items_written += 1

        if self.flush_interval > 0 and self._items_written % self.flush_interval == 0:
            if self._h5_file is not None:
                self._h5_file.flush()

        return group_path


class HDF5Reader(legacy.HDF5Reader):
    """Drop-in replacement for :class:`gdwh.storage.hdf5_writer.HDF5Reader` with lazy read support."""

    def load_data(
        self,
        design_uuid: str,
        target_id: int,
        data_type: str = "discrete",
        keys: Optional[List[str]] = None,
        slices: Optional[Dict[str, tuple]] = None,
    ) -> Optional[Dict[str, np.ndarray]]:
        """
        Load data for a specific design/target/type.

        Args:
            design_uuid: Design UUID
            target_id: Target ID
            data_type: Type of data ('pk', 'discrete', 'mc')
            keys: If provided, load only these datasets (missing keys are ignored)
            slices: Optional per-key index tuples for partial reads (e.g. {'pk_det': (...)}).

        Returns:
            Dictionary of numpy arrays, or None if group not found.
        """
        h5 = self._ensure_open()
        group_path = f"designs/{design_uuid}/targets/{target_id}/{data_type}"

        if group_path not in h5:
            return None

        grp = h5[group_path]
        keys_to_load = list(keys) if keys is not None else list(grp.keys())

        out: Dict[str, np.ndarray] = {}
        for key in keys_to_load:
            if key not in grp:
                continue
            ds = grp[key]
            if slices and key in slices and slices[key] is not None:
                out[key] = ds[slices[key]]
            else:
                out[key] = ds[()]
        return out

    def get_dataset_info(
        self,
        design_uuid: str,
        target_id: int,
        data_type: str = "discrete",
    ) -> Dict[str, Dict[str, Any]]:
        """Return dataset shape/dtype/size info without loading data."""
        h5 = self._ensure_open()
        group_path = f"designs/{design_uuid}/targets/{target_id}/{data_type}"

        if group_path not in h5:
            return {}

        grp = h5[group_path]
        info: Dict[str, Dict[str, Any]] = {}
        for key in grp.keys():
            obj = grp[key]
            if not isinstance(obj, h5py.Dataset):
                continue
            try:
                size_mb = float(obj.nbytes) / 1e6
            except Exception:
                size_mb = None
            info[key] = {
                "shape": tuple(obj.shape),
                "dtype": str(obj.dtype),
                "size_mb": size_mb,
            }
        return info


def open_reader(h5_path: Path) -> HDF5Reader:
    """Convenience helper mirroring the legacy reader constructor."""
    return HDF5Reader(h5_path)

