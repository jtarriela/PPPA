"""Batched database writer for GWDH optimization results."""

import logging
import duckdb
import numpy as np
from typing import List, Dict, Optional, Set
from pathlib import Path
import time

from .db_schema import DatabaseSchema
from ..utils import compute_bytes_checksum

logger = logging.getLogger(__name__)


class BatchedDBWriter:
    """
    Batched writer for optimization results.

    Accumulates results and writes in batches for efficiency.
    """

    def __init__(self, db_path: Path, campaign_id: str):
        """
        Initialize batched writer.

        Args:
            db_path: Path to DuckDB database
            campaign_id: Campaign identifier
        """
        self.db_path = db_path
        self.campaign_id = campaign_id

        # Ensure schema exists
        DatabaseSchema.create_schema(db_path)

        # Get connection
        self.conn = DatabaseSchema.get_connection(db_path, read_only=False)
        
        # Optimize for bulk loading
        try:
            # Increase WAL limit to avoid frequent checkpoints during run
            self.conn.execute("PRAGMA wal_autocheckpoint='1GB'")
        except Exception:
            pass

        # Batch buffers
        self.evaluation_buffer = []
        self.target_results_buffer = []
        self.zdata_buffer = []
        self._temp_eval_id = -1 

    def write_campaign(
        self,
        name: str,
        config_yaml: str,
        n_variables: int,
        n_objectives: int,
        population_size: int,
    ):
        """Write campaign metadata."""
        self.conn.execute(
            """
            INSERT OR REPLACE INTO campaigns
            (campaign_id, name, config_yaml, n_variables, n_objectives, population_size, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            [
                self.campaign_id,
                name,
                config_yaml,
                n_variables,
                n_objectives,
                population_size,
                "running",
            ],
        )
        self.conn.commit()

    def write_generation(
        self,
        gen_num: int,
        pop_size: int,
        n_feasible: int,
        n_infeasible: int,
        hypervolume: Optional[float] = None,
        pareto_size: Optional[int] = None,
    ) -> int:
        """
        Write generation metadata.

        Returns:
            gen_id: Generated generation ID
        """
        next_id_row = self.conn.execute(
            "SELECT COALESCE(MAX(gen_id), 0) + 1 FROM generations"
        ).fetchone()
        next_id = int(next_id_row[0]) if next_id_row is not None else 1

        self.conn.execute(
            """
            INSERT OR REPLACE INTO generations
            (gen_id, campaign_id, gen_num, pop_size, n_feasible, n_infeasible, hypervolume, pareto_size)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                next_id,
                self.campaign_id,
                gen_num,
                pop_size,
                n_feasible,
                n_infeasible,
                hypervolume,
                pareto_size,
            ],
        )

        self.conn.commit()
        return next_id

    def _map_temp_eval_ids(self) -> Dict[int, int]:
        """
        Resolve buffered temporary eval IDs to real database eval_ids.
        Fallback method used ONLY when pre-allocation fails.
        """
        if not self.evaluation_buffer:
            return {}

        data_to_insert = []
        unique_gen_ids: Set[int] = set()
        
        for row in self.evaluation_buffer:
            data_to_insert.append((
                row["temp_eval_id"],
                row["gen_id"],
                row["design_uuid"]
            ))
            unique_gen_ids.add(row["gen_id"])

        self.conn.execute("CREATE TEMP TABLE IF NOT EXISTS temp_id_map (temp_id INTEGER, gid INTEGER, uuid VARCHAR)")
        self.conn.execute("DELETE FROM temp_id_map")
        self.conn.executemany("INSERT INTO temp_id_map VALUES (?, ?, ?)", data_to_insert)

        gen_id_list = list(unique_gen_ids)
        placeholders = ",".join(["?"] * len(gen_id_list))
        
        query = f"""
            SELECT t.temp_id, e.eval_id
            FROM evaluations e
            JOIN temp_id_map t ON e.gen_id = t.gid AND e.design_uuid = t.uuid
            WHERE e.gen_id IN ({placeholders})
        """
        
        rows = self.conn.execute(query, gen_id_list).fetchall()
        temp_to_real: Dict[int, int] = {r[0]: int(r[1]) for r in rows}
        
        self.conn.execute("DELETE FROM temp_id_map")
        return temp_to_real

    def update_generation(
        self,
        gen_id: int,
        n_feasible: int,
        n_infeasible: int,
        hypervolume: float,
        pareto_size: int,
    ):
        """Update statistics for an existing generation record."""
        self.conn.execute(
            """
            UPDATE generations
            SET n_feasible = ?, n_infeasible = ?, hypervolume = ?, pareto_size = ?
            WHERE gen_id = ?
            """,
            [n_feasible, n_infeasible, hypervolume, pareto_size, gen_id],
        )
        self.conn.commit()

    def register_generation_file(
        self,
        generation: int,
        hdf5_path: str,
        designs_count: int = 0,
        file_size_bytes: int = 0,
    ) -> None:
        """Register per-generation HDF5 file."""
        self.conn.execute(
            """
            INSERT INTO generation_files
                (campaign_id, generation, hdf5_path, designs_count, file_size_bytes)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT (campaign_id, generation)
            DO UPDATE SET hdf5_path = EXCLUDED.hdf5_path,
                          designs_count = EXCLUDED.designs_count,
                          file_size_bytes = EXCLUDED.file_size_bytes
            """,
            [self.campaign_id, generation, hdf5_path, designs_count, file_size_bytes],
        )
        self.conn.commit()

    def add_evaluation(
        self,
        gen_id: int,
        design_uuid: str,
        design_vector: np.ndarray,
        feasible: bool,
        frag_mass_kg: float,
        charge_mass_kg: float,
        total_mass_kg: float,
        violation: Optional[str] = None,
        is_pareto: bool = False,
        pareto_rank: Optional[int] = None,
        eval_time_s: float = 0.0,
    ) -> int:
        """Add evaluation to batch buffer."""
        n_zones = 15
        n_bins = 7
        n_zones_bins = n_zones * n_bins

        frag_sizes = design_vector[:n_zones_bins].tolist()
        frag_quantities = design_vector[n_zones_bins : 2 * n_zones_bins].tolist()
        zone_velocities = design_vector[2 * n_zones_bins :].tolist()

        temp_eval_id = self._temp_eval_id
        self._temp_eval_id -= 1

        self.evaluation_buffer.append(
            {
                "temp_eval_id": temp_eval_id,
                "gen_id": gen_id,
                "design_uuid": design_uuid,
                "feasible": feasible,
                "violation": violation,
                "frag_sizes": frag_sizes,
                "frag_quantities": frag_quantities,
                "zone_velocities": zone_velocities,
                "frag_mass_kg": frag_mass_kg,
                "charge_mass_kg": charge_mass_kg,
                "total_mass_kg": total_mass_kg,
                "is_pareto": is_pareto,
                "pareto_rank": pareto_rank,
                "eval_time_s": eval_time_s,
            }
        )

        return temp_eval_id

    def add_target_result(
        self,
        eval_id: int,
        target_id: int,
        target_name: str,
        ikp: float,
        volume: float,
        pk_npz_uuid: Optional[str] = None,
        discrete_npz_uuid: Optional[str] = None,
    ):
        """Add target result to batch buffer."""
        self.target_results_buffer.append(
            {
                "eval_id": eval_id,
                "target_id": target_id,
                "target_name": target_name,
                "integrated_kill_potential": ikp,
                "volume_at_threshold": volume,
                "pk_npz_uuid": pk_npz_uuid,
                "discrete_npz_uuid": discrete_npz_uuid,
            }
        )

    def add_zdata(self, design_uuid: str, zdata_bytes: bytes):
        """Add ZDATA bytes to batch buffer."""
        checksum = compute_bytes_checksum(zdata_bytes)

        self.zdata_buffer.append(
            {
                "design_uuid": design_uuid,
                "zdata_bytes": zdata_bytes,
                "checksum": checksum,
            }
        )

    def flush(self):
        """Flush using Optimistic Fast Insert (Strict INSERT) with fallback."""
        if not self.evaluation_buffer and not self.zdata_buffer:
            return

        self.conn.execute("BEGIN TRANSACTION")
        
        try:
            eval_id_map: Dict[int, int] = {}

            # ADR-017: Deduplicate evaluations by (gen_id, design_uuid) before insert
            # This is a safety net in case any duplicates slip through the pymoo-level dedup
            if self.evaluation_buffer:
                seen = set()
                deduped = []
                for e in self.evaluation_buffer:
                    key = (e["gen_id"], e["design_uuid"])
                    if key not in seen:
                        seen.add(key)
                        deduped.append(e)

                if len(deduped) < len(self.evaluation_buffer):
                    logger.debug(
                        "Deduplicated %d evaluations before DB insert",
                        len(self.evaluation_buffer) - len(deduped),
                    )
                    self.evaluation_buffer = deduped

            # Write evaluations without specifying eval_id so DuckDB assigns it
            if self.evaluation_buffer:
                self.conn.executemany(
                    """
                    INSERT OR IGNORE INTO evaluations
                    (gen_id, design_uuid, feasible, violation,
                     frag_sizes, frag_quantities, zone_velocities,
                     frag_mass_kg, charge_mass_kg, total_mass_kg,
                     is_pareto, pareto_rank, eval_time_s)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            e["gen_id"],
                            e["design_uuid"],
                            e["feasible"],
                            e["violation"],
                            e["frag_sizes"],
                            e["frag_quantities"],
                            e["zone_velocities"],
                            e["frag_mass_kg"],
                            e["charge_mass_kg"],
                            e["total_mass_kg"],
                            e["is_pareto"],
                            e["pareto_rank"],
                            e["eval_time_s"],
                        )
                        for e in self.evaluation_buffer
                    ],
                )
                eval_id_map = self._map_temp_eval_ids()
                self.evaluation_buffer.clear()

                # 2. Target Results
                if self.target_results_buffer:
                    rows = []
                    for r in self.target_results_buffer:
                        raw_eval_id = r["eval_id"]
                        real_eval_id = raw_eval_id if raw_eval_id >= 0 else eval_id_map.get(raw_eval_id)
                        
                        if real_eval_id is not None:
                            rows.append(
                                (
                                    real_eval_id,
                                    r["target_id"],
                                    r["target_name"],
                                    r["integrated_kill_potential"],
                                    r["volume_at_threshold"],
                                    r["pk_npz_uuid"],
                                    r.get("discrete_npz_uuid"),
                                )
                            )
                    
                    if rows:
                        # Let DB assign ID via sequence
                        self.conn.executemany(
                            """
                            INSERT OR IGNORE INTO target_results
                            (result_id, eval_id, target_id, target_name,
                             integrated_kill_potential, volume_at_threshold, pk_npz_uuid, discrete_npz_uuid)
                            VALUES (nextval('result_id_seq'), ?, ?, ?, ?, ?, ?, ?)
                            """,
                            rows,
                        )
                    self.target_results_buffer.clear()

            # 3. ZDATA
            if self.zdata_buffer:
                self.conn.executemany(
                    """
                    INSERT OR IGNORE INTO zdata_store
                    (design_uuid, zdata_bytes, checksum)
                    VALUES (?, ?, ?)
                    """,
                    [
                        (z["design_uuid"], z["zdata_bytes"], z["checksum"])
                        for z in self.zdata_buffer
                    ],
                )
                self.zdata_buffer.clear()

            self.conn.execute("COMMIT")
        except Exception as e:
            self.conn.execute("ROLLBACK")
            logger.error(f"Fallback flush failed: {e}")
            raise

    def close(self):
        """Close database connection."""
        self.flush()
        self.conn.close()

    def __enter__(self):
        """Context manager enter."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    def __getstate__(self):
        """Exclude DuckDB connection from pickling."""
        state = self.__dict__.copy()
        if 'conn' in state:
            del state['conn']
        return state

    def __setstate__(self, state):
        """Restore state and reconnect to database."""
        self.__dict__.update(state)
        try:
            self.conn = DatabaseSchema.get_connection(self.db_path, read_only=False)
        except Exception:
            self.conn = None
