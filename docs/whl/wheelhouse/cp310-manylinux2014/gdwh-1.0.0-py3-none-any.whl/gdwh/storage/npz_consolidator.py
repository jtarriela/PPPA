"""NPZ file consolidation with UUID-based naming."""

import shutil
from pathlib import Path
from typing import Dict, List
import duckdb

from ..utils import compute_npz_uuid, compute_file_checksum


class NPZConsolidator:
    """
    DEPRECATED: Use HDF5Writer instead.
    Kept for legacy support and migration.
    """
    """def _evaluate(self, X: np.ndarray, out: dict, *args, **kwargs):
      
        n_designs = X.shape[0]
        self.logger.info(f"Evaluating {n_designs} designs")

        # 1. Validation
        validation = self.validator.validate_batch(X)
        feasible_count = validation.count_feasible()
        infeasible_count = validation.count_infeasible()

        self.logger.info(
            f"Feasibility: {feasible_count} feasible, {infeasible_count} infeasible "
            f"({feasible_count/n_designs:.1%})"
        )

        self.n_evaluations += n_designs
        self.n_feasible += feasible_count
        self.n_infeasible += infeasible_count

        # 2. Preparation
        feasible_indices = validation.get_feasible_indices()
        feasible_designs = X[feasible_indices]

        if len(feasible_designs) > 0:
            uuids = [self.zdata_generator.compute_uuid(d) for d in feasible_designs]
            
            # Map UUID to original design vector (Needed for old db_writer schema)
            uuid_to_design = {uuids[i]: feasible_designs[i] for i in range(len(uuids))}
            uuid_to_index = {uuids[i]: int(feasible_indices[i]) for i in range(len(uuids))}

            params_list = [{"design_vector": d} for d in feasible_designs]

            if self._use_parallel:
                # Store ZDATA (without extra args)
                if self.db_writer:
                    try:
                        zdata_dict = self.zdata_batch_generator.generate_parallel(
                            feasible_designs, uuids, n_workers=1
                        )
                        for duuid, zbytes in zdata_dict.items():
                            # FIX 1: Removed extra argument (checksum calculated inside writer)
                            self.db_writer.add_zdata(duuid, zbytes)
                    except Exception as e:
                        self.logger.warning(f"Failed to store ZDATA: {e}")

                eval_results = self.evaluator.evaluate_batch(uuids, params_list)
            else:
                zdata_dict = self.zdata_batch_generator.generate_parallel(
                    feasible_designs, uuids, n_workers=None
                )
                if self.db_writer:
                    for duuid, zbytes in zdata_dict.items():
                        self.db_writer.add_zdata(duuid, zbytes)
                
                eval_results = self.evaluator.evaluate_batch(uuids, zdata_dict)
        else:
            eval_results = {}

        # 3. Persistence
        if self.db_writer and self.npz_consolidator and eval_results:
            try:
                uuid_to_design
            except NameError:
                uuid_to_design = {}
                uuid_to_index = {}

            for duuid, result in eval_results.items():
                consolidated_by_target = {}

                # A. Handle Bytes (MPI)
                if getattr(result, "binary_data", None):
                    for tid, data_map in result.binary_data.items():
                        target_uuids = {}
                        for ntype, data in data_map.items():
                            try:
                                uuid = self.npz_consolidator.add_from_bytes(duuid, tid, ntype, data)
                                target_uuids[ntype] = uuid
                            except Exception as e:
                                self.logger.warning(f"Failed to save bytes for {duuid}: {e}")
                        if target_uuids:
                            consolidated_by_target[tid] = target_uuids

                # B. Handle Files (Local)
                elif getattr(result, "legacy_paths", None):
                    for tid, paths in result.legacy_paths.items():
                        if tid in consolidated_by_target: continue
                        if not isinstance(paths, dict): paths = {"pk": paths}
                        try:
                            uuids_map = self.npz_consolidator.consolidate_design_npz(duuid, tid, paths)
                            consolidated_by_target[tid] = uuids_map
                        except Exception as e:
                            self.logger.warning(f"Failed to consolidate files for {duuid}: {e}")

                # C. DB Write
                if self.current_gen_id is not None:
                    idx = uuid_to_index.get(duuid)
                    design_vector = uuid_to_design.get(duuid) # Required by your writer
                    
                    # Safe fallbacks
                    fm, cm, tm = 0.0, 0.0, 0.0
                    if idx is not None:
                        try:
                            fm = validation.frag_masses[idx]
                            cm = validation.charge_masses[idx]
                            tm = validation.total_masses[idx]
                        except: pass

                    if design_vector is None:
                        # Should not happen for feasible designs
                        design_vector = np.zeros(X.shape[1])

                    try:
                        # FIX 2: Correct arguments for your existing db_writer
                        eval_id = self.db_writer.add_evaluation(
                            gen_id=self.current_gen_id,
                            design_uuid=duuid,
                            design_vector=design_vector, # REQUIRED
                            feasible=True,
                            frag_mass_kg=fm,
                            charge_mass_kg=cm,
                            total_mass_kg=tm,
                            violation=None,
                            is_pareto=False,
                            pareto_rank=None,
                            eval_time_s=getattr(result, "eval_time_s", 0.0)
                            # REMOVED: metadata (your writer doesn't have it)
                        )

                        for tid, uuids_map in consolidated_by_target.items():
                            target_name = str(tid)
                            self.db_writer.add_target_result(
                                eval_id=eval_id,
                                target_id=tid,
                                target_name=target_name,
                                ikp=result.ikp_by_target.get(tid, 0.0),
                                volume=result.volume_by_target.get(tid, 0.0),
                                pk_npz_uuid=uuids_map.get("pk"),
                                discrete_npz_uuid=uuids_map.get("discrete"),
                            )
                    except Exception as e:
                        self.logger.warning(f"Failed to write evaluation for {duuid}: {e}")

            try:
                self.db_writer.flush()
            except Exception as e:
                self.logger.warning(f"DB flush failed: {e}")

        # 4. Objectives
        out["F"] = self._assign_objectives(X, validation, feasible_indices, eval_results)
        
        self.logger.info(
            f"Evaluation complete: {self.n_evaluations} total, "
            f"{self.n_feasible} feasible, {self.n_infeasible} infeasible"
        )
    Consolidate NPZ files with UUID-based naming.

    Moves NPZ files from temporary SABRE output directories to
    consolidated storage with UUID names and tracks in database.
    """

    def __init__(self, consolidated_dir: Path, db_conn: duckdb.DuckDBPyConnection):
        """
        Initialize NPZ consolidator.

        Args:
            consolidated_dir: Target directory for consolidated NPZ files
            db_conn: DuckDB connection for registry
        """
        self.consolidated_dir = Path(consolidated_dir)
        self.db_conn = db_conn

        # Ensure consolidated directory exists
        self.consolidated_dir.mkdir(parents=True, exist_ok=True)

    def add_from_bytes(
        self,
        design_uuid: str,
        target_id: int,
        npz_type: str,
        data: bytes
    ) -> str:
        """
        Write raw NPZ bytes to consolidated storage and register in DB.
        Used for MPI workers that return data in-memory.
        """
        # Compute deterministic UUID
        npz_uuid = compute_npz_uuid(design_uuid, target_id, npz_type)

        # Define destination path
        consolidated_path = self.consolidated_dir / f"{npz_uuid}.npz"

        # Write bytes directly
        with open(consolidated_path, "wb") as f:
            f.write(data)

        # Register in DB
        size_bytes = len(data)
        checksum = compute_file_checksum(consolidated_path)

        self._register_npz(
            npz_uuid=npz_uuid,
            original_path=f"memory://{design_uuid}/{target_id}/{npz_type}",
            consolidated_path=str(consolidated_path.resolve()),
            npz_type=npz_type,
            size_bytes=size_bytes,
            checksum=checksum,
        )

        return npz_uuid

    def consolidate_design_npz(
        self,
        design_uuid: str,
        target_id: int,
        original_npz_paths: Dict[str, Path],
    ) -> Dict[str, str]:
        """Consolidate NPZ files from disk paths."""
        npz_uuids = {}

        for npz_type, original_path in original_npz_paths.items():
            if not original_path.exists():
                continue

            npz_uuid = compute_npz_uuid(design_uuid, target_id, npz_type)
            consolidated_path = self.consolidated_dir / f"{npz_uuid}.npz"

            try:
                shutil.move(str(original_path), str(consolidated_path))
            except OSError:
                shutil.copy2(str(original_path), str(consolidated_path))
                original_path.unlink()

            checksum = compute_file_checksum(consolidated_path)
            size_bytes = consolidated_path.stat().st_size

            self._register_npz(
                npz_uuid=npz_uuid,
                original_path=str(original_path),
                consolidated_path=str(consolidated_path.resolve()),
                npz_type=npz_type,
                size_bytes=size_bytes,
                checksum=checksum,
            )

            npz_uuids[npz_type] = npz_uuid

        return npz_uuids

    def _register_npz(self, npz_uuid, original_path, consolidated_path, npz_type, size_bytes, checksum):
        """Register NPZ file in database."""
        self.db_conn.execute(
            """
            INSERT OR IGNORE INTO npz_registry
            (npz_uuid, original_path, consolidated_path, npz_type, size_bytes, checksum)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [npz_uuid, original_path, consolidated_path, npz_type, size_bytes, checksum],
        )