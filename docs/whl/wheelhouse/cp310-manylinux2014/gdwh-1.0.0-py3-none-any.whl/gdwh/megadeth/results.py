"""MEGADETH result extraction and processing."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from pathlib import Path
import os

try:
    from megadeth.ga import GaResult, TargetResult
    MEGADETH_AVAILABLE = True
except ImportError:
    MEGADETH_AVAILABLE = False
    GaResult = object
    TargetResult = object


@dataclass
class EvalResult:
    """Evaluation result for a single design."""

    design_uuid: str
    ikp_by_target: Dict[int, float]  # target_id -> IKP
    volume_by_target: Dict[int, float]  # target_id -> volume
    
    # Original paths (useful for debugging or local runs)
    legacy_paths: Dict[int, Dict[str, Path]]  # target_id -> {type: path}
    
    # NEW: Binary data content (critical for MPI + /dev/shm)
    # target_id -> {type: bytes}
    binary_data: Dict[int, Dict[str, bytes]] = field(default_factory=dict)
    
    # NEW: HDF5 paths if saved by coordinator (target_id -> {type: hdf5_path})
    saved_paths: Dict[int, Dict[str, str]] = field(default_factory=dict)

    eval_time_s: float = 0.0

    # Global objectives (masses) - computed by validation, passed through for Pareto
    total_mass_kg: Optional[float] = None
    fragment_mass_kg: Optional[float] = None
    charge_mass_kg: Optional[float] = None


@dataclass
class LightweightResult:
    """
    Lightweight result for Phase 1 of two-phase gather.
    
    Contains only objective values and metadata needed for Pareto determination.
    No heavy binary_data - that's fetched selectively in Phase 2.
    """
    uuid: str
    ikp_by_target: Dict[int, float]      # target_id -> IKP
    volume_by_target: Dict[int, float]   # target_id -> volume
    source_rank: int                      # Which MPI rank has the binary data
    compressed_size: int                  # Estimated compressed size for memory planning
    eval_time_s: float = 0.0
    
    # Global objectives
    total_mass_kg: Optional[float] = None
    fragment_mass_kg: Optional[float] = None
    charge_mass_kg: Optional[float] = None
    
    @classmethod
    def from_eval_result(cls, result: EvalResult, source_rank: int, compressed_size: int) -> "LightweightResult":
        """Create from a full EvalResult."""
        return cls(
            uuid=result.design_uuid,
            ikp_by_target=result.ikp_by_target.copy(),
            volume_by_target=result.volume_by_target.copy(),
            source_rank=source_rank,
            compressed_size=compressed_size,
            eval_time_s=result.eval_time_s,
            total_mass_kg=result.total_mass_kg,
            fragment_mass_kg=result.fragment_mass_kg,
            charge_mass_kg=result.charge_mass_kg,
        )



class ResultExtractor:
    """Extract objectives from MEGADETH GaResult."""

    @staticmethod
    def extract(
        design_uuid: str,
        ga_result: GaResult,
        eval_time_s: float = 0.0,
        include_data_types: Optional[List[str]] = None,
        extra_objectives: Optional[Dict[str, float]] = None,
    ) -> EvalResult:
        """
        Extract evaluation result from MEGADETH GaResult.

        Reads generated NPZ files into memory to support distributed execution
        where workers use local scratch (/dev/shm) that the master cannot access.

        Args:
            design_uuid: Unique identifier for this design
            ga_result: MEGADETH GaResult object with target results
            eval_time_s: Time taken for evaluation
            include_data_types: Filter which data types to include in binary_data.
                               If None, includes all types ['pk', 'discrete', 'mc'].
                               For GA runs, typically ['discrete'] to skip heavy pk hypercube.
            extra_objectives: Optional dictionary of pre-computed objectives (e.g. masses)

        Returns:
            EvalResult with objectives and filtered binary data
        """
        ikp_by_target = {}
        volume_by_target = {}
        legacy_paths = {}
        binary_data = {}

        for target_result in ga_result.targets:
            target_id = target_result.target_id

            # Extract Objectives
            ikp_by_target[target_id] = target_result.integrated_kill_potential or 0.0
            volume_by_target[target_id] = target_result.volume_at_threshold or 0.0

            # Extract NPZ Paths & Data
            target_legacy_paths = {}
            target_binary_data = {}

            if getattr(target_result, "npz_paths", None):
                for key in ["pk", "discrete", "mc"]:
                    if key in target_result.npz_paths and target_result.npz_paths[key]:
                        path = Path(target_result.npz_paths[key])
                        target_legacy_paths[key] = path

                        # --- FILTER: Skip data types not in include list ---
                        if include_data_types is not None and key not in include_data_types:
                            # Still delete the file to free scratch space
                            if path.exists():
                                try:
                                    os.unlink(path)
                                except OSError:
                                    pass
                            continue

                        # --- READ INTO MEMORY ---
                        if path.exists():
                            try:
                                with open(path, "rb") as f:
                                    target_binary_data[key] = f.read()

                                # Delete temp file immediately to save RAM disk space
                                try:
                                    os.unlink(path)
                                except OSError:
                                    pass
                            except Exception as e:
                                print(f"Error reading result file {path}: {e}")

            if target_legacy_paths:
                legacy_paths[target_id] = target_legacy_paths

            if target_binary_data:
                binary_data[target_id] = target_binary_data

        # Extract extra objectives
        tm, fm, cm = None, None, None
        if extra_objectives:
            tm = extra_objectives.get("total_mass_kg")
            fm = extra_objectives.get("fragment_mass_kg")
            cm = extra_objectives.get("charge_mass_kg")

        return EvalResult(
            design_uuid=design_uuid,
            ikp_by_target=ikp_by_target,
            volume_by_target=volume_by_target,
            legacy_paths=legacy_paths,
            binary_data=binary_data,  # Contains the bytes to send over MPI
            eval_time_s=eval_time_s,
            total_mass_kg=tm,
            fragment_mass_kg=fm,
            charge_mass_kg=cm,
        )

    @staticmethod
    def extract_batch(results: Dict[str, GaResult]) -> Dict[str, EvalResult]:
        """Extract results for a batch of evaluations."""
        extracted = {}
        for uuid, ga_result in results.items():
            extracted[uuid] = ResultExtractor.extract(uuid, ga_result)
        return extracted
