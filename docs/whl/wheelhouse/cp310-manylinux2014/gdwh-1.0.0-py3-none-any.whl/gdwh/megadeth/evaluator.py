"""MEGADETH evaluator wrapper for GA integration."""

import time
from typing import Dict
from pathlib import Path

try:
    from megadeth.ga import run_ga_design, GaStaticContext, DesignVector
    MEGADETH_AVAILABLE = True
except ImportError:
    MEGADETH_AVAILABLE = False
    run_ga_design = None
    GaStaticContext = object
    DesignVector = object

from ..config import CampaignConfig
from ..utils import setup_logger
from .results import ResultExtractor, EvalResult


class MEGADETHEvaluator:
    """
    MEGADETH evaluator wrapper for GA integration.

    Handles calls to MEGADETH's run_ga_design() API with bytes-based inputs.
    """

    def __init__(
        self,
        config: CampaignConfig,
        static_context: GaStaticContext,
    ):
        """
        Initialize MEGADETH evaluator.

        Args:
            config: Campaign configuration
            static_context: MEGADETH GaStaticContext with bytes-based inputs
        """
        if not MEGADETH_AVAILABLE:
            raise ImportError(
                "MEGADETH library not available. Install with: pip install -e /path/to/megadeth"
            )

        self.config = config
        self.static_context = static_context
        self.pk_threshold = config.megadeth.pk_threshold
        self.run_mc = config.megadeth.run_mc

        self.logger = setup_logger(
            "gdwh.megadeth.evaluator",
            level=config.logging.level,
            console=config.logging.console,
        )
        self.logger.info("Initialized MEGADETH evaluator")

        # Statistics
        self.n_evaluations = 0
        self.total_eval_time_s = 0.0

    def evaluate_single(self, design_uuid: str, zdata_bytes: bytes) -> EvalResult:
        """
        Evaluate a single design via MEGADETH.

        Args:
            design_uuid: Design UUID
            zdata_bytes: ZDATA file content as bytes

        Returns:
            EvalResult with objectives and NPZ paths
        """
        start_time = time.time()

        # Create DesignVector with bytes
        design_vector = DesignVector(
            zdata_number=self.config.warhead.zdata_number,
            zdata_bytes=zdata_bytes,
        )

        # Call MEGADETH API
        try:
            ga_result = run_ga_design(
                design=design_vector,
                static=self.static_context,
                pk_threshold=self.pk_threshold,
                run_mc=self.run_mc,
            )
        except Exception as e:
            self.logger.error(f"MEGADETH evaluation failed for {design_uuid}: {e}")
            raise

        eval_time = time.time() - start_time

        # Update statistics
        self.n_evaluations += 1
        self.total_eval_time_s += eval_time

        # Extract results
        result = ResultExtractor.extract(design_uuid, ga_result, eval_time)

        return result

    def evaluate_batch(
        self,
        uuids: list,
        zdata_dict: Dict[str, bytes],
    ) -> Dict[str, EvalResult]:
        """
        Evaluate a batch of designs via MEGADETH.

        Note: This is a sequential implementation. For parallel evaluation,
        use MPI coordinator or local pool evaluator.

        Args:
            uuids: List of design UUIDs
            zdata_dict: Dict mapping UUID -> ZDATA bytes

        Returns:
            Dict mapping UUID -> EvalResult
        """
        results = {}

        self.logger.info(f"Evaluating batch of {len(uuids)} designs")

        for uuid in uuids:
            if uuid not in zdata_dict:
                self.logger.warning(f"Missing ZDATA for design {uuid}")
                continue

            try:
                result = self.evaluate_single(uuid, zdata_dict[uuid])
                results[uuid] = result
            except Exception as e:
                self.logger.error(f"Failed to evaluate {uuid}: {e}")
                continue

        avg_time = self.total_eval_time_s / max(self.n_evaluations, 1)
        self.logger.info(
            f"Batch evaluation complete: {len(results)}/{len(uuids)} successful, "
            f"avg time: {avg_time:.1f}s"
        )

        return results

    def get_statistics(self) -> dict:
        """Get evaluator statistics."""
        avg_time = self.total_eval_time_s / max(self.n_evaluations, 1)

        return {
            "n_evaluations": self.n_evaluations,
            "total_eval_time_s": self.total_eval_time_s,
            "avg_eval_time_s": avg_time,
        }
