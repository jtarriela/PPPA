"""Pymoo problem definition for GWDH optimization."""

import numpy as np
from typing import Dict, List, Optional, Union, Any
from pathlib import Path
from pymoo.core.problem import Problem

from ..config import CampaignConfig, InputBytesCache
from ..validation import ParallelValidator, ValidationBatch
from ..zdata import ZDATAGenerator, ZDATABatchGenerator
from ..zdata.batch import ZDATAGeneratorConfig
from ..parallel import LocalPoolEvaluator, get_mpi_evaluator_or_local
from ..parallel.resources import detect_resources
from ..utils import setup_logger


class GWDHProblem(Problem):
    """Pymoo problem definition for warhead optimization."""

    def __init__(
        self,
        config: CampaignConfig,
        input_cache: InputBytesCache,
        static_context,
        evaluator=None,
        use_parallel_evaluator: bool = True,
        db_writer: Optional["BatchedDBWriter"] = None,
        h5_writer: Optional["HDF5Writer"] = None,
        # ADR-009: Per-generation storage context
        output_dir: Optional[Path] = None,
        campaign_id: Optional[str] = None,
    ):
        self.config = config
        self.input_cache = input_cache
        self.static_context = static_context
        self.logger = setup_logger(
            "gdwh.ga.problem",
            level=config.logging.level,
            console=config.logging.console,
        )

        n_var = config.count_variables()
        n_obj = config.count_objectives()
        n_constr = 0

        self.validator = ParallelValidator(config.warhead, config.variables)
        self.zdata_generator = ZDATAGenerator(config.warhead, config.variables)
        self.zdata_batch_generator = ZDATABatchGenerator(
            self.zdata_generator,
            chunk_size=config.parallel.zdata_generation.chunk_size,
        )
        self.zdata_generator_config = ZDATAGeneratorConfig.from_generator(self.zdata_generator)

        # Detect local resources for master node ops
        self.master_resources = detect_resources()
        self.master_cores = self.master_resources.physical_cores

        if use_parallel_evaluator and static_context is not None:
            cores_per_node = config.parallel.mpi.cores_per_node
            designs_per_core = config.parallel.mpi.designs_per_core
            
            if config.parallel.mode != "mpi":
                self.logger.info(
                    f"Resource detection: Found {self.master_resources.cpu_count} logical CPUs, "
                    f"{self.master_cores} physical cores."
                )
                cores_per_node = self.master_cores
            
            self.logger.info(f"Initializing parallel evaluator with {cores_per_node} workers per node")

            # Extract global objectives configuration
            global_objectives_config = {
                'total_mass': config.objectives.total_mass.enabled,
                'fragment_mass': config.objectives.fragment_mass.enabled,
                'explosive_mass': config.objectives.explosive_mass.enabled,
            }

            self.evaluator = get_mpi_evaluator_or_local(
                static_context=static_context,
                pk_threshold=config.megadeth.pk_threshold,
                run_mc=config.megadeth.run_mc,
                zdata_number=config.warhead.zdata_number,
                zdata_generator_config=self.zdata_generator_config,
                cores_per_node=cores_per_node,
                designs_per_core=designs_per_core,
                prefer_mpi=(config.parallel.mode == "mpi"),
                log_file=config.logging.file,
                log_level=config.logging.level,
                # ADR-006: Filter data types at worker BEFORE MPI send
                # Default ['discrete'] skips pk hypercube, reducing network by ~99%
                include_data_types=config.storage.hdf5.ga_data_types,
                global_objectives_config=global_objectives_config,
            )
            self._use_parallel = True
        elif evaluator is not None:
            self.evaluator = evaluator
            self._use_parallel = False
        else:
            self.evaluator = None
            self._use_parallel = False

        xl, xu = self._compute_variable_bounds()

        super().__init__(n_var=n_var, n_obj=n_obj, n_constr=n_constr, xl=xl, xu=xu)

        self.n_evaluations = 0
        self.n_feasible = 0
        self.n_infeasible = 0
        self.db_writer = db_writer
        self.h5_writer = h5_writer
        self.current_gen_id: Optional[int] = None
        self.current_gen_num: int = 1  # ADR-009: Track generation number for file naming
        self.output_dir = output_dir
        self.campaign_id = campaign_id

        # Context storage for callbacks
        self._batch_context: Dict[str, Any] = {}

    def _compute_variable_bounds(self) -> tuple:
        n_zones = self.config.warhead.n_zones
        bin_edges = self.config.variables.fragment_sizes.bin_edges_grams
        n_bins = len(bin_edges) - 1

        xl = []
        xu = []

        for _ in range(n_zones):
            for i in range(n_bins):
                xl.append(bin_edges[i])
                xu.append(bin_edges[i + 1])

        min_qty = self.config.variables.fragment_quantities.min_per_bin
        max_qty = self.config.variables.fragment_quantities.max_per_bin
        for _ in range(n_zones * n_bins):
            xl.append(min_qty)
            xu.append(max_qty)

        vel_bounds = self.config.variables.zone_velocities.bounds_mps
        strategy = self.config.variables.zone_velocities.strategy
        n_vel_vars = n_zones + 1 if strategy == "nodal" else n_zones

        for _ in range(n_vel_vars):
            xl.append(vel_bounds[0])
            xu.append(vel_bounds[1])

        return np.array(xl), np.array(xu)

    def _persist_results_callback(self, results: Dict[str, Any]):
        """
        Callback to persist evaluation results immediately.
        
        This moves heavy I/O (DB writes, NPZ consolidation) out of the main evaluation
        loop logic and into a handler that can be called iteratively by the MPI evaluator.
        This prevents the root node from accumulating gigabytes of binary data.
        """
        import time
        callback_start = time.time()
        
        if not self.db_writer or not results:
            return

        # Retrieve context set in _evaluate
        uuid_to_design = self._batch_context.get("uuid_to_design", {})
        uuid_to_index = self._batch_context.get("uuid_to_index", {})
        validation = self._batch_context.get("validation", None)
        
        loop_start = time.time()

        for duuid, result in results.items():
            consolidated_by_target = {}

            # A. Handle HDF5 Paths (Already saved by Coordinator)
            if getattr(result, "saved_paths", None):
                consolidated_by_target = result.saved_paths

            # B. Handle Bytes (Local Return or Coordinator Fallback)
            elif getattr(result, "binary_data", None) and self.h5_writer:
                for tid, data_map in result.binary_data.items():
                    target_uuids = {}
                    for ntype, data in data_map.items():
                        try:
                            # Save binary blob to HDF5
                            h5_path = self.h5_writer.add_from_bytes(duuid, tid, ntype, data)
                            target_uuids[ntype] = h5_path
                        except Exception as e:
                            self.logger.warning(f"Failed to save bytes for {duuid}: {e}")
                    if target_uuids:
                        consolidated_by_target[tid] = target_uuids

            # B. Handle Files (Local Return) - NOT SUPPORTED for HDF5 yet
            elif result.legacy_paths and self.h5_writer:
                self.logger.warning("File-based return not supported with HDF5 writer yet")

            # C. DB Write
            if self.current_gen_id is not None:
                idx = uuid_to_index.get(duuid)
                design_vector = uuid_to_design.get(duuid)
                
                fm, cm, tm = 0.0, 0.0, 0.0
                if idx is not None and validation:
                    try:
                        fm = validation.frag_masses[idx]
                        cm = validation.charge_masses[idx]
                        tm = validation.total_masses[idx]
                    except: pass

                # Fallback if design vector missing (rare)
                if design_vector is None:
                    # Try to reconstruct or just use zeros/placeholder if critical
                    design_vector = [] 

                try:
                    eval_id = self.db_writer.add_evaluation(
                        gen_id=self.current_gen_id,
                        design_uuid=duuid,
                        design_vector=design_vector,
                        feasible=True,
                        frag_mass_kg=fm,
                        charge_mass_kg=cm,
                        total_mass_kg=tm,
                        violation=None,
                        is_pareto=False,
                        pareto_rank=None,
                        eval_time_s=getattr(result, "eval_time_s", 0.0)
                    )

                    for tid, uuids_map in consolidated_by_target.items():
                        target_name = str(tid)
                        self.db_writer.add_target_result(
                            eval_id=eval_id,
                            target_id=tid,
                            target_name=target_name,
                            ikp=result.ikp_by_target.get(tid, 0.0),
                            volume=result.volume_by_target.get(tid, 0.0),
                            pk_npz_uuid=uuids_map.get("pk"),
                            discrete_npz_uuid=uuids_map.get("discrete"),
                            # NOTE: DB schema might need update if we want to store HDF5 paths properly
                            # For now we store the path in the UUID column which is VARCHAR
                        )
                except Exception as e:
                    self.logger.warning(f"Failed to write evaluation for {duuid}: {e}")
        
        loop_time = time.time() - loop_start
        self.logger.info(f"Callback loop processed {len(results)} results in {loop_time:.2f}s")

        # Flush after every batch to keep DB WAL size manageable
        flush_start = time.time()
        try:
            self.db_writer.flush()
            flush_time = time.time() - flush_start
            self.logger.info(f"DB flush completed in {flush_time:.2f}s")
        except Exception as e:
            self.logger.warning(f"DB flush failed: {e}")
        
        total_time = time.time() - callback_start
        self.logger.info(f"Total callback time: {total_time:.2f}s (loop: {loop_time:.2f}s, flush: {flush_time if 'flush_time' in locals() else 0:.2f}s)")

    def _evaluate(self, X: np.ndarray, out: dict, *args, **kwargs):
        """Evaluate design population."""
        n_designs = X.shape[0]
        self.logger.info(f"Evaluating {n_designs} designs")

        # 1. Validation
        validation = self.validator.validate_batch(X)
        feasible_count = validation.count_feasible()
        infeasible_count = validation.count_infeasible()

        self.logger.info(
            f"Feasibility: {feasible_count} feasible, {infeasible_count} infeasible "
            f"({feasible_count/n_designs:.1%})"
        )

        self.n_evaluations += n_designs
        self.n_feasible += feasible_count
        self.n_infeasible += infeasible_count

        # 2. Preparation
        feasible_indices = validation.get_feasible_indices()
        feasible_designs = X[feasible_indices]
        
        eval_results = {}

        if len(feasible_designs) > 0:
            # Deduplicate feasible designs by UUID to avoid redundant evaluation and DB writes.
            # Pymoo enables duplicate elimination by default, but duplicates can still appear due to
            # clipping/rounding, custom sampling, or resume/initialization edge cases.
            uuids_all = [self.zdata_generator.compute_uuid(d) for d in feasible_designs]
            seen_uuids = set()
            unique_local_indices = []
            uuids = []
            duplicate_count = 0
            for local_idx, duuid in enumerate(uuids_all):
                if duuid in seen_uuids:
                    duplicate_count += 1
                    continue
                seen_uuids.add(duuid)
                unique_local_indices.append(local_idx)
                uuids.append(duuid)

            if duplicate_count > 0:
                self.logger.info(
                    f"Deduplicated {duplicate_count} duplicate feasible designs "
                    f"(unique={len(uuids)}/{len(uuids_all)})"
                )

            feasible_designs_unique = feasible_designs[unique_local_indices]
            feasible_indices_unique = feasible_indices[unique_local_indices]
            
            # Store context for the callback to access
            self._batch_context = {
                "uuid_to_design": {uuids[i]: feasible_designs_unique[i] for i in range(len(uuids))},
                "uuid_to_index": {uuids[i]: int(feasible_indices_unique[i]) for i in range(len(uuids))},
                "validation": validation
            }

            params_list = []
            for i, d in enumerate(feasible_designs_unique):
                params_list.append({
                    "design_vector": d,
                    "extra_objectives": {
                        "total_mass_kg": validation.total_masses[int(feasible_indices_unique[i])] if self.config.objectives.total_mass.enabled else None,
                        "fragment_mass_kg": validation.frag_masses[int(feasible_indices_unique[i])] if self.config.objectives.fragment_mass.enabled else None,
                        "charge_mass_kg": validation.charge_masses[int(feasible_indices_unique[i])] if self.config.objectives.explosive_mass.enabled else None,
                    }
                })

            # OPTIMIZED: Parallelize ZDATA generation for DB on Master node
            if self.db_writer and self.config.storage.zdata.store_bytes:
                try:
                    # Use available cores on master node instead of serial
                    n_workers_db = self.master_cores if self.master_cores > 1 else None
                    zdata_dict = self.zdata_batch_generator.generate_parallel(
                        feasible_designs_unique, uuids, n_workers=n_workers_db
                    )
                    for duuid, zbytes in zdata_dict.items():
                        self.db_writer.add_zdata(duuid, zbytes)
                except Exception as e:
                    self.logger.warning(f"Failed to store ZDATA: {e}")

            # 3. Evaluation & Persistence
            if self._use_parallel and hasattr(self.evaluator, 'evaluate_generation'):
                # MPI Mode: Use callback to offload data incrementally
                # This prevents OOM on the root node by discarding binary data after the callback returns
                eval_results = self.evaluator.evaluate_generation(
                    uuids, 
                    params_list, 
                    h5_writer=None, # ADR-009: Managed internally by evaluator per-generation
                    results_callback=self._persist_results_callback,
                    generation=self.current_gen_num,
                    output_dir=self.output_dir,
                    campaign_id=self.campaign_id,
                )
            else:
                # Local/Legacy Mode: Standard execution
                # Note: For local mode we might just pass ZDATA dict if needed, 
                # but params_list is generally safer for the unified API.
                try:
                    # Attempt params_list first (Unified API)
                    eval_results = self.evaluator.evaluate_batch(uuids, params_list)
                except (TypeError, ValueError):
                    # Fallback to ZDATA dict for legacy local evaluators
                    zdata_dict = self.zdata_batch_generator.generate_parallel(
                        feasible_designs, uuids, n_workers=None
                    )
                    eval_results = self.evaluator.evaluate_batch(uuids, zdata_dict)
                
                # Manually trigger persistence since local mode doesn't iterate batches with callback
                self._persist_results_callback(eval_results)

            # Clear context to free memory
            self._batch_context = {}

        # 4. Objectives
        # Note: eval_results from MPI mode will now be "lightweight" (stripped of binaries)
        # but still contain the objective values needed here.
        out["F"] = self._assign_objectives(X, validation, feasible_indices, eval_results)
        
        self.logger.info(
            f"Evaluation complete: {self.n_evaluations} total, "
            f"{self.n_feasible} feasible, {self.n_infeasible} infeasible"
        )

    def _assign_objectives(self, X, validation, feasible_indices, eval_results):
        n_designs = X.shape[0]
        n_obj = self.n_obj
        objectives = np.full((n_designs, n_obj), 1e6)

        for i, idx in enumerate(feasible_indices):
            uuid = self.zdata_generator.compute_uuid(X[idx])
            # Check if we have results (lightweight or full)
            if uuid not in eval_results: continue
            
            result = eval_results[uuid]
            obj_idx = 0

            if self.config.objectives.integrated_kill_potential.enabled:
                if self.config.objectives.integrated_kill_potential.per_target:
                    for target_id in sorted(result.ikp_by_target.keys()):
                        objectives[idx, obj_idx] = -result.ikp_by_target[target_id]
                        obj_idx += 1
                else:
                    ikp_total = sum(result.ikp_by_target.values())
                    objectives[idx, obj_idx] = -ikp_total
                    obj_idx += 1

            if self.config.objectives.volume_at_threshold.enabled:
                if self.config.objectives.volume_at_threshold.per_target:
                    for target_id in sorted(result.volume_by_target.keys()):
                        objectives[idx, obj_idx] = -result.volume_by_target[target_id]
                        obj_idx += 1
                else:
                    volume_total = sum(result.volume_by_target.values())
                    objectives[idx, obj_idx] = -volume_total
                    obj_idx += 1

            if self.config.objectives.total_mass.enabled:
                objectives[idx, obj_idx] = validation.total_masses[idx]
                obj_idx += 1
            if self.config.objectives.fragment_mass.enabled:
                objectives[idx, obj_idx] = validation.frag_masses[idx]
                obj_idx += 1
            if self.config.objectives.explosive_mass.enabled:
                objectives[idx, obj_idx] = validation.charge_masses[idx]
                obj_idx += 1

        return objectives

    def get_statistics(self) -> dict:
        stats = {
            "n_evaluations": self.n_evaluations,
            "n_feasible": self.n_feasible,
            "n_infeasible": self.n_infeasible,
            "feasibility_rate": self.n_feasible / max(self.n_evaluations, 1),
            "using_parallel_evaluator": self._use_parallel,
        }
        if hasattr(self.evaluator, "get_statistics"):
            stats["evaluator"] = self.evaluator.get_statistics()
        return stats
