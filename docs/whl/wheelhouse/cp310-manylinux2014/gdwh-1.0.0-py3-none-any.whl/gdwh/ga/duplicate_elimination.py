"""UUID-based duplicate elimination for pymoo.

ADR-017: Implements UUID-based duplicate elimination to prevent near-duplicate
designs from consuming population slots and causing database constraint violations.
"""

from pymoo.core.duplicate import ElementwiseDuplicateElimination

from ..utils.hashing import compute_design_uuid


class UUIDDuplicateElimination(ElementwiseDuplicateElimination):
    """
    Eliminate duplicates based on design UUID hash.

    This catches near-duplicates that differ only in floating-point precision
    but hash to the same UUID. Unlike exact vector comparison, this:

    1. Catches designs that round to the same bytes
    2. Prevents wasted population slots
    3. Avoids DB constraint violations

    The check is performed BEFORE evaluation, saving compute time.

    Example:
        algorithm = NSGA3(
            ...,
            eliminate_duplicates=UUIDDuplicateElimination(),
        )
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._uuid_cache = {}

    def _get_uuid(self, x):
        """Get UUID for design, with caching."""
        # Use tuple of array bytes for cache key (hashable)
        key = x.tobytes()
        if key not in self._uuid_cache:
            self._uuid_cache[key] = compute_design_uuid(x)
        return self._uuid_cache[key]

    def is_equal(self, a, b):
        """Check if two individuals have the same UUID."""
        return self._get_uuid(a.X) == self._get_uuid(b.X)

    def _do(self, pop, *args, **kwargs):
        """Override to clear cache after each call."""
        result = super()._do(pop, *args, **kwargs)
        self._uuid_cache.clear()  # Prevent memory leak
        return result
