"""Main GA optimizer for GWDH campaigns."""

import numpy as np
import math
import pickle
import time
import yaml
import shutil
from pathlib import Path
from typing import Optional, Callable, Dict, Any
from dataclasses import dataclass, asdict
from pymoo.algorithms.moo.nsga2 import NSGA2, RankAndCrowdingSurvival
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.termination import get_termination
from pymoo.optimize import minimize
from pymoo.core.callback import Callback

from ..config import CampaignConfig, InputBytesCache, StaticContextBuilder
from ..storage import DatabaseSchema, BatchedDBWriter, HDF5Writer
from ..utils import setup_logger, ProgressLogger, compute_hv_for_population
from ..utils.cleanup import cleanup_shm
from ..parallel.resources import detect_resources
from .problem import GWDHProblem
from .duplicate_elimination import UUIDDuplicateElimination
from ..optimization.pareto import JensenNDS

# MEGADETH Accelerator detection
try:
    from megadeth.analysis import CPP_ACCELERATOR_AVAILABLE
    from megadeth.analysis._accelerator import get_info as get_accelerator_info
except ImportError:
    CPP_ACCELERATOR_AVAILABLE = False
    get_accelerator_info = lambda: {"available": False, "version": "N/A", "has_openmp": False}


@dataclass
class CheckpointData:
    """Data structure for checkpoint save/restore."""

    generation: int
    population_X: np.ndarray
    population_F: np.ndarray
    algorithm_state: dict
    problem_stats: dict
    campaign_id: str
    elapsed_time_s: float

    def save(self, path: Path):
        """Save checkpoint to file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(asdict(self), f)

    @classmethod
    def load(cls, path: Path) -> "CheckpointData":
        """Load checkpoint from file."""
        with open(path, "rb") as f:
            data = pickle.load(f)
        return cls(**data)


class CheckpointCallback(Callback):
    """Pymoo callback for periodic checkpoint saving."""

    def __init__(
        self,
        optimizer: "GWDHOptimizer",
        every_n_gens: int = 10,
        checkpoint_dir: Optional[Path] = None,
    ):
        """
        Initialize checkpoint callback.

        Args:
            optimizer: Parent optimizer instance
            every_n_gens: Save checkpoint every N generations
            checkpoint_dir: Directory for checkpoints
        """
        super().__init__()
        self.optimizer = optimizer
        self.every_n_gens = every_n_gens
        self.checkpoint_dir = checkpoint_dir or Path("output/checkpoints")
        self.start_time = time.time()

    def notify(self, algorithm):
        """Called after each generation."""
        gen = algorithm.n_gen

        # Save checkpoint at specified intervals
        if self.optimizer.config.storage.checkpoints.enabled:
            if gen % self.every_n_gens == 0 or gen == 1:
                self._save_checkpoint(algorithm, gen)

        # Log progress
        if hasattr(self.optimizer, "progress_logger"):
            self.optimizer.progress_logger.log_generation(
                gen,
                pop_size=len(algorithm.pop),
                n_feasible=getattr(self.optimizer.problem, "n_feasible", 0),
                n_evaluated=getattr(self.optimizer.problem, "n_evaluations", None),
            )

        # ADR-009: Register per-generation HDF5 file
        if self.optimizer.db_writer and hasattr(self.optimizer.problem, 'evaluator'):
            try:
                evaluator = self.optimizer.problem.evaluator
                if hasattr(evaluator, '_last_gen_h5_path') and evaluator._last_gen_h5_path:
                    h5_path = evaluator._last_gen_h5_path
                    designs_count = len(algorithm.pop) if hasattr(algorithm, 'pop') else 0
                    
                    self.optimizer.db_writer.register_generation_file(
                        generation=gen,
                        hdf5_path=str(h5_path),
                        designs_count=designs_count,
                    )
                    # Clear it
                    evaluator._last_gen_h5_path = None
            except Exception:
                 self.optimizer.logger.warning("Failed to register generation file", exc_info=True)

        # Update generation stats in DB and create next generation record
        try:
            if self.optimizer.db_writer is not None and self.optimizer.problem is not None:
                # Determine completed generation id (the one problem is writing into)
                completed_gen_id = getattr(self.optimizer.problem, "current_gen_id", None)

                # Compute per-generation feasible/infeasible counts by delta from last checkpoint
                last_feasible = getattr(self.optimizer, "_last_cum_feasible", 0)
                last_infeasible = getattr(self.optimizer, "_last_cum_infeasible", 0)
                cur_feasible = getattr(self.optimizer.problem, "n_feasible", 0)
                cur_infeasible = getattr(self.optimizer.problem, "n_infeasible", 0)

                # FIXED: Cast to native int to avoid DuckDB numpy errors
                n_feasible_gen = int(cur_feasible - last_feasible)
                n_infeasible_gen = int(cur_infeasible - last_infeasible)

                # Pareto/hypervolume metrics (ADR-010)
                # Extract actual Pareto front size (rank 0) from pymoo's NDS results
                pareto_size = 0
                pareto_X_current = None
                if hasattr(algorithm, "pop") and algorithm.pop is not None:
                    rank = algorithm.pop.get("rank")
                    if rank is not None:
                        # Rank 0 = non-dominated (Pareto optimal)
                        pareto_mask = (rank == 0)
                        pareto_size = int(np.sum(pareto_mask))
                        pareto_X_current = algorithm.pop[pareto_mask].get("X")
                    else:
                        # Fallback: population size
                        pareto_size = int(len(algorithm.pop))
                
                hypervolume = compute_hv_for_population(algorithm)
                
                # Live Pareto update: Mark current rank-0 designs in DB
                if pareto_X_current is not None:
                    try:
                        self.optimizer._update_pareto_flags_in_db(pareto_X_current)
                    except Exception:
                        self.optimizer.logger.warning("Failed to perform live Pareto update", exc_info=True)

                if completed_gen_id is not None:
                    try:
                        self.optimizer.db_writer.update_generation(
                            completed_gen_id,
                            n_feasible_gen,
                            n_infeasible_gen,
                            hypervolume,
                            pareto_size,
                        )
                    except Exception:
                        self.optimizer.logger.warning("Failed to update generation stats in DB", exc_info=True)

                # Create next generation record
                try:
                    next_gen_num = gen + 1
                    next_gen_id = self.optimizer.db_writer.write_generation(
                        next_gen_num, pop_size=int(len(algorithm.pop)), n_feasible=0, n_infeasible=0
                    )
                    # Update problem with new generation id
                    # Update problem with new generation id
                    self.optimizer.problem.current_gen_id = next_gen_id
                    # ADR-009: Update generation number explicitly
                    self.optimizer.problem.current_gen_num = next_gen_num

                    # Update internal cumulative counters
                    self.optimizer._last_cum_feasible = cur_feasible
                    self.optimizer._last_cum_infeasible = cur_infeasible
                    
                    # ADR-011: Export progress sidecar for live monitoring
                    self._export_progress_sidecar(gen)
                except Exception:
                    self.optimizer.logger.warning("Failed to create next generation record in DB", exc_info=True)

            # Periodic cleanup to prevent /dev/shm exhaustion during long runs
            if gen % 5 == 0:
                try:
                    cleanup_shm(self.optimizer.logger)
                except Exception:
                    pass  # Best effort cleanup
        except Exception:
            # Avoid letting DB issues break optimizer loop
            self.optimizer.logger.error("Critical error in checkpoint callback", exc_info=True)

    def _save_checkpoint(self, algorithm, gen: int):
        """Save checkpoint at current generation."""
        elapsed = time.time() - self.start_time

        checkpoint = CheckpointData(
            generation=gen,
            population_X=algorithm.pop.get("X").copy(),
            population_F=algorithm.pop.get("F").copy(),
            algorithm_state={
                "n_gen": algorithm.n_gen,
                "algorithm_type": type(algorithm).__name__,
            },
            problem_stats=self.optimizer.problem.get_statistics() if self.optimizer.problem else {},
            campaign_id=self.optimizer.campaign_id,
            elapsed_time_s=elapsed,
        )

        # Save checkpoint files
        checkpoint_path = self.checkpoint_dir / f"gen_{gen:04d}.pkl"
        checkpoint.save(checkpoint_path)

        # Also save population as NPZ for easy inspection
        npz_path = self.checkpoint_dir / f"gen_{gen:04d}_pop.npz"
        np.savez_compressed(
            npz_path,
            X=checkpoint.population_X,
            F=checkpoint.population_F,
            generation=gen,
        )

        self.optimizer.logger.info(f"Saved checkpoint at generation {gen}: {checkpoint_path}")

    def _export_progress_sidecar(self, gen: int):
        """
        Export live progress for concurrent monitoring (ADR-011).
        
        Creates Parquet sidecar files that can be read from login node
        without locking the DuckDB database.
        """
        if self.optimizer.db_writer is None:
            return
        
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
            
            conn = self.optimizer.db_writer.conn
            campaign_id = self.optimizer.campaign_id
            output_dir = self.optimizer.config.storage.hdf5.consolidated_dir.parent
            
            # Export generation metrics
            df_gen = conn.execute("""
                SELECT gen_num, n_feasible, n_infeasible, 
                       hypervolume, pareto_size, created_at
                FROM generations 
                WHERE campaign_id = ?
                ORDER BY gen_num
            """, [campaign_id]).df()
            
            # Export current Pareto front for visualization
            # Note: is_pareto is only set at END of run, so during optimization
            # we export the latest COMPLETED generation's feasible population
            # The MAX(gen_num) is a placeholder, so we get the second-to-last
            df_pareto = conn.execute("""
                WITH completed_gens AS (
                    SELECT gen_num FROM generations 
                    WHERE campaign_id = ? AND n_feasible > 0
                    ORDER BY gen_num DESC LIMIT 1
                )
                SELECT e.design_uuid, e.total_mass_kg, e.frag_mass_kg,
                       e.charge_mass_kg, g.gen_num, e.feasible
                FROM evaluations e
                JOIN generations g ON e.gen_id = g.gen_id
                WHERE g.campaign_id = ?
                  AND e.feasible = true
                  AND g.gen_num = (SELECT gen_num FROM completed_gens)
            """, [campaign_id, campaign_id]).df()
            
            # Export target results for latest completed generation
            df_targets = conn.execute("""
                WITH completed_gens AS (
                    SELECT gen_num FROM generations 
                    WHERE campaign_id = ? AND n_feasible > 0
                    ORDER BY gen_num DESC LIMIT 1
                )
                SELECT e.design_uuid, t.target_name, 
                       t.integrated_kill_potential, t.volume_at_threshold
                FROM evaluations e
                JOIN target_results t ON e.eval_id = t.eval_id
                JOIN generations g ON e.gen_id = g.gen_id
                WHERE g.campaign_id = ?
                  AND e.feasible = true
                  AND g.gen_num = (SELECT gen_num FROM completed_gens)
            """, [campaign_id, campaign_id]).df()
            
            # Atomic writes using temp files
            for name, df in [
                ("live_generations", df_gen),
                ("live_pareto", df_pareto),
                ("live_targets", df_targets),
            ]:
                if df.empty:
                    continue
                tmp_path = output_dir / f".{name}.parquet.tmp"
                final_path = output_dir / f"{name}.parquet"
                pq.write_table(pa.Table.from_pandas(df), tmp_path)
                tmp_path.rename(final_path)
                
        except ImportError:
            # pyarrow not available - skip sidecar export
            pass
        except Exception:
            self.optimizer.logger.debug("Failed to export progress sidecar", exc_info=True)


class GWDHOptimizer:
    """
    Main optimizer for GWDH campaigns.
    
    Orchestrates:
    - Configuration loading
    - GA algorithm setup with parallel MEGADETH evaluation
    - Storage management (DuckDB + NPZ)
    - Progress tracking and checkpointing
    - Resume from checkpoint
    """

    def __init__(self, config: CampaignConfig, campaign_id: Optional[str] = None):
        """
        Initialize GWDH optimizer.

        Args:
            config: Campaign configuration
            campaign_id: Unique campaign ID (auto-generated if None)
        """
        self.config = config

        # Generate campaign ID if not provided
        if campaign_id is None:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            campaign_id = f"{config.name}_{timestamp}"
        self.campaign_id = campaign_id

        from ..parallel.resources import detect_resources
        resources = detect_resources()
        is_worker = resources.mpi_available and resources.mpi_rank > 0
        
        # Silence workers by setting level to WARNING or ERROR
        log_level = "WARNING" if is_worker else config.logging.level
        
        # Determine if we should use per-rank log files
        mpi_rank_param = None
        if config.logging.mpi_per_rank and resources.mpi_available and resources.mpi_rank is not None:
            mpi_rank_param = resources.mpi_rank
        
        self.logger = setup_logger(
            "gdwh.optimizer",
            log_file=config.logging.file,
            level=log_level,  # Use the conditional level
            mpi_rank=mpi_rank_param,
            console=config.logging.console,
        )
        self.progress_logger = ProgressLogger(self.logger, config.ga.max_generations)

        self.logger.info(f"Initializing GWDH Optimizer for campaign: {campaign_id}")

        # Initialize components
        self.input_cache: Optional[InputBytesCache] = None
        self.static_context = None
        self.problem: Optional[GWDHProblem] = None
        self.algorithm = None
        self.db_writer: Optional[BatchedDBWriter] = None
        self.h5_writer: Optional[HDF5Writer] = None

        # Checkpoint callback
        self._checkpoint_callback: Optional[CheckpointCallback] = None
        self._resumed_from_gen: int = 0

        # Results
        self.result = None
        self.start_time = None
        self.end_time = None

    def initialize(self):
        """Initialize all components."""
        # Step 0: Log system resources and configuration
        resources = detect_resources()
        is_master = (not resources.mpi_available) or (resources.mpi_rank is None) or (resources.mpi_rank == 0)
        
        # Only log verbose configuration banner on master rank
        if is_master:
            self.logger.info("System Resources:")
            self.logger.info(f"  Hostname: {resources.hostname}")
            self.logger.info(f"  CPU Cores: {resources.cpu_count} (Physical: {resources.physical_cores})")
            self.logger.info(f"  Available RAM: {resources.available_memory_gb:.1f} GB")
            
            mode = self.config.parallel.mode
            self.logger.info(f"Parallel Execution Configuration:")
            self.logger.info(f"  Mode: {mode}")
            
            if resources.mpi_available:
                 self.logger.info(f"  MPI: Available (Rank {resources.mpi_rank}/{resources.mpi_size})")
            else:
                 self.logger.info(f"  MPI: Not available")
                 
            if mode == "mpi":
                 self.logger.info(f"  Configured MPI Nodes: {self.config.parallel.mpi.nodes}")
                 self.logger.info(f"  Configured Cores/Node: {self.config.parallel.mpi.cores_per_node}")

            # MEGADETH C++ Accelerator status
            accel_info = get_accelerator_info()
            self.logger.info("MEGADETH Accelerator:")
            if accel_info["available"]:
                self.logger.info(f"  Status: ENABLED (v{accel_info['version']})")
                self.logger.info(f"  OpenMP: {'Yes' if accel_info['has_openmp'] else 'No'}")
            else:
                self.logger.info("  Status: Not available (using Python fallback)")

            # Log problem configuration summary
            self._log_problem_configuration()

        self.logger.info("Initializing optimizer components...")

        # Step 1: Load input files as bytes
        self.logger.info("Loading input files as bytes...")
        self.input_cache = InputBytesCache.load_all(self.config)
        self.logger.info(f"Loaded {len(self.input_cache.targets)} target input sets")

        # Step 2: Build MEGADETH static context
        self.logger.info("Building MEGADETH static context...")
        self.static_context = StaticContextBuilder.build(self.config, self.input_cache)

        # Step 3: Setup storage (ONLY ON MASTER)
        if is_master:
            self.logger.info("Setting up storage...")
            DatabaseSchema.create_schema(self.config.storage.database)

            self.db_writer = BatchedDBWriter(
                self.config.storage.database,
                self.campaign_id,
            )

            # Write campaign metadata
            config_yaml = yaml.dump(self.config.model_dump(mode="json"), default_flow_style=False)
            self.db_writer.write_campaign(
                name=self.config.name,
                config_yaml=config_yaml,
                n_variables=self.config.count_variables(),
                n_objectives=self.config.count_objectives(),
                population_size=self.config.ga.population_size,
            )

            # Initialize HDF5 writer for result storage
            # ADR-009: Per-generation files created by MPIEvaluator. No single global writer.
            conn = DatabaseSchema.get_connection(self.config.storage.database)
            self.h5_writer = None
        else:
            # Workers do not touch the DB
            self.db_writer = None
            self.h5_writer = None

        # Step 4: Create optimization problem
        # Step 4: Create optimization problem
        self.logger.info("Creating optimization problem with parallel evaluator...")
        self.problem = GWDHProblem(
            config=self.config,
            input_cache=self.input_cache,
            static_context=self.static_context,
            evaluator=None,
            use_parallel_evaluator=True,
            db_writer=self.db_writer,
            h5_writer=None, # ADR-009: No global writer
            # ADR-009: Context for per-generation storage
            output_dir=self.config.storage.hdf5.consolidated_dir.parent,
            campaign_id=self.campaign_id,
        )

        # Step 5 & 6 (Algorithm & Checkpoints) -> ONLY ON MASTER
        if is_master:
            self.logger.info(f"Setting up {self.config.ga.algorithm} algorithm...")
            self.algorithm = self._create_algorithm()

            self._checkpoint_callback = CheckpointCallback(
                optimizer=self,
                every_n_gens=self.config.storage.checkpoints.every_n_gens,
                checkpoint_dir=self.config.storage.checkpoints.path,
            )
        
        self.logger.info("Initialization complete")

    def _log_problem_configuration(self):
        """Log a formatted summary of the problem configuration."""
        cfg = self.config

        self.logger.info("=" * 60)
        self.logger.info("PROBLEM CONFIGURATION SUMMARY")
        self.logger.info("=" * 60)

        # Warhead Configuration
        self.logger.info("Warhead:")
        self.logger.info(f"  Zones: {cfg.warhead.n_zones}")
        self.logger.info(f"  ZDATA Number: {cfg.warhead.zdata_number}")
        self.logger.info(f"  Total Mass: {cfg.warhead.mass_constraints.total_mass_kg} kg")
        self.logger.info(f"  Fragment Mass Limit: {cfg.warhead.mass_constraints.fragment_mass_kg} kg")
        self.logger.info(f"  Gurney Constant: {cfg.warhead.physics.gurney_constant_kms} km/s")
        self.logger.info(f"  Shape Factor: {cfg.warhead.physics.shape_factor}")

        # Design Variables
        n_bins = len(cfg.variables.fragment_sizes.bin_edges_grams) - 1
        n_vars = cfg.count_variables()
        self.logger.info("Design Variables:")
        self.logger.info(f"  Fragment Size Bins: {n_bins}")
        self.logger.info(f"  Velocity Bounds: {cfg.variables.zone_velocities.bounds_mps} m/s")
        self.logger.info(f"  Total Variables: {n_vars}")

        # Targets
        self.logger.info(f"Targets: {len(cfg.targets)}")
        for t in cfg.targets:
            self.logger.info(f"  - {t.name} (RCAS {t.rcas_number})")

        # MEGADETH Terminal Conditions
        n_hob = len(cfg.megadeth.axes.hob_m)
        n_vel = len(cfg.megadeth.axes.vel_mps)
        n_aof = len(cfg.megadeth.axes.aof_deg)
        total_conditions = n_hob * n_vel * n_aof
        target_count = len(cfg.targets)
        total_conditions_all_targets = total_conditions * target_count

        self.logger.info("MEGADETH Terminal Conditions:")
        self.logger.info(f"  HOB steps: {n_hob} ({min(cfg.megadeth.axes.hob_m)}-{max(cfg.megadeth.axes.hob_m)} m)")
        self.logger.info(f"  Velocity steps: {n_vel} ({min(cfg.megadeth.axes.vel_mps)}-{max(cfg.megadeth.axes.vel_mps)} m/s)")
        self.logger.info(f"  AOF steps: {n_aof} ({min(cfg.megadeth.axes.aof_deg)}-{max(cfg.megadeth.axes.aof_deg)} deg)")
        self.logger.info(f"  FSM executions per design per target: {total_conditions} ({n_hob}×{n_vel}×{n_aof})")
        if target_count > 1:
            self.logger.info(f"  FSM executions per design across all targets: {total_conditions_all_targets} ({target_count} targets)")
        self.logger.info(f"  Pk Threshold: {cfg.megadeth.pk_threshold}")
        self.logger.info(f"  Monte Carlo: {'enabled' if cfg.megadeth.run_mc else 'disabled'}")

        # Precision/Error Model
        self.logger.info("Precision (Error Model):")
        self.logger.info(f"  TLE: {cfg.precision.tle_radius_m} m @ {cfg.precision.tle_fraction*100:.0f}%")
        self.logger.info(f"  CEP: {cfg.precision.cep_radius_m} m @ {cfg.precision.cep_fraction*100:.0f}%")

        # Objectives
        n_obj = cfg.count_objectives()
        self.logger.info(f"Objectives: {n_obj} total")

        obj_list = []
        if cfg.objectives.integrated_kill_potential.enabled:
            mode = "per-target" if cfg.objectives.integrated_kill_potential.per_target else "aggregate"
            obj_list.append(f"IKP ({mode})")
        if cfg.objectives.volume_at_threshold.enabled:
            mode = "per-target" if cfg.objectives.volume_at_threshold.per_target else "aggregate"
            obj_list.append(f"Volume ({mode})")
        if cfg.objectives.total_mass.enabled:
            obj_list.append("Total Mass")
        if cfg.objectives.fragment_mass.enabled:
            obj_list.append("Fragment Mass")
        if cfg.objectives.explosive_mass.enabled:
            obj_list.append("Explosive Mass")

        self.logger.info(f"  Active: {', '.join(obj_list)}")

        # GA Configuration
        self.logger.info("Genetic Algorithm:")
        self.logger.info(f"  Algorithm: {cfg.ga.algorithm}")
        self.logger.info(f"  Population: {cfg.ga.population_size}")
        self.logger.info(f"  Max Generations: {cfg.ga.max_generations}")
        init_strategy = getattr(cfg.ga.initialization, 'strategy', 'random')
        self.logger.info(f"  Initialization: {init_strategy}")

        # Total computational estimate
        total_evals_per_gen = cfg.ga.population_size
        total_fsm_per_gen = total_evals_per_gen * total_conditions_all_targets
        self.logger.info("Computational Estimate:")
        self.logger.info(
            f"  FSM executions per generation: ~{total_fsm_per_gen:,} "
            f"({total_evals_per_gen} designs × {target_count} targets × {total_conditions} conditions)"
        )
        self.logger.info(f"  (assumes all designs feasible)")

        self.logger.info("=" * 60)

    def _get_ref_dirs(self, n_obj: int, target_pop: int):
        """Generate reference directions approx matching target population size."""
        # For small objectives, use Das-Dennis
        # Binomial coeff: (n_obj + k - 1) choose k
        
        best_k = 1
        min_diff = float('inf')
        
        # Search range for partitions k
        for k in range(1, 200):
            n_points = math.comb(n_obj + k - 1, k)
            diff = abs(n_points - target_pop)
            
            if diff < min_diff:
                min_diff = diff
                best_k = k
            
            # If we pass the target, we can stop if the gap is increasing
            if n_points > target_pop:
                break
                
        return get_reference_directions("das-dennis", n_dim=n_obj, n_partitions=best_k)

    def _create_algorithm(self):
        """Create pymoo algorithm instance."""
        # Sampling
        if hasattr(self.config.ga, "initialization") and self.config.ga.initialization.strategy == "guided":
            from .sampling import GuidedSampling
            self.logger.info("Using Guided Random Initialization")
            sampling = GuidedSampling(
                warhead_config=self.config.warhead,
                variables_config=self.config.variables,
                init_config=self.config.ga.initialization,
                seed=42
            )
        else:
            sampling = FloatRandomSampling()

        # Crossover
        crossover = SBX(
            eta=self.config.ga.operators.crossover_eta,
            prob=self.config.ga.operators.crossover_prob,
        )

        # Mutation
        mutation = PM(eta=self.config.ga.operators.mutation_eta)

        # Create algorithm
        # ADR-017: Use UUID-based duplicate elimination to catch near-duplicates
        duplicate_elimination = UUIDDuplicateElimination()
        self.logger.info("ADR-017: Using UUID-based duplicate elimination")

        if self.config.ga.algorithm == "NSGA-II":
            algorithm = NSGA2(
                pop_size=self.config.ga.population_size,
                sampling=sampling,
                crossover=crossover,
                mutation=mutation,
                survival=RankAndCrowdingSurvival(nds=JensenNDS()),
                eliminate_duplicates=duplicate_elimination,
            )
        elif self.config.ga.algorithm == "NSGA-III":
            n_obj = self.config.count_objectives()
            ref_dirs = self._get_ref_dirs(n_obj, self.config.ga.population_size)
            
            # Update population size to match ref_dirs
            if len(ref_dirs) != self.config.ga.population_size:
                self.logger.warning(
                    f"NSGA-III: Adjusted population size from {self.config.ga.population_size} "
                    f"to {len(ref_dirs)} to match reference directions."
                )
            
            # Create custom survival with JensenNDS
            from ..optimization.pareto import create_jensen_nsga3_survival
            jensen_survival = create_jensen_nsga3_survival(ref_dirs)
            
            self.logger.info("ADR-007: Using JensenNDS survival for NSGA-III")
            
            algorithm = NSGA3(
                ref_dirs=ref_dirs,
                pop_size=len(ref_dirs),
                sampling=sampling,
                crossover=crossover,
                mutation=mutation,
                survival=jensen_survival,
                eliminate_duplicates=duplicate_elimination,
            )
        else:
            raise ValueError(f"Unknown algorithm: {self.config.ga.algorithm}")

        return algorithm

    def run(self) -> dict:
        """
        Run optimization campaign.

        Returns:
            Results dictionary with Pareto front and statistics
        """
        if self.algorithm is None and self.db_writer is None:
             self.initialize()
        
        resources = detect_resources()
        is_master = (not resources.mpi_available) or (resources.mpi_rank is None) or (resources.mpi_rank == 0)

        # --- WORKER MODE ---
        if not is_master:
            self.logger.info(f"Rank {resources.mpi_rank}: Entering MPI worker loop")
            if hasattr(self.problem, 'evaluator') and hasattr(self.problem.evaluator, 'run_worker_loop'):
                self.problem.evaluator.run_worker_loop()
            else:
                self.logger.warning(
                    f"Rank {resources.mpi_rank}: No worker loop available - "
                    "evaluator may not be MPI-enabled"
                )
            self.logger.info(f"Rank {resources.mpi_rank}: Exiting worker mode")
            return {}
        
        self.logger.info("Starting optimization campaign...")
        self.start_time = time.time()

        # Setup termination
        termination = get_termination("n_gen", self.config.ga.max_generations)

        # Ensure first generation record exists
        if self.db_writer is not None and getattr(self.problem, 'current_gen_id', None) is None:
            try:
                first_gen_id = self.db_writer.write_generation(1, pop_size=self.config.ga.population_size, n_feasible=0, n_infeasible=0)
                self.problem.current_gen_id = first_gen_id
                self._last_cum_feasible = 0
                self._last_cum_infeasible = 0
            except Exception:
                self.logger.warning("Failed to create initial generation record in DB", exc_info=True)

        try:
            self.result = minimize(
                self.problem,
                self.algorithm,
                termination,
                seed=42,
                verbose=True,
                save_history=False,
                callback=self._checkpoint_callback,
            )

            self.end_time = time.time()
            runtime = self.end_time - self.start_time

            self.logger.info(f"Optimization complete in {runtime:.1f} seconds")

            # Signal MPI workers to terminate
            if hasattr(self.problem, 'evaluator') and hasattr(self.problem.evaluator, 'signal_workers_terminate'):
                self.problem.evaluator.signal_workers_terminate()

            # Save final checkpoint
            if self.config.storage.checkpoints.enabled:
                final_path = self.config.storage.checkpoints.path / "final.pkl"
                CheckpointData(
                    generation=self.result.algorithm.n_gen,
                    population_X=self.result.X,
                    population_F=self.result.F,
                    algorithm_state={"n_gen": self.result.algorithm.n_gen},
                    problem_stats=self.problem.get_statistics(),
                    campaign_id=self.campaign_id,
                    elapsed_time_s=runtime,
                ).save(final_path)
                self.logger.info(f"Saved final checkpoint: {final_path}")

            # Extract results
            results = self._extract_results(runtime)

            return results

        finally:
            # Always clean up resources, even on crash
            self.cleanup()

    def _extract_results(self, runtime: float) -> dict:
        """Extract and format results."""
        # Pareto front
        pareto_X = self.result.X
        pareto_F = self.result.F

        # Persist Pareto membership into the database
        self._update_pareto_flags_in_db(pareto_X)

        self.logger.info(f"Pareto front size: {len(pareto_X)}")

        # Statistics
        stats = {
            "campaign_id": self.campaign_id,
            "n_generations": self.result.algorithm.n_gen,
            "pareto_size": len(pareto_X),
            "total_evaluations": self.problem.n_evaluations,
            "n_feasible": self.problem.n_feasible,
            "n_infeasible": self.problem.n_infeasible,
            "feasibility_rate": self.problem.n_feasible / max(self.problem.n_evaluations, 1),
            "runtime_s": runtime,
            "resumed_from_gen": self._resumed_from_gen,
            "problem_stats": self.problem.get_statistics(),
            "pareto_front": {
                "designs": pareto_X,
                "objectives": pareto_F,
            },
        }

        return stats

    def resume(self, checkpoint_path: Path) -> dict:
        """
        Resume optimization from checkpoint.

        Args:
            checkpoint_path: Path to checkpoint file (.pkl)

        Returns:
            Results dictionary with Pareto front and statistics
        """
        self.logger.info(f"Resuming from checkpoint: {checkpoint_path}")

        # Load checkpoint
        checkpoint = CheckpointData.load(checkpoint_path)
        self._resumed_from_gen = checkpoint.generation

        self.logger.info(
            f"Loaded checkpoint from generation {checkpoint.generation} "
            f"(elapsed: {checkpoint.elapsed_time_s:.1f}s)"
        )

        if self.algorithm is None:
            self.initialize()

        # Restore population
        self.logger.info(f"Restoring population of {len(checkpoint.population_X)} designs")

        from pymoo.core.population import Population

        pop = Population.new("X", checkpoint.population_X)
        pop.set("F", checkpoint.population_F)

        # Setup algorithm with restored population
        self.algorithm.initialization = pop

        remaining_gens = self.config.ga.max_generations - checkpoint.generation

        if remaining_gens <= 0:
            self.logger.warning(
                f"Checkpoint generation ({checkpoint.generation}) >= max generations "
                f"({self.config.ga.max_generations}). Nothing to resume."
            )
            return self._extract_results(checkpoint.elapsed_time_s)

        self.logger.info(f"Resuming for {remaining_gens} more generations")

        termination = get_termination("n_gen", remaining_gens)

        self.start_time = time.time()

        try:
            self.result = minimize(
                self.problem,
                self.algorithm,
                termination,
                seed=42,
                verbose=True,
                save_history=False,
                callback=self._checkpoint_callback,
            )

            self.end_time = time.time()
            runtime = checkpoint.elapsed_time_s + (self.end_time - self.start_time)

            self.logger.info(f"Resume complete. Total runtime: {runtime:.1f} seconds")

            results = self._extract_results(runtime)

            return results

        finally:
            # Always clean up resources, even on crash
            self.cleanup()

    def get_latest_checkpoint(self) -> Optional[Path]:
        """Find the latest checkpoint file."""
        checkpoint_dir = self.config.storage.checkpoints.path

        if not checkpoint_dir.exists():
            return None

        checkpoints = list(checkpoint_dir.glob("gen_*.pkl"))

        if not checkpoints:
            return None

        def get_gen(p: Path) -> int:
            try:
                return int(p.stem.split("_")[1])
            except (IndexError, ValueError):
                return 0

        checkpoints.sort(key=get_gen, reverse=True)

        return checkpoints[0]

    def _update_pareto_flags_in_db(self, pareto_X: np.ndarray):

        """Mark Pareto-front evaluations in the database."""
        if self.db_writer is None or self.problem is None or pareto_X is None:
            return

        try:
            self.db_writer.flush()
        except Exception:
            self.logger.warning("Failed to flush DB writer before Pareto update", exc_info=True)
            return

        try:
            uuids = [self.problem.zdata_generator.compute_uuid(x) for x in pareto_X]
            seen = set()
            pareto_uuids = []
            for uid in uuids:
                if uid not in seen:
                    seen.add(uid)
                    pareto_uuids.append(uid)

            conn = self.db_writer.conn

            conn.execute(
                """
                UPDATE evaluations
                SET is_pareto = FALSE, pareto_rank = NULL
                WHERE gen_id IN (
                    SELECT gen_id FROM generations WHERE campaign_id = ?
                )
                """,
                [self.campaign_id],
            )

            for uid in pareto_uuids:
                conn.execute(
                    """
                    UPDATE evaluations
                    SET is_pareto = TRUE, pareto_rank = 0
                    WHERE design_uuid = ?
                      AND gen_id IN (
                          SELECT gen_id FROM generations WHERE campaign_id = ?
                      )
                    """,
                    [uid, self.campaign_id],
                )

            conn.execute(
                """
                UPDATE generations
                SET pareto_size = ?
                WHERE campaign_id = ?
                  AND gen_num = (
                      SELECT MAX(gen_num) FROM generations WHERE campaign_id = ?
                  )
                """,
                [len(pareto_uuids), self.campaign_id, self.campaign_id],
            )

            conn.commit()
        except Exception as e:
            self.logger.warning(f"Failed to update Pareto flags in DB: {e}", exc_info=True)

    def _handle_results(self, results: Dict[str, Any]):
        """
        Callback to handle a batch of evaluation results immediately.
        
        Writes heavy NPZ data to disk and records stats to DB to keep 
        memory usage low during large MPI generations.
        """
        if not results:
            return

        # 1. Write to HDF5 storage (Heavy I/O - now handled in gather_results)
        # HDF5 writes are done during gather_results_pipelined via h5_writer
        # No separate batch operation needed here

        # 2. Write evaluations to Database
        if self.db_writer and self.problem:
            try:
                # We need the current generation ID from the problem
                gen_id = getattr(self.problem, "current_gen_id", None)
                if gen_id is not None:
                    # Convert EvalResult objects to the format expected by db_writer
                    # This depends on your specific DB writer API, but generally involves
                    # passing the result objects.
                    self.db_writer.write_evaluations(gen_id, results)
            except Exception as e:
                self.logger.error(f"Failed to write evaluation batch to DB: {e}")

    def cleanup(self):
        """Clean up resources and temporary directories."""
        if self.db_writer is not None:
            self.db_writer.close()

        # Use shared utility
        cleanup_shm(self.logger)
        self.logger.info("Cleanup complete")
