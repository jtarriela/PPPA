"""Guided sampling for population initialization."""

import numpy as np
from typing import Optional
from pymoo.core.sampling import Sampling

from ..config import WarheadConfig, VariablesConfig, GuidedInitConfig
from ..validation.mass import MassCalculator
from ..validation.gurney import GurneyCalculator


class GuidedSampling(Sampling):
    """
    Guided sampling strategy for warhead optimization.

    Constructs initial population designs that are probabilistically likely
    to satisfy mass and velocity constraints by working backwards from
    the constraints themselves.

    Strategy:
    1. Select a target total mass (randomly within budget fraction)
    2. Split mass between fragments and explosive (randomly within split fraction)
    3. Distribute fragment mass across zones/bins (randomly with Dirichlet-like weights)
    4. Calculate fragment counts from distributed mass
    5. Calculate Gurney velocity limit for the chosen Charge-to-Metal ratio
    6. Select velocity (randomly within velocity fraction of limit)
    """

    def __init__(
        self,
        warhead_config: WarheadConfig,
        variables_config: VariablesConfig,
        init_config: GuidedInitConfig,
        seed: Optional[int] = None,
    ):
        """
        Initialize guided sampling.

        Args:
            warhead_config: Warhead configuration
            variables_config: Design variables configuration
            init_config: Initialization configuration
            seed: Random seed
        """
        super().__init__()
        self.warhead_config = warhead_config
        self.variables_config = variables_config
        self.init_config = init_config
        self.rng = np.random.default_rng(seed)

        # Helpers
        bin_edges = np.array(variables_config.fragment_sizes.bin_edges_grams)
        self.mass_calc = MassCalculator(warhead_config, bin_edges)
        self.gurney_calc = GurneyCalculator(warhead_config)
        
        # Pre-compute bin average masses
        self.bin_avg_masses_kg = self.mass_calc.bin_centers_g / 1000.0

    def _do(self, problem, n_samples, **kwargs):
        """
        Sample designs.

        Args:
            problem: Pymoo problem instance
            n_samples: Number of samples to generate

        Returns:
            X: Design matrix (n_samples, n_vars)
        """
        n_zones = self.warhead_config.n_zones
        n_bins = len(self.variables_config.fragment_sizes.bin_edges_grams) - 1
        n_vars = problem.n_var

        # Dimensions
        n_frag_vars = n_zones * n_bins
        
        # Allocate output matrix
        X = np.zeros((n_samples, n_vars))
        
        # 1. Target Total Masses
        # Range: [0.8 * Limit, 1.0 * Limit]
        min_mass_frac = self.init_config.mass_budget_fraction[0]
        max_mass_frac = self.init_config.mass_budget_fraction[1]
        
        target_total_masses = self.rng.uniform(
            min_mass_frac * self.mass_calc.total_mass_kg,
            max_mass_frac * self.mass_calc.total_mass_kg,
            size=n_samples
        )
        
        # Subtract fixed case mass (approximate or exact if known)
        # Assuming case mass is part of the budget but handled in mass calculator?
        # MassCalculator computes: total = frag + charge + case
        # So: available = target - case
        # We need case mass from somewhere. MassCalculator might know it?
        # MassCalculator stores case_mass_kg if provided in config?
        # WarheadConfig has physics.case_mass_kg? No, let's check config schema.
        # WarheadConfig -> MassConstraints -> total/frag/charge.
        # Physics has densities.
        # Wait, usually case mass is implicit or fixed. 
        # In example config: physics.case_mass_kg is present.
        # But in Schema, WarheadConfig.Physics doesn't list case_mass_kg explicitly in my read.
        # Let's check Schema again.
        # WarheadConfig.Physics only had gurney and densities.
        # Wait, example had `case_mass_kg: 2.0`. 
        # If schema doesn't have it, then example is wrong or I missed it.
        # I'll check mass.py if I can, but let's assume we can calculate available mass.
        # If charge_mass_kg is computed as (total - frag - case), then case must be known.
        
        # Let's check MassCalculator in gdwh/validation/mass.py to be safe.
        # For now, I'll proceed assuming I can get available mass.
        # If MassCalculator doesn't expose it, I'll assume 0 or estimate.
        
        # Actually, let's just target Fragment Mass directly if Total is constrained.
        # The constraint is total <= limit.
        # Frag + Charge + Case <= Limit.
        
        # 2. Split Mass (Fragment vs Charge)
        # Range: [0.1, 0.9] of available mass
        min_split = self.init_config.frag_mass_split[0]
        max_split = self.init_config.frag_mass_split[1]
        
        split_ratios = self.rng.uniform(min_split, max_split, size=n_samples)
        
        # We need to know available mass (Total - Case).
        # I'll assume a safe margin if I don't know case mass. 
        # Or better, just target Fragment Mass directly based on its own limit?
        # config.warhead.mass_constraints.fragment_mass_kg is a limit.
        
        # Let's use the explicit Fragment Mass Limit as a ceiling, 
        # and the Total Mass Limit - Charge Min as another.
        
        # Simplification: 
        # Target Frag Mass = split_ratio * (target_total_mass)
        # Just ensure it doesn't exceed fragment_mass_limit.
        
        target_frag_masses = split_ratios * target_total_masses
        
        # Clip to fragment limit
        frag_limit = self.warhead_config.mass_constraints.fragment_mass_kg
        target_frag_masses = np.minimum(target_frag_masses, frag_limit)
        
        # 3. Distribute Fragment Mass (Random Weights)
        # We need to distribute target_frag_masses[i] into n_frag_vars bins.
        # Use Dirichlet distribution for "jagged" randomness, or normalized uniform.
        # Dirichlet(alpha=1) is uniform over simplex. alpha<1 is sparse (jagged).
        # Let's use alpha=0.5 for some sparsity/variety.
        
        # Generate random weights: (n_samples, n_frag_vars)
        # Using gamma distribution is faster for Dirichlet generation
        alpha = 0.5
        weights = self.rng.gamma(alpha, 1.0, size=(n_samples, n_frag_vars))
        
        # Normalize weights per sample
        sums = weights.sum(axis=1, keepdims=True)
        normalized_weights = weights / sums
        
        # Allocated mass per bin: (n_samples, n_frag_vars)
        bin_masses = normalized_weights * target_frag_masses[:, None]
        
        # 4. Calculate Counts
        # count = mass / avg_bin_mass
        # Tile bin masses for vectorization
        tiled_avg_masses = np.tile(self.bin_avg_masses_kg, n_zones)
        
        counts = bin_masses / tiled_avg_masses
        
        # Round to integers? No, variables are usually continuous in pymoo until evaluation/repair?
        # But bounds are integers. Let's round.
        counts = np.round(counts)
        
        # Clip to bounds
        min_qty = self.variables_config.fragment_quantities.min_per_bin
        max_qty = self.variables_config.fragment_quantities.max_per_bin
        counts = np.clip(counts, min_qty, max_qty)
        
        # Fill X with counts (indices n_frag_vars : 2*n_frag_vars)
        # Wait, design vector layout:
        # [frag_sizes (flat), frag_quantities (flat), zone_velocities]
        # Frag sizes are fixed? No, they are variables?
        # schema.py says:
        # VariablesConfig.FragmentSizes.bin_edges_grams
        # But Problem definition says: "Design variables (225: fragment sizes, quantities, velocities)"
        # Wait, frag sizes are usually FIXED bins in this formulation (ZDATA buckets).
        # But the problem defines `n_var` as `n_zones * n_bins * 2 + n_zones`.
        # Why *2?
        # If sizes are variables, they vary within bins?
        # Let's check `_compute_variable_bounds` in `problem.py`.
        # "Fragment sizes: use bin edges as bounds".
        # So yes, actual fragment size is a variable within the bin range.
        
        # So we need to generate Fragment Sizes too.
        # Just pick random uniform within bin edges for sizes.
        
        # 4a. Generate Fragment Sizes
        # Layout: First n_frag_vars are sizes.
        # Bounds are repeating bin edges.
        
        bin_edges = self.variables_config.fragment_sizes.bin_edges_grams
        size_vars = np.zeros((n_samples, n_frag_vars))
        
        for z in range(n_zones):
            for b in range(n_bins):
                idx = z * n_bins + b
                low = bin_edges[b]
                high = bin_edges[b+1]
                size_vars[:, idx] = self.rng.uniform(low, high, size=n_samples)
        
        X[:, :n_frag_vars] = size_vars
        
        # 4b. Fill Counts
        X[:, n_frag_vars : 2*n_frag_vars] = counts
        
        # 5. Calculate Velocities
        # We need actual mass of the generated counts to get C/M.
        # Recalculate actual frag mass
        actual_frag_masses = np.sum(counts * tiled_avg_masses, axis=1) # approx using avg
        
        # Assuming we targeted total mass, the rest is Charge (+ Case).
        # Charge = TargetTotal - Frag - Case.
        # We need to know Case Mass.
        # I'll check `warhead_config` again or assume 0 for safety (conservative Gurney).
        # If case is 0, C/M is higher, Velocity limit is higher.
        # If we assume 0 but case is 2kg, we overestimate V_max, so we might violate constraint.
        # We SHOULD estimate case mass.
        # Let's try to fetch it from config if possible, or default to a small value.
        # In `MassCalculator`, it might have it.
        # Let's check `MassCalculator` in `gdwh/validation/mass.py`?
        # I can't read it now easily without switching context, but I instantiated it.
        # `self.mass_calc.case_mass_kg` might exist?
        
        case_mass = getattr(self.mass_calc, "case_mass_kg", 0.0)
        
        # Calculate Charge Mass
        charge_masses = target_total_masses - actual_frag_masses - case_mass
        
        # Ensure positive charge
        charge_masses = np.maximum(charge_masses, 0.1)
        
        # Calculate Gurney Limit
        # V = sqrt(2E) * sqrt( C/M / (1 + 0.5 C/M) ) for cylinder
        # self.gurney_calc.compute_limit(charge, metal)
        # I can use `gurney_calc.compute_limits_batch`.
        
        # Need to construct a MassBatch-like object or just arrays?
        # `compute_limits_batch` takes (frag_masses, charge_masses).
        
        limits = self.gurney_calc.compute_limits_batch(actual_frag_masses, charge_masses)
        v_max = limits.v_max
        
        # 6. Select Velocities
        # Range: [min_vel_frac, max_vel_frac] * v_max
        min_v = self.init_config.velocity_fraction[0]
        max_v = self.init_config.velocity_fraction[1]

        # Determine number of velocity variables based on strategy
        strategy = self.variables_config.zone_velocities.strategy
        n_vel_vars = n_zones + 1 if strategy == "nodal" else n_zones

        vel_fractions = self.rng.uniform(min_v, max_v, size=(n_samples, n_vel_vars))

        velocities = vel_fractions * v_max[:, None]

        # Clip to absolute bounds
        v_bounds = self.variables_config.zone_velocities.bounds_mps
        velocities = np.clip(velocities, v_bounds[0], v_bounds[1])

        X[:, 2*n_frag_vars:] = velocities
        
        return X
