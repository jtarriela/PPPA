"""CSV importer for legacy fragment definition files."""

import re
import uuid
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
import pandas as pd

# Regex patterns for dynamic headers
Z_BIN_PATTERN = re.compile(r"z(\d+)_b(\d+)_(size|qty)", re.IGNORECASE)
Z_SPD_PATTERN = re.compile(r"z(\d+)_spd_mps", re.IGNORECASE)


@dataclass
class ImportedDesign:
    """Structured representation of a single imported design."""

    original_id: str
    design_uuid: str
    n_zones: int
    n_bins: int
    velocities_nodal: np.ndarray  # Shape (N+1,)
    frag_sizes: np.ndarray  # Shape (N, M) in grams
    frag_counts: np.ndarray  # Shape (N, M)
    total_frag_mass_kg: float


class FragFileImporter:
    """Parse fragment CSVs into structures suitable for ZDATA generation."""

    GRAINS_TO_GRAMS = 0.06479891

    def __init__(self, csv_path: str):
        self.csv_path = csv_path
        self.df = pd.read_csv(csv_path)
        self.check_required_columns()

    def check_required_columns(self):
        """Ensure the CSV includes mandatory identifiers."""
        if "eval_id" not in self.df.columns:
            raise ValueError("CSV must contain 'eval_id' column")

    def inspect_geometry(self) -> Tuple[int, int]:
        """Scan headers to infer zone/bin dimensions."""
        max_zone = 0
        max_bin = 0

        for col in self.df.columns:
            bin_match = Z_BIN_PATTERN.match(col)
            if bin_match:
                z_idx = int(bin_match.group(1))
                b_idx = int(bin_match.group(2))
                max_zone = max(max_zone, z_idx)
                max_bin = max(max_bin, b_idx)
                continue

            spd_match = Z_SPD_PATTERN.match(col)
            if spd_match:
                z_idx = int(spd_match.group(1))
                max_zone = max(max_zone, z_idx)

        if max_zone == 0 or max_bin == 0:
            raise ValueError("No fragment bin columns found (expected zXX_bYY_size/qty)")

        return max_zone, max_bin

    def _get_value(self, row: pd.Series, key: str, default: float = 0.0) -> float:
        """Fetch value from row with NaN and missing safeguards."""
        val = row.get(key, default)
        if pd.isna(val):
            return default
        try:
            return float(val)
        except (TypeError, ValueError):
            return default

    def _get_bin_value(self, row: pd.Series, z: int, b: int, suffix: str) -> float:
        """Support both padded and unpadded header lookups."""
        padded = f"z{z:02d}_b{b:02d}_{suffix}"
        unpadded = f"z{z}_b{b}_{suffix}"
        return self._get_value(row, padded, self._get_value(row, unpadded, 0.0))

    def process_velocities(self, row: pd.Series, n_zones: int) -> np.ndarray:
        """
        Convert zonal velocities to nodal boundaries.

        Node[0] = Zone[0]
        Node[i] = Avg(Zone[i-1], Zone[i])
        Node[N] = Zone[N-1]
        """
        v_zonal = np.array(
            [self._get_value(row, f"z{z:02d}_spd_mps", self._get_value(row, f"z{z}_spd_mps", 0.0)) for z in range(1, n_zones + 1)]
        )
        v_zonal = np.nan_to_num(v_zonal, nan=0.0)

        v_nodal = np.zeros(n_zones + 1)
        if len(v_zonal) > 0:
            v_nodal[0] = v_zonal[0]
            v_nodal[-1] = v_zonal[-1]
        if n_zones > 1:
            v_nodal[1:-1] = (v_zonal[:-1] + v_zonal[1:]) / 2.0
        return v_nodal

    def parse(self) -> List[ImportedDesign]:
        """Parse the CSV into ImportedDesign records."""
        n_zones, n_bins = self.inspect_geometry()
        results: List[ImportedDesign] = []

        for _, row in self.df.iterrows():
            design_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, str(row["eval_id"])))

            sizes = np.zeros((n_zones, n_bins))
            counts = np.zeros((n_zones, n_bins))

            for z in range(1, n_zones + 1):
                for b in range(1, n_bins + 1):
                    size_grains = self._get_bin_value(row, z, b, "size")
                    counts[z - 1, b - 1] = self._get_bin_value(row, z, b, "qty")
                    sizes[z - 1, b - 1] = size_grains * self.GRAINS_TO_GRAMS

            total_mass_g = float(np.sum(sizes * counts))
            velocities_nodal = self.process_velocities(row, n_zones)

            results.append(
                ImportedDesign(
                    original_id=str(row["eval_id"]),
                    design_uuid=design_uuid,
                    n_zones=n_zones,
                    n_bins=n_bins,
                    velocities_nodal=velocities_nodal,
                    frag_sizes=sizes,
                    frag_counts=counts,
                    total_frag_mass_kg=total_mass_g / 1000.0,
                )
            )

        return results
