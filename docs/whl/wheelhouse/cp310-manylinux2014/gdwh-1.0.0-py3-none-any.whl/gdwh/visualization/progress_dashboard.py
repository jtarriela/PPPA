"""
Live Progress Dashboard for GDWH optimization runs (ADR-011).

This lightweight Streamlit dashboard reads from Parquet sidecar files
instead of the DuckDB database, enabling lock-free concurrent monitoring
from a login node while optimization runs on compute nodes.

Usage:
    gdwh progress /path/to/output
    # or
    streamlit run progress_dashboard.py -- /path/to/output
"""

import sys
import time
from pathlib import Path

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

# Import Scikit-Learn for Projections
try:
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA
    from sklearn.manifold import TSNE
    from sklearn.impute import SimpleImputer
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

# Import UMAP (optional, faster than t-SNE for large datasets)
try:
    import umap
    UMAP_AVAILABLE = True
except ImportError:
    UMAP_AVAILABLE = False

# Import chart functions
from gdwh.visualization.charts import (
    plot_objective_correlation_heatmap,
    plot_objective_distributions,
)
from gdwh.visualization.usage_stats_view import render_usage_stats_tab

# Page Configuration
st.set_page_config(
    page_title="GDWH Live Progress",
    page_icon="chart",
    layout="wide",
    initial_sidebar_state="expanded",
)


def load_parquet_safe(path: Path) -> pd.DataFrame:
    """Load Parquet file, returning empty DataFrame if not found."""
    if not path.exists():
        return pd.DataFrame()
    try:
        import pyarrow.parquet as pq
        return pq.read_table(path).to_pandas()
    except Exception:
        return pd.DataFrame()


def main():
    st.title("GDWH Live Progress Monitor")
    st.caption("Real-time monitoring from Parquet sidecar files (no database lock)")
    
    # Get output directory from command line or sidebar
    if len(sys.argv) > 1 and not sys.argv[-1].startswith("-"):
        default_dir = sys.argv[-1]
    else:
        default_dir = "output"
    
    output_dir = Path(st.sidebar.text_input("Output Directory", value=default_dir))
    
    # Auto-refresh settings
    auto_refresh = st.sidebar.checkbox("Auto-refresh", value=True)
    refresh_interval = st.sidebar.slider("Refresh interval (seconds)", 1, 30, 5)
    
    if not output_dir.exists():
        st.warning(f"Output directory not found: {output_dir}")
        st.info("Waiting for optimization to create output files...")
        if auto_refresh:
            time.sleep(refresh_interval)
            st.rerun()
        return
    
    # Load Parquet sidecar files
    gen_path = output_dir / "live_generations.parquet"
    pareto_path = output_dir / "live_pareto.parquet"
    targets_path = output_dir / "live_targets.parquet"
    
    df_gen = load_parquet_safe(gen_path)
    df_pareto = load_parquet_safe(pareto_path)
    df_targets = load_parquet_safe(targets_path)
    
    # Show status
    st.sidebar.markdown("---")
    st.sidebar.markdown("### Data Status")
    st.sidebar.markdown(f"Generations: {'OK' if not df_gen.empty else 'Waiting'}")
    st.sidebar.markdown(f"Pareto Front: {'OK' if not df_pareto.empty else 'Waiting'}")
    st.sidebar.markdown(f"Target Results: {'OK' if not df_targets.empty else 'Waiting'}")
    
    if df_gen.empty:
        st.warning("Waiting for optimization to start...")
        st.info(f"Looking for: {gen_path}")
        if auto_refresh:
            time.sleep(refresh_interval)
            st.rerun()
        return
    
    # Create tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs(["Convergence", "Pareto Frontier", "Analysis", "Drill-Down", "Usage Stats"])
    
    # === TAB 1: CONVERGENCE ===
    with tab1:
        st.header("Convergence Metrics")
        
        # Metrics row
        col1, col2, col3, col4 = st.columns(4)
        
        # Filter out placeholder row (last row with 0 or NaN n_feasible)
        df_complete = df_gen[(df_gen["n_feasible"].notna()) & (df_gen["n_feasible"] > 0)]
        
        latest_gen = int(df_complete["gen_num"].max()) if len(df_complete) > 0 else 0
        total_feasible = int(df_gen["n_feasible"].sum()) if "n_feasible" in df_gen.columns else 0
        
        # pareto_size now shows actual rank-0 count (non-dominated designs)
        latest_pareto = 0
        if "pareto_size" in df_complete.columns and len(df_complete) > 0:
            last_val = df_complete["pareto_size"].iloc[-1]
            if pd.notna(last_val):
                latest_pareto = int(last_val)
        
        col1.metric("Current Generation", latest_gen)
        col2.metric("Total Feasible", f"{total_feasible:,}")
        col3.metric("Pareto Size", latest_pareto)
        
        if "hypervolume" in df_gen.columns and df_gen["hypervolume"].notna().any():
            # Get last non-null HV value (the last row may be a placeholder with NaN)
            hv_values = df_gen["hypervolume"].dropna()
            if len(hv_values) > 0:
                latest_hv = hv_values.iloc[-1]
                col4.metric("Hypervolume", f"{latest_hv:.4e}")
            else:
                col4.metric("Hypervolume", "N/A")
        else:
            col4.metric("Hypervolume", "N/A")
        
        # Hypervolume convergence plot
        st.subheader("Hypervolume Convergence")
        if "hypervolume" in df_gen.columns and df_gen["hypervolume"].notna().any():
            fig_hv = px.line(
                df_gen[df_gen["hypervolume"].notna()],
                x="gen_num",
                y="hypervolume",
                markers=True,
                title="Hypervolume Over Generations"
            )
            fig_hv.update_layout(
                xaxis_title="Generation",
                yaxis_title="Hypervolume",
                template="plotly_white"
            )
            st.plotly_chart(fig_hv, use_container_width=True)
        else:
            st.info("Hypervolume data not yet available")
        
        # Pareto size convergence
        st.subheader("Pareto Front Size")
        if "pareto_size" in df_gen.columns and df_gen["pareto_size"].notna().any():
            fig_ps = px.line(
                df_gen[df_gen["pareto_size"].notna()],
                x="gen_num",
                y="pareto_size",
                markers=True,
                title="Pareto Front Size Over Generations"
            )
            fig_ps.update_layout(
                xaxis_title="Generation",
                yaxis_title="Pareto Size",
                template="plotly_white"
            )
            st.plotly_chart(fig_ps, use_container_width=True)
        
        # Feasibility bar chart
        st.subheader("Population Feasibility")
        if "n_feasible" in df_gen.columns and "n_infeasible" in df_gen.columns:
            fig_feas = go.Figure()
            fig_feas.add_trace(go.Bar(
                x=df_gen["gen_num"],
                y=df_gen["n_feasible"],
                name="Feasible",
                marker_color="green"
            ))
            fig_feas.add_trace(go.Bar(
                x=df_gen["gen_num"],
                y=df_gen["n_infeasible"],
                name="Infeasible",
                marker_color="red"
            ))
            fig_feas.update_layout(
                barmode="stack",
                xaxis_title="Generation",
                yaxis_title="Count",
                template="plotly_white"
            )
            st.plotly_chart(fig_feas, use_container_width=True)
    
    # === TAB 2: PARETO FRONTIER ===
    with tab2:
        st.header("Current Pareto Frontier")
        
        if df_pareto.empty:
            st.warning("No Pareto front data available yet")
        else:
            # Merge with target results to get IKP/Volume columns
            df_viz = df_pareto.copy()
            if not df_targets.empty:
                # Pivot targets to wide format
                try:
                    ikp_pivot = df_targets.pivot(
                        index='design_uuid', 
                        columns='target_name', 
                        values='integrated_kill_potential'
                    )
                    ikp_pivot.columns = [f"ikp_{c}" for c in ikp_pivot.columns]
                    
                    vol_pivot = df_targets.pivot(
                        index='design_uuid', 
                        columns='target_name', 
                        values='volume_at_threshold'
                    )
                    vol_pivot.columns = [f"vol_{c}" for c in vol_pivot.columns]
                    
                    targets_wide = pd.concat([ikp_pivot, vol_pivot], axis=1).reset_index()
                    df_viz = df_viz.merge(targets_wide, on="design_uuid", how="left")
                except Exception:
                    pass  # Keep original df_viz if pivot fails
            
            st.markdown(f"**{len(df_viz)} feasible designs from latest generation**")
            
            # Identify objective columns (exclude metadata)
            exclude_cols = ["design_uuid", "gen_num", "is_pareto", "feasible"]
            obj_cols = [c for c in df_viz.columns if c not in exclude_cols]
            
            if len(obj_cols) >= 2:
                # Pairwise scatter
                st.subheader("Objective Tradeoffs")
                col1, col2, col3 = st.columns(3)
                x_axis = col1.selectbox("X Axis", obj_cols, index=0)
                y_axis = col2.selectbox("Y Axis", obj_cols, index=min(1, len(obj_cols)-1))
                color_by = col3.selectbox("Color By", obj_cols + ["gen_num"], index=len(obj_cols))
                
                fig_scatter = px.scatter(
                    df_viz,
                    x=x_axis,
                    y=y_axis,
                    color=color_by,
                    hover_data=["design_uuid"],
                    title=f"{y_axis} vs {x_axis}"
                )
                fig_scatter.update_layout(template="plotly_white")
                st.plotly_chart(fig_scatter, use_container_width=True)
                
                # Parallel coordinates
                if len(obj_cols) >= 3:
                    st.subheader("Parallel Coordinates")
                    sel_dims = st.multiselect(
                        "Dimensions",
                        obj_cols,
                        default=obj_cols[:min(5, len(obj_cols))]
                    )
                    if sel_dims:
                        fig_par = px.parallel_coordinates(
                            df_viz,
                            dimensions=sel_dims,
                            color=sel_dims[0] if sel_dims else None,
                            color_continuous_scale=px.colors.diverging.Tealrose
                        )
                        st.plotly_chart(fig_par, use_container_width=True)
            
            # Design table - selectable
            st.subheader("Designs Data")
            st.caption("Click a row to select for drill-down")
            
            event = st.dataframe(
                df_viz,
                use_container_width=True,
                hide_index=True,
                selection_mode="single-row",
                on_select="rerun"
            )
            
            # Store selection in session state
            if event and event.selection and event.selection.get("rows"):
                selected_idx = event.selection["rows"][0]
                selected_uuid = df_viz.iloc[selected_idx]["design_uuid"]
                st.session_state["selected_design_uuid"] = selected_uuid
                st.success(f"Selected: `{selected_uuid}` — Go to Drill-Down tab to view details")

    # === TAB 3: ANALYSIS ===
    with tab3:
        st.header("Multi-Objective Analysis")

        if df_pareto.empty:
            st.warning("No Pareto front data available for analysis")
        else:
            # Prepare data with merged targets
            df_analysis = df_pareto.copy()
            if not df_targets.empty:
                try:
                    ikp_pivot = df_targets.pivot(
                        index='design_uuid',
                        columns='target_name',
                        values='integrated_kill_potential'
                    )
                    ikp_pivot.columns = [f"ikp_{c}" for c in ikp_pivot.columns]

                    vol_pivot = df_targets.pivot(
                        index='design_uuid',
                        columns='target_name',
                        values='volume_at_threshold'
                    )
                    vol_pivot.columns = [f"vol_{c}" for c in vol_pivot.columns]

                    targets_wide = pd.concat([ikp_pivot, vol_pivot], axis=1).reset_index()
                    df_analysis = df_analysis.merge(targets_wide, on="design_uuid", how="left")
                except Exception:
                    pass

            # Identify objective columns
            exclude_cols = ["design_uuid", "gen_num", "is_pareto", "feasible"]
            obj_cols = [c for c in df_analysis.columns if c not in exclude_cols and df_analysis[c].dtype in ['float64', 'int64', 'float32', 'int32']]

            if len(obj_cols) < 2:
                st.warning("Need at least 2 numeric objective columns for analysis")
            else:
                # Sub-tabs for different analysis types
                analysis_tabs = st.tabs(["Projections", "Correlations", "Distributions"])

                with analysis_tabs[0]:  # Projections
                    if not SKLEARN_AVAILABLE:
                        st.warning("Scikit-learn not installed. `pip install scikit-learn`")
                    else:
                        st.subheader("Dimensionality Reduction")

                        # Build available methods
                        proj_methods = ["PCA (Linear)", "t-SNE (Non-linear)"]
                        if UMAP_AVAILABLE:
                            proj_methods.append("UMAP (Fast Non-linear)")

                        col1, col2, col3 = st.columns(3)
                        proj_method = col1.selectbox("Method", proj_methods, key="prog_proj_method")
                        proj_dims = col2.radio("Dimensions", [2, 3], horizontal=True, key="prog_proj_dims")

                        # n_jobs slider for t-SNE/UMAP
                        if proj_method.startswith("t-SNE") or proj_method.startswith("UMAP"):
                            n_jobs = col3.slider(
                                "CPU Cores", 1, 8, 2,
                                help="Keep low on login nodes",
                                key="prog_proj_njobs"
                            )
                        else:
                            n_jobs = 1

                        proj_features = st.multiselect(
                            "Features to Project", obj_cols, default=obj_cols,
                            key="prog_proj_features"
                        )

                        if len(proj_features) >= 2 and len(df_analysis) >= 5:
                            X = df_analysis[proj_features].values
                            imputer = SimpleImputer(strategy='mean')
                            X = imputer.fit_transform(X)
                            scaler = StandardScaler()
                            X_scaled = scaler.fit_transform(X)

                            if proj_method.startswith("PCA"):
                                reducer = PCA(n_components=proj_dims)
                                proj_data = reducer.fit_transform(X_scaled)
                                labels = {f"C{i+1}": f"PC{i+1} ({var:.1f}%)"
                                          for i, var in enumerate(reducer.explained_variance_ratio_ * 100)}
                            elif proj_method.startswith("UMAP"):
                                reducer = umap.UMAP(
                                    n_components=proj_dims,
                                    n_neighbors=min(15, len(df_analysis) - 1),
                                    min_dist=0.1,
                                    n_jobs=n_jobs,
                                    random_state=42
                                )
                                proj_data = reducer.fit_transform(X_scaled)
                                labels = {f"C{i+1}": f"UMAP {i+1}" for i in range(proj_dims)}
                            else:
                                perp = min(30, len(df_analysis) - 1)
                                reducer = TSNE(n_components=proj_dims, perplexity=perp, n_jobs=n_jobs, random_state=42)
                                proj_data = reducer.fit_transform(X_scaled)
                                labels = {f"C{i+1}": f"t-SNE {i+1}" for i in range(proj_dims)}

                            proj_df = df_analysis.copy()
                            for i in range(proj_dims):
                                proj_df[f"PROJ_{i}"] = proj_data[:, i]

                            color_col = st.selectbox("Color By", obj_cols + ["gen_num"], key="prog_proj_color")

                            if proj_dims == 3:
                                fig_proj = px.scatter_3d(
                                    proj_df, x="PROJ_0", y="PROJ_1", z="PROJ_2",
                                    color=color_col,
                                    hover_data=["design_uuid"],
                                    labels={"PROJ_0": labels["C1"], "PROJ_1": labels["C2"], "PROJ_2": labels["C3"]},
                                    title=f"{proj_method} Projection (3D)"
                                )
                            else:
                                fig_proj = px.scatter(
                                    proj_df, x="PROJ_0", y="PROJ_1",
                                    color=color_col,
                                    hover_data=["design_uuid"],
                                    labels={"PROJ_0": labels["C1"], "PROJ_1": labels["C2"]},
                                    title=f"{proj_method} Projection (2D)"
                                )
                            st.plotly_chart(fig_proj, use_container_width=True)
                        else:
                            st.info("Select at least 2 features and need at least 5 data points")

                with analysis_tabs[1]:  # Correlations
                    st.subheader("Objective Correlations")
                    st.caption("Negative correlations (blue) indicate trade-offs between objectives.")
                    if len(obj_cols) >= 2:
                        fig_corr = plot_objective_correlation_heatmap(df_analysis, obj_cols)
                        st.plotly_chart(fig_corr, use_container_width=True)
                    else:
                        st.info("Need at least 2 objectives")

                with analysis_tabs[2]:  # Distributions
                    st.subheader("Objective Distributions")
                    st.caption("Violin plots show distribution across Pareto front (normalized to [0,1]).")
                    if len(obj_cols) >= 1:
                        fig_dist = plot_objective_distributions(df_analysis, obj_cols)
                        st.plotly_chart(fig_dist, use_container_width=True)
                    else:
                        st.info("No objective columns found")

    # === TAB 4: DRILL-DOWN ===
    with tab4:
        st.header("Design Drill-Down (Read-Only)")
        
        st.info("This is a read-only view. For MEGADETH regeneration, use `gdwh dashboard`.")
        
        if df_pareto.empty:
            st.warning("No designs available for drill-down")
        else:
            # Design selector - uses selection from Pareto tab if available
            design_options = df_pareto["design_uuid"].tolist() if "design_uuid" in df_pareto.columns else []
            
            if design_options:
                # Default to session state selection if available
                default_idx = 0
                if "selected_design_uuid" in st.session_state:
                    try:
                        default_idx = design_options.index(st.session_state["selected_design_uuid"])
                    except ValueError:
                        pass
                
                selected_uuid = st.selectbox("Select Design", design_options, index=default_idx)
                
                if selected_uuid:
                    st.markdown(f"### Design: `{selected_uuid}`")
                    
                    # Show design properties from Pareto table
                    design_row = df_pareto[df_pareto["design_uuid"] == selected_uuid]
                    if not design_row.empty:
                        st.subheader("Design Properties")
                        prop_cols = st.columns(3)
                        for i, col in enumerate(design_row.columns):
                            if col != "design_uuid":
                                val = design_row[col].iloc[0]
                                if pd.notna(val):
                                    prop_cols[i % 3].metric(col.replace("_", " ").title(), f"{val:.4f}" if isinstance(val, float) else str(val))
                    
                    # Show target results if available
                    if not df_targets.empty and "design_uuid" in df_targets.columns:
                        design_targets = df_targets[df_targets["design_uuid"] == selected_uuid].copy()
                        if not design_targets.empty:
                            # Try to convert target_name to int for better x-axis sorting
                            try:
                                # Handle strings like 'target_1' or just '1'
                                if design_targets["target_name"].dtype == object:
                                    design_targets["target_id"] = design_targets["target_name"].apply(
                                        lambda x: int(''.join(filter(str.isdigit, str(x)))) if any(c.isdigit() for c in str(x)) else str(x)
                                    )
                                else:
                                    design_targets["target_id"] = design_targets["target_name"]
                            except Exception:
                                design_targets["target_id"] = design_targets["target_name"]

                            st.subheader("Target Performance")
                            
                            col_ikp, col_vol = st.columns(2)
                            
                            with col_ikp:
                                if "integrated_kill_potential" in design_targets.columns:
                                    fig_ikp = px.bar(
                                        design_targets.sort_values("target_id"),
                                        x="target_id",
                                        y="integrated_kill_potential",
                                        title="IKP by Target",
                                        labels={"target_id": "Target ID", "integrated_kill_potential": "IKP"},
                                        color="integrated_kill_potential",
                                        color_continuous_scale="Viridis"
                                    )
                                    fig_ikp.update_layout(xaxis=dict(type='category'))
                                    st.plotly_chart(fig_ikp, use_container_width=True)
                            
                            with col_vol:
                                if "volume_at_threshold" in design_targets.columns:
                                    fig_vol = px.bar(
                                        design_targets.sort_values("target_id"),
                                        x="target_id",
                                        y="volume_at_threshold",
                                        title="Volume by Target",
                                        labels={"target_id": "Target ID", "volume_at_threshold": "Volume"},
                                        color="volume_at_threshold",
                                        color_continuous_scale="Magenta"
                                    )
                                    fig_vol.update_layout(xaxis=dict(type='category'))
                                    st.plotly_chart(fig_vol, use_container_width=True)
                            
                            # Table
                            st.dataframe(design_targets.drop(columns=["target_id"], errors="ignore"), use_container_width=True, hide_index=True)

    # === TAB 5: USAGE STATS ===
    with tab5:
        render_usage_stats_tab(output_dir)

    # Auto-refresh
    if auto_refresh:
        time.sleep(refresh_interval)
        st.rerun()


if __name__ == "__main__":
    main()
