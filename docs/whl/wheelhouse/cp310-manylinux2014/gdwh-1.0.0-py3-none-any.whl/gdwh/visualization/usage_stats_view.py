"""Usage stats tab for the progress dashboard."""

import json
from pathlib import Path

import streamlit as st
import pandas as pd
import plotly.express as px


def render_usage_stats_tab(output_dir: Path):
    """
    Render usage stats tab in progress dashboard.

    Args:
        output_dir: Path to optimization output directory
    """
    st.header("Node Usage Statistics")

    stats_file = output_dir / "usage_stats.json"
    if not stats_file.exists():
        st.info(
            "No usage stats collected yet. Stats are recorded at generation start/end "
            "when running with MPI."
        )
        return

    try:
        with open(stats_file) as f:
            history = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        st.error(f"Failed to load usage stats: {e}")
        return

    if not history:
        st.info("No usage data recorded yet.")
        return

    # Latest stats
    latest = history[-1]
    st.subheader(f"Latest: Generation {latest['generation']} ({latest['phase']})")

    summary = latest.get("summary", {})

    # Key metrics
    cols = st.columns(4)
    cols[0].metric("Nodes", summary.get("node_count", 0))
    cols[1].metric(
        "SHM Max Used",
        f"{summary.get('shm_used_max_mb', 0):.0f} MB",
    )
    cols[2].metric(
        "SHM Max %",
        f"{summary.get('shm_percent_max', 0):.1f}%",
    )
    cols[3].metric(
        "Megadeth Dirs",
        summary.get("megadeth_dirs_total", 0),
    )

    # Alert if SHM usage is high
    shm_percent = summary.get("shm_percent_max", 0)
    if shm_percent > 90:
        st.error(
            f"WARNING: /dev/shm usage is at {shm_percent:.1f}% on at least one node! "
            "Risk of 'No space on device' errors."
        )
    elif shm_percent > 75:
        st.warning(
            f"High /dev/shm usage ({shm_percent:.1f}%). Consider monitoring closely."
        )

    # Per-node details
    st.subheader("Per-Node Details")
    nodes = latest.get("nodes", [])
    if nodes:
        nodes_df = pd.DataFrame(nodes)
        display_cols = [
            "hostname",
            "rank",
            "shm_used_mb",
            "shm_percent_used",
            "mem_percent_used",
            "megadeth_dir_count",
        ]
        # Only show columns that exist
        display_cols = [c for c in display_cols if c in nodes_df.columns]
        st.dataframe(nodes_df[display_cols], use_container_width=True)

    # Historical trend
    st.subheader("Historical Trend")
    trend_data = []
    for record in history:
        row = {
            "generation": record["generation"],
            "phase": record["phase"],
        }
        row.update(record.get("summary", {}))
        trend_data.append(row)

    trend_df = pd.DataFrame(trend_data)

    if not trend_df.empty and "shm_used_max_mb" in trend_df.columns:
        # SHM usage over time
        fig_shm = px.line(
            trend_df,
            x="generation",
            y="shm_used_max_mb",
            color="phase",
            title="Max /dev/shm Usage Over Generations (MB)",
            markers=True,
        )
        st.plotly_chart(fig_shm, use_container_width=True)

        # Megadeth directories over time
        if "megadeth_dirs_total" in trend_df.columns:
            fig_dirs = px.line(
                trend_df,
                x="generation",
                y="megadeth_dirs_total",
                color="phase",
                title="Total Megadeth Temp Directories Over Generations",
                markers=True,
            )
            st.plotly_chart(fig_dirs, use_container_width=True)

    # Memory usage
    if not trend_df.empty and "mem_used_avg_percent" in trend_df.columns:
        fig_mem = px.line(
            trend_df,
            x="generation",
            y="mem_used_avg_percent",
            color="phase",
            title="Average Memory Usage Over Generations (%)",
            markers=True,
        )
        st.plotly_chart(fig_mem, use_container_width=True)

    # Raw data expander
    with st.expander("Raw Data"):
        st.json(latest)
