"""
Modular analysis views for GDWH Dashboard.

This module contains reusable view functions for different analysis modes,
ported from the MEGADETH analytics dashboard with GDWH-specific adaptations.
"""

import duckdb
import streamlit as st
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path
from typing import Optional, Dict, Any, Union, Tuple
import tempfile
import os
from gdwh.storage.hdf5_writer import HDF5Reader

# Consistent float formatting across dashboard views
pd.options.display.float_format = lambda v: f"{v:.2f}"

from .charts import (
    plot_pk_heatmap_plotly,
    plot_3d_volume_plotly,
    plot_hob_mr_contour_plotly,
    plot_iso_mesh_colored_by_pk,
    plot_salvo_boxplot_plotly,
    plot_r2k_heatmap_plotly,
    compute_hob_mr_grid,
    plot_stoplight_grid_plotly,
    plot_error_model_pdf_plotly,
    plot_pk_vs_vel_hob_plotly,
    plot_r2k_stoplight_plotly,
    plot_multi_threshold_boxplot_plotly,
    plot_mc_draw_diagnostics_plotly,
    plot_radar_chart,
    normalize_hypercube_to_native,
    compute_curvature,
)
from gdwh.config.schema import CampaignConfig

import logging

logger = logging.getLogger(__name__)


# =============================================================================
# Data Loading Utilities
# =============================================================================

def load_analysis_context(
    conn: duckdb.DuckDBPyConnection,
    design_uuid: str,
    campaign_id: str,
    root_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Load all analysis data for a design into a unified context dictionary.

    Returns:
        Dictionary with keys: pk_path, disc_path, mc_path, axes, config
    """
    context = {
        'pk_path': None,
        'disc_path': None,
        'mc_path': None,
        'pk_data': None,
        'disc_data': None,
        'mc_data': None,
        'axes': None,
        'config': {},
        'config_raw': {},
        'design_uuid': design_uuid,
        'campaign_id': campaign_id,
        'targets': {},
    }

    resolved_root = root_dir.resolve() if root_dir else None
    resolved_root_parent = resolved_root.parent if resolved_root else None

    # Load campaign config early to get storage roots
    storage_root = None
    storage_root_parent = None
    h5_path = None

    try:
        config_query = "SELECT config_yaml FROM campaigns WHERE campaign_id = ?"
        result = conn.execute(config_query, [campaign_id]).fetchone()
        if result and result[0]:
            import yaml
            config_dict = yaml.safe_load(result[0])
            context['config_raw'] = config_dict
            try:
                context['config'] = CampaignConfig.model_validate(config_dict)
            except Exception:
                context['config'] = config_dict

            try:
                # Extract consolidated_dir (HDF5 or Legacy NPZ)
                consolidated_dir = None
                
                # Check for HDF5 config first
                if isinstance(context['config'], CampaignConfig):
                    if hasattr(context['config'].storage, 'hdf5') and context['config'].storage.hdf5:
                        consolidated_dir = context['config'].storage.hdf5.consolidated_dir
                    elif hasattr(context['config'].storage, 'npz') and context['config'].storage.npz:
                        consolidated_dir = context['config'].storage.npz.consolidated_dir
                
                # Fallback to raw dict search if object lookup failed
                if consolidated_dir is None and isinstance(context['config_raw'], dict):
                    storage_cfg = context['config_raw'].get('storage', {})
                    if 'hdf5' in storage_cfg:
                        consolidated_dir = Path(storage_cfg['hdf5'].get('consolidated_dir', ''))
                    elif 'npz' in storage_cfg:
                        # Legacy fallback
                        consolidated_dir = Path(storage_cfg['npz'].get('consolidated_dir', ''))

                # Resolve relative consolidated_dir against root_dir
                if consolidated_dir:
                    if not Path(consolidated_dir).is_absolute() and resolved_root:
                        storage_root = resolved_root / consolidated_dir
                    else:
                        storage_root = Path(consolidated_dir)
                    
                    # ADR-009: Try per-generation file first (DB Lookup)
                    try:
                        row = conn.execute(
                            """
                            SELECT gf.hdf5_path
                            FROM evaluations e
                            JOIN generations g ON e.gen_id = g.gen_id
                            JOIN generation_files gf ON g.campaign_id = gf.campaign_id 
                                                     AND g.gen_num = gf.generation
                            WHERE e.design_uuid = ? AND g.campaign_id = ?
                            LIMIT 1
                            """,
                            [design_uuid, campaign_id]
                        ).fetchone()
                        
                        if row and row[0]:
                            found_gen_path = Path(row[0])
                            
                            # Resolve path strategies
                            if found_gen_path.is_absolute() and found_gen_path.exists():
                                h5_path = found_gen_path
                            elif resolved_root and (resolved_root / found_gen_path).exists():
                                h5_path = resolved_root / found_gen_path
                            elif (storage_root and (storage_root / found_gen_path.name).exists()):
                                # Try in consolidated dir if filename matches
                                h5_path = storage_root / found_gen_path.name
                            elif found_gen_path.exists():
                                h5_path = found_gen_path
                    except Exception:
                        pass

                    # Legacy fallback: Campaign consolidated file
                    if not h5_path:
                        possible_h5 = storage_root / f"{campaign_id}.h5"
                        if possible_h5.exists():
                            h5_path = possible_h5
                    
                    storage_root_parent = storage_root.parent if storage_root else None
                else:
                    storage_root = None
                    storage_root_parent = None
            except Exception:
                storage_root = None
                storage_root_parent = None
    except Exception:
        pass

    # --- STRATEGY 1: HDF5 (Unified Storage) ---
    if h5_path and h5_path.exists():
        try:
            with HDF5Reader(h5_path) as reader:
                if reader.has_design(design_uuid):
                    # Load axes from metadata if possible, or from specific target
                    # (HDF5Writer typically stores axes in metadata/axes or inside each design)
                    # For now, we try to grab axes from the first target we load
                    
                    targets_map = get_target_npz_map(conn, design_uuid)
                    
                    first = True
                    for tgt_name, meta in targets_map.items():
                        target_id = meta.get("target_id")
                        
                        # Load data eagerly
                        pk_data = reader.load_data(design_uuid, target_id, 'pk')
                        disc_data = reader.load_data(design_uuid, target_id, 'discrete')
                        mc_data = reader.load_data(design_uuid, target_id, 'mc')
                        
                        targets_map[tgt_name].update({
                            "pk_data": pk_data,
                            "disc_data": disc_data,
                            "mc_data": mc_data,
                            "pk_path": f"{h5_path}::/designs/{design_uuid}/targets/{target_id}/pk", # Virtual path
                            "disc_path": f"{h5_path}::/designs/{design_uuid}/targets/{target_id}/discrete",
                        })
                        
                        if first and pk_data:
                            context['pk_data'] = pk_data
                            context['disc_data'] = disc_data
                            context['mc_data'] = mc_data
                            
                            # Extract axes from pk_data
                            if not context.get('axes'):
                                context['axes'] = {
                                    'vel': pk_data.get('vel'),
                                    'hob': pk_data.get('hob'),
                                    'miss_x': pk_data.get('miss_x'),
                                    'miss_y': pk_data.get('miss_y'),
                                    'aof': pk_data.get('aof'),
                                }
                                # Share axes with target
                                targets_map[tgt_name]['axes'] = context['axes']
                            
                            first = False

                    context['targets'] = targets_map
                    return context
        except Exception as e:
            st.warning(f"Failed to read from HDF5: {e}")

    # --- STRATEGY 2: Legacy NPZ (Distributed Storage) ---
    # Load NPZ data for all targets tied to this design
    search_roots = [p for p in [resolved_root, resolved_root_parent, storage_root, storage_root_parent] if p]
    targets_map = get_target_npz_map(conn, design_uuid)

    # Resolve paths per target and keep backward-compatible top-level paths
    first_resolved_path = None
    for tgt_name, meta in targets_map.items():
        raw_pk = _resolve_npz_uuid(conn, meta.get("pk_uuid"))
        raw_disc = _resolve_npz_uuid(conn, meta.get("discrete_uuid"))

        resolved_pk = resolve_npz_path(raw_pk, search_roots) if raw_pk else None
        resolved_disc = resolve_npz_path(raw_disc, search_roots) if raw_disc else None

        if not resolved_pk and raw_pk:
            roots_text = ", ".join(str(r) for r in search_roots) if search_roots else "CWD"
            st.warning(f"Pk NPZ not found for target {tgt_name} at {raw_pk} (searched {roots_text})")
        if not resolved_disc and raw_disc:
            roots_text = ", ".join(str(r) for r in search_roots) if search_roots else "CWD"
            st.warning(f"Discrete NPZ not found for target {tgt_name} at {raw_disc} (searched {roots_text})")

        targets_map[tgt_name].update(
            {
                "pk_path": resolved_pk if resolved_pk else (Path(raw_pk) if raw_pk else None),
                "disc_path": resolved_disc if resolved_disc else (Path(raw_disc) if raw_disc else None),
            }
        )

        if not first_resolved_path and (resolved_pk or resolved_disc):
            first_resolved_path = resolved_pk or resolved_disc
            context['pk_path'] = resolved_pk
            context['disc_path'] = resolved_disc

    context['targets'] = targets_map

    if not first_resolved_path:
        st.error(f"No Analysis Data found for design {design_uuid} (Checked: HDF5, NPZ).")
    else:
        # Extract axes from the first available NPZ (geometry shared across targets)
        context['axes'] = extract_axes_from_npz(first_resolved_path)
        if not context['axes']:
            st.warning(f"Could not extract axes from {first_resolved_path}")
        else:
            missing_axes = [k for k in ['hob', 'vel', 'aof'] if context['axes'].get(k) is None]
            if missing_axes:
                st.warning(f"Missing axes {', '.join(missing_axes)} in NPZ for design {design_uuid}")

    return context


def get_npz_path(conn, design_uuid: str, data_type: str = 'discrete') -> Optional[str]:
    """Get path to data file (NPZ) for a design."""
    try:
        query_uuid = f"""
        SELECT {data_type}_npz_uuid
        FROM target_results t
        JOIN evaluations e ON t.eval_id = e.eval_id
        WHERE e.design_uuid = ? AND {data_type}_npz_uuid IS NOT NULL
        ORDER BY t.eval_id DESC
        LIMIT 1
        """
        result = conn.execute(query_uuid, [design_uuid]).fetchone()
        if not result or not result[0]:
            return None

        npz_uuid = result[0]

        query_path = """
        SELECT consolidated_path, original_path
        FROM npz_registry
        WHERE npz_uuid = ?
        """
        path_res = conn.execute(query_path, [npz_uuid]).fetchone()
        if path_res:
            path = path_res[0] if path_res[0] else path_res[1]
            return path
    except Exception:
        pass
    return None


def load_npz_data(path: str, root_dir: Optional[Path] = None) -> Optional[Dict]:
    """Load NPZ file."""
    if not path:
        return None

    p = Path(path)

    # First try provided path (absolute or relative to CWD)
    if p.exists():
        try:
            with np.load(p) as data:
                return dict(data)
        except Exception:
            return None

    # Then try relative to supplied root directory
    if root_dir:
        p_root = root_dir / path
        if p_root.exists():
            try:
                with np.load(p_root) as data:
                    return dict(data)
            except Exception:
                return None

    # Fallback to original relative resolution
    p_cwd = Path.cwd() / path
    if not p_cwd.exists():
        return None

    try:
        with np.load(p_cwd) as data:
            return dict(data)
    except Exception:
        return None


def resolve_npz_path(path: Optional[str], roots: Optional[Tuple[Path, ...]]) -> Optional[Path]:
    """
    Resolve NPZ path using provided roots and current working directory.

    Handles both absolute paths and relative paths, including legacy paths
    that may have mismatched prefixes (e.g., 'output/npz/' when root already
    includes 'output/').
    """
    if not path:
        return None

    p = Path(path)

    # Try absolute path first
    if p.is_absolute() and p.exists():
        return p

    # Try path as-is from CWD
    if p.exists():
        return p.resolve()

    candidates = []

    # For relative paths, try with roots
    if roots:
        for root in roots:
            # Direct join
            candidates.append(root / path)

            # Strip leading 'output/' if present (common mismatch when
            # root_dir is already the 'output' directory)
            path_parts = p.parts
            if path_parts and path_parts[0] == 'output':
                stripped = Path(*path_parts[1:])
                candidates.append(root / stripped)

            # Try just the filename (for UUID-named NPZ files)
            candidates.append(root / p.name)

    # CWD fallback
    candidates.append(Path.cwd() / path)

    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()

    # Log failure for debugging
    logger.debug(f"Failed to resolve NPZ path: {path}, tried: {[str(c) for c in candidates]}")
    return None


def _resolve_npz_uuid(conn: duckdb.DuckDBPyConnection, npz_uuid: Optional[str]) -> Optional[str]:
    """
    Resolve an NPZ UUID to its consolidated/original path using the registry.
    """
    if not npz_uuid:
        return None

    try:
        row = conn.execute(
            """
            SELECT consolidated_path, original_path
            FROM npz_registry
            WHERE npz_uuid = ?
            """,
            [npz_uuid],
        ).fetchone()
        if row:
            return row[0] or row[1]
    except Exception:
        pass
    return None


def get_target_npz_map(conn: duckdb.DuckDBPyConnection, design_uuid: str) -> Dict[str, Dict[str, Any]]:
    """
    Return NPZ UUIDs and target metadata for all targets associated with a design.
    """
    targets: Dict[str, Dict[str, Any]] = {}

    try:
        rows = conn.execute(
            """
            SELECT
                t.target_id,
                t.target_name,
                t.pk_npz_uuid,
                t.discrete_npz_uuid,
                t.integrated_kill_potential,
                t.volume_at_threshold,
                t.eval_id
            FROM target_results t
            JOIN evaluations e ON t.eval_id = e.eval_id
            WHERE e.design_uuid = ?
            ORDER BY t.eval_id DESC, t.target_id
            """,
            [design_uuid],
        ).fetchall()
    except Exception:
        return targets

    for row in rows:
        (
            target_id,
            target_name,
            pk_uuid,
            disc_uuid,
            ikp,
            volume,
            _eval_id,
        ) = row

        # Deduplicate by target name (keep most recent eval_id due to ORDER BY)
        key = target_name or str(target_id)
        if key in targets:
            continue

        targets[key] = {
            "target_id": target_id,
            "pk_uuid": pk_uuid,
            "discrete_uuid": disc_uuid,
            "ikp": ikp,
            "volume": volume,
        }

    return targets


def extract_axes_from_npz(npz_path: Path) -> Optional[Dict[str, np.ndarray]]:
    """Extract axis arrays from NPZ without loading heavy datasets."""
    try:
        with np.load(npz_path, mmap_mode="r") as data:
            def get_axis(*keys):
                for key in keys:
                    if key in data:
                        return data[key]
                return None

            axes = {
                'hob': get_axis('hob_axis', 'hob'),
                'vel': get_axis('velocity_axis', 'vel_axis', 'vel'),
                'aof': get_axis('aof_axis', 'aof'),
                'miss_x': get_axis('miss_x_axis', 'miss_x'),
                'miss_y': get_axis('miss_y_axis', 'miss_y'),
            }
            if any(axis is not None for axis in axes.values()):
                return axes
    except Exception:
        return None
    return None


@st.cache_data
def load_cached_npz(path: Union[str, Path], root_dir: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Cached NPZ loader for on-demand data access."""
    resolved_root = Path(root_dir) if root_dir else None
    return load_npz_data(str(path), root_dir=resolved_root)


def _ensure_npz_loaded(
    npz_source: Optional[Union[Dict[str, Any], str, Path]],
    root_dir: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    """Return NPZ dictionary, loading from disk if a path was provided."""
    if npz_source is None:
        return None
    if isinstance(npz_source, dict):
        return npz_source
    return load_cached_npz(str(npz_source), str(root_dir) if root_dir else None)


def _get_precision_config(config: Union[CampaignConfig, Dict[str, Any]]) -> Dict[str, Any]:
    """Access precision config as a dictionary regardless of backing type."""
    if isinstance(config, CampaignConfig):
        try:
            return config.precision.model_dump()
        except Exception:
            return {}
    if isinstance(config, dict):
        return config.get('precision', {}) or {}
    return {}


def _get_discrete_pk_threshold(config: Union[CampaignConfig, Dict[str, Any]], default: float = 0.5) -> float:
    """Extract discrete analysis pk_threshold if present."""
    if isinstance(config, CampaignConfig):
        discrete_cfg = getattr(config, 'discrete_analysis', None)
        if discrete_cfg and hasattr(discrete_cfg, 'pk_threshold'):
            try:
                return float(discrete_cfg.pk_threshold)
            except Exception:
                return default
    if isinstance(config, dict):
        return float(config.get('discrete_analysis', {}).get('pk_threshold', default))
    return default


def get_zdata_obj(conn, design_uuid: str):
    """Load ZDATA object for a design."""
    try:
        from megadeth.physics.zdata import read_zdata
    except ImportError:
        return None

    try:
        query = "SELECT zdata_bytes FROM zdata_store WHERE design_uuid = ?"
        result = conn.execute(query, [design_uuid]).fetchone()

        if not result or not result[0]:
            return None

        zdata_bytes = result[0]

        with tempfile.NamedTemporaryFile(suffix=".DAT", delete=False) as tmp:
            tmp.write(zdata_bytes)
            tmp_path = Path(tmp.name)

        try:
            zdata = read_zdata(tmp_path)
        finally:
            try:
                os.unlink(tmp_path)
            except:
                pass

        return zdata
    except Exception:
        return None


def process_zdata_for_radar(zdata):
    """Helper to process ZDATA object into metrics for plotting."""
    if not zdata:
        return None, None, None, None

    FT_TO_M = 0.3048
    GRAINS_TO_KG = 6.479891e-5
    GRAINS_TO_GRAMS = 0.06479891

    raw_angles = [z.angle_mid for z in zdata.zones]
    raw_masses = [z.total_mass for z in zdata.zones]
    raw_masses_grams = [m * GRAINS_TO_GRAMS for m in raw_masses]

    raw_velocities = []
    raw_energies_mj = []

    for z in zdata.zones:
        m_grains = z.total_mass
        ke_raw = z.total_ke

        if m_grains > 0:
            v_fps = np.sqrt(2 * ke_raw / m_grains)
            v_mps = v_fps * FT_TO_M
        else:
            v_mps = 0

        m_kg = m_grains * GRAINS_TO_KG
        ke_j = 0.5 * m_kg * (v_mps**2)
        ke_mj = ke_j / 1e6

        raw_velocities.append(v_mps)
        raw_energies_mj.append(ke_mj)

    # Mirror data
    angles = raw_angles + [360 - a for a in reversed(raw_angles)]
    masses_grams = raw_masses_grams + list(reversed(raw_masses_grams))
    velocities = raw_velocities + list(reversed(raw_velocities))
    energies = raw_energies_mj + list(reversed(raw_energies_mj))

    angles.append(angles[0])
    masses_grams.append(masses_grams[0])
    velocities.append(velocities[0])
    energies.append(energies[0])

    return angles, masses_grams, velocities, energies


# =============================================================================
# Modular View Functions
# =============================================================================

def render_campaign_statistics(
    disc_data: Optional[Union[Dict[str, Any], str, Path]],
    mc_data: Optional[Dict],
    pk_data: Optional[Union[Dict[str, Any], str, Path]],
    root_dir: Optional[Path] = None,
) -> None:
    """
    Render campaign statistics view showing system-level metrics.
    """
    st.subheader("Campaign Statistics")

    disc_loaded = _ensure_npz_loaded(disc_data, root_dir=root_dir)

    if not disc_loaded or 'system_pk' not in disc_loaded:
        st.warning("No discrete analysis data available for statistics.")
        return

    sys_pk = disc_loaded['system_pk']

    # Summary Statistics
    st.markdown("### System Pk Summary")
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("Max System Pk", f"{np.max(sys_pk):.2f}")
    with col2:
        st.metric("Mean System Pk", f"{np.mean(sys_pk):.2f}")
    with col3:
        st.metric("Std Dev", f"{np.std(sys_pk):.2f}")
    with col4:
        # Robustness: fraction of conditions above 0.5
        robust_frac = np.sum(sys_pk > 0.5) / sys_pk.size
        st.metric("Robustness (Pk>0.5)", f"{robust_frac:.2%}")

    # Rounds-to-Kill Statistics
    if 'rounds_to_kill' in disc_loaded and 'pk_thresholds' in disc_loaded:
        st.markdown("### Rounds-to-Kill Statistics")
        r2k = disc_loaded['rounds_to_kill']  # [H, V, A, T]
        thresholds = disc_loaded['pk_thresholds']

        # Create summary table
        stats_data = []
        for t_idx, thresh in enumerate(thresholds):
            r2k_slice = r2k[:, :, :, t_idx]
            stats_data.append({
                'Pk Threshold': f"{thresh:.2f}",
                'Min R2K': int(np.min(r2k_slice)),
                'Max R2K': int(np.max(r2k_slice)),
                'Mean R2K': f"{np.mean(r2k_slice):.2f}",
                'Median R2K': int(np.median(r2k_slice)),
            })

        st.dataframe(pd.DataFrame(stats_data), use_container_width=True)

        # Boxplot
        fig = plot_multi_threshold_boxplot_plotly(r2k, thresholds)
        st.plotly_chart(fig, use_container_width=True)


def render_weapon_characteristics(
    conn: duckdb.DuckDBPyConnection,
    design_uuid: str,
    config: Union[CampaignConfig, Dict[str, Any]],
) -> None:
    """
    Render weapon characteristics view showing ZDATA analysis and error model.
    """
    st.subheader("Weapon Characteristics")

    # Load ZDATA
    zdata = get_zdata_obj(conn, design_uuid)

    if not zdata:
        st.warning("No ZDATA available for this design.")
        return

    # ZDATA Radar Charts
    angles, masses_grams, velocities, energies = process_zdata_for_radar(zdata)

    st.markdown("### Fragment Distribution")
    c1, c2, c3 = st.columns(3)

    with c1:
        st.markdown("**Fragment Mass**")
        st.caption("Total Mass (grams)")
        fig = plot_radar_chart(masses_grams, angles, color="#1f77b4", title="")
        st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.markdown("**Fragment Velocity**")
        st.caption("Avg Velocity (m/s)")
        fig = plot_radar_chart(velocities, angles, color="#ff7f0e", title="")
        st.plotly_chart(fig, use_container_width=True)

    with c3:
        st.markdown("**Kinetic Energy**")
        st.caption("Total KE (MJ)")
        fig = plot_radar_chart(energies, angles, color="#2ca02c", title="")
        st.plotly_chart(fig, use_container_width=True)

    # Error Model Visualization (from config)
    st.markdown("---")
    st.markdown("### Delivery Error Model")

    err = _get_precision_config(config)
    if err:
        c1, c2 = st.columns([1, 2])

        with c1:
            tle_r = err.get('tle_radius_m', 0)
            tle_f = err.get('tle_fraction', 0.9)
            cep_r = err.get('cep_radius_m', 0)
            cep_f = err.get('cep_fraction', 0.5)
            bias_x = err.get('fixed_bias_deflection_m', 0)
            bias_y = err.get('fixed_bias_range_m', 0)

            st.metric("TLE Radius", f"{tle_r:.2f} m", f"P={tle_f:.0%}")
            st.metric("CEP Radius", f"{cep_r:.2f} m", f"P={cep_f:.0%}")

        with c2:
            fig_pdf = plot_error_model_pdf_plotly(
                tle_radius_m=tle_r,
                tle_fraction=tle_f,
                cep_radius_m=cep_r,
                cep_fraction=cep_f,
                bias_x_m=bias_x,
                bias_y_m=bias_y,
                height=400
            )
            st.plotly_chart(fig_pdf, use_container_width=True)
    else:
        st.info("No error model configured in campaign.")


def render_single_slice_analysis(
    pk_data: Optional[Union[Dict[str, Any], str, Path]],
    disc_data: Optional[Union[Dict[str, Any], str, Path]],
    axes: Dict,
    config: Union[CampaignConfig, Dict[str, Any]],
    root_dir: Optional[Path] = None,
) -> None:
    """
    Render single slice analysis view with interactive 2D plots.
    """
    st.subheader("Single Slice Analysis")

    if not axes or axes.get('hob') is None:
        st.error("No axis data available.")
        return

    hob = axes['hob']
    vel = axes['vel']
    aof = axes['aof']
    precision_cfg = _get_precision_config(config)

    # Controls
    col_ctrl, col_plot = st.columns([1, 3])

    with col_ctrl:
        # Plot type selector
        plot_options = []
        if pk_data:
            plot_options.extend(["Pk Contour (Miss Grid)", "HOB vs Miss Range Contour"])
        if disc_data:
            plot_options.extend(["System Pk (Vel vs HOB)", "Rounds-to-Kill Heatmap", "R2K Stoplight Grid"])

        plot_type = st.selectbox("Plot Type", plot_options)

        # Initialize indices to middle
        i_hob_idx = len(hob) // 2
        i_vel_idx = len(vel) // 2
        i_aof_idx = len(aof) // 2
        
        i_hob = hob[i_hob_idx]
        i_vel = vel[i_vel_idx]
        i_aof = aof[i_aof_idx]

        # Determine which sliders to show
        show_hob = plot_type == "Pk Contour (Miss Grid)"
        show_vel = plot_type in ["Pk Contour (Miss Grid)", "HOB vs Miss Range Contour"]
        show_aof = True # Always needed for current plots (unless we add A. vs V.)

        # Render Sliders
        if show_hob:
            i_hob = st.select_slider("HOB (m)", options=hob, value=i_hob)
            i_hob_idx = np.where(hob == i_hob)[0][0]

        if show_vel:
            i_vel = st.select_slider("Velocity (m/s)", options=vel, value=i_vel)
            i_vel_idx = np.where(vel == i_vel)[0][0]

        if show_aof:
            i_aof = st.select_slider("AOF (deg)", options=aof, value=i_aof)
            i_aof_idx = np.where(aof == i_aof)[0][0]

        # Weighted Pk toggle for miss grid
        use_weighted = False
        if plot_type == "Pk Contour (Miss Grid)" and precision_cfg:
            use_weighted = st.checkbox("Weight by Error Model", value=False)

    with col_plot:
        if plot_type == "Pk Contour (Miss Grid)" and pk_data:
            pk_loaded = _ensure_npz_loaded(pk_data, root_dir=root_dir)
            if not pk_loaded or 'pk_det' not in pk_loaded:
                st.warning("Pk data structure missing 'pk_det'.")
                return

            pk_det = pk_loaded['pk_det']
            pk_det = normalize_hypercube_to_native(pk_det, axes)
            pk_slice = pk_det[:, :, i_hob_idx, i_vel_idx, i_aof_idx]

            if use_weighted and precision_cfg:
                # Weight by error model PDF
                err = precision_cfg
                miss_x = axes['miss_x']
                miss_y = axes['miss_y']

                # Compute PDF (simplified - would need full implementation)
                X, Y = np.meshgrid(miss_x, miss_y, indexing='ij')
                r2 = X**2 + Y**2
                sigma = err.get('cep_radius_m', 2.0) / 0.674  # Rough approximation
                pdf = np.exp(-r2 / (2 * sigma**2))
                pdf = pdf / np.sum(pdf)

                weighted_pk = pk_slice * pdf
                display_pk = weighted_pk / weighted_pk.max() if weighted_pk.max() > 0 else weighted_pk

                fig = plot_pk_heatmap_plotly(
                    pk_slice=display_pk,
                    x_axis=miss_x,
                    y_axis=miss_y,
                    x_label="Miss Distance X (m)",
                    y_label="Miss Distance Y (m)",
                    title=f"Weighted Pk @ HOB={i_hob}m, Vel={i_vel}m/s, AOF={i_aof}°",
                    colorbar_title="Pk×PDF",
                )
                bias_x = err.get('fixed_bias_deflection_m', 0)
                bias_y = err.get('fixed_bias_range_m', 0)
                tle_r = err.get('tle_radius_m', 0)
                cep_r = err.get('cep_radius_m', 0)
                shapes = []
                if cep_r:
                    shapes.append(dict(
                        type="circle",
                        xref="x",
                        yref="y",
                        x0=bias_x - cep_r,
                        x1=bias_x + cep_r,
                        y0=bias_y - cep_r,
                        y1=bias_y + cep_r,
                        line=dict(color="orange", width=2, dash="dash"),
                    ))
                if tle_r:
                    shapes.append(dict(
                        type="circle",
                        xref="x",
                        yref="y",
                        x0=bias_x - tle_r,
                        x1=bias_x + tle_r,
                        y0=bias_y - tle_r,
                        y1=bias_y + tle_r,
                        line=dict(color="red", width=2, dash="dot"),
                    ))
                if shapes:
                    fig.update_layout(shapes=shapes)
            else:
                fig = plot_pk_heatmap_plotly(
                    pk_slice=pk_slice,
                    x_axis=axes['miss_x'],
                    y_axis=axes['miss_y'],
                    x_label="Miss Distance X (m)",
                    y_label="Miss Distance Y (m)",
                    title=f"Raw Pk @ HOB={i_hob}m, Vel={i_vel}m/s, AOF={i_aof}°",
                )
            st.plotly_chart(fig, use_container_width=True)

        elif plot_type == "System Pk (Vel vs HOB)" and disc_data:
            disc_loaded = _ensure_npz_loaded(disc_data, root_dir=root_dir)
            if not disc_loaded:
                st.warning("Discrete data unavailable for System Pk.")
                return

            sys_pk = disc_loaded.get('system_pk', disc_loaded.get('reliability'))
            slice_2d = sys_pk[:, :, i_aof_idx]

            fig = plot_pk_vs_vel_hob_plotly(
                slice_2d, vel, hob,
                title=f"System Pk @ AOF={i_aof}°"
            )
            st.plotly_chart(fig, use_container_width=True)

        elif plot_type == "HOB vs Miss Range Contour" and pk_data:
            pk_loaded = _ensure_npz_loaded(pk_data, root_dir=root_dir)
            if not pk_loaded or 'pk_det' not in pk_loaded:
                st.warning("Pk data structure missing 'pk_det'.")
                return

            pk_det = normalize_hypercube_to_native(pk_loaded['pk_det'], axes)

            mr_axis, pk_hob_mr = compute_hob_mr_grid(
                pk_det, hob, axes['miss_x'], axes['miss_y'], i_vel_idx, i_aof_idx
            )

            fig = plot_hob_mr_contour_plotly(hob, mr_axis, pk_hob_mr,
                                            title=f"HOB vs Miss Range @ Vel={i_vel}m/s, AOF={i_aof}°")
            st.plotly_chart(fig, use_container_width=True)

        elif plot_type == "Rounds-to-Kill Heatmap" and disc_data:
            disc_loaded = _ensure_npz_loaded(disc_data, root_dir=root_dir)
            if disc_loaded and 'rounds_to_kill' in disc_loaded:
                r2k = disc_loaded['rounds_to_kill']
                thresh_idx = 0
                r2k_slice = r2k[:, :, i_aof_idx, thresh_idx]

                fig = plot_r2k_heatmap_plotly(
                    r2k_slice, vel, hob,
                    x_label="Velocity (m/s)", y_label="HOB (m)",
                    title=f"R2K @ AOF={i_aof}°"
                )
                st.plotly_chart(fig, use_container_width=True)

        elif plot_type == "R2K Stoplight Grid" and disc_data:
            disc_loaded = _ensure_npz_loaded(disc_data, root_dir=root_dir)
            if disc_loaded and 'rounds_to_kill' in disc_loaded:
                r2k = disc_loaded['rounds_to_kill']
                thresh_idx = 0
                r2k_slice = r2k[:, :, i_aof_idx, thresh_idx]

                fig = plot_r2k_stoplight_plotly(
                    r2k_slice, vel, hob, title=f"Stoplight @ AOF={i_aof}°"
                )
                st.plotly_chart(fig, use_container_width=True)


def render_3d_volume_explorer(
    disc_data: Optional[Union[Dict[str, Any], str, Path]],
    axes: Dict,
    config: Union[CampaignConfig, Dict[str, Any]],
    root_dir: Optional[Path] = None,
) -> None:
    """
    Render 3D volume explorer view.
    """
    st.subheader("3D Volume Explorer")

    disc_loaded = _ensure_npz_loaded(disc_data, root_dir=root_dir)

    if not disc_loaded or 'system_pk' not in disc_loaded:
        st.warning("No discrete analysis data available for 3D visualization.")
        return

    sys_pk = disc_loaded['system_pk']
    hob = axes['hob']
    vel = axes['vel']
    aof = axes['aof']

    high_perf = st.checkbox("High Performance Mode (Downsample)", value=True)

    # Metric selection
    metric = st.radio("Metric", ["System Pk", "Sensitivity", "Curvature"], horizontal=True)

    data_3d = sys_pk
    if metric == "Sensitivity":
        grads = np.gradient(sys_pk)
        data_3d = np.sqrt(sum(g**2 for g in grads))
    elif metric == "Curvature":
        data_3d = compute_curvature(sys_pk)

    plot_data = data_3d
    plot_pk = sys_pk
    plot_hob = hob
    plot_vel = vel
    plot_aof = aof

    if high_perf:
        plot_data = data_3d[::2, ::2, ::2]
        plot_pk = sys_pk[::2, ::2, ::2]
        plot_hob = hob[::2]
        plot_vel = vel[::2]
        plot_aof = aof[::2]

    col_viz, col_opts = st.columns([3, 1])

    with col_opts:
        d_min = float(plot_data.min())
        d_max = float(plot_data.max())
        d_mean = float(plot_data.mean())

        if d_min < d_max:
            iso_val = st.slider("Isosurface Level", d_min, d_max, d_mean)
        else:
            st.info(f"Constant Field Value: {d_min:.2f}")
            iso_val = d_min

        opacity = st.slider("Opacity", 0.1, 1.0, 0.3)
        color_by_pk = st.checkbox("Color by Pk", value=(metric!="System Pk"))

    with col_viz:
        if color_by_pk and metric != "System Pk":
            fig = plot_iso_mesh_colored_by_pk(
                plot_data, plot_pk, plot_hob, plot_vel, plot_aof, iso_val, opacity
            )
        else:
            fig = plot_3d_volume_plotly(
                plot_data, plot_hob, plot_vel, plot_aof, opacity=opacity, colorbar_title=metric, iso_val=iso_val
            )
        st.plotly_chart(fig, use_container_width=True)

    # Envelope volume calculation
    st.markdown("---")
    st.markdown("### Envelope Volume Analysis")

    default_thresh = _get_discrete_pk_threshold(config, default=0.5)
    pk_threshold = st.slider("Pk Threshold", 0.0, 1.0, float(default_thresh), 0.05)

    # Calculate volume above threshold
    voxel_volume = (
        (hob[1] - hob[0]) *
        (vel[1] - vel[0]) *
        (aof[1] - aof[0])
    )
    n_voxels_above = np.sum(sys_pk > pk_threshold)
    total_volume = n_voxels_above * voxel_volume

    st.metric(f"Volume with Pk > {pk_threshold}", f"{total_volume:.2f} m·(m/s)·deg")
    st.caption(f"{n_voxels_above} / {sys_pk.size} terminal conditions meet threshold")

    # List terminal conditions meeting the threshold
    if n_voxels_above > 0:
        hits = np.argwhere(sys_pk > pk_threshold)
        rows = []
        for h_idx, v_idx, a_idx in hits:
            rows.append(
                {
                    "HOB (m)": float(hob[h_idx]),
                    "Velocity (m/s)": float(vel[v_idx]),
                    "AOF (deg)": float(aof[a_idx]),
                    "Pk": float(sys_pk[h_idx, v_idx, a_idx]),
                }
            )
        hits_df = pd.DataFrame(rows).sort_values("Pk", ascending=False)
        max_rows = 200
        if len(hits_df) > max_rows:
            st.caption(f"Showing top {max_rows} of {len(hits_df)} conditions (sorted by Pk)")
        st.dataframe(hits_df.head(max_rows), use_container_width=True, hide_index=True)


def render_mc_salvo_analysis(
    mc_data: Optional[Dict],
    config: Union[CampaignConfig, Dict[str, Any]],
) -> None:
    """
    Render Monte Carlo salvo analysis view.
    """
    st.subheader("MC Salvo Analysis")

    if not mc_data:
        st.info("No Monte Carlo analysis data available for this design.")
        st.markdown("""
        Monte Carlo analysis requires the campaign to be configured with:
        ```yaml
        monte_carlo:
          enabled: true
          n_draws: 1000
        ```
        """)
        return

    # Check for required MC data
    if 'mean_acc_pk_by_shot' not in mc_data:
        st.warning("MC data structure incomplete. Expected 'mean_acc_pk_by_shot' array.")
        return

    st.markdown("### Monte Carlo Simulation Results")

    # MC diagnostics would go here
    # This requires additional implementation based on MEGADETH dashboard
    st.info("MC Salvo Analysis implementation requires additional Monte Carlo data structures.")
