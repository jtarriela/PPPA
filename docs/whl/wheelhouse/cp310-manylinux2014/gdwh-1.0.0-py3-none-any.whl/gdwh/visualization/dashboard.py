import streamlit as st
import duckdb
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import yaml
import sys
import tempfile
import os
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

# Consistent float formatting across the dashboard
pd.options.display.float_format = lambda v: f"{v:.2f}"

# Add project root to path to ensure imports work if run directly
sys.path.append(str(Path(__file__).parent.parent.parent))

# Import Scikit-Learn for Projections
try:
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA
    from sklearn.manifold import TSNE
    from sklearn.impute import SimpleImputer
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

# Import UMAP (optional, faster than t-SNE for large datasets)
try:
    import umap
    UMAP_AVAILABLE = True
except ImportError:
    UMAP_AVAILABLE = False

from gdwh.visualization.charts import (
    plot_pk_heatmap_plotly,
    plot_3d_volume_plotly,
    plot_hob_mr_contour_plotly,
    plot_iso_mesh_colored_by_pk,
    plot_salvo_boxplot_plotly,
    plot_r2k_heatmap_plotly,
    plot_stoplight_grid_plotly,
    plot_error_model_pdf_plotly,
    plot_pk_vs_vel_hob_plotly,
    plot_r2k_stoplight_plotly,
    plot_multi_threshold_boxplot_plotly,
    plot_radar_chart,
    normalize_hypercube_to_native,
    detect_hypercube_format,
    compute_curvature,
    plot_objective_correlation_heatmap,
    plot_objective_distributions,
)

from gdwh.visualization.analysis_views_perf import (
    load_analysis_context,
    render_campaign_statistics,
    render_weapon_characteristics,
    render_single_slice_analysis,
    render_3d_volume_explorer,
    render_mc_salvo_analysis,
)
# =============================================================================
# Queue Management Functions (Database-Backed, ADR-006)
# =============================================================================
# Uses megadeth_queue table for persistent queueing across browser refreshes.
# Queue items can be processed by Dashboard modal or CLI `gdwh run-queue`.


def add_to_queue(design_uuid: str, campaign_id: str, target_id: int = None, priority: int = 0):
    """Add a design to the persistence database queue."""
    if 'db_conn' not in st.session_state or not st.session_state.db_conn:
        st.error("Database connection not available")
        return False
        
    try:
        # Check if already exists/pending
        conn = st.session_state.db_conn
        
        # ADR-006 Hardening: Check if data already exists to avoid redundant analysis
        data_params = [design_uuid]
        data_clause = "design_uuid = ? AND data_type = 'pk'"
        if target_id is not None:
            data_clause += " AND target_id = ?"
            data_params.append(target_id)
            
        has_data = conn.execute(f"SELECT 1 FROM hdf5_entries WHERE {data_clause}", data_params).fetchone()
        if has_data:
            return False

        # Handle NULL target_id correctly in SQL for queue table check
        if target_id is None:
            target_clause = "target_id IS NULL"
            params = [design_uuid, campaign_id]
        else:
            target_clause = "target_id = ?"
            params = [design_uuid, campaign_id, target_id]

        exists = conn.execute(f"""
            SELECT 1 FROM megadeth_queue 
            WHERE design_uuid = ? AND campaign_id = ? AND {target_clause}
            AND status IN ('pending', 'running')
        """, params).fetchone()
        
        if exists:
            return False
            
        conn.execute("""
            INSERT INTO megadeth_queue 
            (design_uuid, campaign_id, target_id, priority, status, requested_at)
            VALUES (?, ?, ?, ?, 'pending', now())
            ON CONFLICT (design_uuid, campaign_id, target_id) 
            DO UPDATE SET status = 'pending', priority = ?, requested_at = now(), error_message = NULL
        """, [design_uuid, campaign_id, target_id, priority, priority])
        conn.commit()
        return True
    except Exception as e:
        logger.error(f"Failed to add to queue: {e}")
        # st.error(f"Failed to add to queue: {e}") # Suppress ID error in UI
        return False


def get_queue_stats(campaign_id: str = None):
    """Get queue statistics from database."""
    if 'db_conn' not in st.session_state or not st.session_state.db_conn:
        return {'pending': 0, 'running': 0, 'completed': 0, 'failed': 0, 'total': 0}
        
    try:
        conn = st.session_state.db_conn
        df = conn.execute("""
            SELECT status, COUNT(*) as count 
            FROM megadeth_queue 
            WHERE campaign_id = ?
            GROUP BY status
        """, [campaign_id]).df()
        
        stats = {
            'pending': 0, 'running': 0, 'completed': 0, 'failed': 0
        }
        for _, row in df.iterrows():
            if row['status'] in stats:
                stats[row['status']] = int(row['count'])
            
        stats['total'] = sum(stats.values())
        return stats
    except Exception:
        return {'pending': 0, 'running': 0, 'completed': 0, 'failed': 0, 'total': 0}


def get_queue_items(campaign_id: str = None, limit: int = 100):
    """Get queue items from database."""
    if 'db_conn' not in st.session_state or not st.session_state.db_conn:
        return pd.DataFrame(columns=['design_uuid', 'campaign_id', 'target_id', 'status'])
        
    try:
        conn = st.session_state.db_conn
        df = conn.execute("""
            SELECT * FROM megadeth_queue
            WHERE campaign_id = ?
            ORDER BY requested_at DESC
            LIMIT ?
        """, [campaign_id, limit]).df()
        return df
    except Exception:
        return pd.DataFrame(columns=['design_uuid', 'campaign_id', 'target_id', 'status'])


def clear_queue_items(campaign_id: str = None, status: str = None):
    """Clear queue items from database."""
    if 'db_conn' not in st.session_state or not st.session_state.db_conn:
        return False
        
    try:
        conn = st.session_state.db_conn
        if status:
            conn.execute("""
                DELETE FROM megadeth_queue 
                WHERE campaign_id = ? AND status = ?
            """, [campaign_id, status])
        else:
            # Clear all
            conn.execute("""
                DELETE FROM megadeth_queue 
                WHERE campaign_id = ?
            """, [campaign_id])
        conn.commit()
        return True
    except Exception as e:
        logger.error(f"Failed to clear queue: {e}")
        return False


@st.dialog("MEGADETH Analysis Running", width="large")
def execute_queue_modal(db_path: str, campaign_id: str, root_dir=None):
    """Modal that locks UI during queue execution."""
    st.warning("Dashboard is locked. Please wait for analysis to complete.")
    
    # Close dashboard DB connection to avoid lock conflicts
    try:
        if 'db_conn' in st.session_state and st.session_state.db_conn:
            st.session_state.db_conn.close()
    except Exception:
        pass
    
    # Clear the connection cache so it reconnects after rerun
    get_db_connection.clear()
    
    # Imports for processing
    import importlib
    import gdwh.queue.processor
    importlib.reload(gdwh.queue.processor)
    from gdwh.queue.processor import QueueProcessor, load_campaign_config_from_db
    
    progress = st.progress(0, text="Initializing...")
    status = st.empty()
    
    # Create a processor instance
    processor = QueueProcessor(
        db_path=Path(db_path),
        config_loader=lambda cid: None
    )
    
    try:
        # Open connection
        processor._conn = duckdb.connect(db_path)
        processor.config_loader = lambda cid: load_campaign_config_from_db(Path(db_path), cid, conn=processor._conn)
        
        # Count total pending (approximate)
        try:
            total_pending = processor._conn.execute(
                "SELECT COUNT(*) FROM megadeth_queue WHERE status = 'pending'"
            ).fetchone()[0]
        except:
            total_pending = 1
            
        st.info(f"Processing queue ({total_pending} items pending)...")
        
        headers_checked = False
        completed = 0
        processed_total = 0
        errors = []
        
        while True:
            # Claim batch from DB
            items = processor._claim_batch()
            if not items:
                break
                
            for item in items:
                processed_total += 1
                uuid = item['design_uuid']
                status.text(f"Analyzing design {uuid[:8]}... ({processed_total}/{total_pending if total_pending > 0 else '?'})")
                
                try:
                    processor._process_single(item)
                    processor._mark_completed(item['queue_id'])
                    completed += 1
                except Exception as e:
                    processor._mark_failed(item['queue_id'], str(e))
                    errors.append(f"{uuid[:8]}: {str(e)}")
                    logger.error(f"Failed to analyze {uuid}: {e}", exc_info=True)
                
                if total_pending > 0:
                    prog = min(1.0, processed_total / total_pending)
                    progress.progress(prog, text=f"{processed_total}/{total_pending} complete")
                    
    finally:
        # Clean up processor connection
        if processor._conn:
            processor._conn.close()
    
    if errors:
        st.error(f"{len(errors)} failed:\n" + "\n".join(errors[:5]))
        if len(errors) > 5:
            st.write(f"... and {len(errors)-5} more.")
            
    st.success(f"Completed {completed}/{processed_total} analyses")
    
    if st.button("Close & Refresh Dashboard", type="primary"):
        st.rerun()


def retry_failed_items(conn, campaign_id: str):
    """Reset failed queue items back to pending."""
    try:
        db_path = conn.execute("PRAGMA database_list").fetchone()[2]
        write_conn = duckdb.connect(db_path)
        write_conn.execute("""
            UPDATE megadeth_queue
            SET status = 'pending', error_message = NULL, started_at = NULL, worker_id = NULL
            WHERE campaign_id = ? AND status = 'failed'
        """, [campaign_id])
        write_conn.commit()
        write_conn.close()
        return True
    except Exception as e:
        st.error(f"Failed to retry items: {e}")
        return False


def check_pk_availability(conn, design_uuid: str, campaign_id: str):
    """Check if Pk hypercube data is available for a design."""
    try:
        result = conn.execute("""
            SELECT COUNT(*) FROM hdf5_entries
            WHERE design_uuid = ? AND data_type = 'pk'
        """, [design_uuid]).fetchone()
        return result[0] > 0 if result else False
    except Exception:
        return False


def get_queue_status_for_design(design_uuid: str, campaign_id: str):
    """Get queue status for a specific design from database."""
    if 'db_conn' not in st.session_state or not st.session_state.db_conn:
        return None
        
    try:
        conn = st.session_state.db_conn
        result = conn.execute("""
            SELECT status, requested_at, error_message
            FROM megadeth_queue
            WHERE design_uuid = ? AND campaign_id = ?
            ORDER BY requested_at DESC
            LIMIT 1
        """, [design_uuid, campaign_id]).fetchone()
        
        if result:
            return {
                'status': result[0],
                'requested_at': result[1],
                'error': result[2]
            }
        return None
    except Exception:
        return None

# Page Configuration
st.set_page_config(
    page_title="GDWH Optimization Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)

# =============================================================================
# Database & Data Loading
# =============================================================================

@st.cache_resource
def get_db_connection(db_path: str):
    """Connect to DuckDB."""
    try:
        # Default to read_only=False to match other processes and avoid configuration mismatches
        conn = duckdb.connect(db_path)
        return conn
    except Exception as e:
        st.error(f"Failed to connect to database at {db_path}: {e}")
        return None

def load_campaign_info(conn):
    """Load campaign configuration and status."""
    try:
        df = conn.execute("SELECT * FROM campaigns ORDER BY created_at DESC LIMIT 1").df()
        if not df.empty:
            return df.iloc[0]
        return None
    except Exception:
        return None

def load_generations(conn, campaign_id):
    """Load generation statistics."""
    query = """
    SELECT gen_num, pop_size, n_feasible, n_infeasible, 
           hypervolume, best_ikp, best_volume 
    FROM generations 
    WHERE campaign_id = ? 
    ORDER BY gen_num
    """
    return conn.execute(query, [campaign_id]).df()

@st.cache_data(ttl=30)
def _get_pk_availability_set(db_path: str, campaign_id: str) -> set:
    """
    Get set of design_uuids that have Pk data available.
    Cached separately to avoid recomputing on every Streamlit rerun.

    ADR-019: This fixes checkbox disappearing in Design Explorer with large HDF5 files.
    """
    conn = duckdb.connect(db_path, read_only=True)
    try:
        result = conn.execute("""
            SELECT DISTINCT h.design_uuid
            FROM hdf5_entries h
            JOIN evaluations e ON h.design_uuid = e.design_uuid
            JOIN generations g ON e.gen_id = g.gen_id
            WHERE g.campaign_id = ? AND h.data_type = 'pk'
        """, [campaign_id]).fetchall()
        return {row[0] for row in result}
    finally:
        conn.close()

@st.cache_data(ttl=30, show_spinner="Loading evaluations...")
def load_evaluations_flat(db_path: str, campaign_id: str) -> pd.DataFrame:
    """
    Load all evaluations with pivoted target results and aggregate metrics.
    Returns a DataFrame with one row per design.

    Args:
        db_path: Path to DuckDB database
        campaign_id: Campaign identifier
    """
    # ADR-019: Removed expensive EXISTS subquery - use cached set lookup instead
    evals_query = """
        SELECT
            e.eval_id, e.design_uuid, e.gen_id, g.gen_num,
            e.feasible, e.total_mass_kg, e.charge_mass_kg, e.frag_mass_kg,
            json_extract(e.metadata, '$.original_eval_id') AS original_eval_id,
            json_extract(e.metadata, '$.source') AS metadata_source,
            e.is_pareto, e.pareto_rank
        FROM evaluations e
        JOIN generations g ON e.gen_id = g.gen_id
        WHERE g.campaign_id = ?
    """

    targets_query = """
        SELECT 
            t.eval_id,
            t.target_name,
            t.integrated_kill_potential,
            t.volume_at_threshold
        FROM target_results t
        JOIN evaluations e ON t.eval_id = e.eval_id
        JOIN generations g ON e.gen_id = g.gen_id
        WHERE g.campaign_id = ?
    """

    conn = duckdb.connect(db_path, read_only=True)
    try:
        try:
            evals_df = conn.execute(evals_query, [campaign_id]).df()
        except Exception:
            return pd.DataFrame()

        # ADR-019: Add has_pk column using cached set lookup (fast O(1) per row)
        if not evals_df.empty:
            pk_uuids = _get_pk_availability_set(db_path, campaign_id)
            evals_df["has_pk"] = evals_df["design_uuid"].isin(pk_uuids)
        else:
            evals_df["has_pk"] = False

        try:
            targets_df = conn.execute(targets_query, [campaign_id]).df()
        except Exception:
            targets_df = pd.DataFrame()

        if targets_df.empty:
            return evals_df

        # Pivot targets into one row per eval with IKP/Vol columns per target
        try:
            ikp_pivot = targets_df.pivot(index="eval_id", columns="target_name", values="integrated_kill_potential")
            ikp_pivot.columns = [f"ikp_{c}" for c in ikp_pivot.columns]

            vol_pivot = targets_df.pivot(index="eval_id", columns="target_name", values="volume_at_threshold")
            vol_pivot.columns = [f"vol_{c}" for c in vol_pivot.columns]

            pivot_df = pd.concat([ikp_pivot, vol_pivot], axis=1)

            # --- CALCULATE AGGREGATES ---
            ikp_cols = [c for c in pivot_df.columns if c.startswith("ikp_")]
            if ikp_cols:
                pivot_df["total_ikp"] = pivot_df[ikp_cols].sum(axis=1)
                pivot_df["mean_ikp"] = pivot_df[ikp_cols].mean(axis=1)

            vol_cols = [c for c in pivot_df.columns if c.startswith("vol_")]
            if vol_cols:
                pivot_df["total_vol"] = pivot_df[vol_cols].sum(axis=1)
                pivot_df["mean_vol"] = pivot_df[vol_cols].mean(axis=1)

            pivot_df = pivot_df.reset_index()
        except Exception:
            return evals_df

        return evals_df.merge(pivot_df, on="eval_id", how="left")
    finally:
        conn.close()


def _downsample_for_plot(df: pd.DataFrame, max_points: int = 10000) -> pd.DataFrame:
    """Downsample large DataFrames for plotting performance (ADR-020)."""
    if df is None or df.empty or len(df) <= max_points:
        return df
    return df.sample(n=max_points, random_state=42)


@st.cache_data(ttl=300, max_entries=20, show_spinner="Computing projection...")
def _compute_projection(
    X_scaled: np.ndarray,
    method: str,
    n_dims: int,
    n_jobs: int,
) -> tuple[np.ndarray, dict]:
    """Cached dimensionality reduction for the Pareto projection tab (ADR-020)."""
    if method == "pca":
        reducer = PCA(n_components=n_dims)
        proj_data = reducer.fit_transform(X_scaled)
        labels = {
            f"C{i+1}": f"PC{i+1} ({var:.1f}%)"
            for i, var in enumerate(reducer.explained_variance_ratio_ * 100)
        }
        return proj_data, labels

    if method == "umap":
        reducer = umap.UMAP(
            n_components=n_dims,
            n_neighbors=min(15, X_scaled.shape[0] - 1),
            min_dist=0.1,
            n_jobs=n_jobs,
            random_state=42,
        )
        proj_data = reducer.fit_transform(X_scaled)
        labels = {f"C{i+1}": f"UMAP {i+1}" for i in range(n_dims)}
        return proj_data, labels

    # t-SNE
    perp = min(30, X_scaled.shape[0] - 1)
    reducer = TSNE(n_components=n_dims, perplexity=perp, n_jobs=n_jobs, random_state=42)
    proj_data = reducer.fit_transform(X_scaled)
    labels = {f"C{i+1}": f"t-SNE {i+1}" for i in range(n_dims)}
    return proj_data, labels

def get_zdata_bytes(conn, design_uuid):
    """Fetch raw ZDATA bytes from the database."""
    try:
        query = "SELECT zdata_bytes FROM zdata_store WHERE design_uuid = ?"
        result = conn.execute(query, [design_uuid]).fetchone()
        if not result or not result[0]:
            return None
        return result[0]
    except Exception:
        return None

def get_zdata_obj(conn, design_uuid):
    """Load ZDATA object for a design."""
    try:
        from megadeth.physics.zdata import read_zdata
    except ImportError:
        st.error("MEGADETH library not found. Cannot parse ZDATA.")
        return None

    zdata_bytes = get_zdata_bytes(conn, design_uuid)
    if not zdata_bytes:
        return None
    
    with tempfile.NamedTemporaryFile(suffix=".DAT", delete=False) as tmp:
        tmp.write(zdata_bytes)
        tmp_path = Path(tmp.name)
        
    try:
        zdata = read_zdata(tmp_path)
    except Exception as e:
        st.error(f"Error parsing ZDATA: {e}")
        zdata = None
    finally:
        try:
            os.unlink(tmp_path)
        except:
            pass
            
    return zdata

def process_zdata_for_radar(zdata):
    """Helper to process ZDATA object into metrics for plotting."""
    if not zdata:
        return None, None, None, None
        
    FT_TO_M = 0.3048
    GRAINS_TO_KG = 6.479891e-5
    GRAINS_TO_GRAMS = 0.06479891
    
    raw_angles = [z.angle_mid for z in zdata.zones]
    raw_masses = [z.total_mass for z in zdata.zones]
    raw_masses_grams = [m * GRAINS_TO_GRAMS for m in raw_masses]
    
    raw_velocities = []
    raw_energies_mj = []
    
    for z in zdata.zones:
        m_grains = z.total_mass
        ke_raw = z.total_ke
        
        if m_grains > 0:
            v_fps = np.sqrt(2 * ke_raw / m_grains)
            v_mps = v_fps * FT_TO_M
        else:
            v_mps = 0
            
        m_kg = m_grains * GRAINS_TO_KG
        ke_j = 0.5 * m_kg * (v_mps**2)
        ke_mj = ke_j / 1e6
        
        raw_velocities.append(v_mps)
        raw_energies_mj.append(ke_mj)
        
    angles = raw_angles + [360 - a for a in reversed(raw_angles)]
    masses_grams = raw_masses_grams + list(reversed(raw_masses_grams))
    velocities = raw_velocities + list(reversed(raw_velocities))
    energies = raw_energies_mj + list(reversed(raw_energies_mj))
    
    angles.append(angles[0])
    masses_grams.append(masses_grams[0])
    velocities.append(velocities[0])
    energies.append(energies[0])
    
    return angles, masses_grams, velocities, energies

# =============================================================================
# Main App
# =============================================================================

def main():
    if 'compare_list' not in st.session_state:
        st.session_state['compare_list'] = []

    st.sidebar.title("GDWH Dashboard")
    
    default_db = "output/optimization.duckdb"
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        default_db = sys.argv[1]
        
    db_path = st.sidebar.text_input("Database Path", value=default_db)
    
    if not Path(db_path).exists():
        st.warning(f"Database not found at {db_path}")
        return

    root_dir = Path(db_path).parent.resolve()
    # Heuristic: if DB is in 'output', assume project root is one level up
    # This prevents double 'output/output' in HDF5 path resolution
    if root_dir.name == 'output':
        root_dir = root_dir.parent
    conn = get_db_connection(db_path)
    st.session_state.db_conn = conn
    if not conn:
        return

    campaign = load_campaign_info(conn)
    if campaign is None:
        st.error("No campaign found in database.")
        return

    st.sidebar.success(f"Connected: {campaign.get('name', 'Unknown')}")
    st.sidebar.caption(f"Status: {campaign.get('status', 'Unknown')}")
    
    # Navigation
    pages = ["Home", "Optimization Progress", "Pareto Frontier", "Design Explorer", "Drill Down Analysis", "Comparison", "Queue Management"]
    selection = st.sidebar.radio("Navigation", pages, key="nav_selection")
    
    st.sidebar.markdown("---")
    st.sidebar.markdown("---")
    st.sidebar.subheader("Analysis Queue")
    q_stats = get_queue_stats(campaign['campaign_id'])
    st.sidebar.metric("Pending Designs", q_stats['pending'])
    
    if q_stats['pending'] > 0:
        if st.sidebar.button("Execute Queue", type="primary", use_container_width=True):
            execute_queue_modal(db_path, campaign['campaign_id'], root_dir=root_dir)
        if st.sidebar.button("Clear Queue", use_container_width=True):
            clear_queue_items(campaign['campaign_id'])
            st.sidebar.success("Queue cleared")
            st.rerun()
    else:
        st.sidebar.info("Queue is empty. Select designs in the 'Design Explorer' to add.")
    
    # --- HOME PAGE ---
    if selection == "Home":
        st.title(f"Campaign: {campaign.get('name', 'Unknown')}")
        
        # Stats logic
        try:
            if pd.isna(campaign.get('n_generations')) or campaign.get('n_generations') is None:
                n_gen = conn.execute("SELECT COUNT(*) FROM generations WHERE campaign_id=?", [campaign['campaign_id']]).fetchone()[0]
            else:
                n_gen = campaign['n_generations']
                
            if pd.isna(campaign.get('total_evaluations')) or campaign.get('total_evaluations') is None:
                n_eval = conn.execute("SELECT COUNT(*) FROM evaluations e JOIN generations g ON e.gen_id=g.gen_id WHERE g.campaign_id=?", [campaign['campaign_id']]).fetchone()[0]
            else:
                n_eval = campaign['total_evaluations']
                
            if pd.isna(campaign.get('total_runtime_sec')) or campaign.get('total_runtime_sec') is None:
                times = conn.execute("SELECT MIN(evaluated_at), MAX(evaluated_at) FROM evaluations e JOIN generations g ON e.gen_id=g.gen_id WHERE g.campaign_id=?", [campaign['campaign_id']]).fetchone()
                if times and times[0] and times[1]:
                    runtime_sec = (times[1] - times[0]).total_seconds()
                else:
                    runtime_sec = 0
            else:
                runtime_sec = campaign['total_runtime_sec']
        except Exception:
            n_gen = 0
            n_eval = 0
            runtime_sec = 0

        col1, col2 = st.columns(2)
        with col1:
            st.markdown("### Configuration")
            st.write(f"**ID:** `{campaign['campaign_id']}`")
            st.write(f"**Created:** {campaign.get('created_at', 'N/A')}")
            st.write(f"**Population:** {campaign.get('population_size', 'N/A')}")
            st.write(f"**Generations:** {n_gen}")
            
        with col2:
            st.markdown("### Status")
            st.metric("Total Evaluations", f"{n_eval:,}")
            if runtime_sec > 0:
                hours = runtime_sec / 3600
                st.metric("Runtime", f"{hours:.2f} hrs")
            else:
                st.metric("Runtime", "N/A")

    # --- OPTIMIZATION PROGRESS ---
    elif selection == "Optimization Progress":
        st.title("Optimization Progress")
        df_gen = load_generations(conn, campaign['campaign_id'])
        
        if df_gen.empty:
            st.warning("No generation data available yet.")
        else:
            st.subheader("Convergence: Hypervolume")
            if 'hypervolume' in df_gen.columns and df_gen['hypervolume'].notna().any():
                fig_hv = px.line(df_gen, x='gen_num', y='hypervolume', markers=True, title="Hypervolume")
                st.plotly_chart(fig_hv, use_container_width=True)
            
            st.subheader("Population Health")
            fig_pop = go.Figure()
            fig_pop.add_trace(go.Scatter(x=df_gen['gen_num'], y=df_gen['n_feasible'], name='Feasible', fill='tozeroy'))
            fig_pop.add_trace(go.Scatter(x=df_gen['gen_num'], y=df_gen['n_infeasible'], name='Infeasible', fill='tonexty'))
            st.plotly_chart(fig_pop, use_container_width=True)

    # --- PARETO FRONTIER & PROJECTIONS ---
    elif selection == "Pareto Frontier":
        st.title("Pareto Frontier & Projections")

        df = load_evaluations_flat(db_path, campaign["campaign_id"])

        if df.empty:
            st.warning("No evaluation data available.")
        else:
            c1, c2 = st.columns(2)
            show_all = c1.checkbox("Show All Designs (including dominated)", value=False)
            
            if show_all:
                plot_df = df
            else:
                plot_df = df[df['is_pareto'] == True]
            
            exclude_cols = ['design_uuid', 'violation', 'metadata_source', 'original_eval_id', 
                            'is_pareto', 'pareto_rank', 'gen_id', 'eval_id', 'gen_num', 'feasible']
            
            ikp_cols = [c for c in plot_df.columns if 'ikp' in c.lower() and c not in exclude_cols]
            vol_cols = [c for c in plot_df.columns if 'vol' in c.lower() and c not in exclude_cols]
            mass_cols = [c for c in ['total_mass_kg', 'charge_mass_kg', 'frag_mass_kg'] if c in plot_df.columns]
            
            all_obj_cols = sorted(list(set(mass_cols + ikp_cols + vol_cols)))
            
            if not all_obj_cols:
                st.warning("No objective columns found (IKP/Volume/Mass). Check database.")
            else:
                # --- 1. PROJECTION ANALYSIS (t-SNE / PCA / UMAP) ---
                st.subheader("Interactive Projection (Clustering Analysis)")
                if not SKLEARN_AVAILABLE:
                    st.warning("Scikit-learn is not installed. Projections unavailable. `pip install scikit-learn`")
                else:
                    # Build available methods list
                    proj_methods = ["PCA (Linear)", "t-SNE (Non-linear)"]
                    if UMAP_AVAILABLE:
                        proj_methods.append("UMAP (Fast Non-linear)")

                    with st.expander("Projection Settings", expanded=True):
                        col_p1, col_p2, col_p3 = st.columns(3)
                        proj_method = col_p1.selectbox("Method", proj_methods)
                        proj_dims = col_p2.radio("Dimensions", [2, 3], horizontal=True)

                        # n_jobs slider for t-SNE/UMAP (login node friendly)
                        if proj_method.startswith("t-SNE") or proj_method.startswith("UMAP"):
                            n_jobs = col_p3.slider(
                                "CPU Cores",
                                min_value=1,
                                max_value=8,
                                value=2,
                                help="Keep low on login nodes to avoid resource contention"
                            )
                        else:
                            n_jobs = 1

                        proj_features = st.multiselect("Features to Project", all_obj_cols, default=all_obj_cols)

                    if len(proj_features) < 2:
                        st.info("Select at least 2 features for projection.")
                    elif len(plot_df) < 5:
                        st.info("Not enough data points for projection (need > 5).")
                    else:
                        # Downsample aggressively for projection methods that don't scale well.
                        proj_input_df = _downsample_for_plot(plot_df, max_points=20000)
                        if len(proj_input_df) < len(plot_df):
                            st.caption(f"Downsampled to {len(proj_input_df):,} points for projection performance.")

                        # Prepare data
                        X = proj_input_df[proj_features].values

                        # Handle NaNs
                        imputer = SimpleImputer(strategy='mean')
                        X = imputer.fit_transform(X)

                        # Scale
                        scaler = StandardScaler()
                        X_scaled = scaler.fit_transform(X)

                        # Compute Projection (cached)
                        method_key = "pca" if proj_method.startswith("PCA") else ("umap" if proj_method.startswith("UMAP") else "tsne")
                        proj_data, labels = _compute_projection(X_scaled, method_key, proj_dims, n_jobs)

                        # Create Projection DataFrame
                        proj_df = proj_input_df.copy()
                        for i in range(proj_dims):
                            proj_df[f"PROJ_{i}"] = proj_data[:, i]

                        # Coloring
                        color_col = st.selectbox("Color Clusters By", all_obj_cols + ['gen_num'], index=0)

                        if proj_dims == 3:
                            fig_proj = px.scatter_3d(
                                proj_df, x="PROJ_0", y="PROJ_1", z="PROJ_2",
                                color=color_col,
                                hover_data=['design_uuid', 'total_mass_kg'],
                                labels={"PROJ_0": labels["C1"], "PROJ_1": labels["C2"], "PROJ_2": labels["C3"]},
                                title=f"{proj_method} Projection (3D)"
                            )
                        else:
                            render_mode = "webgl" if len(proj_df) > 5000 else "auto"
                            fig_proj = px.scatter(
                                proj_df, x="PROJ_0", y="PROJ_1",
                                color=color_col,
                                hover_data=['design_uuid', 'total_mass_kg'],
                                labels={"PROJ_0": labels["C1"], "PROJ_1": labels["C2"]},
                                title=f"{proj_method} Projection (2D)",
                                render_mode=render_mode,
                            )
                        
                        st.plotly_chart(fig_proj, use_container_width=True)
                        st.caption("Projections help identify 'islands' of similar performance in high-dimensional space.")

                # --- 2. Objective Analysis ---
                st.markdown("---")
                st.subheader("Objective Tradeoffs")

                tabs = st.tabs(["Pairwise Scatter", "Parallel Coordinates", "Scatter Matrix", "Correlations", "Distributions"])

                with tabs[0]:  # Pairwise
                    col1, col2, col3 = st.columns(3)
                    x_axis = col1.selectbox("X Axis", all_obj_cols, index=0)
                    y_axis = col2.selectbox("Y Axis", all_obj_cols, index=1 if len(all_obj_cols) > 1 else 0)
                    c_axis = col3.selectbox("Color", all_obj_cols + ['gen_num'], index=2 if len(all_obj_cols) > 2 else 0)

                    scatter_df = _downsample_for_plot(plot_df, max_points=10000)
                    render_mode = "webgl" if len(scatter_df) > 5000 else "auto"
                    fig = px.scatter(
                        scatter_df, x=x_axis, y=y_axis, color=c_axis,
                        hover_data=['design_uuid'], title=f"{y_axis} vs {x_axis}",
                        template="plotly_white",
                        render_mode=render_mode,
                    )
                    st.plotly_chart(fig, use_container_width=True)

                with tabs[1]:  # Parallel Coords
                    default_dims = ['total_mass_kg', 'total_ikp', 'mean_ikp', 'total_vol']
                    avail_dims = [c for c in default_dims if c in plot_df.columns]
                    if len(avail_dims) < 3:
                        avail_dims = all_obj_cols[:5]

                    sel_dims = st.multiselect("Dimensions", all_obj_cols, default=avail_dims)
                    if sel_dims:
                        par_df = _downsample_for_plot(plot_df, max_points=5000)
                        fig_par = px.parallel_coordinates(
                            par_df, dimensions=sel_dims,
                            color=sel_dims[0],
                            color_continuous_scale=px.colors.diverging.Tealrose
                        )
                        st.plotly_chart(fig_par, use_container_width=True)

                with tabs[2]:  # Matrix
                    sel_mat_dims = st.multiselect("Matrix Dims", all_obj_cols, default=all_obj_cols[:4])
                    if len(sel_mat_dims) > 1:
                        mat_df = _downsample_for_plot(plot_df, max_points=2000)
                        fig_mat = px.scatter_matrix(
                            mat_df, dimensions=sel_mat_dims,
                            color=c_axis, title="Scatter Matrix"
                        )
                        fig_mat.update_traces(diagonal_visible=False, showupperhalf=False)
                        fig_mat.update_layout(height=800)
                        st.plotly_chart(fig_mat, use_container_width=True)

                with tabs[3]:  # Correlations
                    st.caption("Negative correlations (blue) indicate trade-offs between objectives.")
                    if len(all_obj_cols) >= 2:
                        corr_df = _downsample_for_plot(plot_df, max_points=10000)
                        fig_corr = plot_objective_correlation_heatmap(corr_df, all_obj_cols)
                        st.plotly_chart(fig_corr, use_container_width=True)
                    else:
                        st.info("Need at least 2 objectives to compute correlations.")

                with tabs[4]:  # Distributions
                    st.caption("Violin plots show the distribution of each objective across the Pareto front (normalized to [0,1]).")
                    if len(all_obj_cols) >= 1:
                        dist_df = _downsample_for_plot(plot_df, max_points=10000)
                        fig_dist = plot_objective_distributions(dist_df, all_obj_cols)
                        st.plotly_chart(fig_dist, use_container_width=True)
                    else:
                        st.info("No objective columns found.")

                # --- 3. Table ---
                st.subheader("Design Data")
                # Fix sorting logic from previous error
                # Sort full DF first, then select columns
                sort_col = st.selectbox("Sort Table By", all_obj_cols, index=0)
                sorted_df = plot_df.sort_values(sort_col, ascending=False)
                
                # Dynamic column selection for table
                # Rename has_pk to Analyzed for user clarity
                table_df = sorted_df.rename(columns={'has_pk': 'Analyzed'})
                default_cols = ['design_uuid', 'Analyzed', 'gen_num', 'total_mass_kg', 'charge_mass_kg', 'frag_mass_kg']
                aggs = ['total_ikp', 'mean_ikp', 'total_vol']
                
                view_cols = [c for c in default_cols if c in table_df.columns]
                view_cols += [c for c in aggs if c in table_df.columns]
                view_cols += [c for c in ikp_cols if c not in aggs]
                
                # Verify columns exist
                view_cols = [c for c in view_cols if c in table_df.columns]
                
                st.dataframe(table_df[view_cols], use_container_width=True, hide_index=True)

    # --- DESIGN EXPLORER ---
    elif selection == "Design Explorer":
        st.title("Design Explorer")
        df = load_evaluations_flat(db_path, campaign["campaign_id"])

        if df.empty:
            st.warning("No data.")
        else:
            # Identify objective columns for filtering
            all_obj_cols = [c for c in df.columns if c.startswith('ikp_') or c.startswith('vol_') or c in ['total_ikp', 'mean_ikp', 'total_vol', 'mean_vol', 'total_mass_kg', 'charge_mass_kg', 'frag_mass_kg']]
            
            with st.expander("Filters", expanded=True):
                # Row 1: Generation and Pareto filters
                c1, c2, c3 = st.columns(3)
                
                gens = sorted(df['gen_num'].unique())
                if len(gens) > 1:
                    gen_range = c1.select_slider("Generation", options=gens, value=(gens[0], gens[-1]))
                else:
                    gen_range = (gens[0], gens[0]) if gens else (0, 0)
                
                pareto_only = c1.checkbox("Pareto Designs Only", value=True)
                feasible_only = c2.checkbox("Feasible Only", value=True)
                analyzed_only = c3.checkbox("Show Only Analyzed", value=False, help="Show designs that already have Pk analysis data")
                
                # Row 2: Dynamic objective filters
                st.markdown("**Objective Filters**")
                active_filters = {}
                
                # Group objectives into columns
                filter_cols = st.columns(3)
                for i, col in enumerate(all_obj_cols):
                    col_data = df[col].dropna()
                    if len(col_data) == 0:
                        continue
                    min_val = float(col_data.min())
                    max_val = float(col_data.max())
                    # Skip if no range
                    if min_val >= max_val:
                        continue
                    # Short label for display
                    label = col.replace('_', ' ').title()
                    with filter_cols[i % 3]:
                        active_filters[col] = st.slider(
                            label, 
                            min_value=min_val, 
                            max_value=max_val, 
                            value=(min_val, max_val),
                            key=f"filter_{col}"
                        )
            
            # Apply filters
            filtered_df = df[
                (df['gen_num'] >= gen_range[0]) & 
                (df['gen_num'] <= gen_range[1])
            ]
            
            if pareto_only:
                filtered_df = filtered_df[filtered_df['is_pareto'] == True]
            if feasible_only and 'feasible' in filtered_df.columns:
                filtered_df = filtered_df[filtered_df['feasible'] == True]
            if analyzed_only:
                filtered_df = filtered_df[filtered_df['has_pk'] == True]
            
            # Apply objective filters
            for col, (min_v, max_v) in active_filters.items():
                filtered_df = filtered_df[
                    (filtered_df[col] >= min_v) & 
                    (filtered_df[col] <= max_v)
                ]

            st.markdown(f"**Showing {len(filtered_df)} designs**")
            
            # Queue selection UI
            with st.expander("Queue Metrics & Bulk Actions", expanded=False):
                st.markdown("Metrics for the regeneration queue.")
                
                # Show queue stats
                queue_stats = get_queue_stats(campaign['campaign_id'])
                stat_cols = st.columns(4)
                stat_cols[0].metric("Pending", queue_stats['pending'])
                stat_cols[1].metric("Running", queue_stats['running'])
                stat_cols[2].metric("Completed", queue_stats['completed'])
                stat_cols[3].metric("Failed", queue_stats['failed'])
                
                st.markdown("---")
                st.markdown("**Bulk Queueing**")
                # Queue controls for filtered view
                q_col1, q_col2 = st.columns([1, 1])
                priority = q_col1.number_input("Priority", min_value=0, max_value=100, value=0, help="Higher = processed first")
                
                if q_col2.button("Queue ALL Filtered Designs", type="primary", disabled=len(filtered_df) == 0):
                    # Filter out already analyzed
                    to_queue = filtered_df[filtered_df['has_pk'] == False]
                    if not to_queue.empty:
                        success_count = 0
                        for uuid in to_queue['design_uuid']:
                            if add_to_queue(uuid, campaign['campaign_id'], priority=priority):
                                success_count += 1
                        st.success(f"Queued {success_count} designs. (Skipped {len(filtered_df) - len(to_queue)} already analyzed)")
                        st.rerun()
                    else:
                        st.warning("All filtered designs already have analysis data.")
            
            # Smart Column Selection
            # Rename has_pk to Analyzed for user clarity
            df_renamed = filtered_df.rename(columns={'has_pk': 'Analyzed'})
            all_cols = df_renamed.columns.tolist()
            priority_cols = ['design_uuid', 'Analyzed', 'gen_num', 'total_mass_kg', 'total_ikp', 'mean_ikp']
            display_cols = [c for c in priority_cols if c in all_cols]
            
            # Add other numeric objectives
            extra_objs = [c for c in all_cols if ('ikp' in c.lower() or 'vol' in c.lower()) and c not in display_cols]
            display_cols.extend(extra_objs)

            display_df = df_renamed[display_cols]
            
            event = st.dataframe(
                display_df,
                use_container_width=True,
                selection_mode="multi-row",
                on_select="rerun",
                hide_index=True,
            )
            
            # Store multi-selection for queue
            if event and event.selection['rows']:
                selected_uuids = [filtered_df.iloc[idx]['design_uuid'] for idx in event.selection['rows']]
                st.session_state['selected_design_uuids'] = selected_uuids
                st.caption(f"Selected {len(selected_uuids)} design(s)")
            else:
                st.session_state['selected_design_uuids'] = []
            
            # --- NEW: Selection Action Bar ---
            if st.session_state['selected_design_uuids']:
                st.markdown("---")
                a_c1, a_c2 = st.columns([1, 2])
                
                # Get selected subset
                sel_indices = event.selection['rows']
                sel_df = filtered_df.iloc[sel_indices]
                
                # Valid items have has_pk == False
                valid_queue_df = sel_df[sel_df['has_pk'] == False]
                n_valid = len(valid_queue_df)
                n_skip = len(sel_df) - n_valid
                
                with a_c1:
                    if st.button(f"Add {n_valid} to Queue", type="primary", disabled=n_valid==0):
                        count = 0
                        for uuid in valid_queue_df['design_uuid']:
                            if add_to_queue(uuid, campaign['campaign_id'], priority=10):
                                count += 1
                        st.success(f"Added {count} to queue.")
                        if n_skip > 0:
                            st.info(f"Skipped {n_skip} designs that already have analysis.")
                        st.rerun()
                with a_c2:
                    if n_skip > 0:
                        st.caption(f"{n_skip} selected designs already analyzed.")

            # Single selection for drill down (first selected)
            if event and len(event.selection['rows']) > 0:
                idx = event.selection['rows'][0]
                uuid = filtered_df.iloc[idx]['design_uuid']
                st.session_state['selected_uuid'] = uuid
                
                st.info(f"Primary Selection: `{uuid}`")
                
                # Check Pk availability
                has_pk = check_pk_availability(conn, uuid, campaign['campaign_id'])
                queue_status = get_queue_status_for_design(uuid, campaign['campaign_id'])
                
                status_cols = st.columns(3)
                with status_cols[0]:
                    if has_pk:
                        st.success("Pk hypercube available")
                    elif queue_status:
                        if queue_status['status'] == 'pending':
                            st.warning(f"Queued (priority: pending)")
                        elif queue_status['status'] == 'running':
                            st.info("Processing...")
                        elif queue_status['status'] == 'failed':
                            st.error(f"Failed: {queue_status.get('error', 'Unknown')}")
                    else:
                        st.warning("No Pk data - queue for regeneration")
                
                with status_cols[1]:
                    st.button("View Drill Down Analysis", 
                              on_click=lambda: st.session_state.update({"nav_selection": "Drill Down Analysis"}))
                with status_cols[2]:
                    if uuid not in st.session_state['compare_list']:
                        if st.button("Add to Comparison"):
                            st.session_state['compare_list'].append(uuid)
                            st.success("Added!")

                # Quick ZDATA Preview
                zdata = get_zdata_obj(conn, uuid)
                if zdata:
                    angles, masses, velocities, energies = process_zdata_for_radar(zdata)
                    c1, c2 = st.columns(2)
                    with c1:
                        fig = plot_radar_chart(masses, angles, color="#1f77b4", title="Fragment Mass")
                        st.plotly_chart(fig, use_container_width=True)
                    with c2:
                        fig = plot_radar_chart(velocities, angles, color="#ff7f0e", title="Velocity")
                        st.plotly_chart(fig, use_container_width=True)

    # --- DRILL DOWN ANALYSIS ---
    elif selection == "Drill Down Analysis":
        st.title("Drill Down: Design Analysis")

        if 'selected_uuid' not in st.session_state:
            st.info("Please select a design from the 'Design Explorer' tab first.")
            return

        uuid = st.session_state['selected_uuid']
        st.markdown(f"### Design: `{uuid}`")
        
        # Check Pk data availability and show banner if missing
        has_pk = check_pk_availability(conn, uuid, campaign['campaign_id'])
        queue_status = get_queue_status_for_design(uuid, campaign['campaign_id'])
        
        if not has_pk:
            if queue_status and queue_status['status'] == 'running':
                st.info("**Pk hypercube is being generated...** Refresh the page to check for updates.")
            elif queue_status and queue_status['status'] == 'pending':
                st.warning(f"**Pk hypercube queued for regeneration** — Some visualizations may be limited until processing completes.")
            elif queue_status and queue_status['status'] == 'failed':
                st.error(f"**Pk regeneration failed:** {queue_status.get('error', 'Unknown error')}")
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("Retry Regeneration"):
                        add_to_queue(uuid, campaign['campaign_id'], priority=100)
                        st.success("Added to queue with high priority")
                        st.rerun()
            else:
                st.warning("""**Pk hypercube data not available** — Some visualizations (3D Volume, Pk heatmaps) are disabled.
                
During GA optimization, only lightweight `discrete` data is stored. Queue this design to regenerate the full Pk hypercube.""")
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("Queue for Regeneration", type="primary"):
                        if add_to_queue(uuid, campaign['campaign_id'], priority=50):
                            st.success("Added to regeneration queue!")
                            st.rerun()
                with col2:
                    st.caption("Run `gdwh run-queue --db-path <path>` to process the queue")

        with st.spinner("Loading analysis results..."):
            context = load_analysis_context(conn, uuid, campaign['campaign_id'], root_dir=root_dir)

        targets_ctx = context.get('targets') or {}
        target_names = list(targets_ctx.keys())

        if target_names:
            target_state_key = f"drilldown_target_{uuid}"
            default_target = st.session_state.get(target_state_key)
            if default_target not in target_names:
                default_target = target_names[0]
            selected_target = st.selectbox("Select Target", target_names, index=target_names.index(default_target))
            st.session_state[target_state_key] = selected_target
            active_target = targets_ctx.get(selected_target, {})
        else:
            active_target = {}

        pk_data = active_target.get('pk_data') or active_target.get('pk_path') or context.get('pk_data') or context.get('pk_path')
        disc_data = active_target.get('disc_data') or active_target.get('disc_path') or context.get('disc_data') or context.get('disc_path')
        mc_data = active_target.get('mc_data') or context.get('mc_data')
        axes = active_target.get('axes') or context.get('axes')
        config = context.get('config')

        view_modes = []
        if disc_data or pk_data:
            view_modes.append("Campaign Statistics")
        view_modes.append("Weapon Characteristics")
        if mc_data:
            view_modes.append("MC Salvo Analysis")
        if pk_data or disc_data:
            view_modes.extend(["Single Slice Analysis", "3D Volume Explorer"])

        if not view_modes:
             st.error("No analysis data found.")
        else:
             view_mode = st.radio("Analysis View", view_modes, horizontal=True)

             if view_mode == "Campaign Statistics":
                 render_campaign_statistics(disc_data, mc_data, pk_data, root_dir=root_dir)
             elif view_mode == "Weapon Characteristics":
                 render_weapon_characteristics(conn, uuid, config)
             elif view_mode == "Single Slice Analysis":
                 if not has_pk and not pk_data:
                     st.warning("Pk hypercube required for this view. Queue the design for regeneration.")
                 elif axes:
                     render_single_slice_analysis(pk_data, disc_data, axes, config, root_dir=root_dir)
                 else:
                     st.error("No axis data available.")
             elif view_mode == "3D Volume Explorer":
                 if axes:
                     render_3d_volume_explorer(disc_data, axes, config, root_dir=root_dir)
                 else:
                     st.error("No axis data available.")
             elif view_mode == "MC Salvo Analysis":
                 render_mc_salvo_analysis(mc_data, config)

    # --- COMPARISON ---
    elif selection == "Comparison":
        st.title("Design Comparison")
        
        compare_list = st.session_state['compare_list']
        if not compare_list:
            st.info("No designs selected. Add from 'Design Explorer'.")
            return

        df = load_evaluations_flat(db_path, campaign["campaign_id"])
        comp_df = df[df['design_uuid'].isin(compare_list)].copy()
        
        st.subheader("Metrics Comparison")
        # Ensure aggregates are computed/loaded
        cols = ['design_uuid', 'gen_num', 'total_mass_kg', 'total_ikp', 'mean_ikp']
        # Add dynamic cols if they exist
        avail_cols = [c for c in cols if c in comp_df.columns]
        other_objs = [c for c in comp_df.columns if ('ikp' in c.lower() or 'vol' in c.lower()) and c not in avail_cols]
        avail_cols.extend(other_objs)
        
        comp_view = comp_df[avail_cols].set_index('design_uuid').transpose()
        st.dataframe(comp_view, use_container_width=True)
        
        st.subheader("Visual Comparison")
        cols = st.columns(len(compare_list))
        for i, uuid in enumerate(compare_list):
            with cols[i]:
                st.markdown(f"#### {uuid[:8]}")
                zdata = get_zdata_obj(conn, uuid)
                if zdata:
                    angles, masses, velocities, energies = process_zdata_for_radar(zdata)
                    fig_radar = plot_radar_chart(velocities, angles, color="#ff7f0e", height=300, title="Velocity")
                    st.plotly_chart(fig_radar, use_container_width=True)

    # --- QUEUE MANAGEMENT ---
    elif selection == "Queue Management":
        st.title("Megadeth Queue Management")
        st.markdown("Manage the on-demand Pk hypercube regeneration queue.")
        
        # Queue Statistics
        stats = get_queue_stats(campaign['campaign_id'])
        total = sum(stats.values())
        
        st.subheader("Queue Status")
        stat_cols = st.columns(5)
        stat_cols[0].metric("Total", total)
        stat_cols[1].metric("Pending", stats['pending'])
        stat_cols[2].metric("Running", stats['running'])
        stat_cols[3].metric("Completed", stats['completed'])
        stat_cols[4].metric("Failed", stats['failed'])
        
        # Progress bar if items are processing
        if total > 0:
            completed_pct = stats['completed'] / total
            st.progress(completed_pct, text=f"{stats['completed']}/{total} completed ({completed_pct*100:.1f}%)")
        
        st.markdown("---")
        
        # Queue Controls
        st.subheader("Controls")
        ctrl_cols = st.columns(4)
        
        with ctrl_cols[0]:
            if st.button("Refresh", use_container_width=True):
                st.rerun()
        
        with ctrl_cols[1]:
            if stats['failed'] > 0:
                if st.button(f"Retry Failed ({stats['failed']})", use_container_width=True):
                    if retry_failed_items(conn, campaign['campaign_id']):
                        st.success(f"Reset {stats['failed']} failed items to pending")
                        st.rerun()
        
        with ctrl_cols[2]:
            if stats['completed'] > 0:
                if st.button(f"Clear Completed ({stats['completed']})", use_container_width=True):
                    if clear_queue_items(campaign['campaign_id'], 'completed'):
                        st.success(f"Cleared {stats['completed']} completed items")
                        st.rerun()
        
        with ctrl_cols[3]:
            if stats['pending'] > 0:
                if st.button("Execute Queue", type="primary", use_container_width=True):
                    execute_queue_modal(db_path, campaign['campaign_id'])
            else:
                st.button("Execute Queue", type="primary", use_container_width=True, disabled=True)
        
        # CLI Command Helper
        st.subheader("Run Queue Processor")
        with st.expander("CLI Commands", expanded=stats['pending'] > 0):
            db_path_display = db_path
            st.markdown("**Single-core (default):**")
            st.code(f"gdwh run-queue --db-path {db_path_display}", language="bash")
            
            st.markdown("**Multi-process (faster):**")
            st.code(f"gdwh run-queue --db-path {db_path_display} --max-workers 4", language="bash")
            
            st.markdown("**With custom batch size:**")
            st.code(f"gdwh run-queue --db-path {db_path_display} --max-workers 4 --batch-size 20", language="bash")
        
        st.markdown("---")
        
        # Queue Items Table
        st.subheader("Queue Items")
        queue_df = get_queue_items(campaign['campaign_id'], limit=200)
        
        if queue_df.empty:
            st.info("Queue is empty. Select designs from the Design Explorer to queue them for Pk regeneration.")
        else:
            # Status filter
            status_filter = st.multiselect(
                "Filter by Status",
                ['pending', 'running', 'completed', 'failed'],
                default=['pending', 'running', 'failed']
            )
            
            filtered_queue = queue_df[queue_df['status'].isin(status_filter)]
            
            # Format display
            display_queue = filtered_queue[['queue_id', 'design_uuid', 'target_id', 'status', 'priority', 'requested_at', 'error_message']].copy()
            display_queue['design_uuid'] = display_queue['design_uuid'].apply(lambda x: x[:12] + '...' if len(str(x)) > 12 else x)
            
            # Color-code status
            def style_status(val):
                colors = {
                    'pending': 'background-color: #fff3cd',
                    'running': 'background-color: #cce5ff',
                    'completed': 'background-color: #d4edda',
                    'failed': 'background-color: #f8d7da'
                }
                return colors.get(val, '')
            
            st.dataframe(
                display_queue,
                use_container_width=True,
                hide_index=True,
                column_config={
                    'queue_id': st.column_config.NumberColumn('ID', width='small'),
                    'design_uuid': st.column_config.TextColumn('Design UUID', width='medium'),
                    'target_id': st.column_config.NumberColumn('Target', width='small'),
                    'status': st.column_config.TextColumn('Status', width='small'),
                    'priority': st.column_config.NumberColumn('Priority', width='small'),
                    'requested_at': st.column_config.DatetimeColumn('Requested', width='medium'),
                    'error_message': st.column_config.TextColumn('Error', width='large'),
                }
            )
            
            st.caption(f"Showing {len(filtered_queue)} of {len(queue_df)} items")


if __name__ == "__main__":
    main()
