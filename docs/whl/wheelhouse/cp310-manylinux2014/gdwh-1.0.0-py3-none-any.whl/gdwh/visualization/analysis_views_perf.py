"""
Performance-optimized analysis views for the Streamlit dashboard (ADR-020).

This module wraps `gdwh.visualization.analysis_views` and overrides the hot
paths that become problematic with very large HDF5 files:
- Avoid eager loading of multi-GB `pk_det` datasets (lazy slice reads)
- Cache small repeated computations (gradient magnitude)
- Avoid huge allocations when enumerating "hits" above a threshold
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

import duckdb
import numpy as np
import pandas as pd
import streamlit as st

from gdwh.config.schema import CampaignConfig
from gdwh.storage import HDF5Reader

from . import analysis_views as legacy
from .charts import (
    compute_curvature,
    compute_gradient_magnitude,
    compute_hob_mr_grid,
    plot_3d_volume_plotly,
    plot_hob_mr_contour_plotly,
    plot_iso_mesh_colored_by_pk,
    plot_pk_heatmap_plotly,
    plot_pk_vs_vel_hob_plotly,
    plot_r2k_heatmap_plotly,
    plot_r2k_stoplight_plotly,
)

logger = logging.getLogger(__name__)

H5_REF_KEY = "__hdf5__"
PK_DET_SHAPE_KEY = "__pk_det_shape__"


def _encode_index_tuple(index: tuple) -> tuple:
    """Make an h5py index tuple hashable for st.cache_data."""
    encoded = []
    for item in index:
        if isinstance(item, slice):
            encoded.append((item.start, item.stop, item.step))
        else:
            encoded.append(item)
    return tuple(encoded)


def _decode_index_tuple(encoded: tuple) -> tuple:
    decoded = []
    for item in encoded:
        if isinstance(item, tuple) and len(item) == 3:
            decoded.append(slice(item[0], item[1], item[2]))
        else:
            decoded.append(item)
    return tuple(decoded)


@st.cache_data(ttl=300, max_entries=512, show_spinner=False)
def _load_hdf5_data(
    h5_path: str,
    design_uuid: str,
    target_id: int,
    data_type: str,
    keys: Tuple[str, ...],
    slice_items: Optional[Tuple[Tuple[str, tuple], ...]] = None,
) -> Dict[str, Any]:
    """Load a small subset/slice of datasets from HDF5 with caching."""
    slices = None
    if slice_items:
        slices = {k: _decode_index_tuple(v) for k, v in slice_items}
    with HDF5Reader(Path(h5_path)) as reader:
        data = reader.load_data(
            design_uuid=design_uuid,
            target_id=target_id,
            data_type=data_type,
            keys=list(keys),
            slices=slices,
        )
    return data or {}


@st.cache_data(ttl=300, max_entries=256, show_spinner=False)
def _get_hdf5_dataset_info(
    h5_path: str,
    design_uuid: str,
    target_id: int,
    data_type: str,
) -> Dict[str, Dict[str, Any]]:
    with HDF5Reader(Path(h5_path)) as reader:
        return reader.get_dataset_info(design_uuid, target_id, data_type) or {}


def _detect_pk_det_format(pk_det_shape: Tuple[int, ...], axes: Dict[str, np.ndarray]) -> str:
    """Detect pk_det ordering from stored shape + axis lengths."""
    if not pk_det_shape or len(pk_det_shape) != 5:
        return "native"

    def _axis_len(v: Optional[np.ndarray]) -> int:
        return int(len(v)) if v is not None else 0

    n_miss_x = _axis_len(axes.get("miss_x"))
    n_miss_y = _axis_len(axes.get("miss_y"))
    n_hob = _axis_len(axes.get("hob"))
    n_vel = _axis_len(axes.get("vel"))
    n_aof = _axis_len(axes.get("aof"))

    if pk_det_shape == (n_miss_x, n_miss_y, n_hob, n_vel, n_aof):
        return "native"
    if pk_det_shape == (n_hob, n_vel, n_aof, n_miss_x, n_miss_y):
        return "legacy"

    # Heuristic fallback (mirrors charts.detect_hypercube_format)
    if pk_det_shape[0] > pk_det_shape[2] and pk_det_shape[1] > pk_det_shape[3]:
        return "native"
    if pk_det_shape[3] > pk_det_shape[0] and pk_det_shape[4] > pk_det_shape[1]:
        return "legacy"
    return "native"


def load_analysis_context(
    conn: duckdb.DuckDBPyConnection,
    design_uuid: str,
    campaign_id: str,
    root_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Load analysis context with HDF5 lazy loading (ADR-020).

    For HDF5-backed campaigns, this avoids eager loading of `pk_det` and loads
    only axis/summary datasets up-front.
    """
    context: Dict[str, Any] = {
        "pk_path": None,
        "disc_path": None,
        "mc_path": None,
        "pk_data": None,
        "disc_data": None,
        "mc_data": None,
        "axes": None,
        "config": {},
        "config_raw": {},
        "design_uuid": design_uuid,
        "campaign_id": campaign_id,
        "targets": {},
    }

    resolved_root = root_dir.resolve() if root_dir else None
    resolved_root_parent = resolved_root.parent if resolved_root else None

    storage_root = None
    storage_root_parent = None
    h5_path = None

    try:
        config_query = "SELECT config_yaml FROM campaigns WHERE campaign_id = ?"
        result = conn.execute(config_query, [campaign_id]).fetchone()
        if result and result[0]:
            import yaml

            config_dict = yaml.safe_load(result[0])
            context["config_raw"] = config_dict
            try:
                context["config"] = CampaignConfig.model_validate(config_dict)
            except Exception:
                context["config"] = config_dict

            consolidated_dir = None
            try:
                if isinstance(context["config"], CampaignConfig):
                    if hasattr(context["config"].storage, "hdf5") and context["config"].storage.hdf5:
                        consolidated_dir = context["config"].storage.hdf5.consolidated_dir
                    elif hasattr(context["config"].storage, "npz") and context["config"].storage.npz:
                        consolidated_dir = context["config"].storage.npz.consolidated_dir
                if consolidated_dir is None and isinstance(context["config_raw"], dict):
                    storage_cfg = context["config_raw"].get("storage", {})
                    if "hdf5" in storage_cfg:
                        consolidated_dir = Path(storage_cfg["hdf5"].get("consolidated_dir", ""))
                    elif "npz" in storage_cfg:
                        consolidated_dir = Path(storage_cfg["npz"].get("consolidated_dir", ""))
            except Exception:
                consolidated_dir = None

            if consolidated_dir:
                if not Path(consolidated_dir).is_absolute() and resolved_root:
                    storage_root = resolved_root / consolidated_dir
                else:
                    storage_root = Path(consolidated_dir)

                # ADR-009: Prefer per-generation file via DB lookup.
                try:
                    row = conn.execute(
                        """
                        SELECT gf.hdf5_path
                        FROM evaluations e
                        JOIN generations g ON e.gen_id = g.gen_id
                        JOIN generation_files gf ON g.campaign_id = gf.campaign_id
                                                 AND g.gen_num = gf.generation
                        WHERE e.design_uuid = ? AND g.campaign_id = ?
                        LIMIT 1
                        """,
                        [design_uuid, campaign_id],
                    ).fetchone()

                    if row and row[0]:
                        found_gen_path = Path(row[0])
                        if found_gen_path.is_absolute() and found_gen_path.exists():
                            h5_path = found_gen_path
                        elif resolved_root and (resolved_root / found_gen_path).exists():
                            h5_path = resolved_root / found_gen_path
                        elif storage_root and (storage_root / found_gen_path.name).exists():
                            h5_path = storage_root / found_gen_path.name
                        elif found_gen_path.exists():
                            h5_path = found_gen_path
                except Exception:
                    pass

                if not h5_path:
                    possible_h5 = storage_root / f"{campaign_id}.h5"
                    if possible_h5.exists():
                        h5_path = possible_h5

                storage_root_parent = storage_root.parent if storage_root else None
    except Exception:
        pass

    # --- STRATEGY 1: HDF5 (Unified Storage) ---
    if h5_path and h5_path.exists():
        try:
            with HDF5Reader(h5_path) as reader:
                if reader.has_design(design_uuid):
                    targets_map = legacy.get_target_npz_map(conn, design_uuid)

                    first = True
                    for tgt_name, meta in targets_map.items():
                        target_id = meta.get("target_id")
                        if target_id is None:
                            continue

                        # Minimal up-front loads (no pk_det).
                        pk_axes = reader.load_data(
                            design_uuid,
                            target_id,
                            "pk",
                            keys=["vel", "hob", "miss_x", "miss_y", "aof"],
                        ) or {}

                        disc_small = reader.load_data(
                            design_uuid,
                            target_id,
                            "discrete",
                            keys=["system_pk", "reliability", "rounds_to_kill", "pk_thresholds", "hob", "vel", "aof"],
                        ) or {}

                        pk_info = reader.get_dataset_info(design_uuid, target_id, "pk") or {}
                        pk_det_shape = None
                        if "pk_det" in pk_info and isinstance(pk_info["pk_det"], dict):
                            pk_det_shape = tuple(pk_info["pk_det"].get("shape") or ())

                        mc_info = reader.get_dataset_info(design_uuid, target_id, "mc") or {}

                        pk_data = dict(pk_axes)
                        if pk_det_shape:
                            pk_data[PK_DET_SHAPE_KEY] = pk_det_shape
                        if pk_axes or pk_det_shape:
                            pk_data[H5_REF_KEY] = {
                                "h5_path": str(h5_path),
                                "design_uuid": design_uuid,
                                "target_id": int(target_id),
                                "data_type": "pk",
                            }

                        disc_data = dict(disc_small)
                        if disc_data:
                            disc_data[H5_REF_KEY] = {
                                "h5_path": str(h5_path),
                                "design_uuid": design_uuid,
                                "target_id": int(target_id),
                                "data_type": "discrete",
                            }

                        mc_data = None
                        if mc_info:
                            mc_data = {
                                H5_REF_KEY: {
                                    "h5_path": str(h5_path),
                                    "design_uuid": design_uuid,
                                    "target_id": int(target_id),
                                    "data_type": "mc",
                                }
                            }

                        targets_map[tgt_name].update(
                            {
                                "pk_data": pk_data or None,
                                "disc_data": disc_data or None,
                                "mc_data": mc_data,
                                "pk_path": f"{h5_path}::/designs/{design_uuid}/targets/{target_id}/pk",
                                "disc_path": f"{h5_path}::/designs/{design_uuid}/targets/{target_id}/discrete",
                                "mc_path": f"{h5_path}::/designs/{design_uuid}/targets/{target_id}/mc",
                            }
                        )

                        if first:
                            context["pk_data"] = pk_data or None
                            context["disc_data"] = disc_data or None
                            context["mc_data"] = mc_data

                            axes = None
                            if pk_axes:
                                axes = {
                                    "vel": pk_axes.get("vel"),
                                    "hob": pk_axes.get("hob"),
                                    "miss_x": pk_axes.get("miss_x"),
                                    "miss_y": pk_axes.get("miss_y"),
                                    "aof": pk_axes.get("aof"),
                                }
                            elif disc_small:
                                axes = {
                                    "vel": disc_small.get("vel"),
                                    "hob": disc_small.get("hob"),
                                    "aof": disc_small.get("aof"),
                                    "miss_x": None,
                                    "miss_y": None,
                                }
                            if axes and any(v is not None for v in axes.values()):
                                context["axes"] = axes
                                targets_map[tgt_name]["axes"] = axes

                            first = False

                    context["targets"] = targets_map
                    return context
        except Exception as e:
            st.warning(f"Failed to read from HDF5: {e}")

    # --- STRATEGY 2: Legacy NPZ (Distributed Storage) ---
    return legacy.load_analysis_context(conn, design_uuid, campaign_id, root_dir=root_dir)


def render_single_slice_analysis(
    pk_data: Optional[Union[Dict[str, Any], str, Path]],
    disc_data: Optional[Union[Dict[str, Any], str, Path]],
    axes: Dict,
    config: Union[CampaignConfig, Dict[str, Any]],
    root_dir: Optional[Path] = None,
) -> None:
    """Override of legacy single-slice view with lazy pk_det slice reads (ADR-020)."""
    st.subheader("Single Slice Analysis")

    if not axes or axes.get("hob") is None:
        st.error("No axis data available.")
        return

    hob = axes["hob"]
    vel = axes["vel"]
    aof = axes["aof"]
    precision_cfg = legacy._get_precision_config(config)

    col_ctrl, col_plot = st.columns([1, 3])

    with col_ctrl:
        plot_options = []
        if pk_data:
            plot_options.extend(["Pk Contour (Miss Grid)", "HOB vs Miss Range Contour"])
        if disc_data:
            plot_options.extend(["System Pk (Vel vs HOB)", "Rounds-to-Kill Heatmap", "R2K Stoplight Grid"])

        plot_type = st.selectbox("Plot Type", plot_options)

        i_hob_idx = len(hob) // 2
        i_vel_idx = len(vel) // 2
        i_aof_idx = len(aof) // 2

        i_hob = hob[i_hob_idx]
        i_vel = vel[i_vel_idx]
        i_aof = aof[i_aof_idx]

        show_hob = plot_type == "Pk Contour (Miss Grid)"
        show_vel = plot_type in ["Pk Contour (Miss Grid)", "HOB vs Miss Range Contour"]
        show_aof = True

        if show_hob:
            i_hob = st.select_slider("HOB (m)", options=hob, value=i_hob)
            i_hob_idx = int(np.where(hob == i_hob)[0][0])

        if show_vel:
            i_vel = st.select_slider("Velocity (m/s)", options=vel, value=i_vel)
            i_vel_idx = int(np.where(vel == i_vel)[0][0])

        if show_aof:
            i_aof = st.select_slider("AOF (deg)", options=aof, value=i_aof)
            i_aof_idx = int(np.where(aof == i_aof)[0][0])

        use_weighted = False
        if plot_type == "Pk Contour (Miss Grid)" and precision_cfg:
            use_weighted = st.checkbox("Weight by Error Model", value=False)

    with col_plot:
        if plot_type == "Pk Contour (Miss Grid)" and pk_data:
            pk_loaded = legacy._ensure_npz_loaded(pk_data, root_dir=root_dir)
            pk_slice = None

            if pk_loaded and "pk_det" in pk_loaded:
                pk_det = legacy.normalize_hypercube_to_native(pk_loaded["pk_det"], axes)
                pk_slice = pk_det[:, :, i_hob_idx, i_vel_idx, i_aof_idx]
            elif isinstance(pk_loaded, dict) and H5_REF_KEY in pk_loaded:
                ref = pk_loaded[H5_REF_KEY]
                h5_path = ref["h5_path"]
                target_id = int(ref["target_id"])

                info = _get_hdf5_dataset_info(h5_path, ref["design_uuid"], target_id, "pk")
                pk_det_shape = tuple((pk_loaded.get(PK_DET_SHAPE_KEY) or info.get("pk_det", {}).get("shape") or ()))
                fmt = _detect_pk_det_format(pk_det_shape, axes)

                if fmt == "legacy":
                    index = (i_hob_idx, i_vel_idx, i_aof_idx, slice(None), slice(None))
                else:
                    index = (slice(None), slice(None), i_hob_idx, i_vel_idx, i_aof_idx)

                data = _load_hdf5_data(
                    h5_path=h5_path,
                    design_uuid=ref["design_uuid"],
                    target_id=target_id,
                    data_type="pk",
                    keys=("pk_det",),
                    slice_items=(("pk_det", _encode_index_tuple(index)),),
                )
                pk_slice = data.get("pk_det")

            if pk_slice is None:
                st.warning("Pk data unavailable for this plot.")
                return

            if use_weighted and precision_cfg:
                err = precision_cfg
                miss_x = axes["miss_x"]
                miss_y = axes["miss_y"]

                X, Y = np.meshgrid(miss_x, miss_y, indexing="ij")
                r2 = X**2 + Y**2
                sigma = err.get("cep_radius_m", 2.0) / 0.674
                pdf = np.exp(-r2 / (2 * sigma**2))
                pdf = pdf / np.sum(pdf)

                weighted_pk = pk_slice * pdf
                display_pk = weighted_pk / weighted_pk.max() if weighted_pk.max() > 0 else weighted_pk

                fig = plot_pk_heatmap_plotly(
                    pk_slice=display_pk,
                    x_axis=miss_x,
                    y_axis=miss_y,
                    x_label="Miss Distance X (m)",
                    y_label="Miss Distance Y (m)",
                    title=f"Weighted Pk @ HOB={i_hob}m, Vel={i_vel}m/s, AOF={i_aof}°",
                    colorbar_title="Pk×PDF",
                )

                bias_x = err.get("fixed_bias_deflection_m", 0)
                bias_y = err.get("fixed_bias_range_m", 0)
                tle_r = err.get("tle_radius_m", 0)
                cep_r = err.get("cep_radius_m", 0)

                shapes = []
                if cep_r:
                    shapes.append(
                        dict(
                            type="circle",
                            xref="x",
                            yref="y",
                            x0=bias_x - cep_r,
                            x1=bias_x + cep_r,
                            y0=bias_y - cep_r,
                            y1=bias_y + cep_r,
                            line=dict(color="orange", width=2, dash="dash"),
                        )
                    )
                if tle_r:
                    shapes.append(
                        dict(
                            type="circle",
                            xref="x",
                            yref="y",
                            x0=bias_x - tle_r,
                            x1=bias_x + tle_r,
                            y0=bias_y - tle_r,
                            y1=bias_y + tle_r,
                            line=dict(color="red", width=2, dash="dot"),
                        )
                    )
                if shapes:
                    fig.update_layout(shapes=shapes)
            else:
                fig = plot_pk_heatmap_plotly(
                    pk_slice=pk_slice,
                    x_axis=axes["miss_x"],
                    y_axis=axes["miss_y"],
                    x_label="Miss Distance X (m)",
                    y_label="Miss Distance Y (m)",
                    title=f"Raw Pk @ HOB={i_hob}m, Vel={i_vel}m/s, AOF={i_aof}°",
                )

            st.plotly_chart(fig, use_container_width=True)

        elif plot_type == "System Pk (Vel vs HOB)" and disc_data:
            disc_loaded = legacy._ensure_npz_loaded(disc_data, root_dir=root_dir)
            if not disc_loaded:
                st.warning("Discrete data unavailable for System Pk.")
                return

            sys_pk = disc_loaded.get("system_pk", disc_loaded.get("reliability"))
            slice_2d = sys_pk[:, :, i_aof_idx]

            fig = plot_pk_vs_vel_hob_plotly(slice_2d, vel, hob, title=f"System Pk @ AOF={i_aof}°")
            st.plotly_chart(fig, use_container_width=True)

        elif plot_type == "HOB vs Miss Range Contour" and pk_data:
            pk_loaded = legacy._ensure_npz_loaded(pk_data, root_dir=root_dir)
            pk_miss_xy_hob = None

            if pk_loaded and "pk_det" in pk_loaded:
                pk_det = legacy.normalize_hypercube_to_native(pk_loaded["pk_det"], axes)
                pk_miss_xy_hob = pk_det[:, :, :, i_vel_idx, i_aof_idx]
            elif isinstance(pk_loaded, dict) and H5_REF_KEY in pk_loaded:
                ref = pk_loaded[H5_REF_KEY]
                h5_path = ref["h5_path"]
                target_id = int(ref["target_id"])

                info = _get_hdf5_dataset_info(h5_path, ref["design_uuid"], target_id, "pk")
                pk_det_shape = tuple((pk_loaded.get(PK_DET_SHAPE_KEY) or info.get("pk_det", {}).get("shape") or ()))
                fmt = _detect_pk_det_format(pk_det_shape, axes)

                if fmt == "legacy":
                    index = (slice(None), i_vel_idx, i_aof_idx, slice(None), slice(None))
                else:
                    index = (slice(None), slice(None), slice(None), i_vel_idx, i_aof_idx)

                data = _load_hdf5_data(
                    h5_path=h5_path,
                    design_uuid=ref["design_uuid"],
                    target_id=target_id,
                    data_type="pk",
                    keys=("pk_det",),
                    slice_items=(("pk_det", _encode_index_tuple(index)),),
                )
                pk_miss_xy_hob = data.get("pk_det")
                if pk_miss_xy_hob is not None and fmt == "legacy":
                    # (hob, miss_x, miss_y) -> (miss_x, miss_y, hob)
                    pk_miss_xy_hob = np.transpose(pk_miss_xy_hob, (1, 2, 0))

            if pk_miss_xy_hob is None:
                st.warning("Pk data unavailable for this plot.")
                return

            mr_axis, pk_hob_mr = compute_hob_mr_grid(
                pk_miss_xy_hob, hob, axes["miss_x"], axes["miss_y"], i_vel=0, i_aof=0
            )

            fig = plot_hob_mr_contour_plotly(
                hob,
                mr_axis,
                pk_hob_mr,
                title=f"HOB vs Miss Range @ Vel={i_vel}m/s, AOF={i_aof}°",
            )
            st.plotly_chart(fig, use_container_width=True)

        elif plot_type == "Rounds-to-Kill Heatmap" and disc_data:
            disc_loaded = legacy._ensure_npz_loaded(disc_data, root_dir=root_dir)
            if disc_loaded and "rounds_to_kill" in disc_loaded:
                r2k = disc_loaded["rounds_to_kill"]
                thresh_idx = 0
                r2k_slice = r2k[:, :, i_aof_idx, thresh_idx]

                fig = plot_r2k_heatmap_plotly(
                    r2k_slice,
                    vel,
                    hob,
                    x_label="Velocity (m/s)",
                    y_label="HOB (m)",
                    title=f"R2K @ AOF={i_aof}°",
                )
                st.plotly_chart(fig, use_container_width=True)

        elif plot_type == "R2K Stoplight Grid" and disc_data:
            disc_loaded = legacy._ensure_npz_loaded(disc_data, root_dir=root_dir)
            if disc_loaded and "rounds_to_kill" in disc_loaded:
                r2k = disc_loaded["rounds_to_kill"]
                thresh_idx = 0
                r2k_slice = r2k[:, :, i_aof_idx, thresh_idx]

                fig = plot_r2k_stoplight_plotly(r2k_slice, vel, hob, title=f"Stoplight @ AOF={i_aof}°")
                st.plotly_chart(fig, use_container_width=True)


def render_3d_volume_explorer(
    disc_data: Optional[Union[Dict[str, Any], str, Path]],
    axes: Dict,
    config: Union[CampaignConfig, Dict[str, Any]],
    root_dir: Optional[Path] = None,
) -> None:
    """Override of legacy 3D explorer with cached derivatives and efficient hit enumeration (ADR-020)."""
    st.subheader("3D Volume Explorer")

    disc_loaded = legacy._ensure_npz_loaded(disc_data, root_dir=root_dir)
    if not disc_loaded or "system_pk" not in disc_loaded:
        st.warning("No discrete analysis data available for 3D visualization.")
        return

    sys_pk = disc_loaded["system_pk"]
    hob = axes["hob"]
    vel = axes["vel"]
    aof = axes["aof"]

    high_perf = st.checkbox("High Performance Mode (Downsample)", value=True)

    metric = st.radio("Metric", ["System Pk", "Sensitivity", "Curvature"], horizontal=True)

    if metric == "Sensitivity":
        data_3d = compute_gradient_magnitude(sys_pk)
    elif metric == "Curvature":
        data_3d = compute_curvature(sys_pk)
    else:
        data_3d = sys_pk

    plot_data = data_3d
    plot_pk = sys_pk
    plot_hob = hob
    plot_vel = vel
    plot_aof = aof

    if high_perf:
        plot_data = data_3d[::2, ::2, ::2]
        plot_pk = sys_pk[::2, ::2, ::2]
        plot_hob = hob[::2]
        plot_vel = vel[::2]
        plot_aof = aof[::2]

    col_viz, col_opts = st.columns([3, 1])

    with col_opts:
        d_min = float(plot_data.min())
        d_max = float(plot_data.max())
        d_mean = float(plot_data.mean())

        if d_min < d_max:
            iso_val = st.slider("Isosurface Level", d_min, d_max, d_mean)
        else:
            st.info(f"Constant Field Value: {d_min:.2f}")
            iso_val = d_min

        opacity = st.slider("Opacity", 0.1, 1.0, 0.3)
        color_by_pk = st.checkbox("Color by Pk", value=(metric != "System Pk"))

    with col_viz:
        if color_by_pk and metric != "System Pk":
            fig = plot_iso_mesh_colored_by_pk(plot_data, plot_pk, plot_hob, plot_vel, plot_aof, iso_val, opacity)
        else:
            fig = plot_3d_volume_plotly(
                plot_data, plot_hob, plot_vel, plot_aof, opacity=opacity, colorbar_title=metric, iso_val=iso_val
            )
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")
    st.markdown("### Envelope Volume Analysis")

    default_thresh = legacy._get_discrete_pk_threshold(config, default=0.5)
    pk_threshold = st.slider("Pk Threshold", 0.0, 1.0, float(default_thresh), 0.05)

    voxel_volume = (hob[1] - hob[0]) * (vel[1] - vel[0]) * (aof[1] - aof[0])
    flat_pk = np.asarray(sys_pk).ravel()
    n_voxels_above = int(np.count_nonzero(flat_pk > pk_threshold))
    total_volume = n_voxels_above * voxel_volume

    st.metric(f"Volume with Pk > {pk_threshold}", f"{total_volume:.2f} m·(m/s)·deg")
    st.caption(f"{n_voxels_above} / {sys_pk.size} terminal conditions meet threshold")

    if n_voxels_above <= 0:
        return

    # Show top-N hits efficiently (avoid allocating all hit coordinates).
    max_rows = 200
    if n_voxels_above <= max_rows:
        hit_flat = np.flatnonzero(flat_pk > pk_threshold)
    else:
        hit_flat = np.argpartition(flat_pk, -max_rows)[-max_rows:]

    hit_flat = hit_flat[np.argsort(flat_pk[hit_flat])[::-1]]
    h_idx, v_idx, a_idx = np.unravel_index(hit_flat, sys_pk.shape)

    rows = [
        {
            "HOB (m)": float(hob[hi]),
            "Velocity (m/s)": float(vel[vi]),
            "AOF (deg)": float(aof[ai]),
            "Pk": float(sys_pk[hi, vi, ai]),
        }
        for hi, vi, ai in zip(h_idx, v_idx, a_idx)
        if float(sys_pk[hi, vi, ai]) > pk_threshold
    ]

    hits_df = pd.DataFrame(rows)
    if hits_df.empty:
        return

    if n_voxels_above > max_rows:
        st.caption(f"Showing top {max_rows} of {n_voxels_above} conditions (sorted by Pk)")
    st.dataframe(hits_df, use_container_width=True, hide_index=True)


def render_mc_salvo_analysis(
    mc_data: Optional[Dict],
    config: Union[CampaignConfig, Dict[str, Any]],
) -> None:
    """Override of legacy MC view to support lazy HDF5 loading when present."""
    if isinstance(mc_data, dict) and H5_REF_KEY in mc_data and "mean_acc_pk_by_shot" not in mc_data:
        ref = mc_data[H5_REF_KEY]
        h5_path = ref["h5_path"]
        target_id = int(ref["target_id"])
        loaded = _load_hdf5_data(
            h5_path=h5_path,
            design_uuid=ref["design_uuid"],
            target_id=target_id,
            data_type="mc",
            keys=("mean_acc_pk_by_shot",),
        )
        if loaded:
            mc_data = {**mc_data, **loaded}

    return legacy.render_mc_salvo_analysis(mc_data, config)


# Re-export the remaining views unchanged.
render_campaign_statistics = legacy.render_campaign_statistics
render_weapon_characteristics = legacy.render_weapon_characteristics
