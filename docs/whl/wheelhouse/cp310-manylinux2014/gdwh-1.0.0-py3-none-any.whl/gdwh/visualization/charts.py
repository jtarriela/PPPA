"""
GDWH Visualization Charts Module

Combined implementation of Plotly visualizations and helper functions 
for the GDWH dashboard. Adapted from SABRE example code.
"""

import numpy as np
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from scipy.ndimage import map_coordinates
from skimage import measure
from typing import Optional, List, Tuple, Union, Iterable, Dict, Any

# =============================================================================
# Helper Functions (from plots.py)
# =============================================================================

def detect_hypercube_format(pk_det: np.ndarray, axes: dict) -> str:
    """
    Detect whether hypercube is in 'native' or 'legacy' format.
    
    Native format: (miss_x, miss_y, n_hob, n_vel, n_aof)
    Legacy format: (n_hob, n_vel, n_aof, miss_x, miss_y)
    """
    if pk_det.ndim != 5:
        raise ValueError(f"Expected 5D array, got {pk_det.ndim}D")
    
    n_miss_x = len(axes.get("miss_x", []))
    n_miss_y = len(axes.get("miss_y", []))
    n_hob = len(axes.get("hob", []))
    n_vel = len(axes.get("vel", []))
    n_aof = len(axes.get("aof", []))
    
    shape = pk_det.shape
    
    # Native: (miss_x, miss_y, hob, vel, aof)
    if shape == (n_miss_x, n_miss_y, n_hob, n_vel, n_aof):
        return "native"
    
    # Legacy: (hob, vel, aof, miss_x, miss_y)
    if shape == (n_hob, n_vel, n_aof, n_miss_x, n_miss_y):
        return "legacy"
    
    # Try to infer from dimension sizes
    if shape[0] > shape[2] and shape[1] > shape[3]:
        return "native"
    elif shape[3] > shape[0] and shape[4] > shape[1]:
        return "legacy"
    
    return "native"


@st.cache_data(max_entries=5, show_spinner=False)
def normalize_hypercube_to_native(pk_det: np.ndarray, axes: dict) -> np.ndarray:
    """Ensure hypercube is in native format: (miss_x, miss_y, n_hob, n_vel, n_aof)."""
    fmt = detect_hypercube_format(pk_det, axes)
    
    if fmt == "native":
        return pk_det
    elif fmt == "legacy":
        return np.transpose(pk_det, (3, 4, 0, 1, 2))
    else:
        return pk_det

@st.cache_data(max_entries=10, show_spinner=False)
def compute_curvature(data):
    """
    Compute scalar curvature (Laplacian) of a 3D array.
    """
    grads = np.gradient(data)
    laplacian = np.sum([np.gradient(g, axis=i) for i, g in enumerate(grads)], axis=0)
    return laplacian


@st.cache_data(max_entries=10, show_spinner=False)
def compute_gradient_magnitude(data: np.ndarray) -> np.ndarray:
    """Compute gradient magnitude (sensitivity) of a 3D array."""
    grads = np.gradient(data)
    return np.sqrt(sum(g**2 for g in grads))

# =============================================================================
# Plotly Plots (from plotly_plots.py)
# =============================================================================

def get_colorscale(name: str = 'blue_red'):
    """Return standard Plotly colorscales matching SABRE styles."""
    if name == 'blue_red':
        # White -> Blue -> Red
        return [
            [0.0, "white"],
            [0.5, "blue"],
            [1.0, "red"]
        ]
    elif name == 'r2k':
        return 'RdYlGn_r'
    elif name == 'jet':
        return 'Jet'
    return 'RdBu_r'

def plot_pk_heatmap_plotly(
    pk_slice: np.ndarray,
    x_axis: np.ndarray,
    y_axis: np.ndarray,
    x_label: str = "X",
    y_label: str = "Y",
    title: str = "Pk Heatmap",
    z_min: float = 0.0,
    z_max: float = 1.0,
    colorscale: str = 'blue_red',
    show_contours: bool = True,
    height: int = 600,
    colorbar_title: str = "Pk",
) -> go.Figure:
    scale = get_colorscale(colorscale) if colorscale == 'blue_red' else colorscale
    
    fig = go.Figure(data=go.Contour(
        z=pk_slice.T,
        x=x_axis,
        y=y_axis,
        colorscale=scale,
        zmin=z_min,
        zmax=z_max,
        contours=dict(
            coloring='heatmap',
            showlabels=True,
            start=z_min,
            end=z_max,
        ) if show_contours else None,
        line_smoothing=0.85,
        colorbar=dict(title=colorbar_title),
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title=x_label,
        yaxis_title=y_label,
        height=height,
        margin=dict(l=50, r=50, t=50, b=50),
    )
    return fig

def plot_r2k_heatmap_plotly(
    r2k_slice: np.ndarray,
    x_axis: np.ndarray,
    y_axis: np.ndarray,
    x_label: str = "X",
    y_label: str = "Y",
    title: str = "Rounds to Kill",
    max_rounds: int = 20,
    height: int = 600,
) -> go.Figure:
    fig = go.Figure(data=go.Heatmap(
        z=r2k_slice.T,
        x=x_axis,
        y=y_axis,
        colorscale='RdYlGn_r',
        zmin=1,
        zmax=max_rounds,
        colorbar=dict(title='Rounds'),
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title=x_label,
        yaxis_title=y_label,
        height=height,
    )
    return fig

def compute_hob_mr_grid(
    pk_hypercube: np.ndarray,
    hob_axis: np.ndarray,
    deflection_axis: np.ndarray,
    range_axis: np.ndarray,
    i_vel: int = 0,
    i_aof: int = 0,
    n_mr_points: int = 50,
    n_angles: int = 36,
) -> Tuple[np.ndarray, np.ndarray]:
    max_range = max(np.abs(deflection_axis).max(), np.abs(range_axis).max())
    mr_axis = np.linspace(0, max_range, n_mr_points)
    
    pk_hob_mr = np.zeros((len(hob_axis), len(mr_axis)))
    angles = np.linspace(0, 2 * np.pi, n_angles, endpoint=False)
    
    if pk_hypercube.ndim not in (3, 5):
        raise ValueError(f"Expected 3D (miss_x, miss_y, hob) or 5D hypercube, got {pk_hypercube.ndim}D")

    for i_hob in range(len(hob_axis)):
        if pk_hypercube.ndim == 3:
            pk_2d = pk_hypercube[:, :, i_hob]
        else:
            pk_2d = pk_hypercube[:, :, i_hob, i_vel, i_aof]
        
        for i_mr, mr in enumerate(mr_axis):
            if mr < 0.1:
                i_center_x = len(deflection_axis) // 2
                i_center_y = len(range_axis) // 2
                pk_hob_mr[i_hob, i_mr] = pk_2d[i_center_x, i_center_y]
            else:
                pk_samples = []
                for theta in angles:
                    x = mr * np.cos(theta)
                    y = mr * np.sin(theta)
                    i_x = np.argmin(np.abs(deflection_axis - x))
                    i_y = np.argmin(np.abs(range_axis - y))
                    if 0 <= i_x < pk_2d.shape[0] and 0 <= i_y < pk_2d.shape[1]:
                        pk_samples.append(pk_2d[i_x, i_y])
                pk_hob_mr[i_hob, i_mr] = np.mean(pk_samples) if pk_samples else 0.0
    
    return mr_axis, pk_hob_mr

def plot_hob_mr_contour_plotly(
    hob_axis: np.ndarray,
    miss_range_axis: np.ndarray,
    pk_grid: np.ndarray,
    title: str = "HOB-MR Contour",
    levels: int = 15,
    height: int = 600,
) -> go.Figure:
    fig = go.Figure(data=go.Contour(
        z=pk_grid.T,
        x=miss_range_axis,
        y=hob_axis,
        colorscale=get_colorscale('blue_red'),
        zmin=0.0,
        zmax=1.0,
        contours=dict(
            start=0,
            end=1,
            size=1.0/levels,
            showlabels=True,
        ),
        colorbar=dict(title='Pk')
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Miss Range (m)",
        yaxis_title="HOB (m)",
        height=height,
    )
    return fig

def plot_3d_volume_plotly(
    system_pk: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    opacity: float = 0.3,
    surface_count: int = 5,
    height: int = 700,
    colorbar_title: str = 'Pk',
    iso_val: float = None,
) -> go.Figure:
    H, V, A = np.meshgrid(hob_axis, vel_axis, aof_axis, indexing='ij')
    
    d_min, d_max = float(np.min(system_pk)), float(np.max(system_pk))
    
    if iso_val is not None:
        iso_min = iso_val
        # If user selected a specific value, show a small band around it or just that surface
        # For volume, isomin defines the floor. 
        iso_max = d_max
    else:
        iso_min, iso_max = (0.1, 1.0) if colorbar_title == 'Pk' else (d_min, d_max)

    fig = go.Figure(data=go.Isosurface(
        x=V.flatten(),
        y=H.flatten(),
        z=A.flatten(),
        value=system_pk.flatten(),
        isomin=iso_min,
        isomax=iso_max,
        opacity=opacity,
        surface_count=surface_count,
        colorscale='Jet',
        caps=dict(x_show=False, y_show=False),
        colorbar=dict(title=colorbar_title),
    ))
    
    fig.update_layout(
        title="3D System Pk Volume",
        scene=dict(
            xaxis_title='Velocity (m/s)',
            yaxis_title='HOB (m)',
            zaxis_title='AOF (deg)',
        ),
        margin=dict(l=0, r=0, b=0, t=30),
        height=height,
    )
    return fig

def plot_iso_mesh_colored_by_pk(
    iso_data: np.ndarray,
    color_data: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    aof_axis: np.ndarray,
    level: float,
    opacity: float = 0.5,
    height: int = 700,
) -> go.Figure:
    try:
        verts, faces, normals, values = measure.marching_cubes(iso_data, level=level)
    except (ValueError, RuntimeError):
        return go.Figure()

    color_vals = map_coordinates(color_data, verts.T, order=1)
    
    def map_axis(indices, axis):
        return np.interp(indices, np.arange(len(axis)), axis)

    phys_h = map_axis(verts[:, 0], hob_axis)
    phys_v = map_axis(verts[:, 1], vel_axis)
    phys_a = map_axis(verts[:, 2], aof_axis)
    
    fig = go.Figure(data=go.Mesh3d(
        x=phys_v,
        y=phys_h,
        z=phys_a,
        i=faces[:, 1],
        j=faces[:, 0],
        k=faces[:, 2],
        intensity=color_vals,
        colorscale='Jet',
        opacity=opacity,
        colorbar=dict(title='Pk'),
        cmin=0.0,
        cmax=1.0,
    ))
    
    fig.update_layout(
        title=f"Isosurface @ {level:.2f} Colored by Pk",
        scene=dict(
            xaxis_title='Velocity (m/s)',
            yaxis_title='HOB (m)',
            zaxis_title='AOF (deg)',
        ),
        margin=dict(l=0, r=0, b=0, t=30),
        height=height,
    )
    return fig

def plot_salvo_boxplot_plotly(
    rounds_to_kill: Union[np.ndarray, Iterable[float]],
    title: str = "Rounds-to-Kill Distribution",
    pk_threshold: float = 0.9,
    max_rounds: int = 10,
    height: int = 600,
) -> go.Figure:
    data = np.asarray(rounds_to_kill).flatten()
    data = data[~np.isnan(data)]
    
    fig = go.Figure()
    fig.add_trace(go.Box(
        y=data,
        name=f"Pk ≥ {pk_threshold:.0%}",
        boxpoints='outliers',
        jitter=0.3,
        pointpos=-1.8,
        marker=dict(color='rgb(7,40,89)'),
        line=dict(color='rgb(7,40,89)'),
        fillcolor='lightblue',
    ))
    
    fig.update_layout(
        title=title,
        yaxis_title="Rounds to Kill",
        yaxis_range=[0, max_rounds+1],
        height=height,
        showlegend=False,
    )
    
    if len(data) > 0:
        stats_text = (
            f"Median: {np.median(data):.2f}<br>"
            f"Mean: {np.mean(data):.2f}<br>"
            f"Std: {np.std(data):.2f}<br>"
            f"N: {len(data)}"
        )
        fig.add_annotation(
            xref="paper", yref="paper",
            x=0.95, y=0.95,
            text=stats_text,
            showarrow=False,
            align="right",
            bgcolor="rgba(255, 255, 255, 0.8)",
            bordercolor="black",
            borderwidth=1,
        )
    return fig

def plot_stoplight_grid_plotly(
    pass_threshold: np.ndarray,
    pass_objective: np.ndarray,
    hob_axis: np.ndarray,
    vel_axis: np.ndarray,
    title: str = "Threshold/Objective Stoplight",
    threshold_color: str = "rgb(144, 238, 144)",
    objective_color: str = "rgb(30, 144, 255)",
    height: int = 500,
) -> go.Figure:
    fig = go.Figure()
    
    d_hob = (hob_axis[-1] - hob_axis[0]) / (len(hob_axis) - 1) if len(hob_axis) > 1 else 1.0
    d_vel = (vel_axis[-1] - vel_axis[0]) / (len(vel_axis) - 1) if len(vel_axis) > 1 else 1.0
    
    pass_threshold_only = np.logical_and(pass_threshold, ~pass_objective)
    
    obj_hob_idx, obj_vel_idx = np.where(pass_objective)
    for h_i, v_i in zip(obj_hob_idx, obj_vel_idx):
        fig.add_shape(
            type="rect",
            x0=vel_axis[v_i], x1=vel_axis[v_i] + d_vel,
            y0=hob_axis[h_i], y1=hob_axis[h_i] + d_hob,
            fillcolor=objective_color,
            line=dict(color="black", width=0.5),
        )
    
    thr_hob_idx, thr_vel_idx = np.where(pass_threshold_only)
    for h_i, v_i in zip(thr_hob_idx, thr_vel_idx):
        fig.add_shape(
            type="rect",
            x0=vel_axis[v_i], x1=vel_axis[v_i] + d_vel,
            y0=hob_axis[h_i], y1=hob_axis[h_i] + d_hob,
            fillcolor=threshold_color,
            line=dict(color="black", width=0.5),
        )
    
    fig.add_trace(go.Scatter(
        x=[None], y=[None], mode='markers',
        marker=dict(size=15, color=objective_color, symbol='square'),
        name='Objective Met'
    ))
    fig.add_trace(go.Scatter(
        x=[None], y=[None], mode='markers',
        marker=dict(size=15, color=threshold_color, symbol='square'),
        name='Threshold Only'
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Velocity (m/s)",
        yaxis_title="HOB (m)",
        xaxis=dict(range=[vel_axis[0], vel_axis[-1] + d_vel]),
        yaxis=dict(range=[hob_axis[0], hob_axis[-1] + d_hob]),
        height=height,
        showlegend=True,
    )
    return fig

def plot_error_model_pdf_plotly(
    tle_radius_m: float,
    tle_fraction: float,
    cep_radius_m: float,
    cep_fraction: float,
    bias_x_m: float = 0.0,
    bias_y_m: float = 0.0,
    n_points: int = 200,
    max_extent: Optional[float] = None,
    height: int = 500,
    show_sigma_ellipses: bool = True,
) -> go.Figure:
    from scipy.stats import multivariate_normal
    
    def radius_to_sigma(radius: float, fraction: float) -> float:
        if fraction <= 0 or fraction >= 1 or radius <= 0:
            return 0.0
        return radius / np.sqrt(-2 * np.log(1 - fraction))
    
    sigma_tle = radius_to_sigma(tle_radius_m, tle_fraction)
    sigma_cep = radius_to_sigma(cep_radius_m, cep_fraction)
    sigma_total = np.sqrt(sigma_tle**2 + sigma_cep**2)
    
    if sigma_total < 1e-6:
        fig = go.Figure()
        fig.add_annotation(text="No error model (TLE/CEP=0)", x=0.5, y=0.5, showarrow=False)
        return fig
    
    if max_extent is None:
        max_extent = max(3.5 * sigma_total, abs(bias_x_m) + 3 * sigma_total, abs(bias_y_m) + 3 * sigma_total)
    
    x = np.linspace(-max_extent, max_extent, n_points)
    y = np.linspace(-max_extent, max_extent, n_points)
    X, Y = np.meshgrid(x, y)
    pos = np.dstack((X, Y))
    
    mean = [bias_x_m, bias_y_m]
    cov = [[sigma_total**2, 0], [0, sigma_total**2]]
    rv = multivariate_normal(mean, cov)
    Z = rv.pdf(pos)
    
    fig = go.Figure()
    fig.add_trace(go.Heatmap(
        x=x, y=y, z=Z, colorscale='Blues_r', showscale=True,
        colorbar=dict(title='PDF'), zsmooth='best', name='Error PDF'
    ))
    
    if show_sigma_ellipses:
        theta = np.linspace(0, 2*np.pi, 100)
        
        if tle_radius_m > 0:
            x_tle = bias_x_m + tle_radius_m * np.cos(theta)
            y_tle = bias_y_m + tle_radius_m * np.sin(theta)
            fig.add_trace(go.Scatter(
                x=x_tle, y=y_tle, mode='lines',
                line=dict(color='#00BFFF', width=2.5, dash='solid'),
                name=f'TLE r={tle_radius_m:.2f}m (P={tle_fraction:.0%})'
            ))
        
        if cep_radius_m > 0:
            x_cep = bias_x_m + cep_radius_m * np.cos(theta)
            y_cep = bias_y_m + cep_radius_m * np.sin(theta)
            fig.add_trace(go.Scatter(
                x=x_cep, y=y_cep, mode='lines',
                line=dict(color='#FFD700', width=2.5, dash='solid'),
                name=f'CEP r={cep_radius_m:.2f}m (P={cep_fraction:.0%})'
            ))
            
        x_combined = bias_x_m + sigma_total * np.cos(theta)
        y_combined = bias_y_m + sigma_total * np.sin(theta)
        fig.add_trace(go.Scatter(
            x=x_combined, y=y_combined, mode='lines',
            line=dict(color='#FF4500', width=2, dash='dot'),
            name=f'Combined 1σ={sigma_total:.2f}m'
        ))
    
    if abs(bias_x_m) > 0.1 or abs(bias_y_m) > 0.1:
        fig.add_annotation(
            x=bias_x_m, y=bias_y_m, ax=0, ay=0, showarrow=True, arrowhead=2,
            arrowcolor='#FF1744'
        )
        fig.add_trace(go.Scatter(
            x=[bias_x_m], y=[bias_y_m], mode='markers',
            marker=dict(size=12, color='#FF1744', symbol='x'),
            name=f'Bias ({bias_x_m:.2f}, {bias_y_m:.2f})m'
        ))
    
    fig.add_hline(y=0, line_dash="dot", line_color="rgba(255,255,255,0.5)")
    fig.add_vline(x=0, line_dash="dot", line_color="rgba(255,255,255,0.5)")
    
    stats_text = (
        f"TLE{tle_fraction*100:.0f}: σ={sigma_tle:.2f}m<br>"
        f"CEP{cep_fraction*100:.0f}: σ={sigma_cep:.2f}m<br>"
        f"Combined σ: {sigma_total:.2f}m<br>"
        f"Bias: ({bias_x_m:.2f}, {bias_y_m:.2f})m"
    )
    fig.add_annotation(
        xref="paper", yref="paper", x=0.02, y=0.98, text=stats_text,
        showarrow=False, align="left", bgcolor="rgba(30,30,30,0.85)",
        bordercolor="rgba(255,255,255,0.3)", font=dict(color="white")
    )
    
    fig.update_layout(
        title="Delivery Error Model PDF (TLE + CEP)",
        xaxis_title="Deflection (m)",
        yaxis_title="Range (m)",
        yaxis=dict(scaleanchor="x", scaleratio=1),
        height=height,
    )
    return fig

def plot_pk_vs_vel_hob_plotly(
    pk_2d: np.ndarray,
    vel_axis: np.ndarray,
    hob_axis: np.ndarray,
    title: str = "System Pk (Vel vs HOB)",
    z_min: float = 0.0,
    z_max: float = 1.0,
    height: int = 600,
) -> go.Figure:
    fig = go.Figure(data=go.Contour(
        z=pk_2d,
        x=vel_axis,
        y=hob_axis,
        colorscale=get_colorscale('blue_red'),
        zmin=z_min,
        zmax=z_max,
        contours=dict(coloring='heatmap', showlabels=True, start=z_min, end=z_max, size=0.1),
        line_smoothing=0.85,
        colorbar=dict(title='Pk'),
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Velocity (m/s)",
        yaxis_title="HOB (m)",
        height=height,
        margin=dict(l=50, r=50, t=50, b=50),
    )
    return fig

def plot_r2k_stoplight_plotly(
    r2k_2d: np.ndarray,
    vel_axis: np.ndarray,
    hob_axis: np.ndarray,
    threshold_rounds: int = 3,
    objective_rounds: int = 2,
    title: str = "R2K Stoplight Grid",
    height: int = 500,
) -> go.Figure:
    pass_threshold = r2k_2d <= threshold_rounds
    pass_objective = r2k_2d <= objective_rounds
    
    return plot_stoplight_grid_plotly(
        pass_threshold=pass_threshold,
        pass_objective=pass_objective,
        hob_axis=hob_axis,
        vel_axis=vel_axis,
        title=title,
        height=height,
    )

def plot_multi_threshold_boxplot_plotly(
    r2k_data: np.ndarray,
    pk_thresholds: List[float],
    title: str = "Rounds-to-Kill by Pk Threshold",
    max_rounds: int = 10,
    height: int = 500,
) -> go.Figure:
    fig = go.Figure()
    colors = px.colors.qualitative.Plotly
    
    for i, pk_thresh in enumerate(pk_thresholds):
        if r2k_data.ndim == 4:
            data = r2k_data[:, :, :, i].flatten()
        elif r2k_data.ndim == 3:
            data = r2k_data[:, :, i].flatten()
        else:
            data = r2k_data.flatten()
        
        data = data[~np.isnan(data)]
        
        if len(data) > 0:
            fig.add_trace(go.Box(
                y=data,
                name=f"Pk ≥ {pk_thresh:.0%}",
                marker_color=colors[i % len(colors)],
                boxpoints='outliers',
            ))
    
    fig.update_layout(
        title=title,
        yaxis_title="Rounds to Kill",
        yaxis_range=[0, max_rounds + 1],
        height=height,
        showlegend=True,
    )
    return fig

def plot_mc_draw_diagnostics_plotly(
    aimpoint_offsets: np.ndarray,
    dispersion_offsets: np.ndarray,
    tle_1sigma: float,
    cep_1sigma: float,
    var_bias: Optional[Tuple[float, float]] = None,
    n_salvos: int = 1,
    n_shots_per_salvo: int = 1,
    title: str = "MC Draw Diagnostics",
    height: int = 700,
    width: int = 1200,
) -> go.Figure:
    from plotly.subplots import make_subplots
    
    fig = make_subplots(
        rows=2, cols=4,
        column_widths=[0.35, 0.15, 0.35, 0.15],
        row_heights=[0.7, 0.3],
        horizontal_spacing=0.02,
        vertical_spacing=0.05,
        specs=[
            [{"type": "scatter"}, {"type": "histogram"}, {"type": "scatter"}, {"type": "histogram"}],
            [{"type": "histogram"}, None, {"type": "histogram"}, None],
        ],
    )
    
    # Aimpoint (TLE)
    aim_x, aim_y = aimpoint_offsets[:, 0], aimpoint_offsets[:, 1]
    aim_max = max(np.abs(aim_x).max(), np.abs(aim_y).max(), 3 * tle_1sigma) * 1.2
    
    fig.add_trace(go.Scatter(x=aim_x, y=aim_y, mode='markers', marker=dict(size=5, color='blue', opacity=0.6), name='Aimpoint Draws'), row=1, col=1)
    
    for sigma, dash in [(1, 'solid'), (2, 'dash'), (3, 'dot')]:
        theta = np.linspace(0, 2 * np.pi, 100)
        r = sigma * tle_1sigma
        fig.add_trace(go.Scatter(x=r*np.cos(theta), y=r*np.sin(theta), mode='lines', line=dict(color='red', width=1.5, dash=dash), name=f'{sigma}σ TLE'), row=1, col=1)
        
    fig.add_trace(go.Histogram(y=aim_y, nbinsx=30, marker_color='blue', opacity=0.6, showlegend=False), row=1, col=2)
    fig.add_trace(go.Histogram(x=aim_x, nbinsx=30, marker_color='blue', opacity=0.6, showlegend=False), row=2, col=1)

    # Dispersion (CEP)
    disp_flat = dispersion_offsets.reshape(-1, 2) if dispersion_offsets.ndim == 3 else dispersion_offsets
    disp_x, disp_y = disp_flat[:, 0], disp_flat[:, 1]
    disp_max = max(np.abs(disp_x).max(), np.abs(disp_y).max(), 3 * cep_1sigma) * 1.2
    
    fig.add_trace(go.Scatter(x=disp_x, y=disp_y, mode='markers', marker=dict(size=4, color='orange', opacity=0.5), name='Dispersion Draws'), row=1, col=3)
    
    for sigma, dash in [(1, 'solid'), (2, 'dash'), (3, 'dot')]:
        theta = np.linspace(0, 2 * np.pi, 100)
        r = sigma * cep_1sigma
        fig.add_trace(go.Scatter(x=r*np.cos(theta), y=r*np.sin(theta), mode='lines', line=dict(color='darkred', width=1.5, dash=dash), name=f'{sigma}σ CEP'), row=1, col=3)

    fig.add_trace(go.Histogram(y=disp_y, nbinsx=30, marker_color='orange', opacity=0.6, showlegend=False), row=1, col=4)
    fig.add_trace(go.Histogram(x=disp_x, nbinsx=30, marker_color='orange', opacity=0.6, showlegend=False), row=2, col=3)
    
    fig.update_xaxes(range=[-aim_max, aim_max], title_text="Deflection (m)", row=1, col=1)
    fig.update_yaxes(range=[-aim_max, aim_max], title_text="Range (m)", row=1, col=1, scaleanchor="x", scaleratio=1)
    
    fig.update_xaxes(range=[-disp_max, disp_max], title_text="Deflection (m)", row=1, col=3)
    fig.update_yaxes(range=[-disp_max, disp_max], title_text="Range (m)", row=1, col=3, scaleanchor="x3", scaleratio=1)
    
    fig.update_layout(title=title, height=height, width=width)
    return fig

def plot_radar_chart(
    r: List[float],
    theta: List[float],
    color: str = None,
    fill_color: str = None,
    title: str = "",
    height: int = 350
) -> go.Figure:
    """Create radar plot."""
    if color and not fill_color:
        if 'rgb' in color:
            fill_color = color.replace('rgb', 'rgba').replace(')', ',0.3)')
        else:
            # Simple heuristic for hex or names, or just leave None
            fill_color = color # Plotly handles many formats

    fig = go.Figure(data=go.Scatterpolar(
        r=r, theta=theta, fill='toself',
        line_color=color,
        fillcolor=fill_color
    ))
    fig.update_layout(
        title=title,
        showlegend=False,
        polar=dict(
            bgcolor="white",
            radialaxis=dict(visible=True, showticklabels=True, tickfont=dict(color="black", size=12), gridcolor="lightgray"),
            angularaxis=dict(direction="clockwise", rotation=90, tickfont=dict(color="black", size=11))
        ),
        paper_bgcolor="rgba(255, 255, 255, 0.95)",
        font=dict(color="black"),
        margin=dict(l=35, r=35, t=20, b=35),
        height=height
    )
    return fig


# =============================================================================
# Multi-Objective Visualization Charts (ADR-012 related)
# =============================================================================

def plot_objective_correlation_heatmap(
    df,
    obj_columns: List[str],
    title: str = "Objective Correlations",
    height: int = 500,
) -> go.Figure:
    """
    Plot correlation heatmap for objectives on the Pareto front.

    Negative correlations indicate trade-offs between objectives.
    Positive correlations indicate objectives that move together.

    Args:
        df: DataFrame containing objective values
        obj_columns: List of objective column names
        title: Plot title
        height: Figure height in pixels

    Returns:
        Plotly Figure with annotated correlation heatmap
    """
    import pandas as pd

    corr = df[obj_columns].corr()

    # Create shorter labels for display
    labels = [col.replace('_', ' ').title()[:15] for col in obj_columns]

    fig = px.imshow(
        corr.values,
        x=labels,
        y=labels,
        text_auto='.2f',
        color_continuous_scale='RdBu_r',
        zmin=-1,
        zmax=1,
        aspect='equal',
    )

    fig.update_layout(
        title=f"{title} (negative = trade-off)",
        height=height,
        xaxis_tickangle=-45,
        margin=dict(l=80, r=20, t=60, b=80),
    )

    return fig


def plot_objective_distributions(
    df,
    obj_columns: List[str],
    title: str = "Objective Distributions on Pareto Front",
    height: int = 400,
) -> go.Figure:
    """
    Plot violin plots showing distribution of each objective across Pareto front.

    Values are normalized to [0,1] for comparison across different scales.

    Args:
        df: DataFrame containing objective values
        obj_columns: List of objective column names
        title: Plot title
        height: Figure height in pixels

    Returns:
        Plotly Figure with violin plots for each objective
    """
    import pandas as pd

    # Normalize to [0,1] for comparison across different scales
    df_subset = df[obj_columns].copy()
    df_norm = (df_subset - df_subset.min()) / (df_subset.max() - df_subset.min() + 1e-12)

    # Create shorter labels
    rename_map = {col: col.replace('_', ' ').title()[:15] for col in obj_columns}
    df_norm = df_norm.rename(columns=rename_map)

    df_melted = df_norm.melt(var_name='Objective', value_name='Normalized Value')

    fig = px.violin(
        df_melted,
        x='Objective',
        y='Normalized Value',
        box=True,
        points='outliers',
    )

    fig.update_layout(
        title=title,
        height=height,
        xaxis_tickangle=-45,
        margin=dict(l=60, r=20, t=60, b=100),
    )

    return fig
