"""Configuration loader for GWDH-NG campaigns."""

import hashlib
import yaml
from pathlib import Path
from typing import Dict
from dataclasses import dataclass

from .schema import CampaignConfig, TargetConfig


@dataclass
class TargetInputBytes:
    """Input file bytes for a single target."""

    rcas_number: int
    rcas_bytes: bytes
    intrvc_bytes: bytes
    cdrag_bytes: bytes
    checksum: str  # SHA256 of concatenated bytes


class InputBytesCache:
    """Cache for input file bytes loaded once at startup."""

    def __init__(self):
        self.targets: Dict[int, TargetInputBytes] = {}

    @classmethod
    def load_all(cls, config: CampaignConfig) -> "InputBytesCache":
        """Load all input files from campaign configuration as bytes."""
        cache = cls()

        for target in config.targets:
            cache.targets[target.rcas_number] = cls._load_target(target)

        return cache

    @classmethod
    def _load_target(cls, target: TargetConfig) -> TargetInputBytes:
        """Load input files for a single target."""
        rcas_bytes = target.rcas_path.read_bytes()
        intrvc_bytes = target.intrvc_path.read_bytes()
        cdrag_bytes = target.cdrag_path.read_bytes()

        # Compute checksum for integrity verification
        hasher = hashlib.sha256()
        hasher.update(rcas_bytes)
        hasher.update(intrvc_bytes)
        hasher.update(cdrag_bytes)
        checksum = hasher.hexdigest()

        return TargetInputBytes(
            rcas_number=target.rcas_number,
            rcas_bytes=rcas_bytes,
            intrvc_bytes=intrvc_bytes,
            cdrag_bytes=cdrag_bytes,
            checksum=checksum,
        )

    def get_target_bytes(self, rcas_number: int) -> TargetInputBytes:
        """Retrieve cached bytes for a target."""
        if rcas_number not in self.targets:
            raise KeyError(f"Target {rcas_number} not found in cache")
        return self.targets[rcas_number]


class ConfigLoader:
    """Load and validate campaign configurations from YAML."""

    @staticmethod
    def from_yaml(yaml_path: Path) -> CampaignConfig:
        """Load campaign configuration from YAML file."""
        if not yaml_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {yaml_path}")

        with open(yaml_path, "r") as f:
            config_dict = yaml.safe_load(f)

        # Convert paths to absolute paths relative to config file location
        config_dir = yaml_path.parent
        config_dict = ConfigLoader._resolve_paths(config_dict, config_dir)

        # Transform terminal_conditions to axes vectors if present
        ConfigLoader._transform_terminal_conditions(config_dict)

        # Parse with Pydantic
        config = CampaignConfig(**config_dict)

        # Validate input files exist
        ConfigLoader._validate_input_files(config)

        return config

    @staticmethod
    def _resolve_paths(config_dict: dict, base_dir: Path) -> dict:
        """Resolve relative paths in configuration."""

        def resolve_path_recursive(obj, key_path=""):
            """Recursively resolve Path fields."""
            if isinstance(obj, dict):
                for key, value in obj.items():
                    # Resolve input paths relative to config file, but keep outputs relative to CWD
                    is_output = key == "database" or "consolidated_dir" in key or "output" in key
                    is_frag_csv = key == "frag_csv_path"
                    if ((key.endswith("_path") or key.endswith("_dir") or is_frag_csv) and not is_output):
                        if isinstance(value, str):
                            obj[key] = str((base_dir / value).resolve())
                    # Recurse into nested structures
                    if isinstance(value, (dict, list)):
                        resolve_path_recursive(value, f"{key_path}.{key}")
            elif isinstance(obj, list):
                for item in obj:
                    resolve_path_recursive(item, key_path)

        resolve_path_recursive(config_dict)
        return config_dict

    @staticmethod
    def _transform_terminal_conditions(config_dict: dict):
        """Transform terminal_conditions range to axes vectors if present."""
        if 'megadeth' not in config_dict:
            return

        megadeth = config_dict['megadeth']
        if 'terminal_conditions' in megadeth:
            tc = megadeth['terminal_conditions']
            axes = {}

            # Generate vectors for each axis
            for axis_name, axis_key in [('hob', 'hob_m'), ('velocity', 'vel_mps'), ('aof', 'aof_deg')]:
                if axis_name in tc:
                    params = tc[axis_name]
                    min_val = float(params['min'])
                    max_val = float(params['max'])
                    step = float(params['step'])
                    
                    # Generate inclusive range
                    # Use integer counts to avoid floating point drift
                    count = int(round((max_val - min_val) / step)) + 1
                    vector = [min_val + i * step for i in range(count)]
                    axes[axis_key] = vector

            # Update config with axes and remove terminal_conditions
            megadeth['axes'] = axes
            del megadeth['terminal_conditions']

    @staticmethod
    def _validate_input_files(config: CampaignConfig):
        """Validate that all input files exist."""
        missing_files = []

        for target in config.targets:
            if not target.rcas_path.exists():
                missing_files.append(f"RCAS: {target.rcas_path}")
            if not target.intrvc_path.exists():
                missing_files.append(f"INTRVC: {target.intrvc_path}")
            if not target.cdrag_path.exists():
                missing_files.append(f"CDRAG: {target.cdrag_path}")

        if missing_files:
            raise FileNotFoundError(
                f"Missing input files:\n" + "\n".join(f"  - {f}" for f in missing_files)
            )

    @staticmethod
    def to_yaml(config: CampaignConfig, output_path: Path):
        """Save campaign configuration to YAML file."""
        # Convert to dict and handle Path serialization
        config_dict = config.model_dump(mode="json")

        with open(output_path, "w") as f:
            yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False, indent=2)
