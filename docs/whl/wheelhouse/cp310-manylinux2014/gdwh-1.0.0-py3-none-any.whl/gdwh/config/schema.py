"""Configuration schema for GWDH-NG using Pydantic v2."""

from pathlib import Path
from typing import Dict, List, Optional, Sequence
from pydantic import BaseModel, Field, field_validator


class ExecutionConfig(BaseModel):
    """Select run mode and optional fragment import source."""

    mode: str = Field(
        default="ga",
        description="Execution mode: 'ga' for optimization or 'frag_import' to load external CSV designs.",
    )
    frag_csv_path: Optional[Path] = Field(
        default=None,
        description="Path to fragment CSV when mode='frag_import'.",
    )


class WarheadConfig(BaseModel):
    """Warhead geometry and mass constraints."""

    n_zones: int = Field(15, description="Number of angular zones")
    zdata_number: int = Field(1000, description="Fixed 4-digit warhead ID (FullSpray limit)")

    class MassConstraints(BaseModel):
        total_mass_kg: float
        fragment_mass_kg: float
        charge_mass_kg: Optional[float] = None  # Computed if null

    class Physics(BaseModel):
        # Gurney constant - input in km/s (domain convention), converted to m/s internally
        gurney_constant_kms: float = Field(
            default=2.7,
            description="Gurney constant sqrt(2E) in km/s (domain convention)"
        )
        # Material densities for physics context (downstream 2D/3D design)
        density_explosive_kg_m3: float = Field(
            default=1700.0,
            description="Explosive density in kg/m³ (e.g., Comp B: 1717, RDX: 1820)"
        )
        density_fragment_kg_m3: float = Field(
            default=7850.0,
            description="Fragment material density in kg/m³ (e.g., steel: 7850)"
        )
        
        shape_factor: float = Field(
            default=0.461235589,  # Steel Cube default
            description="Fragment shape factor (k-factor) for drag. Default is Steel Cube."
        )

        @property
        def gurney_constant_sqrt2e(self) -> float:
            """Get Gurney constant in m/s (converted from km/s input)."""
            return self.gurney_constant_kms * 1000.0

    mass_constraints: MassConstraints
    physics: Physics


class VariablesConfig(BaseModel):
    """Design variable configuration."""

    class FragmentSizes(BaseModel):
        bin_edges_grams: List[float] = Field(
            default=[0, 1, 2, 4, 8, 16, 32, 64],
            description="Fragment size bin edges in grams (7 bins)"
        )

    class FragmentQuantities(BaseModel):
        min_per_bin: int = 0
        max_per_bin: int = 10000

    class ZoneVelocities(BaseModel):
        bounds_mps: List[float] = Field(
            default=[500.0, 2500.0],
            description="Zone velocity bounds in m/s"
        )
        strategy: str = Field(
            default="nodal",
            description="Velocity representation: 'nodal' (N+1 boundary velocities) or 'uniform' (N zone velocities)"
        )

    fragment_sizes: FragmentSizes
    fragment_quantities: FragmentQuantities
    zone_velocities: ZoneVelocities


class TargetConfig(BaseModel):
    """Per-target descriptor with physics input file paths."""

    name: str
    rcas_number: int
    rcas_path: Path
    intrvc_path: Path
    cdrag_path: Path
    centroid_height_ft: Optional[float] = None


class MatrixOverrides(BaseModel):
    """Optional IP.DAT matrix settings overrides."""

    nx: Optional[int] = None
    ny: Optional[int] = None
    cell_size_m: Optional[float] = None
    range_offset_m: Optional[float] = None


class PrecisionConfig(BaseModel):
    """TLE/CEP/bias error model parameters for Monte Carlo analysis."""

    label: str = "default"
    tle_radius_m: float = 30.0
    tle_fraction: float = 0.90
    cep_radius_m: float = 5.0
    cep_fraction: float = 0.50
    fixed_bias_deflection_m: float = 0.0
    fixed_bias_range_m: float = 0.0
    variable_bias_radius_m: float = 0.0
    variable_bias_fraction: float = 0.50
    tle_z_sigma_m: float = 0.0
    cep_z_sigma_m: float = 0.0


class MEGADETHConfig(BaseModel):
    """MEGADETH solver configuration."""

    fsm_exe_path: Optional[Path] = None  # Auto-detected if omitted
    staging_strategy: str = "batched"
    max_parallel_workers: int = 1
    backend: str = Field(
        default="fortran",
        description="Physics backend: 'fortran' (FSM executable) or 'cpp' (gfs_physics in-memory)"
    )

    class Axes(BaseModel):
        hob_m: List[float] = Field(description="Height of burst in meters")
        vel_mps: List[float] = Field(description="Velocity in m/s")
        aof_deg: List[float] = Field(description="Angle of fall in degrees")

    axes: Axes
    pk_threshold: float = 0.5
    run_mc: bool = False
    matrix_overrides: Optional[MatrixOverrides] = None


class GuidedInitConfig(BaseModel):
    """Configuration for guided population initialization."""

    strategy: str = "guided"  # "guided" | "random"
    
    mass_budget_fraction: List[float] = Field(
        default=[0.8, 1.0],
        description="Fraction of total mass limit to target [min, max]"
    )
    
    velocity_fraction: List[float] = Field(
        default=[0.5, 0.99],
        description="Fraction of Gurney velocity limit to target [min, max]"
    )
    
    # Split between fragment and total available mass (minus case)
    frag_mass_split: List[float] = Field(
        default=[0.1, 0.9],
        description="Fraction of available mass allocated to fragments [min, max]"
    )


class ObjectiveConfig(BaseModel):
    """Objective function configuration."""

    enabled: bool = True
    direction: str  # "maximize" or "minimize"
    per_target: bool = False


class ObjectivesConfig(BaseModel):
    """Multi-objective configuration."""

    integrated_kill_potential: ObjectiveConfig = ObjectiveConfig(
        direction="maximize", per_target=True
    )
    volume_at_threshold: ObjectiveConfig = ObjectiveConfig(
        direction="maximize", per_target=True
    )
    total_mass: ObjectiveConfig = ObjectiveConfig(
        direction="minimize", per_target=False
    )
    fragment_mass: ObjectiveConfig = ObjectiveConfig(
        direction="minimize", per_target=False
    )
    explosive_mass: ObjectiveConfig = ObjectiveConfig(
        direction="minimize", per_target=False
    )


class GAConfig(BaseModel):
    """Genetic algorithm configuration."""

    algorithm: str = "NSGA-III"  # or "NSGA-II"
    population_size: int = 10000
    max_generations: int = 150

    initialization: GuidedInitConfig = Field(default_factory=GuidedInitConfig)

    class Termination(BaseModel):
        class Convergence(BaseModel):
            metric: str = "hypervolume"
            tolerance: float = 0.001
            window_gens: int = 20

        convergence: Convergence = Field(default_factory=Convergence)

    class Operators(BaseModel):
        crossover_eta: int = 15
        crossover_prob: float = 0.9
        mutation_eta: int = 20

    termination: Termination = Field(default_factory=Termination)
    operators: Operators = Field(default_factory=Operators)


class ParallelConfig(BaseModel):
    """Parallelization configuration."""

    mode: str = "mpi"  # "mpi" | "multiprocessing" | "auto"

    class MPI(BaseModel):
        nodes: int = 4
        cores_per_node: int = 92
        designs_per_core: float = Field(
            default=2.5,
            description="Target designs per CPU core per micro-batch when batch_size=0 (auto)."
        )
        # DEPRECATED (ADR-004): Chunking removed, mpi4py handles large messages natively.
        # This field is ignored but retained for backwards compatibility with existing configs.
        mpi_rank_chunk_size_mb: int = Field(
            default=8,
            description="[DEPRECATED] No longer used. MPI handles large messages natively."
        )

    class VariableGeneration(BaseModel):
        parallel: bool = True  # Vectorized numpy

    class FeasibilityCheck(BaseModel):
        parallel: bool = True  # Vectorized numpy

    class ZDATAGeneration(BaseModel):
        parallel: bool = True
        chunk_size: int = 100

    mpi: MPI = Field(default_factory=MPI)
    variable_generation: VariableGeneration = Field(default_factory=VariableGeneration)
    feasibility_check: FeasibilityCheck = Field(default_factory=FeasibilityCheck)
    zdata_generation: ZDATAGeneration = Field(default_factory=ZDATAGeneration)


class StorageConfig(BaseModel):
    """Storage configuration for UUID-based consolidation."""

    database: Path = Path("output/optimization.duckdb")

    class HDF5(BaseModel):
        """HDF5 storage configuration for hypercube data."""
        consolidated_dir: Path = Path("output/hdf5")
        retention: str = Field(
            default="all",
            description="[DEPRECATED per ADR-008] Retention policy is no longer used. All discrete data is stored."
        )
        ga_data_types: List[str] = Field(
            default=["discrete"],
            description="Data types to store during GA: ['discrete'] (default, lightweight) or ['pk', 'discrete', 'mc'] (full)"
        )

    class ZDATA(BaseModel):
        store_bytes: bool = True

    class Inputs(BaseModel):
        store_bytes: bool = True

    class Checkpoints(BaseModel):
        enabled: bool = True
        every_n_gens: int = 10
        path: Path = Path("output/checkpoints")

    hdf5: HDF5 = Field(default_factory=HDF5)
    zdata: ZDATA = Field(default_factory=ZDATA)
    inputs: Inputs = Field(default_factory=Inputs)
    checkpoints: Checkpoints = Field(default_factory=Checkpoints)


class LoggingConfig(BaseModel):
    """Logging configuration."""

    level: str = "INFO"
    file: Path = Path("logs/campaign.log")
    mpi_per_rank: bool = True
    console: bool = False  # Set True to also log to stdout


class CampaignConfig(BaseModel):
    """Top-level campaign configuration."""

    name: str
    version: str = "3.3"

    warhead: WarheadConfig
    variables: VariablesConfig
    targets: List[TargetConfig]
    megadeth: MEGADETHConfig
    precision: PrecisionConfig  # Baseline precision
    objectives: ObjectivesConfig
    ga: GAConfig
    parallel: ParallelConfig
    storage: StorageConfig
    logging: LoggingConfig
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)

    @field_validator('targets')
    @classmethod
    def validate_targets_not_empty(cls, v):
        """Ensure at least one target is specified."""
        if not v:
            raise ValueError("At least one target must be specified")
        return v

    def count_variables(self) -> int:
        """Calculate total number of design variables."""
        n_zones = self.warhead.n_zones
        n_bins = len(self.variables.fragment_sizes.bin_edges_grams) - 1

        # frag_sizes: n_zones × n_bins
        # frag_quantities: n_zones × n_bins
        # velocities: depends on strategy
        if self.variables.zone_velocities.strategy == "nodal":
            # Nodal: N+1 boundary velocities
            n_velocities = n_zones + 1
        else:
            # Zonal: N zone velocities (legacy)
            n_velocities = n_zones

        return n_zones * n_bins * 2 + n_velocities

    def count_objectives(self) -> int:
        """Calculate total number of objectives."""
        n_obj = 0

        if self.objectives.integrated_kill_potential.enabled:
            n_obj += len(self.targets) if self.objectives.integrated_kill_potential.per_target else 1

        if self.objectives.volume_at_threshold.enabled:
            n_obj += len(self.targets) if self.objectives.volume_at_threshold.per_target else 1

        if self.objectives.total_mass.enabled:
            n_obj += 1

        if self.objectives.fragment_mass.enabled:
            n_obj += 1

        if self.objectives.explosive_mass.enabled:
            n_obj += 1

        return n_obj
