"""Build MEGADETH GaStaticContext from campaign configuration."""

from pathlib import Path
from typing import List, Dict, Sequence

try:
    from megadeth.ga import (
        GaStaticContext,
        TargetSpec,
        PrecisionSpec,
        MatrixOverrides as MEGADETHMatrixOverrides,
    )
    MEGADETH_AVAILABLE = True
except ImportError:
    MEGADETH_AVAILABLE = False
    # Define placeholder types for development without MEGADETH
    GaStaticContext = object
    TargetSpec = object
    PrecisionSpec = object
    MEGADETHMatrixOverrides = object

from .schema import CampaignConfig, MatrixOverrides, PrecisionConfig
from .loader import InputBytesCache


class StaticContextBuilder:
    """Build MEGADETH GaStaticContext from GWDH campaign configuration."""

    @staticmethod
    def build(config: CampaignConfig, input_cache: InputBytesCache) -> GaStaticContext:
        """Build GaStaticContext with bytes-based input files."""
        if not MEGADETH_AVAILABLE:
            raise ImportError(
                "MEGADETH library is not installed. Install with: pip install -e /path/to/megadeth"
            )

        # Build target specs with bytes
        targets = StaticContextBuilder._build_targets(config, input_cache)

        # Build axes dictionary
        axes = StaticContextBuilder._build_axes(config)

        # Build precision specs
        precisions = StaticContextBuilder._build_precisions(config)

        # Build matrix overrides if specified
        matrix_overrides = StaticContextBuilder._build_matrix_overrides(
            config.megadeth.matrix_overrides
        )

        # Create GaStaticContext
        static_context = GaStaticContext(
            targets=targets,
            axes=axes,
            fsm_exe_path=config.megadeth.fsm_exe_path,
            staging_strategy=config.megadeth.staging_strategy,
            max_parallel_workers=config.megadeth.max_parallel_workers,
            enable_parallel_salvos=False,  # Disabled for GA determinism
            matrix_overrides=matrix_overrides,
            precisions=precisions,
            backend=config.megadeth.backend,  # Pass through backend selection
        )

        return static_context

    @staticmethod
    def _build_targets(
        config: CampaignConfig, input_cache: InputBytesCache
    ) -> List[TargetSpec]:
        """Build TargetSpec list with bytes-based inputs."""
        targets = []

        for target_config in config.targets:
            # Get cached bytes
            target_bytes = input_cache.get_target_bytes(target_config.rcas_number)

            # Create TargetSpec with bytes (no file paths needed)
            target_spec = TargetSpec(
                rcas_number=target_config.rcas_number,
                rcas_bytes=target_bytes.rcas_bytes,
                intrvc_bytes=target_bytes.intrvc_bytes,
                cdrag_bytes=target_bytes.cdrag_bytes,
                centroid_height_ft=target_config.centroid_height_ft,
            )

            targets.append(target_spec)

        return targets

    @staticmethod
    def _build_axes(config: CampaignConfig) -> Dict[str, Sequence[float]]:
        """Build axes dictionary for terminal conditions."""
        return {
            "hob": config.megadeth.axes.hob_m,
            "vel": config.megadeth.axes.vel_mps,
            "aof": config.megadeth.axes.aof_deg,
        }

    @staticmethod
    def _build_precisions(config: CampaignConfig) -> List[PrecisionSpec]:
        """Build precision specifications for error modeling.

        Uses the single top-level precision config for the entire GA run.
        """
        baseline = config.precision
        return [
            PrecisionSpec(
                label=baseline.label,
                tle_radius_m=baseline.tle_radius_m,
                tle_fraction=baseline.tle_fraction,
                cep_radius_m=baseline.cep_radius_m,
                cep_fraction=baseline.cep_fraction,
                fixed_bias_deflection_m=baseline.fixed_bias_deflection_m,
                fixed_bias_range_m=baseline.fixed_bias_range_m,
                variable_bias_radius_m=baseline.variable_bias_radius_m,
                variable_bias_fraction=baseline.variable_bias_fraction,
                tle_z_sigma_m=baseline.tle_z_sigma_m,
                cep_z_sigma_m=baseline.cep_z_sigma_m,
            )
        ]

    @staticmethod
    def _build_matrix_overrides(
        config_overrides: MatrixOverrides | None,
    ) -> MEGADETHMatrixOverrides | None:
        """Build MEGADETH matrix overrides if specified."""
        if config_overrides is None:
            return None

        return MEGADETHMatrixOverrides(
            nx=config_overrides.nx,
            ny=config_overrides.ny,
            cell_size_m=config_overrides.cell_size_m,
            range_offset_m=config_overrides.range_offset_m,
        )
