"""
MEGADETH queue processor for on-demand hypercube regeneration (ADR-006).

Supports:
- Single-core sequential processing (default, safest)
- Multiprocess parallel processing (optional, faster)
- CLI interface for background execution
"""

import os
import time
import copy
import socket
import tempfile
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Callable, Any
from concurrent.futures import ProcessPoolExecutor

import duckdb

from ..utils import setup_logger


@dataclass
class QueueConfig:
    """Configuration for queue processor."""

    max_workers: int = 1  # 1 = sequential, >1 = multiprocess
    batch_size: int = 10  # Process N items before committing
    poll_interval_s: float = 5.0  # Sleep between empty polls
    max_failures: int = 3  # Retry limit per item


class QueueProcessor:
    """
    Process MEGADETH regeneration queue.

    Design decisions:
    - Uses a separate DuckDB connection (read-write)
    - Appends to existing campaign HDF5 file with file locking
    - Supports graceful shutdown via stop() method
    """

    def __init__(
        self,
        db_path: Path,
        config_loader: Callable[[str], Any],
        queue_config: Optional[QueueConfig] = None,
    ):
        """
        Initialize queue processor.

        Args:
            db_path: Path to DuckDB database
            config_loader: Function to load CampaignConfig by campaign_id
            queue_config: Queue processing configuration
        """
        self.db_path = Path(db_path)
        self.config_loader = config_loader
        self.queue_config = queue_config or QueueConfig()
        self.logger = setup_logger("gdwh.queue.processor")
        self._running = False
        self._conn: Optional[duckdb.DuckDBPyConnection] = None
        self._worker_id = f"worker_{os.getpid()}_{socket.gethostname()}"

    def start(self) -> None:
        """Start processing queue items (blocking)."""
        self._running = True
        self._conn = duckdb.connect(str(self.db_path), read_only=False)

        self.logger.info(
            f"Queue processor started (max_workers={self.queue_config.max_workers}, "
            f"batch_size={self.queue_config.batch_size})"
        )

        try:
            while self._running:
                items = self._claim_batch()

                if not items:
                    self.logger.debug(
                        f"No pending items, sleeping {self.queue_config.poll_interval_s}s"
                    )
                    time.sleep(self.queue_config.poll_interval_s)
                    continue

                self.logger.info(f"Processing {len(items)} queue items")

                if self.queue_config.max_workers == 1:
                    self._process_sequential(items)
                else:
                    self._process_parallel(items)

        finally:
            if self._conn:
                self._conn.close()
                self._conn = None

    def stop(self) -> None:
        """Signal processor to stop."""
        self._running = False
        self.logger.info("Stop signal received")

    def _claim_batch(self) -> List[dict]:
        """Atomically claim a batch of pending items."""
        try:
            # Use UPDATE ... RETURNING for atomic claim
            result = self._conn.execute(
                """
                UPDATE megadeth_queue
                SET status = 'running',
                    started_at = CURRENT_TIMESTAMP,
                    worker_id = ?
                WHERE queue_id IN (
                    SELECT queue_id FROM megadeth_queue
                    WHERE status = 'pending'
                    ORDER BY priority DESC, requested_at ASC
                    LIMIT ?
                )
                RETURNING queue_id, design_uuid, campaign_id, target_id, data_types
                """,
                [self._worker_id, self.queue_config.batch_size],
            ).fetchall()

            self._conn.commit()

            return [
                {
                    "queue_id": r[0],
                    "design_uuid": r[1],
                    "campaign_id": r[2],
                    "target_id": r[3],
                    "data_types": r[4] or ["pk"],
                }
                for r in result
            ]
        except Exception as e:
            self.logger.error(f"Failed to claim batch: {e}")
            return []

    def _process_sequential(self, items: List[dict]) -> None:
        """Process items one at a time."""
        for item in items:
            try:
                self._process_single(item)
                self._mark_completed(item["queue_id"])
            except Exception as e:
                self.logger.error(f"Failed to process {item['design_uuid']}: {e}")
                self._mark_failed(item["queue_id"], str(e))

    def _process_parallel(self, items: List[dict]) -> None:
        """Process items in parallel using ProcessPoolExecutor."""
        # For parallel processing, we need to handle this differently
        # since MEGADETH and HDF5 operations aren't easily parallelizable
        # across processes due to file locking. Use sequential for now
        # but with multiprocess evaluator internally.
        self.logger.warning(
            "Parallel queue processing uses sequential item processing "
            "with multiprocess MEGADETH evaluation per item"
        )
        self._process_sequential(items)

    def _process_single(self, item: dict) -> None:
        """Regenerate data for a single design."""
        campaign_id = item["campaign_id"]
        design_uuid = item["design_uuid"]
        target_id = item["target_id"]
        data_types = item["data_types"]

        self.logger.info(
            f"Processing {design_uuid} for campaign {campaign_id}, "
            f"target={target_id}, data_types={data_types}"
        )

        # Load campaign config
        config = self.config_loader(campaign_id)
        if config is None:
            raise ValueError(f"Campaign config not found for {campaign_id}")

        # Get ZDATA bytes from database
        zdata_bytes = self._get_zdata(design_uuid)
        if not zdata_bytes:
            raise ValueError(f"ZDATA not found for {design_uuid}")

        # Build static context and run MEGADETH
        from ..config import InputBytesCache, StaticContextBuilder
        from ..megadeth.evaluator import MEGADETHEvaluator
        from ..megadeth.results import ResultExtractor
        from ..storage.hdf5_writer import HDF5Writer

        # Load input bytes from database
        input_cache = self._load_input_cache(campaign_id, config)

        # Build static context
        static_context = StaticContextBuilder.build(config, input_cache)

        # Create unique output directory
        hostname = socket.gethostname()
        # Use /dev/shm for speed and auto-cleanup on reboot, but strictly clean up after ourselves
        local_temp_base = Path("/dev/shm") / f"megadeth_queue_{hostname}_{os.getpid()}"
        
        try:
            local_temp_base.mkdir(parents=True, exist_ok=True)
            local_context = copy.copy(static_context)
            local_context.base_output_dir = local_temp_base / design_uuid
            local_context.base_output_dir.mkdir(parents=True, exist_ok=True)
            local_context.staging_strategy = "batched"

            # Run MEGADETH
            try:
                from megadeth.ga import run_ga_design, DesignVector

                design_vector = DesignVector(
                    zdata_number=config.warhead.zdata_number,
                    zdata_bytes=zdata_bytes,
                )

                start_time = time.time()
                ga_result = run_ga_design(
                    design=design_vector,
                    static=local_context,
                    pk_threshold=config.megadeth.pk_threshold,
                    run_mc=config.megadeth.run_mc,
                )
                eval_time = time.time() - start_time

                # Extract with requested data types (typically ['pk'] for queue)
                result = ResultExtractor.extract(
                    design_uuid,
                    ga_result,
                    eval_time_s=eval_time,
                    include_data_types=data_types,
                )

                self.logger.info(f"MEGADETH completed for {design_uuid} in {eval_time:.1f}s")

            except ImportError as e:
                raise RuntimeError(f"MEGADETH not available: {e}")

            # Write to HDF5
            default_h5_path = config.storage.hdf5.consolidated_dir / f"{campaign_id}.h5"
            # ADR-009: Lookup generation file
            h5_path = self._get_h5_path_for_design(design_uuid, campaign_id, default_h5_path)
            
            # Ensure parent dir exists (just in case)
            h5_path.parent.mkdir(parents=True, exist_ok=True)

            with HDF5Writer(h5_path, campaign_id=campaign_id) as writer:
                for tid, data_map in result.binary_data.items():
                    if target_id is not None and tid != target_id:
                        continue
                    for npz_type, data_bytes in data_map.items():
                        if npz_type in data_types:
                            h5_dataset_path = writer.add_from_bytes(
                                design_uuid, tid, npz_type, data_bytes
                            )
                            self.logger.debug(f"Wrote {npz_type} to {h5_dataset_path}")

                            # Update hdf5_entries table
                            self._update_hdf5_entry(
                                design_uuid, tid, npz_type, h5_dataset_path, str(h5_path), len(data_bytes)
                            )

            self.logger.info(f"HDF5 write complete for {design_uuid}")
        
        finally:
            # Cleanup temp directory
            if local_temp_base.exists():
                shutil.rmtree(local_temp_base, ignore_errors=True)

    def _get_h5_path_for_design(self, design_uuid: str, campaign_id: str, default_path: Path) -> Path:
        """
        Get HDF5 file path for a design by looking up its generation (ADR-009).
        """
        try:
            # Join evaluations -> generations -> generation_files
            result = self._conn.execute(
                """
                SELECT gf.hdf5_path
                FROM evaluations e
                JOIN generations g ON e.gen_id = g.gen_id
                JOIN generation_files gf ON g.campaign_id = gf.campaign_id 
                                         AND g.gen_num = gf.generation
                WHERE e.design_uuid = ? AND g.campaign_id = ?
                LIMIT 1
                """,
                [design_uuid, campaign_id],
            ).fetchone()
            
            if result:
                return Path(result[0])
        except Exception as e:
            self.logger.warning(f"Failed to lookup HDF5 generation file: {e}")
            
        return default_path

    def _get_zdata(self, design_uuid: str) -> Optional[bytes]:
        """Fetch ZDATA bytes from database."""
        result = self._conn.execute(
            "SELECT zdata_bytes FROM zdata_store WHERE design_uuid = ?",
            [design_uuid],
        ).fetchone()
        return result[0] if result else None

    def _load_input_cache(self, campaign_id: str, config: Any) -> "InputBytesCache":
        """Load input bytes cache from database."""
        from ..config import InputBytesCache

        # Try to load from input_files table
        rows = self._conn.execute(
            """
            SELECT rcas_number, file_type, file_bytes
            FROM input_files
            WHERE campaign_id = ?
            """,
            [campaign_id],
        ).fetchall()

        if rows:
            # Build cache from database
            cache = InputBytesCache()
            for rcas_number, file_type, file_bytes in rows:
                if file_type == "rcas":
                    cache.rcas_bytes[rcas_number] = file_bytes
                elif file_type == "intrvc":
                    cache.intrvc_bytes[rcas_number] = file_bytes
                elif file_type == "cdrag":
                    cache.cdrag_bytes[rcas_number] = file_bytes
            return cache
        else:
            # Fall back to loading from disk
            return InputBytesCache.load_all(config)

    def _update_hdf5_entry(
        self,
        design_uuid: str,
        target_id: int,
        data_type: str,
        h5_path: str,
        h5_file: str,
        size_bytes: int,
    ) -> None:
        """Update or insert hdf5_entries record."""
        self._conn.execute(
            """
            INSERT INTO hdf5_entries (design_uuid, target_id, data_type, h5_path, h5_file, size_bytes)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT (design_uuid, target_id, data_type) DO UPDATE
            SET h5_path = EXCLUDED.h5_path,
                h5_file = EXCLUDED.h5_file,
                size_bytes = EXCLUDED.size_bytes,
                created_at = now()
            """,
            [design_uuid, target_id, data_type, h5_path, h5_file, size_bytes],
        )
        self._conn.commit()

    def _mark_completed(self, queue_id: int) -> None:
        """Mark queue item as completed."""
        self._conn.execute(
            """
            UPDATE megadeth_queue
            SET status = 'completed', completed_at = CURRENT_TIMESTAMP
            WHERE queue_id = ?
            """,
            [queue_id],
        )
        self._conn.commit()
        self.logger.debug(f"Queue item {queue_id} marked completed")

    def _mark_failed(self, queue_id: int, error: str) -> None:
        """Mark queue item as failed."""
        self._conn.execute(
            """
            UPDATE megadeth_queue
            SET status = 'failed',
                error_message = ?,
                completed_at = CURRENT_TIMESTAMP
            WHERE queue_id = ?
            """,
            [error[:1000], queue_id],  # Truncate error message
        )
        self._conn.commit()
        self.logger.debug(f"Queue item {queue_id} marked failed: {error[:100]}")


def load_campaign_config_from_db(db_path: Path, campaign_id: str, conn: Optional[duckdb.DuckDBPyConnection] = None) -> Optional[Any]:
    """
    Load CampaignConfig from database.

    This is the default config_loader for QueueProcessor.
    """
    import yaml
    from ..config import CampaignConfig

    close_conn = False
    if conn is None:
        conn = duckdb.connect(str(db_path))
        close_conn = True
        
    try:
        result = conn.execute(
            "SELECT config_yaml FROM campaigns WHERE campaign_id = ?",
            [campaign_id],
        ).fetchone()

        if result and result[0]:
            config_dict = yaml.safe_load(result[0])
            return CampaignConfig.model_validate(config_dict)
        return None
    finally:
        if close_conn:
            conn.close()
