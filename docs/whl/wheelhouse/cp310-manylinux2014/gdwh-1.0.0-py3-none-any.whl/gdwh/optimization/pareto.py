"""
Scalable Pareto sorting with auto-selection (ADR-005).

Implements:
- pygmo fast_non_dominated_sorting for m <= 4 objectives (C++ optimized)
- Jensen's divide-and-conquer with numba for m > 4 objectives

Jensen's algorithm scales O(n log^(m-1) n) vs O(n²m) for standard NDS,
providing 10-30x speedup at scale (100k+ designs, 6+ objectives).

Numba compilation is lazy with disk caching to avoid startup overhead.
"""

import os
import logging
import numpy as np
from typing import Optional, List, Tuple, Union

# Module logger
_logger = logging.getLogger("gdwh.optimization.pareto")

# Lazy numba import - only compile when actually needed
_numba_funcs = None

# Track if we've logged the algorithm selection (once per session)
_algorithm_logged = False


def _ensure_numba_compiled():
    """
    Lazy-load and compile numba functions on first use.

    Uses disk caching (cache=True) so compilation only happens once
    per environment, similar to SABRE's approach.
    """
    global _numba_funcs
    if _numba_funcs is not None:
        return _numba_funcs

    try:
        from numba import njit, prange

        # Set cache directory for numba (uses NUMBA_CACHE_DIR or default)
        cache_dir = os.environ.get("NUMBA_CACHE_DIR", None)
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)

        @njit(cache=True, fastmath=True)
        def dominates(a: np.ndarray, b: np.ndarray) -> bool:
            """
            Check if solution 'a' dominates solution 'b' (minimization).

            a dominates b iff:
              - a[i] <= b[i] for all i
              - a[i] < b[i] for at least one i
            """
            dominated = False
            for i in range(len(a)):
                if a[i] > b[i]:
                    return False
                if a[i] < b[i]:
                    dominated = True
            return dominated

        @njit(cache=True)
        def kung_2d(F: np.ndarray, indices: np.ndarray) -> np.ndarray:
            """
            Kung's O(n log n) algorithm for 2D non-dominated sorting.

            Base case for Jensen's recursion.

            Args:
                F: Full objective matrix (n, m) - only first 2 cols used
                indices: Indices into F to consider

            Returns:
                Indices of non-dominated solutions (subset of input indices)
            """
            n = len(indices)
            if n == 0:
                return np.empty(0, dtype=np.int64)
            if n == 1:
                return indices.copy()

            # Extract relevant rows and sort by first objective
            F_sub = np.empty((n, 2), dtype=np.float64)
            for i in range(n):
                F_sub[i, 0] = F[indices[i], 0]
                F_sub[i, 1] = F[indices[i], 1]

            # Argsort by first objective
            order = np.argsort(F_sub[:, 0])

            # Sweep: track minimum of second objective seen so far
            front_mask = np.zeros(n, dtype=np.bool_)
            min_f2 = np.inf

            for i in range(n):
                idx = order[i]
                f2 = F_sub[idx, 1]
                if f2 <= min_f2:
                    front_mask[idx] = True
                    min_f2 = f2

            # Count and collect results
            count = 0
            for i in range(n):
                if front_mask[i]:
                    count += 1

            result = np.empty(count, dtype=np.int64)
            j = 0
            for i in range(n):
                if front_mask[i]:
                    result[j] = indices[i]
                    j += 1

            return result

        @njit(cache=True, parallel=True)
        def remove_dominated_parallel(
            F: np.ndarray,
            high_indices: np.ndarray,
            low_indices: np.ndarray,
        ) -> np.ndarray:
            """
            Remove solutions from high_indices dominated by any in low_indices.

            Parallelized over high_indices using numba prange.

            Args:
                F: Full objective matrix
                high_indices: Indices to filter (potential non-dominated)
                low_indices: Indices that may dominate high

            Returns:
                Surviving indices from high_indices
            """
            n_high = len(high_indices)
            n_low = len(low_indices)

            if n_high == 0:
                return np.empty(0, dtype=np.int64)
            if n_low == 0:
                return high_indices.copy()

            dominated = np.zeros(n_high, dtype=np.bool_)

            # Parallel check: each high solution vs all low solutions
            for i in prange(n_high):
                hi = high_indices[i]
                for j in range(n_low):
                    lo = low_indices[j]
                    # Check if low[j] dominates high[i]
                    if dominates(F[lo], F[hi]):
                        dominated[i] = True
                        break

            # Collect non-dominated
            count = 0
            for i in range(n_high):
                if not dominated[i]:
                    count += 1

            result = np.empty(count, dtype=np.int64)
            j = 0
            for i in range(n_high):
                if not dominated[i]:
                    result[j] = high_indices[i]
                    j += 1

            return result

        @njit(cache=True)
        def _jensen_recursive(
            F: np.ndarray,
            indices: np.ndarray,
            dim: int,
        ) -> np.ndarray:
            """
            Jensen's divide-and-conquer NDS (sequential inner recursion).

            Args:
                F: Objective matrix (n, m)
                indices: Current subset of indices to process
                dim: Current dimension (recursion parameter, starts at m)

            Returns:
                Indices of non-dominated solutions
            """
            n = len(indices)

            # Base cases
            if n <= 1:
                return indices.copy() if n == 1 else np.empty(0, dtype=np.int64)

            if dim == 2:
                return kung_2d(F, indices)

            # Divide by median of current dimension
            vals = np.empty(n, dtype=np.float64)
            for i in range(n):
                vals[i] = F[indices[i], dim - 1]

            median = np.median(vals)

            # Partition
            n_low = 0
            for i in range(n):
                if vals[i] <= median:
                    n_low += 1

            # Handle edge case where all values equal
            if n_low == 0 or n_low == n:
                return _jensen_recursive(F, indices, dim - 1)

            low_indices = np.empty(n_low, dtype=np.int64)
            high_indices = np.empty(n - n_low, dtype=np.int64)

            j_low = 0
            j_high = 0
            for i in range(n):
                if vals[i] <= median:
                    low_indices[j_low] = indices[i]
                    j_low += 1
                else:
                    high_indices[j_high] = indices[i]
                    j_high += 1

            # Conquer: recursively find fronts
            front_low = _jensen_recursive(F, low_indices, dim)
            front_high = _jensen_recursive(F, high_indices, dim)

            # Merge: remove high solutions dominated by low
            if len(front_high) > 0 and len(front_low) > 0:
                front_high = remove_dominated_parallel(F, front_high, front_low)

            # Concatenate results
            total = len(front_low) + len(front_high)
            result = np.empty(total, dtype=np.int64)
            for i in range(len(front_low)):
                result[i] = front_low[i]
            for i in range(len(front_high)):
                result[len(front_low) + i] = front_high[i]

            return result

        _numba_funcs = {
            'dominates': dominates,
            'kung_2d': kung_2d,
            'remove_dominated_parallel': remove_dominated_parallel,
            'jensen_recursive': _jensen_recursive,
        }

        return _numba_funcs

    except ImportError:
        # Numba not available - return None, will use fallback
        return None


def jensen_nds(F: np.ndarray) -> np.ndarray:
    """
    Jensen's divide-and-conquer non-dominated sorting.

    Complexity: O(n log^(m-1) n) where n = designs, m = objectives.

    Args:
        F: Objective matrix (n_designs, n_objectives), minimization assumed

    Returns:
        Array of indices in the first Pareto front
    """
    funcs = _ensure_numba_compiled()

    if funcs is None:
        # Fallback to numpy-only implementation (slower but works)
        return _jensen_nds_numpy(F)

    n, m = F.shape

    if n == 0:
        return np.array([], dtype=np.int64)
    if n == 1:
        return np.array([0], dtype=np.int64)

    # Start recursion with all indices
    indices = np.arange(n, dtype=np.int64)
    return funcs['jensen_recursive'](F, indices, m)


def _jensen_nds_numpy(F: np.ndarray) -> np.ndarray:
    """
    Pure numpy fallback for Jensen's NDS (no numba).

    Slower but guaranteed to work without numba installed.
    """
    n, m = F.shape

    if n == 0:
        return np.array([], dtype=np.int64)
    if n == 1:
        return np.array([0], dtype=np.int64)

    def dominates_np(a, b):
        return np.all(a <= b) and np.any(a < b)

    def kung_2d_np(indices):
        if len(indices) <= 1:
            return indices

        # Sort by first objective
        F_sub = F[indices, :2]
        order = np.argsort(F_sub[:, 0])
        sorted_indices = indices[order]

        # Sweep
        front = [sorted_indices[0]]
        min_f2 = F[sorted_indices[0], 1]

        for idx in sorted_indices[1:]:
            if F[idx, 1] <= min_f2:
                front.append(idx)
                min_f2 = F[idx, 1]

        return np.array(front, dtype=np.int64)

    def recurse(indices, dim):
        if len(indices) <= 1:
            return indices
        if dim == 2:
            return kung_2d_np(indices)

        # Divide by median
        vals = F[indices, dim - 1]
        median = np.median(vals)

        low_mask = vals <= median
        if not np.any(low_mask) or np.all(low_mask):
            return recurse(indices, dim - 1)

        low_indices = indices[low_mask]
        high_indices = indices[~low_mask]

        front_low = recurse(low_indices, dim)
        front_high = recurse(high_indices, dim)

        # Merge: remove dominated from high
        if len(front_high) > 0 and len(front_low) > 0:
            surviving = []
            for hi in front_high:
                dominated = False
                for lo in front_low:
                    if dominates_np(F[lo], F[hi]):
                        dominated = True
                        break
                if not dominated:
                    surviving.append(hi)
            front_high = np.array(surviving, dtype=np.int64) if surviving else np.array([], dtype=np.int64)

        return np.concatenate([front_low, front_high])

    return recurse(np.arange(n, dtype=np.int64), m)


def get_pareto_front(
    F: np.ndarray,
    n_cores: int = 8,
    force_jensen: bool = False,
) -> np.ndarray:
    """
    Get Pareto-optimal indices with auto-selected algorithm.

    Selection logic:
    - m <= 4: Use pygmo's C++ fast_non_dominated_sorting (highly optimized)
    - m > 4: Use Jensen's divide-and-conquer (better asymptotic scaling)

    Args:
        F: Objective matrix (n_designs, m_objectives), minimization assumed
        n_cores: Available cores for parallel Jensen (used in merge step)
        force_jensen: Force Jensen's algorithm regardless of m

    Returns:
        Array of indices in the first Pareto front
    """
    global _algorithm_logged

    if F.size == 0:
        return np.array([], dtype=np.int64)

    n, m = F.shape

    if n == 0:
        return np.array([], dtype=np.int64)
    if n == 1:
        return np.array([0], dtype=np.int64)

    # Log algorithm selection on first call (Gen 1 init)
    if not _algorithm_logged:
        _log_algorithm_selection(n, m, force_jensen)
        _algorithm_logged = True

    # Auto-select algorithm
    if not force_jensen and m <= 4:
        # Try pygmo first (fast C++ implementation)
        try:
            import pygmo as pg
            ndf, _, _, _ = pg.fast_non_dominated_sorting(F)
            return np.array(ndf[0], dtype=np.int64)
        except ImportError:
            pass  # Fall through to Jensen
        except Exception:
            pass  # Fall through to Jensen on any error

    # Jensen's algorithm for m > 4 or as fallback
    return jensen_nds(F)


def _log_algorithm_selection(
    n_designs: int,
    n_objectives: int,
    force_jensen: bool,
    logger: Optional[logging.Logger] = None,
) -> None:
    """
    Log the Pareto sorting algorithm selection at Gen 1.

    Logs which algorithm will be used and why, based on:
    - Number of objectives (m <= 4 → pygmo, m > 4 → Jensen)
    - Availability of pygmo/numba
    - Estimated complexity for the problem size
    """
    # Use provided logger or fall back to module logger
    log = logger if logger is not None else _logger

    # Determine which algorithm will be used
    use_pygmo = False
    use_jensen = False
    pygmo_available = False
    numba_available = _ensure_numba_compiled() is not None

    if not force_jensen and n_objectives <= 4:
        try:
            import pygmo as pg
            pygmo_available = True
            use_pygmo = True
        except ImportError:
            use_jensen = True
    else:
        use_jensen = True

    # Calculate estimated targets from objectives (assuming 2 obj per target: IKP + volume)
    n_targets_est = n_objectives // 2

    # Build log message
    algo_name = "pygmo (C++)" if use_pygmo else "Jensen (numba)" if numba_available else "Jensen (numpy fallback)"
    complexity = "O(n²m)" if use_pygmo else f"O(n log^{n_objectives-1} n)"

    log.info(
        f"ADR-005 Pareto sorting: {algo_name} | "
        f"{n_objectives} objectives (~{n_targets_est} targets) | "
        f"complexity: {complexity}"
    )

    # Log additional details at debug level
    if use_jensen:
        reason = "m > 4 objectives" if n_objectives > 4 else "pygmo unavailable"
        log.debug(
            f"  Using Jensen's divide-and-conquer ({reason}), "
            f"numba={'enabled (cached)' if numba_available else 'disabled (numpy fallback)'}"
        )
    else:
        log.debug(
            f"  Using pygmo fast_non_dominated_sorting (m <= 4 threshold)"
        )


def log_pareto_config(
    n_objectives: int,
    force_jensen: bool = False,
    logger: Optional[logging.Logger] = None,
) -> None:
    """
    Log which Pareto sorting algorithm will be used for this configuration.

    Call this at initialization (e.g., Gen 1) to inform users which algorithm
    will be used, regardless of whether pareto-only retention is enabled.

    Args:
        n_objectives: Number of objectives (typically n_targets * 2 for IKP + volume)
        force_jensen: If True, Jensen's algorithm will be used regardless of m
        logger: Optional logger to use (if None, uses module logger)
    """
    global _algorithm_logged
    if _algorithm_logged:
        return
    _log_algorithm_selection(
        n_designs=0,
        n_objectives=n_objectives,
        force_jensen=force_jensen,
        logger=logger,
    )
    _algorithm_logged = True


def get_pareto_front_with_ranks(
    F: np.ndarray,
    max_fronts: Optional[int] = None,
) -> tuple:
    """
    Get all Pareto fronts with ranks.

    Args:
        F: Objective matrix (n_designs, m_objectives)
        max_fronts: Maximum number of fronts to compute (None = all)

    Returns:
        Tuple of (front_indices_list, ranks_array)
        - front_indices_list: List of arrays, each containing indices in that front
        - ranks_array: Array of rank for each solution (0 = first front)
    """
    n, m = F.shape

    if n == 0:
        return [], np.array([], dtype=np.int64)

    # Try pygmo for full ranking (any m)
    try:
        import pygmo as pg
        ndf, _, _, ndr = pg.fast_non_dominated_sorting(F)

        fronts = [np.array(f, dtype=np.int64) for f in ndf]
        ranks = np.array(ndr, dtype=np.int64)

        if max_fronts is not None:
            fronts = fronts[:max_fronts]

        return fronts, ranks
    except ImportError:
        pass

    # Fallback: iterative front extraction using Jensen
    remaining = np.arange(n, dtype=np.int64)
    fronts = []
    ranks = np.full(n, -1, dtype=np.int64)

    rank = 0
    while len(remaining) > 0:
        if max_fronts is not None and rank >= max_fronts:
            break

        # Extract current front
        F_remaining = F[remaining]
        front_local = get_pareto_front(F_remaining)
        front_global = remaining[front_local]

        fronts.append(front_global)
        ranks[front_global] = rank

        # Remove front from remaining
        mask = np.ones(len(remaining), dtype=np.bool_)
        mask[front_local] = False
        remaining = remaining[mask]

        rank += 1

    return fronts, ranks


# Warmup function for pre-compilation (optional, called during import if NUMBA_WARMUP=1)
def warmup():
    """
    Pre-compile numba functions with small test data.

    Call this during application startup to avoid compilation
    latency on first real use. Skipped if numba unavailable.
    """
    funcs = _ensure_numba_compiled()
    if funcs is None:
        return

    # Small test to trigger compilation
    F_test = np.random.rand(10, 4)
    _ = jensen_nds(F_test)


# Optional: warmup on import if environment variable set
if os.environ.get("GDWH_NUMBA_WARMUP", "0") == "1":
    warmup()


class JensenNDS:
    """
    Pymoo-compatible wrapper for Jensen's Non-Dominated Sorting.
    """
    def do(
        self,
        F: np.ndarray,
        return_rank: bool = False,
        only_non_dominated_front: bool = False,
        n_stop_if_ranked: Optional[int] = None,
        **kwargs
    ) -> Union[List[np.ndarray], Tuple[List[np.ndarray], np.ndarray]]:
        """
        Perform non-dominated sorting.

        Args:
            F: Objective matrix (n_designs, m_objectives)
            return_rank: If True, return (fronts, ranks) tuple
            only_non_dominated_front: If True, return only the first front
            n_stop_if_ranked: Stop sorting once this many individuals are ranked (optimization)

        Returns:
            fronts (list of arrays) or (fronts, ranks)
        """
        # If we only need the first front, use the optimized single-front fetch
        if only_non_dominated_front:
            front = get_pareto_front(F)
            if return_rank:
                ranks = np.full(len(F), -1, dtype=np.int64)
                ranks[front] = 0
                return [front], ranks
            return [front]

        # Get all fronts with ranks using iterative Jensen extraction
        fronts, ranks = get_pareto_front_with_ranks(F, max_fronts=None)
        
        # Ensure integer dtype for Pymoo compatibility
        fronts = [f.astype(np.int64) if f.dtype != np.int64 else f for f in fronts]
        if ranks.dtype != np.int64:
            ranks = ranks.astype(np.int64)
        
        if return_rank:
            return fronts, ranks
        return fronts


def create_jensen_nsga3_survival(ref_dirs: np.ndarray):
    """
    Create an NSGA-III ReferenceDirectionSurvival that uses JensenNDS.
    
    NSGA-III's standard ReferenceDirectionSurvival hardcodes NonDominatedSorting()
    inside its _do method. This factory function creates a patched version that
    uses our JensenNDS instead.
    
    Args:
        ref_dirs: Reference directions for NSGA-III
        
    Returns:
        A survival operator compatible with NSGA-III that uses Jensen's algorithm
    """
    # Import the original NSGA-III survival and related utilities
    from pymoo.algorithms.moo.nsga3 import (
        ReferenceDirectionSurvival,
        HyperplaneNormalization,
        associate_to_niches,
    )
    from pymoo.util.misc import intersect, has_feasible
    
    class JensenReferenceDirectionSurvival(ReferenceDirectionSurvival):
        """
        ReferenceDirectionSurvival that uses JensenNDS instead of Pymoo's NDS.
        
        This is a drop-in replacement for NSGA-III's survival operator that
        uses our efficient Jensen's divide-and-conquer algorithm for
        non-dominated sorting.
        """
        
        def __init__(self, ref_dirs):
            # Call grandparent's __init__ to avoid ReferenceDirectionSurvival's
            # since we're overriding its behavior
            from pymoo.core.survival import Survival
            Survival.__init__(self, filter_infeasible=True)
            self.ref_dirs = ref_dirs
            self.opt = None
            self.norm = HyperplaneNormalization(ref_dirs.shape[1])
            # Use our JensenNDS
            self.nds = JensenNDS()
        
        def _do(self, problem, pop, n_survive, D=None, random_state=None, **kwargs):
            """
            Survival selection using Jensen's NDS algorithm.
            
            This is a copy of ReferenceDirectionSurvival._do but using
            self.nds instead of NonDominatedSorting().
            """
            # Get objective values
            F = pop.get("F")
            
            # Calculate fronts using Jensen's algorithm
            fronts, rank = self.nds.do(F, return_rank=True, n_stop_if_ranked=n_survive)
            non_dominated, last_front = fronts[0], fronts[-1]
            
            # Update the hyperplane based boundary estimation
            hyp_norm = self.norm
            hyp_norm.update(F, nds=non_dominated)
            ideal, nadir = hyp_norm.ideal_point, hyp_norm.nadir_point
            
            # Consider only the population until we come to the splitting front
            I = np.concatenate(fronts)
            pop, rank, F = pop[I], rank[I], F[I]
            
            # Update the front indices for the current population
            counter = 0
            for i in range(len(fronts)):
                for j in range(len(fronts[i])):
                    fronts[i][j] = counter
                    counter += 1
            last_front = fronts[-1]
            
            # Associate individuals to niches
            niche_of_individuals, dist_to_niche, dist_matrix = \
                associate_to_niches(F, self.ref_dirs, ideal, nadir)
            
            # Attributes of a population
            pop.set('rank', rank,
                    'niche', niche_of_individuals,
                    'dist_to_niche', dist_to_niche)
            
            # Set the optimum, first front and closest to all reference directions
            closest = np.unique(dist_matrix[:, np.unique(niche_of_individuals)].argmin(axis=0))
            self.opt = pop[intersect(fronts[0], closest)]
            if len(self.opt) == 0:
                self.opt = pop[fronts[0]]
            
            # If we need to select individuals to survive
            if len(pop) > n_survive:
                # Call parent's niching logic for final selection
                # We import the required function for niching
                from pymoo.algorithms.moo.nsga3 import niching
                
                # If there is only one front
                if len(fronts) == 1:
                    n_remaining = n_survive
                    until_last_front = np.array([], dtype=int)
                    niche_count = np.zeros(len(self.ref_dirs), dtype=int)
                else:
                    # All individuals until the last front
                    until_last_front = np.concatenate(fronts[:-1])
                    
                    # Calculate niche count
                    niche_count = np.zeros(len(self.ref_dirs), dtype=int)
                    for i in until_last_front:
                        niche_count[niche_of_individuals[i]] += 1
                    
                    n_remaining = n_survive - len(until_last_front)
                
                # Select from last front using niching
                S = niching(
                    pop[last_front], 
                    n_remaining, 
                    niche_count, 
                    niche_of_individuals[last_front],
                    dist_to_niche[last_front]
                )
                
                survivors = np.concatenate([until_last_front, last_front[S]])
            else:
                survivors = np.arange(len(pop))
            
            return pop[survivors]
    
    return JensenReferenceDirectionSurvival(ref_dirs)


