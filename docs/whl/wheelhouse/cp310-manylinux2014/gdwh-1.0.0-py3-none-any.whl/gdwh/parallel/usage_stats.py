"""Node usage statistics collection for MPI workers.

Collects /dev/shm and memory usage statistics from all MPI ranks
and aggregates them for monitoring via the progress dashboard.
"""

import os
import socket
import json
import shutil
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional
from datetime import datetime


@dataclass
class NodeUsageStats:
    """Usage statistics for a single node."""

    hostname: str
    rank: int
    timestamp: str

    # /dev/shm stats (MB)
    shm_total_mb: float
    shm_used_mb: float
    shm_free_mb: float
    shm_percent_used: float

    # Memory stats (MB)
    mem_total_mb: float
    mem_available_mb: float
    mem_percent_used: float

    # Temp file counts
    megadeth_dir_count: int
    megadeth_dir_size_mb: float


def collect_local_usage(rank: int = 0) -> NodeUsageStats:
    """
    Collect usage statistics for the local node.

    Args:
        rank: MPI rank of this process

    Returns:
        NodeUsageStats with current resource usage
    """
    hostname = socket.gethostname()
    shm_path = Path("/dev/shm")

    # /dev/shm stats
    shm_total = shm_free = shm_used = shm_percent = 0.0
    if shm_path.exists():
        try:
            stat = os.statvfs(shm_path)
            shm_total = (stat.f_blocks * stat.f_frsize) / (1024 * 1024)
            shm_free = (stat.f_bavail * stat.f_frsize) / (1024 * 1024)
            shm_used = shm_total - shm_free
            shm_percent = (shm_used / shm_total * 100) if shm_total > 0 else 0
        except OSError:
            pass

    # Count megadeth directories
    megadeth_dir_count = 0
    dir_size = 0.0
    if shm_path.exists():
        try:
            megadeth_dirs = list(shm_path.glob("megadeth_*"))
            megadeth_dir_count = len(megadeth_dirs)
            for d in megadeth_dirs:
                if d.is_dir():
                    try:
                        for f in d.rglob("*"):
                            if f.is_file():
                                dir_size += f.stat().st_size
                    except (OSError, PermissionError):
                        pass
            dir_size /= 1024 * 1024  # Convert to MB
        except OSError:
            pass

    # Memory stats (using /proc/meminfo for Linux)
    mem_total = mem_avail = 0.0
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    mem_total = int(line.split()[1]) / 1024  # KB to MB
                elif line.startswith("MemAvailable:"):
                    mem_avail = int(line.split()[1]) / 1024
    except (OSError, ValueError):
        pass

    mem_percent = ((mem_total - mem_avail) / mem_total * 100) if mem_total > 0 else 0

    return NodeUsageStats(
        hostname=hostname,
        rank=rank,
        timestamp=datetime.now().isoformat(),
        shm_total_mb=shm_total,
        shm_used_mb=shm_used,
        shm_free_mb=shm_free,
        shm_percent_used=shm_percent,
        mem_total_mb=mem_total,
        mem_available_mb=mem_avail,
        mem_percent_used=mem_percent,
        megadeth_dir_count=megadeth_dir_count,
        megadeth_dir_size_mb=dir_size,
    )


class UsageStatsCollector:
    """Collects and aggregates usage stats across MPI ranks."""

    def __init__(self, output_dir: Path):
        """
        Initialize the collector.

        Args:
            output_dir: Directory to write usage_stats.json
        """
        self.output_dir = Path(output_dir)
        self.history: List[Dict] = []
        self.stats_file = self.output_dir / "usage_stats.json"
        self._load_history()

    def _load_history(self):
        """Load existing history from file."""
        if self.stats_file.exists():
            try:
                with open(self.stats_file) as f:
                    self.history = json.load(f)
            except (json.JSONDecodeError, OSError):
                self.history = []

    def _save_history(self):
        """Save history to file (atomic write)."""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        tmp = self.stats_file.with_suffix(".tmp")
        try:
            with open(tmp, "w") as f:
                json.dump(self.history, f, indent=2)
            shutil.move(str(tmp), str(self.stats_file))
        except OSError:
            # Best effort - don't fail the optimization
            pass

    def record_generation(
        self,
        generation: int,
        phase: str,
        all_stats: List[NodeUsageStats],
    ):
        """
        Record stats for a generation.

        Args:
            generation: Generation number
            phase: "start" or "end"
            all_stats: List of NodeUsageStats from all ranks
        """
        record = {
            "generation": generation,
            "phase": phase,
            "timestamp": datetime.now().isoformat(),
            "nodes": [asdict(s) for s in all_stats],
            "summary": self._compute_summary(all_stats),
        }
        self.history.append(record)
        self._save_history()

    def _compute_summary(self, stats: List[NodeUsageStats]) -> Dict:
        """Compute aggregate summary across nodes."""
        if not stats:
            return {}
        return {
            "node_count": len(stats),
            "shm_used_total_mb": sum(s.shm_used_mb for s in stats),
            "shm_used_max_mb": max(s.shm_used_mb for s in stats),
            "shm_used_avg_mb": sum(s.shm_used_mb for s in stats) / len(stats),
            "shm_percent_max": max(s.shm_percent_used for s in stats),
            "mem_used_avg_percent": sum(s.mem_percent_used for s in stats) / len(stats),
            "megadeth_dirs_total": sum(s.megadeth_dir_count for s in stats),
        }

    def get_latest(self) -> Optional[Dict]:
        """Get the most recent stats record."""
        return self.history[-1] if self.history else None

    def get_summary_df(self):
        """
        Get summary data as a pandas DataFrame.

        Returns:
            DataFrame with generation, phase, and summary metrics
        """
        try:
            import pandas as pd
        except ImportError:
            return None

        if not self.history:
            return None

        rows = []
        for record in self.history:
            row = {
                "generation": record["generation"],
                "phase": record["phase"],
                "timestamp": record["timestamp"],
            }
            row.update(record.get("summary", {}))
            rows.append(row)

        return pd.DataFrame(rows)
