"""Parallel execution utilities for GWDH-NG.

This module provides:
- LocalPoolEvaluator: Single-node multiprocessing pool for SABRE evaluation
- MPICoordinator: MPI scatter/gather for multi-node distribution
- MPIEvaluator: Combined MPI + local pool evaluation
- Resource detection utilities
"""

from .local_pool import LocalPoolEvaluator
from .mpi_coordinator import (
    MPICoordinator,
    MPIEvaluator,
    WorkItem,
    get_mpi_evaluator_or_local,
    MPI_AVAILABLE,
)
from .resources import (
    SystemResources,
    detect_resources,
    recommend_workers,
    get_cpu_count,
    get_physical_cores,
    get_available_memory_gb,
)

__all__ = [
    # Local pool
    "LocalPoolEvaluator",
    # MPI
    "MPICoordinator",
    "MPIEvaluator",
    "WorkItem",
    "get_mpi_evaluator_or_local",
    "MPI_AVAILABLE",
    # Resources
    "SystemResources",
    "detect_resources",
    "recommend_workers",
    "get_cpu_count",
    "get_physical_cores",
    "get_available_memory_gb",
]
