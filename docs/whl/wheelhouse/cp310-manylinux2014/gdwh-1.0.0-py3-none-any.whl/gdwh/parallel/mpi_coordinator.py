"""MPI coordinator for multi-node distributed evaluation."""

import os
import math
import time
import zlib
import uuid
import shutil
import logging
import pickle
import threading
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import IntEnum
from concurrent.futures import ThreadPoolExecutor
from queue import Queue as ThreadQueue  # Thread-safe queue for threading
import multiprocessing

# Use threading for Phase 2 workers (avoids MPI+spawn issues)
# MPQueue still needed for resources module compatibility
_mp_ctx = multiprocessing.get_context('spawn')
MPQueue = _mp_ctx.Queue

from ..megadeth.results import EvalResult, LightweightResult
from ..utils import setup_logger
from ..utils.cleanup import cleanup_shm 
from ..zdata.batch import ZDATAGeneratorConfig
from .local_pool import LocalPoolEvaluator
from .resources import get_available_memory_gb


def _get_shm_path_if_available(required_mb: int = 50000, filename: Optional[str] = None) -> Optional[Path]:
    """
    Return /dev/shm path if available and has enough space, else None.
    
    Args:
        required_mb: Minimum free space required in MB
        filename: Optional custom filename (default: random UUID-based name)
    
    Returns:
        Path to shm file or None if not available
    """
    shm_dir = Path("/dev/shm")
    if not shm_dir.exists():
        return None

    try:
        stat = os.statvfs(shm_dir)
        free_mb = (stat.f_bavail * stat.f_frsize) / (1024 * 1024)
        if free_mb < required_mb:
            return None
        if filename:
            return shm_dir / filename
        return shm_dir / f"gdwh_{uuid.uuid4().hex[:8]}.h5"
    except OSError:
        return None


# ADR-009: Removed _sync_to_lustre function - was causing race conditions
# Each generation now manages its own HDF5 file lifecycle with synchronous sync at generation end


# --- Multiprocessing worker functions (must be at module level for pickling) ---

def _mp_decompressor_worker(
    recv_queue: MPQueue,
    write_queue: MPQueue,
    worker_id: int,
) -> None:
    """
    Decompression worker process.

    Reads (uuid, compressed) from recv_queue, decompresses,
    puts (uuid, binary_data) into write_queue.
    Exits on None (poison pill).
    """
    import zlib
    import pickle

    while True:
        item = recv_queue.get()
        if item is None:  # Poison pill
            break

        uuid, compressed = item
        try:
            if compressed and len(compressed) > 0:
                binary_data = pickle.loads(zlib.decompress(compressed))
            else:
                binary_data = None
            write_queue.put((uuid, binary_data))
        except Exception:
            # Log error but continue - put None for binary_data
            write_queue.put((uuid, None))
    # Note: With threading, no need for cancel_join_thread()


def _mp_hdf5_writer_worker(
    write_queue: MPQueue,
    result_queue: MPQueue,
    h5_path: Optional[str],
    total_expected: int,
    lw_data: Dict[str, dict],  # uuid -> {ikp_by_target, volume_by_target, eval_time_s}
) -> None:
    """
    HDF5 writer process.

    Reads (uuid, binary_data) from write_queue, writes to HDF5,
    accumulates results. On completion, sends all results via result_queue.
    """
    # Import inside process to avoid pickling issues
    # import logging
    import sys
    import time
    
    # Configure logging for subprocess (spawn doesn't inherit handlers)
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [WRITER] %(levelname)s: %(message)s',
        stream=sys.stderr,
        force=True,  # Override any existing config
    )
    logger = logging.getLogger("gdwh.parallel.mpi.writer")
    
    try:
        from gdwh.storage import HDF5Writer
        from gdwh.megadeth.results import EvalResult

        start_time = time.perf_counter()
        logger.info(f"Writer started: expecting {total_expected} items, h5_path={h5_path}")

        h5_writer = None
        if h5_path:
            h5_writer = HDF5Writer(h5_path)  # Opens in append mode

        results = {}  # uuid -> EvalResult
        processed = 0

        while processed < total_expected:
            item = write_queue.get()
            if item is None:
                continue  # Skip poison pills from decompressors

            uuid, binary_data = item
            uuid_saved_paths = {}

            if binary_data is not None and h5_writer:
                for tid, data_map in binary_data.items():
                    target_saved_paths = {}
                    for npz_type, data_bytes in data_map.items():
                        try:
                            path = h5_writer.add_from_bytes(uuid, tid, npz_type, data_bytes)
                            target_saved_paths[npz_type] = path
                        except Exception:
                            pass  # Skip failed writes
                    if target_saved_paths:
                        uuid_saved_paths[tid] = target_saved_paths

            # Build result from lightweight data
            lw = lw_data.get(uuid, {})
            result = EvalResult(
                design_uuid=uuid,
                ikp_by_target=lw.get('ikp_by_target', {}),
                volume_by_target=lw.get('volume_by_target', {}),
                legacy_paths={},
                binary_data={},  # Already written to HDF5
                saved_paths=uuid_saved_paths,
                eval_time_s=lw.get('eval_time_s', 0.0),
            )
            results[uuid] = result
            processed += 1

            # Log progress every 10 items
            if processed % 10 == 0 or processed == total_expected:
                elapsed = time.perf_counter() - start_time
                logger.debug(f"Writer: {processed}/{total_expected} in {elapsed:.1f}s")

        # Flush and close HDF5
        if h5_writer:
            logger.info(f"Writer: final flush for {h5_writer.items_written} items...")
            flush_start = time.perf_counter()
            h5_writer.flush()
            logger.info(f"Writer: flush done in {time.perf_counter() - flush_start:.1f}s")
            h5_writer.close()
            logger.info("Writer: closed")

        # Send all results back to main process
        result_queue.put(results)
        total_elapsed = time.perf_counter() - start_time
        logger.info(f"Writer complete: {len(results)} results in {total_elapsed:.1f}s")
        
    except Exception as e:
        import traceback
        logger.error(f"Writer subprocess crashed: {e}")
        logger.error(traceback.format_exc())
        # Send empty results to unblock main process
        result_queue.put({})


# Try to import MPI - may not be available
try:
    from mpi4py import MPI
    MPI_AVAILABLE = True
except ImportError:
    MPI_AVAILABLE = False
    MPI = None


# Compression level:  1 = fastest, 9 = smallest
# Level 1 gives ~10x compression with minimal CPU overhead
COMPRESSION_LEVEL = 1


class MPITags(IntEnum):
    """MPI message tags for coordinator protocol (ADR-015)."""
    # Evaluator control signals
    TERMINATE = 0
    CONTINUE = 1
    SKIP_BATCH = 2  # Head-only evaluation for small batches

    # Single-phase gather (ADR-002)
    COUNT = 10
    COMPRESSED_DATA = 11

    # Two-phase gather (ADR-004)
    LW_COUNT = 19
    LW_DATA = 20
    REQUEST = 21
    BINARY_DATA = 23
    RELEASE = 24


@dataclass
class WorkItem:
    """Work item for MPI distribution."""
    uuid: str
    params: dict


class MPICoordinator: 
    """
    MPI coordinator for distributing work across multiple nodes. 

    Handles scatter/gather operations for design evaluations across
    an MPI communicator.  Each rank runs a LocalPoolEvaluator for
    intra-node parallelization.
    """

    def __init__(self, comm=None):
        """
        Initialize MPI coordinator.

        Args:
            comm: MPI communicator (default: MPI.COMM_WORLD)
        """
        if not MPI_AVAILABLE: 
            raise ImportError(
                "mpi4py not available. Install with: pip install mpi4py"
            )

        self.comm = comm if comm is not None else MPI.COMM_WORLD
        self.rank = self.comm.Get_rank()
        self.size = self.comm.Get_size()

        # Check for environment variable mismatch (common in container/container setups)
        env_rank = os.environ.get("SLURM_PROCID") or os.environ.get("OMPI_COMM_WORLD_RANK") or os.environ.get("PMI_RANK")
        env_size = os.environ.get("SLURM_NTASKS") or os.environ.get("OMPI_COMM_WORLD_SIZE") or os.environ.get("PMI_SIZE")

        # Setup logger with rank info (use env rank for logger name if available to avoid collisions)
        logger_rank = int(env_rank) if env_rank else self.rank
        self.logger = setup_logger(
            f"gdwh.parallel.mpi.rank{logger_rank}",
            mpi_rank=logger_rank,
            console=False,  # MPI ranks should not write to stdout (interleaved output)
        )

        # Validate MPI environment matches what mpi4py reports
        if env_rank is not None and env_size is not None: 
            try:
                expected_rank = int(env_rank)
                expected_size = int(env_size)
                if self.rank != expected_rank or self.size != expected_size:
                    self.logger.warning(
                        f"MPI environment mismatch: mpi4py reports rank {self.rank}/{self.size}, "
                        f"but env vars indicate rank {expected_rank}/{expected_size}. "
                        f"MPI communication may not work correctly."
                    )
                    # In containerized environments, mpi4py may not initialize correctly
                    # If size=1 but expected_size > 1, MPI is broken
                    if self.size == 1 and expected_size > 1:
                        self.logger.error(
                            "CRITICAL: mpi4py sees only 1 process but environment expects "
                            f"{expected_size}. MPI is not properly initialized.  "
                            "Check that mpi4py is linked against the correct MPI library "
                            "and that the MPI runtime is properly configured in your container."
                        )
            except ValueError:
                pass  # Ignore if env vars aren't valid integers

        self.logger.info(f"MPI Coordinator initialized: rank {self.rank} of {self.size}")

    def is_root(self) -> bool:
        """Check if this is the root rank."""
        return self.rank == 0

    def scatter_work_params(
        self,
        uuids: Optional[List[str]],
        params_list: Optional[List[dict]],
    ) -> List[WorkItem]:
        """
        Scatter recipe-based work items across all MPI ranks.

        Only root rank provides data; other ranks pass None.
        """
        if self.is_root():
            if uuids is None or params_list is None:
                raise ValueError("Root rank must provide uuids and params_list")

            if len(uuids) != len(params_list):
                raise ValueError(
                    f"Length mismatch: {len(uuids)} uuids but {len(params_list)} param sets"
                )

            n_designs = len(uuids)
            self.logger.info(f"Scattering {n_designs} designs across {self.size} ranks")

            # Create work items
            all_work_items = [
                WorkItem(uuid=uuids[i], params=params_list[i])
                for i in range(n_designs)
            ]

            # Partition work across ranks
            chunks = self._partition_work(all_work_items, self.size)

            # Log distribution
            for i, chunk in enumerate(chunks):
                self.logger.debug(f"Rank {i} gets {len(chunk)} designs")

        else:
            chunks = None

        # Scatter chunks to all ranks
        local_work = self.comm.scatter(chunks, root=0)

        self.logger.info(f"Received {len(local_work)} designs for evaluation")

        return local_work

    def scatter_work(
        self,
        uuids: Optional[List[str]],
        zdata_dict: Optional[Dict[str, bytes]],
    ) -> List[WorkItem]:
        """
        Backwards-compatible scatter using precomputed zdata_dict. 
        Converts to params-based work items under the hood.
        """
        if uuids is None or zdata_dict is None:
            raise ValueError("Root rank must provide uuids and zdata_dict")

        params_list = [{"zdata_bytes": zdata_dict[uuid]} for uuid in uuids if uuid in zdata_dict]
        return self.scatter_work_params(uuids, params_list)

    def gather_results(
        self,
        local_results: Dict[str, EvalResult],
        h5_writer: Optional[Any] = None,
        available_memory_gb: Optional[float] = None,
        n_decompression_workers: int = 4,
    ) -> Optional[Dict[str, EvalResult]]:
        """
        3-stage pipelined gather with HDF5 integration and parallel decompression.

        Pipeline stages:
            1. Receiver Thread: MPI recv() → compressed_queue
            2. Decompressor Pool: compressed_queue → decompressed_queue (parallel)
            3. Writer (main thread): decompressed_queue → HDF5 → combined_lightweight

        Uses bounded queues for natural backpressure. When HDF5 writes are slow,
        pressure propagates back to workers via MPI blocking sends.

        Args:
            local_results: This rank's evaluation results
            h5_writer: Optional HDF5Writer for streaming writes
            available_memory_gb: Available RAM on head node (auto-detected if None)
            n_decompression_workers: Number of parallel decompression threads

        Returns:
            Lightweight results (binary_data cleared) for all ranks, None for workers
        """

        from queue import Queue
        from threading import Thread, Event
        import gc

        items = list(local_results.items())
        count = len(items)

        if not self.is_root():
            # Workers: compress and send
            send_start = time.time()
            total_compressed_bytes = 0

            # Send count first
            self.comm.send(count, dest=0, tag=MPITags.COUNT)

            # Compress and send each item
            for item in items:
                compressed = zlib.compress(pickle.dumps(item, protocol=pickle.HIGHEST_PROTOCOL), level=COMPRESSION_LEVEL)
                total_compressed_bytes += len(compressed)
                self.comm.send(compressed, dest=0, tag=MPITags.COMPRESSED_DATA)

            send_time = time.time() - send_start
            self.logger.debug(
                f"Sent {count} compressed results "
                f"({total_compressed_bytes / 1024 / 1024:.1f} MB) in {send_time:.1f}s"
            )
            return None

        # === HEAD NODE ONLY ===
        gather_start = time.time()

        # Measure sizes from own data for queue sizing
        if items:
            sample = zlib.compress(pickle.dumps(items[0]), level=COMPRESSION_LEVEL)
            compressed_size_mb = len(sample) / 1024 / 1024
        else:
            compressed_size_mb = 40.0  # Fallback estimate

        # Get available memory
        if available_memory_gb is None:
            available_memory_gb = get_available_memory_gb()
        available_ram_mb = available_memory_gb * 1024

        # Queue sizing: 20% RAM for compressed, 30% for decompressed
        queue1_max = max(10, int(available_ram_mb * 0.2 / compressed_size_mb))
        queue2_max = max(5, int(available_ram_mb * 0.3 / 400.0))  # ~400MB decompressed

        self.logger.info(
            f"Pipeline config: compressed_queue={queue1_max}, "
            f"decompressed_queue={queue2_max}, decompression_workers={n_decompression_workers}, "
            f"measured={compressed_size_mb:.1f}MB/item"
        )

        # Bounded queues for backpressure
        compressed_queue: Queue = Queue(maxsize=queue1_max)
        decompressed_queue: Queue = Queue(maxsize=queue2_max)

        combined_lightweight: Dict[str, EvalResult] = {}
        workers_remaining = [self.size - 1]  # Mutable for threads
        recv_error = [None]  # For error propagation
        decomp_error = [None]  # For decompression error propagation
        receiver_done = Event()  # Signal when receiver is finished

        # --- STAGE 1: Receiver Thread ---
        def receiver_thread():
            """Receive compressed data from workers, put in queue.

            Uses ANY_SOURCE for all receives to prevent deadlock when queue fills.
            Tracks expected items per worker to know when each worker is done.
            """
            try:
                # Track how many items we expect from each worker
                expected_from: Dict[int, int] = {}  # source -> remaining count
                workers_announced = 0

                while workers_remaining[0] > 0 or expected_from:
                    # Probe for any incoming message
                    status = MPI.Status()
                    self.comm.Probe(source=MPI.ANY_SOURCE, tag=MPI.ANY_TAG, status=status)
                    source = status.Get_source()
                    tag = status.Get_tag()

                    if tag == MPITags.COUNT:
                        # Count announcement from a new worker
                        r_count = self.comm.recv(source=source, tag=MPITags.COUNT)
                        if r_count > 0:
                            expected_from[source] = r_count
                        else:
                            # Worker had 0 items, mark as done
                            workers_remaining[0] -= 1
                        workers_announced += 1

                    elif tag == MPITags.COMPRESSED_DATA:
                        # Data item - receive and queue
                        compressed = self.comm.recv(source=source, tag=MPITags.COMPRESSED_DATA)
                        compressed_queue.put(compressed)  # Blocks if full (backpressure)

                        # Track completion
                        expected_from[source] -= 1
                        if expected_from[source] == 0:
                            del expected_from[source]
                            workers_remaining[0] -= 1

            except Exception as e:
                recv_error[0] = e
                self.logger.error(f"Receiver error: {e}")
            finally:
                receiver_done.set()

        # --- STAGE 2: Parallel Decompressor Workers ---
        def decompress_one(compressed: bytes) -> Optional[tuple]:
            """Decompress a single item. Returns (uuid, result) or None on error."""
            try:
                return pickle.loads(zlib.decompress(compressed))
            except Exception as e:
                self.logger.error(f"Decompress error: {e}")
                return None

        def decompressor_pool_manager():
            """Manage parallel decompression using ThreadPoolExecutor.

            Bounds pending_futures to prevent OOM when network is faster than decompression.
            Max in-flight = queue2_max (matches decompressed queue capacity).
            """
            from concurrent.futures import wait, FIRST_COMPLETED

            try:
                with ThreadPoolExecutor(max_workers=n_decompression_workers,
                                        thread_name_prefix="Decomp") as executor:
                    pending_futures = set()  # Use set for O(1) removal
                    max_pending = queue2_max  # Bound to decompressed queue size

                    while True:
                        # Check if we should stop: receiver done AND queue empty AND no pending work
                        if receiver_done.is_set() and compressed_queue.empty() and not pending_futures:
                            break

                        # If too many pending, wait for at least one to complete (backpressure)
                        while len(pending_futures) >= max_pending:
                            done, pending_futures = wait(pending_futures, return_when=FIRST_COMPLETED)
                            for future in done:
                                result = future.result()
                                if result is not None:
                                    decompressed_queue.put(result)

                        # Try to get compressed data (non-blocking to check pending futures)
                        try:
                            compressed = compressed_queue.get(timeout=0.01)
                        except:
                            # No data available, harvest any completed futures
                            done_now = {f for f in pending_futures if f.done()}
                            for future in done_now:
                                pending_futures.discard(future)
                                result = future.result()
                                if result is not None:
                                    decompressed_queue.put(result)
                            continue

                        # Submit decompression task
                        future = executor.submit(decompress_one, compressed)
                        pending_futures.add(future)

                        # Harvest completed futures to free memory promptly
                        done_now = {f for f in pending_futures if f.done()}
                        for future in done_now:
                            pending_futures.discard(future)
                            result = future.result()
                            if result is not None:
                                decompressed_queue.put(result)

                    # Drain any remaining pending futures
                    for future in pending_futures:
                        result = future.result()
                        if result is not None:
                            decompressed_queue.put(result)

            except Exception as e:
                decomp_error[0] = e
                self.logger.error(f"Decompressor pool error: {e}")
            finally:
                # Signal end of decompressed stream
                decompressed_queue.put(None)

        # --- STAGE 3: Writer (main thread) ---
        def write_result(uuid: str, result: EvalResult):
            """Write to HDF5 and accumulate lightweight result."""
            # Write to HDF5 if configured
            if h5_writer and hasattr(result, 'binary_data') and result.binary_data:
                for tid, data_map in result.binary_data.items():
                    target_saved_paths = {}
                    for npz_type, data_bytes in data_map.items():
                        try:
                            path = h5_writer.add_from_bytes(uuid, tid, npz_type, data_bytes)
                            target_saved_paths[npz_type] = path
                        except Exception as e:
                            self.logger.warning(f"HDF5 write failed for {uuid}: {e}")

                    if target_saved_paths:
                        if not hasattr(result, 'saved_paths'):
                            result.saved_paths = {}
                        result.saved_paths[tid] = target_saved_paths

            # Clear heavy data, keep objectives
            result.binary_data = {}
            combined_lightweight[uuid] = result

        # Start pipeline threads
        t_recv = Thread(target=receiver_thread, name="MPI-Receiver", daemon=True)
        t_decomp = Thread(target=decompressor_pool_manager, name="DecompManager", daemon=True)

        t_recv.start()
        t_decomp.start()

        # Process head's own results first (while threads warm up)
        for uuid, result in items:
            write_result(uuid, result)

        # Process worker results from pipeline
        items_processed = len(items)
        while True:
            item = decompressed_queue.get()
            if item is None:
                break

            uuid, result = item
            write_result(uuid, result)
            items_processed += 1

        # Single GC after pipeline completes (ADR-015: removed periodic gc.collect())
        gc.collect()

        # Wait for threads to finish
        t_recv.join(timeout=60)
        t_decomp.join(timeout=60)

        # Check for errors
        if recv_error[0] is not None:
            raise recv_error[0]
        if decomp_error[0] is not None:
            raise decomp_error[0]

        # Flush HDF5
        if h5_writer:
            h5_writer.flush()

        total_time = time.time() - gather_start
        self.logger.info(
            f"Pipeline complete: {len(combined_lightweight)} results in {total_time:.1f}s"
        )

        return combined_lightweight

    def gather_results_two_phase(
        self,
        local_results: Dict[str, EvalResult],
        h5_writer: Optional[Any] = None,
        available_memory_gb: Optional[float] = None,
        n_decompression_workers: int = 0,  # 0 = auto-scale based on cores
        global_objectives_config: Optional[Dict[str, bool]] = None,
    ) -> Optional[Dict[str, EvalResult]]:
        """
        Two-phase gather (ADR-004) with adaptive memory and ANY_SOURCE.

        Phase 1: Collect lightweight objectives from all workers
        Phase 2: Send all requests simultaneously, receive from ANY_SOURCE with
                 adaptive backpressure based on actual compressed sizes

        Note: ADR-008 removed Pareto-only filtering. All binary data is now transferred
        since only discrete data (~500KB/design) is stored during GA (per ADR-006).

        Args:
            local_results: This rank's evaluation results
            h5_writer: Optional HDF5Writer for streaming writes
            available_memory_gb: Available RAM on head node
            n_decompression_workers: Number of parallel decompression threads (0 = auto-scale)
            global_objectives_config: Dict[str, bool] indicating which global objectives are enabled.
                                     Keys: 'total_mass', 'fragment_mass', 'explosive_mass'

        Returns:
            Lightweight results (binary_data cleared) for all ranks, None for workers
        """
        from queue import Queue
        from threading import Thread
        import numpy as np
        import gc
        
        # Tags defined in MPITags enum (ADR-015)

        items = list(local_results.items())
        
        if not self.is_root():
            # === WORKER PATH ===

            # Phase 1: Send lightweight results
            lightweight_list = []
            compressed_cache = {}  # uuid -> compressed bytes (hold for Phase 2)

            # Parallel compression helper
            def _compress_item(uuid_result):
                uuid, result = uuid_result
                if result.binary_data:
                    compressed = zlib.compress(
                        pickle.dumps(result.binary_data, protocol=pickle.HIGHEST_PROTOCOL),
                        level=COMPRESSION_LEVEL
                    )
                    return uuid, compressed, len(compressed)
                return uuid, b'', 0

            # Compress all items in parallel using threads (GIL released during zlib)
            if not items:
                # No items to compress - skip to send empty result
                compress_results = []
            elif len(items) == 1:
                # Single item - just compress directly without pool overhead
                compress_results = [_compress_item(items[0])]
            else:
                with ThreadPoolExecutor(max_workers=min(len(items), 8)) as compress_pool:
                    compress_results = list(compress_pool.map(_compress_item, items))

            # Build lightweight list and cache from compression results
            uuid_to_result = {uuid: result for uuid, result in items}
            for uuid, compressed, compressed_size in compress_results:
                if compressed:
                    compressed_cache[uuid] = compressed
                lw = LightweightResult.from_eval_result(
                    uuid_to_result[uuid],
                    source_rank=self.rank,
                    compressed_size=compressed_size,
                )
                lightweight_list.append(lw)

            # Send count (separate tag) + lightweight results
            self.comm.send(len(lightweight_list), dest=0, tag=MPITags.LW_COUNT)
            for lw in lightweight_list:
                self.comm.send(lw, dest=0, tag=MPITags.LW_DATA)
            
            self.logger.debug(f"Sent {len(lightweight_list)} lightweight results")
            
            # Phase 2: Wait for request, send requested binaries directly (ADR-004)
            requested_uuids = self.comm.recv(source=0, tag=MPITags.REQUEST)
            
            self.logger.debug(f"Received request for {len(requested_uuids)} binaries")
            
            # Send items directly - no count announcement, no chunking (ADR-004)
            for uuid in requested_uuids:
                compressed = compressed_cache.get(uuid, b'')
                self.comm.send((uuid, compressed), dest=0, tag=MPITags.BINARY_DATA)
            
            # Wait for release signal
            self.comm.recv(source=0, tag=MPITags.RELEASE)
            
            # Clear compressed cache
            compressed_cache.clear()
            gc.collect()
            
            return None
        
        # === HEAD NODE PATH ===
        gather_start = time.time()
        
        # Get available memory
        if available_memory_gb is None:
            available_memory_gb = get_available_memory_gb()
        
        # Phase 1: Collect lightweight results from all workers
        all_lightweight: List[LightweightResult] = []
        uuid_to_rank: Dict[str, int] = {}
        
        # Process head's own results first (estimate compressed_size, don't actually compress)
        # Actual compression happens in Phase 2 - this avoids blocking worker receives
        for uuid, result in items:
            # Estimate compressed_size from raw binary size (compression ratio ~10:1 for level=1)
            if result.binary_data:
                raw_size = sum(
                    sum(len(v) for v in target_data.values())
                    for target_data in result.binary_data.values()
                )
                compressed_size = max(raw_size // 8, 1024)  # Conservative estimate
            else:
                compressed_size = 0

            lw = LightweightResult.from_eval_result(result, source_rank=0, compressed_size=compressed_size)
            all_lightweight.append(lw)
            uuid_to_rank[uuid] = 0

        # Receive from workers using ANY_SOURCE (ADR-004 Phase 1 optimization)
        # Phase 1a: Receive counts from any ready worker (separate tag to avoid collision)
        worker_counts = {}  # rank -> expected item count
        for _ in range(1, self.size):
            status = MPI.Status()
            count = self.comm.recv(source=MPI.ANY_SOURCE, tag=MPITags.LW_COUNT, status=status)
            worker_counts[status.Get_source()] = count
        
        # Phase 1b: Receive all lightweight items from any ready worker
        total_items = sum(worker_counts.values())
        for _ in range(total_items):
            lw = self.comm.recv(source=MPI.ANY_SOURCE, tag=MPITags.LW_DATA)
            all_lightweight.append(lw)
            uuid_to_rank[lw.uuid] = lw.source_rank
        
        self.logger.info(f"Phase 1 complete: collected {len(all_lightweight)} lightweight results")
        
        # ADR-008: Request all UUIDs (Pareto filtering removed)
        all_uuids = [lw.uuid for lw in all_lightweight]
        request_uuids = set(all_uuids)
        
        # Group requests by rank
        requests_by_rank: Dict[int, List[str]] = {r: [] for r in range(self.size)}
        for uuid in request_uuids:
            rank = uuid_to_rank[uuid]
            requests_by_rank[rank].append(uuid)
        
        # Phase 2: Send requests and receive binaries using multiprocessing
        # Architecture:
        #   - Main thread: MPI recv → recv_queue (+ head's data)
        #   - Decompressor processes: recv_queue → write_queue
        #   - HDF5 writer process: write_queue → HDF5 file (single writer)

        combined_lightweight: Dict[str, EvalResult] = {}

        # Prepare head's binary data for writer process (don't write directly to avoid HDF5 conflicts)
        head_binaries = []  # List of (uuid, binary_data) for head's results
        for uuid, result in items:
            if uuid in request_uuids and result.binary_data:
                head_binaries.append((uuid, result.binary_data))
            # Store result without binary data
            result.binary_data = {}
            combined_lightweight[uuid] = result

        # Build lightweight data dict for writer process
        lw_data = {
            lw.uuid: {
                'ikp_by_target': lw.ikp_by_target,
                'volume_by_target': lw.volume_by_target,
                'eval_time_s': lw.eval_time_s,
            }
            for lw in all_lightweight
        }

        # Calculate expected items: workers + head's binaries
        worker_expected = sum(len(r) for r in list(requests_by_rank.values())[1:])
        total_expected = worker_expected + len(head_binaries)

        if total_expected == 0:
            # No binaries to write at all
            for rank in range(1, self.size):
                self.comm.send(requests_by_rank[rank], dest=rank, tag=MPITags.REQUEST)
            for rank in range(1, self.size):
                self.comm.send(True, dest=rank, tag=MPITags.RELEASE)

            total_time = time.time() - gather_start
            self.logger.info(f"Two-phase gather complete: {len(combined_lightweight)} results in {total_time:.1f}s")
            return combined_lightweight

        # ADR-009: h5_writer is now managed by caller (evaluate_generation) per-generation
        # The caller creates a single HDF5Writer for the entire generation and passes it here
        # No per-batch shm path creation or background sync needed
        h5_path = None
        if h5_writer:
            h5_path = str(h5_writer.h5_path)
            # Close main process's handle so writer thread can open exclusively
            h5_writer.close()

        # Calculate avg compressed size for progress logging
        if all_lightweight:
            avg_compressed_mb = sum(lw.compressed_size for lw in all_lightweight) / len(all_lightweight) / (1024 * 1024)
        else:
            avg_compressed_mb = 0.0  # No data to estimate

        # Auto-scale decompression workers based on available cores
        if n_decompression_workers <= 0:
            # Use ~25% of cores, cap at 8 for memory efficiency
            n_decompression_workers = min(max(1, (os.cpu_count() or 4) // 4), 8)

        # Cap queue sizes for memory efficiency at scale (50+ nodes, 10k jobs)
        recv_queue_size = min(max(20, total_expected * 2), 500)
        write_queue_size = min(max(20, total_expected * 2), 500)

        recv_queue: ThreadQueue = ThreadQueue(maxsize=recv_queue_size)
        write_queue: ThreadQueue = ThreadQueue(maxsize=write_queue_size)  # Bounded for memory
        result_queue: ThreadQueue = ThreadQueue()

        self.logger.info(
            f"Phase 2 threading: {n_decompression_workers} decompressors, "
            f"recv_queue={recv_queue_size}, write_queue={write_queue_size}, total_expected={total_expected}"
        )

        # Start decompressor threads
        self.logger.info(f"Starting {n_decompression_workers} decompressor threads...")
        decompressors = []
        for i in range(n_decompression_workers):
            t = threading.Thread(
                target=_mp_decompressor_worker,
                args=(recv_queue, write_queue, i),
                daemon=True,
            )
            t.start()
            decompressors.append(t)
        self.logger.info(f"All {len(decompressors)} decompressors started")

        # Start HDF5 writer thread
        self.logger.info(f"Starting writer thread (total_expected={total_expected}, h5_path={h5_path})...")
        writer_thread = threading.Thread(
            target=_mp_hdf5_writer_worker,
            args=(write_queue, result_queue, h5_path, total_expected, lw_data),
            daemon=True,
        )
        writer_thread.start()
        self.logger.info(f"Writer thread started (alive={writer_thread.is_alive()})")

        # Send head's binaries directly to write_queue (already decompressed)
        for uuid, binary_data in head_binaries:
            write_queue.put((uuid, binary_data))

        # Send requests to all workers simultaneously
        for rank in range(1, self.size):
            self.comm.send(requests_by_rank[rank], dest=rank, tag=MPITags.REQUEST)

        # Receive from workers and feed recv_queue
        phase2_start = time.time()
        received = 0

        while received < worker_expected:
            # Receive from any ready worker
            uuid, compressed = self.comm.recv(source=MPI.ANY_SOURCE, tag=MPITags.BINARY_DATA)

            # Put in recv_queue (blocks if full - natural backpressure)
            recv_queue.put((uuid, compressed))
            received += 1

            # Progress logging - guarded to prevent overhead when not debugging
            if (received % 10 == 0 or received == worker_expected) and self.logger.isEnabledFor(logging.DEBUG):
                elapsed = time.time() - phase2_start
                mb_recv = received * avg_compressed_mb
                rate = mb_recv / elapsed if elapsed > 0 else 0
                self.logger.debug(
                    f"Phase 2: {received}/{worker_expected} recv'd "
                    f"({mb_recv:.0f}MB in {elapsed:.1f}s, {rate:.1f}MB/s)"
                )

        # Send poison pills to decompressors
        for _ in decompressors:
            recv_queue.put(None)

        # Wait for decompressors to finish
        for p in decompressors:
            p.join(timeout=120)
            if p.is_alive():
                self.logger.warning("Decompressor process timeout, terminating")
                p.terminate()

        # Wait for writer results (contains saved_paths for worker results)
        try:
            worker_results = result_queue.get(timeout=300)
            combined_lightweight.update(worker_results)
        except Exception as e:
            self.logger.error(f"Failed to get writer results: {e}")

        # Wait for writer process
        writer_thread.join(timeout=60)
        if writer_thread.is_alive():
            self.logger.warning("Writer thread timeout (will be cleaned up on exit)")

        # ADR-009: Removed background sync thread spawn
        # The caller (evaluate_generation) handles sync at generation end

        # Signal all workers to release memory
        for rank in range(1, self.size):
            self.comm.send(True, dest=rank, tag=MPITags.RELEASE)

        # Re-open HDF5 in main process if it was closed
        if h5_writer and h5_path:
            # Re-initialize the writer (writer thread closed its handle)
            h5_writer._h5_file = None  # Reset internal state
            h5_writer._ensure_open()  # Re-open in append mode

        total_time = time.time() - gather_start
        self.logger.info(
            f"Two-phase gather complete: {len(combined_lightweight)} results "
            f"({len(request_uuids)} with binary) in {total_time:.1f}s"
        )

        return combined_lightweight


    def broadcast_static_context(self, static_context: Any) -> Any:
        """
        Broadcast SABRE static context to all ranks. 

        Args: 
            static_context:  GaStaticContext (root provides, others receive)

        Returns:
            Static context (all ranks receive same object)
        """
        return self.comm.bcast(static_context, root=0)

    def barrier(self):
        """Synchronize all ranks."""
        self.comm.Barrier()

    def _partition_work(
        self,
        work_items: List[WorkItem],
        n_partitions: int,
    ) -> List[List[WorkItem]]:
        """
        Partition work items as evenly as possible. 

        Args: 
            work_items:  All work items
            n_partitions: Number of partitions (ranks)

        Returns:
            List of work item lists, one per partition
        """
        n_items = len(work_items)
        base_size = n_items // n_partitions
        remainder = n_items % n_partitions

        partitions = []
        start = 0

        for i in range(n_partitions):
            # First 'remainder' partitions get one extra item
            size = base_size + (1 if i < remainder else 0)
            partitions.append(work_items[start:start + size])
            start += size

        return partitions


class MPIEvaluator:
    """
    MPI-aware evaluator combining MPI distribution with local pool evaluation.

    Root rank coordinates work distribution, all ranks evaluate locally
    using multiprocessing pools, then results are gathered back to root. 

    IMPORTANT: Worker ranks must call run_worker_loop() to participate in
    scatter/gather operations.  The master rank drives evaluation via
    evaluate_generation()/evaluate_batch() calls.
    """

    # Message tags for MPI communication (ADR-015: now use MPITags enum)
    TAG_CONTINUE = MPITags.CONTINUE
    TAG_TERMINATE = MPITags.TERMINATE

    def __init__(
        self,
        static_context: Any,
        pk_threshold: float = 0.5,
        run_mc: bool = False,
        zdata_number: int = 1000,
        zdata_generator_config: Optional[ZDATAGeneratorConfig] = None,
        cores_per_node: Optional[int] = None,
        designs_per_core: Optional[float] = None,
        comm=None,
        log_file: Optional[Path] = None,
        log_level: str = "INFO",
        use_two_phase_gather: bool = True,
        include_data_types: Optional[List[str]] = None,
        n_objectives: Optional[int] = None,
        global_objectives_config: Optional[Dict[str, bool]] = None,
        
    ):
        """
        Initialize MPI evaluator.

        Args:
            static_context: SABRE GaStaticContext
            pk_threshold: Pk threshold for evaluation
            run_mc: Whether to run Monte Carlo
            zdata_number: Fixed ZDATA number
            zdata_generator_config: Lightweight config for worker-side ZDATA generation
            cores_per_node: Cores per node for local pool (None = auto)
            designs_per_core: Target designs per core for auto batch sizing (None = default)
            comm: MPI communicator
            log_file: Path to log file
            log_level: Logging level
            use_two_phase_gather: If True, use ADR-004 two-phase gather protocol
            include_data_types: Data types to include in results (e.g., ['discrete'] to skip pk hypercube).
                               Filtering happens at worker BEFORE MPI send, reducing network by ~99%.
            n_objectives: Total number of objectives (for logging purposes)
            global_objectives_config: Configuration of global objectives
        """
        self.mpi = MPICoordinator(comm)
        cleanup_shm(self.mpi.logger)
        self.static_context = self.mpi.broadcast_static_context(static_context)
        
        # Broadcast static context to all ranks
        self.static_context = self.mpi.broadcast_static_context(static_context)

        # Broadcast config values
        config = self.mpi.comm.bcast(
            (
                pk_threshold,
                run_mc,
                zdata_number,
                cores_per_node,
                designs_per_core,
                log_file,
                log_level,
                zdata_generator_config,
                use_two_phase_gather,
                include_data_types,
                global_objectives_config,
            ),
            root=0,
        )
        (
            pk_threshold,
            run_mc,
            zdata_number,
            cores_per_node,
            designs_per_core,
            log_file,
            log_level,
            zdata_generator_config,
            use_two_phase_gather,
            include_data_types,
            global_objectives_config,
        ) = config
        
        # Store gather config
        self.use_two_phase_gather = use_two_phase_gather
        self.global_objectives_config = global_objectives_config

        # Cores per node - used for parallel decompression in gather and local pool sizing
        self.cores_per_node = cores_per_node if cores_per_node is not None else 48
        self.designs_per_core = designs_per_core if designs_per_core is not None else 2.5

        # Number of decompression threads (subset of cores to avoid starving other work)
        self.decompression_workers = min(8, max(2, self.cores_per_node // 6))
        
        # Detect available memory on this node for memory-aware gather
        self.available_memory_gb = get_available_memory_gb()

        # Initialize local pool evaluator on each rank
        # include_data_types filters pk hypercube at worker BEFORE MPI send
        self.local_evaluator = LocalPoolEvaluator(
            static_context=self.static_context,
            pk_threshold=pk_threshold,
            run_mc=run_mc,
            zdata_number=zdata_number,
            zdata_generator_config=zdata_generator_config,
            n_workers=cores_per_node,
            log_file=log_file,
            log_level=log_level,
            include_data_types=include_data_types,
        )

        self.logger = self.mpi.logger

        # Log ADR-005 Pareto algorithm selection at initialization (root only)
        if self.mpi.is_root():
            try:
                from ..optimization.pareto import log_pareto_config
                
                # Use provided count if available, otherwise fallback to estimation
                if n_objectives is None and self.static_context is not None:
                    n_objectives = len(self.static_context.targets) * 2  # IKP + volume per target
                    if self.global_objectives_config:
                        n_objectives += sum(1 for v in self.global_objectives_config.values() if v)
                
                if n_objectives is not None:
                    log_pareto_config(n_objectives, logger=self.logger)
            except (ImportError, AttributeError):
                pass  # Module not available or static_context lacks targets

        # Statistics
        self.n_generations = 0
        self.total_designs = 0
        self.total_time_s = 0.0

        # Track whether worker loop is running (for clean shutdown)
        self._worker_running = False


    def evaluate_generation(
        self,
        uuids: Optional[List[str]],
        params_list: Optional[Any],
        batch_size: int = 0,  # 0 = auto-scale based on cluster size
        h5_writer: Optional[Any] = None,  # Deprecated, ignored in favor of per-gen writer
        results_callback: Optional[callable] = None,
        # ADR-009: New arguments for per-generation storage
        generation: int = 0,
        output_dir: Optional[Path] = None,
        campaign_id: Optional[str] = None,
    ) -> Optional[Dict[str, EvalResult]]:
        """
        Evaluate a generation of designs across all MPI ranks.

        Root rank provides input, coordinates distribution, gathers results. 
        Non-root ranks participate via run_worker_loop().

        Args: 
            uuids:  List of design UUIDs (root only)
            params_list: List of design parameter dicts (root only) or legacy zdata_dict
            batch_size: Micro-batch size for scatter/gather (0 = auto-scale)
            h5_writer: DEPRECATED. Per-generation writer is now created internally.
            results_callback: Optional callback to process results incrementally
            generation: Generation number (ADR-009)
            output_dir: Base output directory (ADR-009)
            campaign_id: Campaign identifier (ADR-009)

        Returns: 
            Combined results (root only), None for other ranks
        """
        if not self.mpi.is_root():
            # Workers should use run_worker_loop(), not call this directly
            self.logger.warning(
                "Non-root rank called evaluate_generation() directly. "
                "Workers should use run_worker_loop() instead."
            )
            return None

        # ADR-009: Initialize per-generation storage
        gen_h5_writer = None
        gen_shm_path = None
        gen_final_path = None

        if self.mpi.is_root() and output_dir and campaign_id:
            try:
                from ..storage import HDF5Writer
                
                # Determine paths
                shm_name = f"gdwh_{campaign_id}_gen{generation:04d}.h5"
                # Require 2GB (buffer) + estimated usage
                gen_shm_path = _get_shm_path_if_available(required_mb=5000, filename=shm_name)
                
                final_dir = output_dir / "hdf5"
                final_dir.mkdir(parents=True, exist_ok=True)
                gen_final_path = final_dir / f"gen_{generation:04d}.h5"

                if not gen_shm_path:
                    # Fallback to direct write if SHM full/unavailable
                    self.logger.warning(f"SHM unavailable, writing directly to Lustre: {gen_final_path}")
                    gen_shm_path = gen_final_path
                else:
                    self.logger.info(f"Using SHM for generation {generation}: {gen_shm_path}")

                # Create writer
                gen_h5_writer = HDF5Writer(gen_shm_path, campaign_id=campaign_id)
            except Exception as e:
                self.logger.error(f"Failed to initialize per-generation HDF5 writer: {e}")
                # Proceeding without writer - data will be dropped!
                
        gen_start = time.time()
        all_results:  Dict[str, EvalResult] = {}

        # Backwards compatibility: allow legacy zdata_dict as params_list
        if isinstance(params_list, dict):
            if uuids is None: 
                uuids = list(params_list.keys())
            params_list = [{"zdata_bytes": params_list[uuid]} for uuid in uuids if uuid in params_list]

        if uuids is None or params_list is None:
            raise ValueError("Root rank must provide uuids and params_list")
        if len(uuids) != len(params_list):
            raise ValueError(
                f"Length mismatch: {len(uuids)} uuids but {len(params_list)} param sets"
            )

        total = len(uuids)

        total_cores = max(1, self.mpi.size * self.cores_per_node)

        # Auto-scale batch size based on total cores and designs-per-core target
        if batch_size > 0:
            effective_batch = batch_size
        else:
            if self.designs_per_core and self.designs_per_core > 0:
                target_batch = math.ceil(total_cores * self.designs_per_core)
                effective_batch = min(total, max(1, target_batch))
            else:
                # Legacy heuristic: ~4 micro-batches per generation
                min_batch = self.mpi.size * 2  # At least 2 designs per rank
                target_batches = 4
                effective_batch = max(min_batch, total // target_batches)
                effective_batch = min(effective_batch, total)

        designs_per_core_actual = effective_batch / total_cores
        self.logger.info(
            f"Evaluating {total} designs with batch_size={effective_batch} "
            f"(~{designs_per_core_actual:.2f} designs/core, "
            f"{total_cores} cores across {self.mpi.size} ranks)"
        )

        # Step 1: Signal workers to start a new evaluation round
        self.mpi.comm.bcast(self.TAG_CONTINUE, root=0)

        # Step 2: Broadcast total count and batch size
        self.mpi.comm.bcast(total, root=0)
        self.mpi.comm.bcast(effective_batch, root=0)

        try:
            # Step 3: Process micro-batches
            for i in range(0, total, effective_batch):
                batch_uuids = uuids[i : i + effective_batch]
                batch_params = params_list[i : i + effective_batch]

                # ADR-015: Head-only evaluation for small batches
                if len(batch_uuids) < self.cores_per_node:
                    self.logger.info(
                        f"Small batch ({len(batch_uuids)} < {self.cores_per_node} cores), "
                        f"evaluating on head node only"
                    )
                    # Signal workers to skip this batch
                    self.mpi.comm.bcast(MPITags.SKIP_BATCH, root=0)

                    # Execute locally
                    local_results = self.local_evaluator.evaluate_batch(batch_uuids, batch_params)

                    # Handle storage (mirroring write_result logic from gather_results)
                    if gen_h5_writer:
                        for uuid, result in local_results.items():
                            if result.binary_data:
                                # Ensure saved_paths dict exists (safety check)
                                if not hasattr(result, 'saved_paths') or result.saved_paths is None:
                                    result.saved_paths = {}

                                for tid, data_map in result.binary_data.items():
                                    target_saved_paths = {}
                                    for npz_type, data_bytes in data_map.items():
                                        try:
                                            path = gen_h5_writer.add_from_bytes(uuid, tid, npz_type, data_bytes)
                                            target_saved_paths[npz_type] = path
                                        except Exception as e:
                                            self.logger.warning(f"HDF5 write failed for {uuid}: {e}")

                                    if target_saved_paths:
                                        result.saved_paths[tid] = target_saved_paths

                    # Callback + accumulate
                    if results_callback:
                        try:
                            results_callback(local_results)
                        except Exception as e:
                            self.logger.error(f"Results callback failed: {e}")

                    # Strip heavy data and accumulate
                    for uuid, result in local_results.items():
                        result.binary_data = {}
                        all_results[uuid] = result

                    # GC after heavy local batch
                    import gc
                    gc.collect()

                    continue  # Skip to next batch

                # Signal workers to participate in this batch
                self.mpi.comm.bcast(MPITags.CONTINUE, root=0)

                self.logger.info(f"Processing micro-batch {i}-{i + len(batch_uuids)}")

                # Scatter work to all ranks
                local_work = self.mpi.scatter_work_params(batch_uuids, batch_params)

                # Evaluate locally using multiprocessing pool
                local_params = [item.params for item in local_work]
                local_uuids = [item.uuid for item in local_work]

                local_results = self.local_evaluator.evaluate_batch(local_uuids, local_params)

                # Gather results from all ranks
                # Use the per-generation writer (gen_h5_writer)
                if self.use_two_phase_gather:
                    # ADR-004: Two-phase gather with adaptive memory and ANY_SOURCE
                    results = self.mpi.gather_results_two_phase(
                        local_results,
                        h5_writer=gen_h5_writer,
                        available_memory_gb=self.available_memory_gb,
                        n_decompression_workers=self.decompression_workers,
                        global_objectives_config=self.global_objectives_config,
                    )
                else:
                    # Original single-phase gather with parallel decompression
                    results = self.mpi.gather_results(
                        local_results,
                        h5_writer=gen_h5_writer,
                        available_memory_gb=self.available_memory_gb,
                        n_decompression_workers=self.decompression_workers,
                    )

                # Process and Accumulate
                if results: 
                    if results_callback: 
                        # 1. Offload heavy data immediately (IO operation)
                        try:
                            results_callback(results)
                        except Exception as e:
                            self.logger.error(f"Results callback failed: {e}")

                        # 2. Strip heavy binary data from memory before accumulating
                        lightweight_results = {}
                        for uuid, res in results.items():
                            # Manually clear the heavy data
                            res.binary_data = {}
                            # We keep the object because the GA needs the objectives/constraints
                            lightweight_results[uuid] = res

                        all_results.update(lightweight_results)
                    else:
                        # Fallback:  Accumulate everything (Risk of OOM)
                        all_results.update(results)



        finally:
            # ADR-009: Finalize generation storage
            if gen_h5_writer:
                try:
                    gen_h5_writer.close()
                    
                    # Store path for optimizer to register in DB
                    # If we wrote to SHM, we need to move it to final location
                    if gen_shm_path and gen_final_path and gen_shm_path != gen_final_path:
                        if gen_h5_writer.items_written > 0:
                            self.logger.info(f"Syncing generation {generation} to Lustre: {gen_shm_path} -> {gen_final_path}")
                            if gen_shm_path.exists():
                                shutil.move(str(gen_shm_path), str(gen_final_path))
                                self._last_gen_h5_path = gen_final_path
                            else:
                                self.logger.error(f"SHM file missing during sync: {gen_shm_path} (expected {gen_h5_writer.items_written} items)")
                        else:
                             self.logger.info(f"Generation {generation}: No HDF5 items written, skipping sync.")
                    else:
                         self._last_gen_h5_path = gen_final_path

                except Exception as e:
                     self.logger.error(f"Error finalizing generation storage: {e}")

        # Update statistics
        gen_time = time.time() - gen_start
        self.n_generations += 1
        self.total_designs += len(all_results)
        self.total_time_s += gen_time

        self.logger.info(
            f"Generation {self.n_generations} complete:  "
            f"{len(all_results)} designs in {gen_time:.1f}s"
        )

        # Synchronize all ranks before next generation
        self.mpi.barrier()

        return all_results

    def evaluate_batch(
        self,
        uuids: Optional[List[str]],
        params_list: Optional[List[dict]],
        batch_size: int = 0,
    ) -> Optional[Dict[str, EvalResult]]: 
        """Alias for evaluate_generation to mirror LocalPoolEvaluator interface."""
        # evaluate_batch doesn't support h5_writer in LocalPool interface usually, 
        # but we can add it if needed. For now assume it's used by worker loop or simple calls.
        return self.evaluate_generation(uuids, params_list, batch_size=batch_size)

    def get_statistics(self) -> dict:
        """Get evaluator statistics (root only)."""
        local_stats = self.local_evaluator.get_statistics()

        return {
            "mpi_rank": self.mpi.rank,
            "mpi_size": self.mpi.size,
            "n_generations": self.n_generations,
            "total_designs": self.total_designs,
            "total_time_s": self.total_time_s,
            "local_evaluator":  local_stats,
        }

    def is_root(self) -> bool:
        """Check if this is the root rank."""
        return self.mpi.is_root()

    def run_worker_loop(self):
        """
        Worker loop for non-root ranks to participate in scatter/gather. 

        This method blocks until the master signals termination.
        Workers participate in: 
        1. Receiving broadcast signals (continue/terminate)
        2. Scatter operations to receive work
        3. Local evaluation
        4. Gather operations to return results

        IMPORTANT: Only non-root ranks should call this method. 
        Root rank drives evaluation via evaluate_generation() calls. 
        """
        if self.mpi.is_root():
            self.logger.warning("Root rank should not call run_worker_loop()")
            return

        self._worker_running = True
        self.logger.info(f"Worker rank {self.mpi.rank} entering work loop")

        while self._worker_running:
            # Step 1: Wait for signal from master (continue or terminate)
            signal = self.mpi.comm.bcast(None, root=0)

            if signal == self.TAG_TERMINATE:
                self.logger.info(f"Worker rank {self.mpi.rank} received termination signal")
                break

            if signal != self.TAG_CONTINUE: 
                self.logger.warning(f"Worker received unexpected signal: {signal}")
                continue

            # Step 2: Participate in one evaluation round
            # Receive total count from master
            total = self.mpi.comm.bcast(None, root=0)

            if total is None or total == 0:
                # Empty batch, just synchronize
                self.mpi.barrier()
                continue

            # Receive batch_size from master
            effective_batch = self.mpi.comm.bcast(None, root=0)

            # Process micro-batches
            for i in range(0, total, effective_batch):
                # ADR-015: Receive per-batch signal (CONTINUE or SKIP_BATCH)
                batch_signal = self.mpi.comm.bcast(None, root=0)

                if batch_signal == MPITags.SKIP_BATCH:
                    self.logger.debug(f"Worker rank {self.mpi.rank} skipping head-only batch")
                    continue  # Skip to next batch

                # Scatter:  receive work from master
                local_work = self.mpi.scatter_work_params(None, None)

                # Evaluate locally
                local_params = [item.params for item in local_work]
                local_uuids = [item.uuid for item in local_work]

                self.logger.debug(
                    f"Worker {self.mpi.rank} processing {len(local_work)} designs"
                )

                local_results = self.local_evaluator.evaluate_batch(local_uuids, local_params)

                # Gather: send results back to master
                if self.use_two_phase_gather:
                    # ADR-004: Two-phase gather (worker participates in both phases)
                    self.mpi.gather_results_two_phase(
                        local_results,
                        global_objectives_config=self.global_objectives_config,
                    )
                else:
                    # Original single-phase gather
                    self.mpi.gather_results(local_results)

            # Synchronize after generation
            self.mpi.barrier()

        self._worker_running = False
        self.logger.info(f"Worker rank {self.mpi.rank} exiting work loop")

    def signal_workers_terminate(self):
        """
        Signal all workers to terminate their work loops. 

        Only the root rank should call this method. 
        """
        if not self.mpi.is_root():
            self.logger.warning("Only root rank should call signal_workers_terminate()")
            return

        self.logger.info("Sending termination signal to all workers")
        self.mpi.comm.bcast(self.TAG_TERMINATE, root=0)


def get_mpi_evaluator_or_local(
    static_context: Any,
    pk_threshold: float = 0.5,
    run_mc: bool = False,
    zdata_number: int = 1000,
    zdata_generator_config: Optional[ZDATAGeneratorConfig] = None,
    cores_per_node: Optional[int] = None,
    designs_per_core: Optional[float] = None,
    prefer_mpi: bool = True,
    log_file: Optional[Path] = None,
    log_level: str = "INFO",
    use_two_phase_gather: bool = True,
    include_data_types: Optional[List[str]] = None,
    n_objectives: Optional[int] = None,
    global_objectives_config: Optional[Dict[str, bool]] = None,
):
    """
    Get appropriate evaluator based on environment.

    Returns MPIEvaluator if MPI is available and multiple ranks exist,
    otherwise returns LocalPoolEvaluator.

    Args:
        static_context: SABRE GaStaticContext
        pk_threshold: Pk threshold
        run_mc: Whether to run MC
        zdata_number: ZDATA number
        zdata_generator_config: ZDATA generator configuration for worker-side generation
        cores_per_node: Cores per node
        designs_per_core: Target designs per core for auto batch sizing
        prefer_mpi: Whether to prefer MPI if available
        log_file: Path to log file
        log_level: Logging level
        use_two_phase_gather: If True, use ADR-004 two-phase gather protocol
        include_data_types: Data types to include in results (e.g., ['discrete'] to skip pk hypercube).
                           Filtering happens at worker BEFORE MPI send, reducing network by ~99%.
        n_objectives: Total number of objectives (for logging)
        global_objectives_config: Configuration of global objectives

    Returns:
        Either MPIEvaluator or LocalPoolEvaluator
    """
    use_mpi = (
        prefer_mpi
        and MPI_AVAILABLE
        and MPI.COMM_WORLD.Get_size() > 1
    )

    if use_mpi:
        return MPIEvaluator(
            static_context=static_context,
            pk_threshold=pk_threshold,
            run_mc=run_mc,
            zdata_number=zdata_number,
            zdata_generator_config=zdata_generator_config,
            cores_per_node=cores_per_node,
            designs_per_core=designs_per_core,
            log_file=log_file,
            log_level=log_level,
            use_two_phase_gather=use_two_phase_gather,
            include_data_types=include_data_types,
            n_objectives=n_objectives,
            global_objectives_config=global_objectives_config,
        )
    else:
        return LocalPoolEvaluator(
            static_context=static_context,
            pk_threshold=pk_threshold,
            run_mc=run_mc,
            zdata_number=zdata_number,
            zdata_generator_config=zdata_generator_config,
            n_workers=cores_per_node,
            log_file=log_file,
            log_level=log_level,
            include_data_types=include_data_types,
        )
