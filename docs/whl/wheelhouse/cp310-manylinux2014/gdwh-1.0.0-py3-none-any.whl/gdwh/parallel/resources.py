"""System resource detection for parallel execution."""

import os
import multiprocessing
import sys
from typing import Optional, Tuple
from dataclasses import dataclass


@dataclass
class SystemResources:
    """Detected system resources for parallel execution."""

    cpu_count: int
    physical_cores: int
    available_memory_gb: float
    hostname: str
    mpi_available: bool
    mpi_rank: Optional[int]
    mpi_size: Optional[int]


def get_cpu_count() -> int:
    """Get total CPU count (including hyperthreads)."""
    return multiprocessing.cpu_count()


def get_physical_cores() -> int:
    """Get physical core count (excluding hyperthreads)."""
    try:
        if os.path.exists("/proc/cpuinfo"):
            with open("/proc/cpuinfo", "r") as f:
                content = f.read()
            cores = set()
            current_physical = None
            for line in content.split("\n"):
                if line.startswith("physical id"):
                    current_physical = line.split(":")[1].strip()
                elif line.startswith("core id"):
                    core_id = line.split(":")[1].strip()
                    if current_physical is not None:
                        cores.add((current_physical, core_id))
            if cores:
                return len(cores)
    except Exception:
        pass
    return max(1, get_cpu_count() // 2)


def get_available_memory_gb() -> float:
    """Get available memory in GB."""
    try:
        if os.path.exists("/proc/meminfo"):
            with open("/proc/meminfo", "r") as f:
                for line in f:
                    if line.startswith("MemAvailable:"):
                        kb = int(line.split()[1])
                        return kb / (1024 * 1024)
    except Exception:
        pass
    return 8.0


def get_hostname() -> str:
    """Get hostname."""
    import socket
    return socket.gethostname()


def get_mpi_info() -> Tuple[bool, Optional[int], Optional[int]]:
    """
    Get MPI availability and rank/size info.
    
    Uses mpi4py directly. For SLURM environments, ensure proper MPI launch
    with mpirun or srun --mpi=pmi2 so mpi4py correctly detects all ranks.
    """
    # Try mpi4py first (preferred)
    try:
        from mpi4py import MPI
        comm = MPI.COMM_WORLD
        size = comm.Get_size()
        if size > 1:
            return True, comm.Get_rank(), size
    except ImportError:
        pass

    # Check for OpenMPI environment (fallback for single-process runs)
    if "OMPI_COMM_WORLD_RANK" in os.environ:
        try:
            rank = int(os.environ["OMPI_COMM_WORLD_RANK"])
            size = int(os.environ.get("OMPI_COMM_WORLD_SIZE", 1))
            if size > 1:
                return True, rank, size
        except ValueError:
            pass

    return False, None, None


def detect_resources() -> SystemResources:
    """Detect system resources for parallel execution."""
    mpi_available, mpi_rank, mpi_size = get_mpi_info()

    return SystemResources(
        cpu_count=get_cpu_count(),
        physical_cores=get_physical_cores(),
        available_memory_gb=get_available_memory_gb(),
        hostname=get_hostname(),
        mpi_available=mpi_available,
        mpi_rank=mpi_rank,
        mpi_size=mpi_size,
    )


def recommend_workers(
    resources: Optional[SystemResources] = None,
    memory_per_worker_gb: float = 0.5,
    prefer_physical_cores: bool = True,
) -> int:
    """Recommend number of workers based on system resources."""
    if resources is None:
        resources = detect_resources()

    if prefer_physical_cores:
        n_workers = resources.physical_cores
    else:
        n_workers = resources.cpu_count

    max_by_memory = int(resources.available_memory_gb / memory_per_worker_gb)
    n_workers = min(n_workers, max_by_memory)

    return max(1, n_workers)


def print_resource_summary(resources: Optional[SystemResources] = None):
    """Print a summary of detected system resources."""
    if resources is None:
        resources = detect_resources()

    print(f"System Resources Summary")
    print(f"=" * 40)
    print(f"Hostname:        {resources.hostname}")
    print(f"CPU Count:       {resources.cpu_count}")
    print(f"Physical Cores:  {resources.physical_cores}")
    print(f"Available RAM:   {resources.available_memory_gb:.1f} GB")
    print(f"MPI Available:   {resources.mpi_available}")

    if resources.mpi_available:
        print(f"MPI Rank:        {resources.mpi_rank}")
        print(f"MPI Size:        {resources.mpi_size}")

    recommended = recommend_workers(resources)
    print(f"Recommended Workers: {recommended}")