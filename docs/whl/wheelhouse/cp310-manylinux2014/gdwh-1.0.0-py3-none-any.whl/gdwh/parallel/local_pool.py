"""Local multiprocessing pool evaluator for SABRE within a single node."""

import atexit
import os
import shutil
import socket
import tempfile
import time
import copy
import logging
from multiprocessing import Pool
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass

from ..megadeth.results import EvalResult, ResultExtractor
from ..utils import setup_logger
from ..utils.cleanup import cleanup_shm 
from ..zdata.batch import ZDATAGeneratorConfig
from ..zdata.generator import ZDATAGenerator, generate_zdata_bytes
import megadeth

# ADR-014: Prefer /dev/shm over TMPDIR to avoid DuckDB locking issues on Lustre
SHM_PATH = Path("/dev/shm") 


# Module-level MEGADETH context for worker processes
_worker_static_context = None
_worker_pk_threshold: float = 0.5
_worker_run_mc: bool = False
_worker_zdata_number: int = 1000
_worker_log_file: Optional[Path] = None
_worker_log_level: str = "INFO"
_worker_zdata_generator: Optional[ZDATAGenerator] = None
_worker_include_data_types: Optional[List[str]] = None


@dataclass
class MEGADETHWorkerConfig:
    """Lightweight config for MEGADETH worker initialization."""

    pk_threshold: float
    run_mc: bool
    zdata_number: int


def _init_megadeth_worker(
    static_context: Any,
    pk_threshold: float,
    run_mc: bool,
    zdata_number: int,
    log_file: Optional[Path] = None,
    log_level: str = "INFO",
    zdata_config: Optional[ZDATAGeneratorConfig] = None,
    include_data_types: Optional[List[str]] = None,
) -> None:
    """Initialize MEGADETH worker process.

    Args:
        static_context: MEGADETH static context
        pk_threshold: Probability of kill threshold
        run_mc: Whether to run Monte Carlo
        zdata_number: ZDATA identifier number
        log_file: Optional log file path
        log_level: Logging level
        zdata_config: ZDATA generator configuration
        include_data_types: Data types to include in results (e.g., ['discrete'] to skip pk hypercube)
    """
    global _worker_static_context, _worker_pk_threshold, _worker_run_mc, _worker_zdata_number
    global _worker_log_file, _worker_log_level, _worker_zdata_generator, _worker_include_data_types

    import socket
    import tempfile

    # Patch MEGADETH staging directory to be unique per worker
    try:
        from megadeth.platform.linux import LinuxAdapter
        LinuxAdapter.STAGING_SUBDIR = f"megadeth_staging_{os.getpid()}"
    except ImportError:
        pass

    try:
        from megadeth.platform.windows import WindowsAdapter
        WindowsAdapter.STAGING_SUBDIR = f"megadeth_staging_{os.getpid()}"
    except ImportError:
        pass

    _worker_static_context = copy.copy(static_context)

    # Each worker needs unique output directory to avoid DB locking conflicts
    # ADR-014: Use /dev/shm to avoid DuckDB locking issues on Lustre (TMPDIR often points there)
    hostname = socket.gethostname()
    temp_root = SHM_PATH if SHM_PATH.exists() else Path(tempfile.gettempdir())
    local_temp_base = temp_root / f"megadeth_{hostname}_{os.getpid()}"
    local_temp_base.mkdir(parents=True, exist_ok=True)
    _worker_static_context.base_output_dir = local_temp_base

    _worker_pk_threshold = pk_threshold
    _worker_run_mc = run_mc
    _worker_zdata_number = zdata_number
    _worker_log_file = log_file
    _worker_log_level = log_level
    _worker_include_data_types = include_data_types

    if zdata_config is not None:
        try:
            _worker_zdata_generator = zdata_config.build_generator()
        except Exception as exc:
            # We want to see initialization errors even if logging is silenced
            print(f"CRITICAL: Worker {os.getpid()} failed to init ZDATA generator: {exc}")
            raise

    # --- LOGGING OPTIMIZATION ---
    # Only capture stdout (heavy I/O) if specifically debugging.
    # Otherwise, silence stdout/stderr to reduce disk load.
    if log_file:
        pid = os.getpid()
        is_debug = (log_level == "DEBUG")

        setup_logger(
            name=None,
            log_file=log_file,
            level=log_level,
            worker_id=f"pid_{pid}",
            capture_stdout=is_debug,  # Only capture stdout in DEBUG mode
            console=False,  # Workers should not write to stdout
        )

    # --- CLEANUP ON EXIT ---
    # Register atexit handler to clean up worker temp directories on exit/crash
    def _cleanup_worker_on_exit():
        """Clean up this worker's temp directory on exit."""
        try:
            base_dir = local_temp_base
            if base_dir.exists() and "/dev/shm" in str(base_dir):
                shutil.rmtree(base_dir, ignore_errors=True)
        except Exception:
            pass  # Best effort - don't raise on cleanup failure

    atexit.register(_cleanup_worker_on_exit)


def _evaluate_single_worker(work_item: Tuple[str, dict]) -> Tuple[str, Optional[EvalResult]]:
    """Worker function for parallel MEGADETH evaluation."""
    global _worker_static_context, _worker_pk_threshold, _worker_run_mc, _worker_zdata_number
    global _worker_zdata_generator, _worker_include_data_types

    design_uuid, design_params = work_item

    # Only log at INFO level if explicitly enabled (which we suppress by default in Pool init)
    logging.getLogger().debug(f"Worker {os.getpid()} received job {design_uuid}")

    try:
        from megadeth.ga import run_ga_design, DesignVector
    except ImportError:
        logging.getLogger().error("Failed to import MEGADETH")
        return (work_item[0], None)

    start_time = time.time()

    # Track output directory for cleanup
    design_output_dir = _worker_static_context.base_output_dir / design_uuid

    try:
        if _worker_zdata_generator is None and "zdata_bytes" not in design_params:
            raise RuntimeError("Worker ZDATA generator not initialized")

        zdata_bytes = generate_zdata_bytes(design_params, _worker_zdata_generator)

        design_vector = DesignVector(
            zdata_number=_worker_zdata_number,
            zdata_bytes=zdata_bytes,
        )

        local_context = copy.copy(_worker_static_context)

        # Each design needs unique output directory to avoid DB locking conflicts
        local_context.base_output_dir = design_output_dir
        try:
            local_context.base_output_dir.mkdir(parents=True, exist_ok=True)
        except Exception as mkdir_err:
            logging.getLogger().error(f"Failed to create output dir for {design_uuid}: {mkdir_err}")
            raise

        ga_result = run_ga_design(
            design=design_vector,
            static=local_context,
            pk_threshold=_worker_pk_threshold,
            run_mc=_worker_run_mc,
        )

        eval_time = time.time() - start_time
        # Filter data types BEFORE sending to head - reduces network bandwidth by ~99%
        result = ResultExtractor.extract(
            design_uuid,
            ga_result,
            eval_time_s=eval_time,
            include_data_types=_worker_include_data_types,
            extra_objectives=design_params.get("extra_objectives"),
        )

        return (design_uuid, result)

    except Exception as e:
        import traceback
        error_msg = f"{type(e).__name__}: {e}"
        tb_str = traceback.format_exc()
        # This ERROR log will trigger the lazy file creation
        logging.getLogger().error(f"Evaluation failed for design {design_uuid}: {error_msg}\n{tb_str}")
        return (design_uuid, None, error_msg)

    finally:
        # Clean up per-design directory after evaluation to prevent /dev/shm exhaustion
        try:
            if design_output_dir.exists():
                shutil.rmtree(design_output_dir, ignore_errors=True)
        except Exception:
            pass  # Best effort cleanup

        # Also clean MEGADETH staging directory
        try:
            staging_dir = SHM_PATH / f"megadeth_staging_{os.getpid()}"
            if staging_dir.exists():
                shutil.rmtree(staging_dir, ignore_errors=True)
        except Exception:
            pass  # Best effort cleanup


class LocalPoolEvaluator:
    """Local multiprocessing pool evaluator for MEGADETH."""

    def __init__(
        self,
        static_context: Any,
        pk_threshold: float = 0.5,
        run_mc: bool = False,
        zdata_number: int = 1000,
        zdata_generator_config: Optional[ZDATAGeneratorConfig] = None,
        n_workers: Optional[int] = None,
        chunk_size: int = 1,
        log_file: Optional[Path] = None,
        log_level: str = "INFO",
        include_data_types: Optional[List[str]] = None,
    ):
        """Initialize LocalPoolEvaluator.

        Args:
            static_context: MEGADETH static context
            pk_threshold: Probability of kill threshold
            run_mc: Whether to run Monte Carlo
            zdata_number: ZDATA identifier number
            zdata_generator_config: ZDATA generator configuration
            n_workers: Number of worker processes
            chunk_size: Chunk size for imap_unordered
            log_file: Optional log file path
            log_level: Logging level
            include_data_types: Data types to include in results (e.g., ['discrete'] to skip pk hypercube).
                               Default None includes all types.
        """
        self.static_context = static_context
        self.pk_threshold = pk_threshold
        self.run_mc = run_mc
        self.zdata_number = zdata_number
        self.zdata_generator_config = zdata_generator_config
        self.n_workers = n_workers
        self.chunk_size = chunk_size
        self.log_file = log_file
        self.log_level = log_level
        self.include_data_types = include_data_types
        self._zdata_generator: Optional[ZDATAGenerator] = (
            zdata_generator_config.build_generator() if zdata_generator_config else None
        )

        self.logger = setup_logger(
            "gdwh.parallel.local_pool",
            log_file=log_file,
            level=log_level,
            console=False,  # Pool should not write to stdout
        )

        # CLEANUP: Clear stale artifacts on this node
        cleanup_shm(self.logger)

        self.n_evaluations = 0
        self.n_failures = 0
        self.total_eval_time_s = 0.0

    def evaluate_batch(
        self,
        uuids: List[str],
        params: Union[List[dict], Dict[str, bytes]],
    ) -> Dict[str, EvalResult]:
        """Evaluate a batch of designs in parallel."""
        n_designs = len(uuids)
        if n_designs == 0:
            return {}

        if isinstance(params, dict):
            params_list = [{"zdata_bytes": params[uuid]} for uuid in uuids if uuid in params]
            uuids = [uuid for uuid in uuids if uuid in params]
        else:
            params_list = params

        self.logger.info(f"Evaluating {n_designs} designs with LocalPoolEvaluator (workers={self.n_workers})")
        batch_start = time.time()

        work_items = list(zip(uuids, params_list))
        results: Dict[str, EvalResult] = {}

        def _record(worker_result) -> None:
            if len(worker_result) == 3:
                uuid, result, error_msg = worker_result
            else:
                uuid, result = worker_result
                error_msg = None

            if result is not None:
                results[uuid] = result
                self.n_evaluations += 1
                self.total_eval_time_s += getattr(result, "eval_time_s", 0.0)
            else:
                self.n_failures += 1
                if error_msg:
                    self.logger.warning(f"Evaluation failed for design {uuid}: {error_msg}")
                else:
                    self.logger.warning(f"Evaluation failed for design {uuid}")

        if len(work_items) == 1:
            seq_result = self._evaluate_single_sequential(work_items[0])
            _record(seq_result)
        else:
            auto_chunk = None
            if self.n_workers:
                auto_chunk = max(1, len(work_items) // (self.n_workers * 4))
                effective_chunk_size = max(self.chunk_size, auto_chunk)
            else:
                effective_chunk_size = self.chunk_size

            # --- LOGGING OPTIMIZATION ---
            # If main level is INFO/WARNING, force workers to ERROR to stay silent.
            # Only use DEBUG for workers if the main process is in DEBUG.
            worker_log_level = "ERROR" if self.log_level != "DEBUG" else "DEBUG"

            with Pool(
                processes=self.n_workers,
                initializer=_init_megadeth_worker,
                initargs=(
                    self.static_context,
                    self.pk_threshold,
                    self.run_mc,
                    self.zdata_number,
                    self.log_file,
                    worker_log_level,  # <--- FORCED SILENCE
                    self.zdata_generator_config,
                    self.include_data_types,  # Filter pk hypercube at worker before MPI send
                ),
            ) as pool:
                iterator = pool.imap_unordered(
                    _evaluate_single_worker,
                    work_items,
                    chunksize=effective_chunk_size,
                )

                for worker_result in iterator:
                    _record(worker_result)

        batch_time = time.time() - batch_start
        self.logger.info(f"Batch complete: {len(results)}/{n_designs} successful in {batch_time:.1f}s")

        return results

    def _evaluate_single_sequential(self, work_item: Tuple[str, dict]) -> Tuple[str, Optional[EvalResult], Optional[str]]:
        """Evaluate single design without pool."""
        # ... (Same as before, sequential usually runs in master process so standard logging applies) ...
        # Simplified for brevity as logic remains identical to previous artifact
        # but ensures we handle imports inside function.
        try:
            from megadeth.ga import run_ga_design, DesignVector
        except ImportError:
            return (work_item[0], None, "MEGADETH not available")

        design_uuid, design_params = work_item
        start_time = time.time()

        # Track output directory for cleanup
        # ADR-014: Use /dev/shm to avoid DuckDB locking issues on Lustre (TMPDIR often points there)
        hostname = socket.gethostname()
        temp_root = SHM_PATH if SHM_PATH.exists() else Path(tempfile.gettempdir())
        local_temp_base = temp_root / f"megadeth_{hostname}_{os.getpid()}"
        design_output_dir = local_temp_base / design_uuid

        try:
            if self._zdata_generator is None and "zdata_bytes" not in design_params:
                return (design_uuid, None, "ZDATA generator not configured")

            zdata_bytes = generate_zdata_bytes(design_params, self._zdata_generator)
            design_vector = DesignVector(zdata_number=self.zdata_number, zdata_bytes=zdata_bytes)

            local_context = copy.copy(self.static_context)

            # Each design needs unique output directory to avoid DB locking conflicts
            local_temp_base.mkdir(parents=True, exist_ok=True)
            local_context.base_output_dir = design_output_dir
            local_context.base_output_dir.mkdir(parents=True, exist_ok=True)

            ga_result = run_ga_design(
                design=design_vector,
                static=local_context,
                pk_threshold=self.pk_threshold,
                run_mc=self.run_mc,
            )

            eval_time = time.time() - start_time
            # Filter data types to reduce memory/network - same as parallel worker
            result = ResultExtractor.extract(
                design_uuid,
                ga_result,
                eval_time_s=eval_time,
                include_data_types=self.include_data_types,
                extra_objectives=design_params.get("extra_objectives"),
            )
            return (design_uuid, result)

        except Exception as e:
            return (design_uuid, None, str(e))

        finally:
            # Clean up per-design directory after evaluation to prevent /dev/shm exhaustion
            try:
                if design_output_dir.exists():
                    shutil.rmtree(design_output_dir, ignore_errors=True)
            except Exception:
                pass  # Best effort cleanup

            # Also clean MEGADETH staging directory
            try:
                staging_dir = SHM_PATH / f"megadeth_staging_{os.getpid()}"
                if staging_dir.exists():
                    shutil.rmtree(staging_dir, ignore_errors=True)
            except Exception:
                pass  # Best effort cleanup

    def get_statistics(self) -> dict:
        return {
            "n_evaluations": self.n_evaluations,
            "n_failures": self.n_failures,
            "total_eval_time_s": self.total_eval_time_s,
        }
