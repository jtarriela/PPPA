"""
Convergence metrics for multi-objective optimization (ADR-010).

Uses PPPA (fast_hv) as the sole hypervolume algorithm for all objective counts.
PPPA provides excellent accuracy (<0.2% error) with superior scalability via
OpenMP parallelization on HPC nodes.

Hypervolume is computed on NORMALIZED objectives [0,1] to produce comparable
values across runs and different objective scales.

Reference: Tang et al. (2020) - Information Sciences, 509, 320-342
"""

import logging
import numpy as np
from typing import Optional

_logger = logging.getLogger("gdwh.utils.convergence")

# Track if we've logged the algorithm selection
_hv_algorithm_logged = False


def compute_hypervolume(
    F: np.ndarray,
    ref_point: Optional[np.ndarray] = None,
    ideal: Optional[np.ndarray] = None,
    nadir: Optional[np.ndarray] = None,
) -> Optional[float]:
    """
    Compute hypervolume using PPPA algorithm (fast_hv) on normalized objectives.
    
    Objectives are normalized to [0,1] using ideal/nadir bounds:
        F_norm = (F - ideal) / (nadir - ideal)
    
    This produces HV values in [0, 1.1^M] range regardless of objective scales.
    For M=5 objectives, HV will be ~0 to 1.6 (maximized when front covers full space).
    
    Note: Pymoo stores F in minimization form (maximize objectives are negated).
    The normalization handles this correctly since ideal < nadir for all objectives.
    
    Args:
        F: Objective matrix (n_points, n_objectives), minimization form
        ref_point: Reference point. If None, uses [1.1, 1.1, ...] (normalized space)
        ideal: Ideal point for normalization. If None, computed as F.min(axis=0)
        nadir: Nadir point for normalization. If None, computed as F.max(axis=0)
        
    Returns:
        Hypervolume value (normalized), or None if computation fails
    """
    global _hv_algorithm_logged
    
    if F is None or len(F) == 0:
        return None
    
    n, m = F.shape
    
    if n == 0:
        return None
    
    # Compute ideal/nadir if not provided
    if ideal is None:
        ideal = F.min(axis=0)
    if nadir is None:
        nadir = F.max(axis=0)
    
    # Check for degenerate case (all objectives identical)
    ranges = nadir - ideal
    if np.any(ranges <= 0):
        _logger.debug("HV skipped: degenerate objective range (nadir <= ideal)")
        return None
    
    # Normalize F to [0, 1] per objective
    F_norm = (F - ideal) / ranges
    
    # Reference point in normalized space: 10% beyond nadir (which is [1,1,...])
    if ref_point is None:
        ref_point = np.ones(m) * 1.1
    
    # Log algorithm on first call
    if not _hv_algorithm_logged:
        _logger.info(
            f"ADR-010 Hypervolume: PPPA (fast_hv) | "
            f"{m} objectives | "
            f"Normalized to [0,1] | "
            f"ref_point=[1.1]*{m}"
        )
        _hv_algorithm_logged = True
    
    # Compute using PPPA on normalized objectives
    return _compute_hv_pppa(F_norm, ref_point)


def _compute_hv_pppa(
    F: np.ndarray,
    ref_point: np.ndarray,
) -> Optional[float]:
    """
    Compute hypervolume using PPPA algorithm via fast_hv.
    
    PPPA (Partial Precision Partial Approximation) combines:
    - Exact segmentation via recursive pivot selection
    - Monte Carlo approximation for corner regions
    - OpenMP task + data parallelism for HPC scaling
    """
    try:
        import fast_hv

        # Ensure contiguous arrays for C++ binding
        F_cont = np.ascontiguousarray(F, dtype=np.float64)
        ref_cont = np.ascontiguousarray(ref_point, dtype=np.float64)

        # Compute hypervolume
        # max_depth=6: segmentation recursion depth
        # n_samples=100000: Monte Carlo samples per unit volume
        hv = fast_hv.compute(F_cont, ref_cont, max_depth=6, n_samples=100000)
        return float(hv)
        
    except ImportError:
        _logger.error(
            "fast_hv not available. Install PPPA package: "
            "pip install /path/to/PPPA"
        )
        return None
        
    except Exception as e:
        _logger.warning(f"PPPA HV computation failed: {e}")
        return None


def compute_hv_for_population(algorithm) -> Optional[float]:
    """
    Compute hypervolume for a pymoo algorithm's current population.
    
    Optimization (ADR-012): Computes HV on Pareto front only (rank-0),
    while preserving normalization bounds from the full feasible population.
    
    Args:
        algorithm: Pymoo algorithm instance with .pop attribute
        
    Returns:
        Hypervolume value (normalized to [0,1] per objective), or None if fails
    """
    if not hasattr(algorithm, "pop") or algorithm.pop is None:
        return None
    
    F = algorithm.pop.get("F")
    if F is None or len(F) == 0:
        return None
    
    # Filter to feasible solutions only
    feasible = algorithm.pop.get("feasible")
    if feasible is not None:
        feasible = feasible.flatten()
    else:
        feasible = np.ones(len(F), dtype=bool)

    F_feasible = F[feasible]
    
    if len(F_feasible) == 0:
        return None
    
    # Compute ideal/nadir from FULL feasible population (preserves normalization)
    ideal = F_feasible.min(axis=0)
    nadir = F_feasible.max(axis=0)

    # ADR-012: Extract Pareto front only (rank-0) for HV computation
    rank = algorithm.pop.get("rank")
    if rank is not None:
        rank = rank.flatten()
        if len(rank) == len(F):
            pareto_mask = feasible & (rank == 0)
            F_pareto = F[pareto_mask]
        else:
            F_pareto = F_feasible
    else:
        F_pareto = F_feasible

    if len(F_pareto) == 0:
        return None

    return compute_hypervolume(F_pareto, ideal=ideal, nadir=nadir)


class HVConvergenceTracker:
    """
    Track hypervolume convergence over generations.
    
    Implements sliding window detection for HV stabilization.
    """
    
    def __init__(
        self,
        tolerance: float = 0.001,
        window_gens: int = 20,
    ):
        """
        Initialize convergence tracker.
        
        Args:
            tolerance: Relative change threshold for convergence detection
            window_gens: Number of generations in sliding window
        """
        self.tolerance = tolerance
        self.window = window_gens
        self.hv_history: list = []
    
    def update(self, hv: Optional[float]) -> bool:
        """
        Update with new HV value and check for convergence.
        
        Args:
            hv: Hypervolume value for current generation
            
        Returns:
            True if converged (HV stabilized), False otherwise
        """
        if hv is None:
            return False
        
        self.hv_history.append(hv)
        
        if len(self.hv_history) < self.window:
            return False
        
        recent = self.hv_history[-self.window:]
        max_hv = max(recent)
        min_hv = min(recent)
        
        if max_hv == 0:
            return False
        
        relative_change = (max_hv - min_hv) / max(max_hv, 1e-12)
        return relative_change < self.tolerance
    
    def get_history(self) -> list:
        """Return the full HV history."""
        return self.hv_history.copy()
    
    def get_latest(self) -> Optional[float]:
        """Return the most recent HV value."""
        return self.hv_history[-1] if self.hv_history else None
