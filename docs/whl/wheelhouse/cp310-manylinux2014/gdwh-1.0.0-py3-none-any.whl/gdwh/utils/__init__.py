"""Utility functions for GWDH-NG."""

from .hashing import (
    compute_design_uuid,
    compute_npz_uuid,
    compute_file_checksum,
    compute_bytes_checksum,
    verify_checksum,
)
from .logging import setup_logger, get_logger, ProgressLogger
from .convergence import (
    compute_hypervolume,
    compute_hv_for_population,
    HVConvergenceTracker,
)
from .cleanup import cleanup_shm

__all__ = [
    "compute_design_uuid",
    "compute_npz_uuid",
    "compute_file_checksum",
    "compute_bytes_checksum",
    "verify_checksum",
    "setup_logger",
    "get_logger",
    "ProgressLogger",
    "compute_hypervolume",
    "compute_hv_for_population",
    "HVConvergenceTracker",
    "cleanup_shm",
]
