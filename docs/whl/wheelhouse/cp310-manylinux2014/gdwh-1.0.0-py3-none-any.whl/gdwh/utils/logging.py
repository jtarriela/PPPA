"""Logging configuration for GWDH-NG."""

import logging
import sys
from pathlib import Path
from typing import Optional


def get_log_file_path(
    base_path: Path,
    mpi_rank: Optional[int] = None,
    worker_id: Optional[str] = None,
) -> Path:
    """Generate a log file path with rank/worker suffixes."""
    base_path = Path(base_path)
    stem = base_path.stem
    
    if mpi_rank is not None:
        stem += f"_rank{mpi_rank}"
        
    if worker_id is not None:
        stem += f"_worker_{worker_id}"
        
    return base_path.parent / f"{stem}{base_path.suffix}"


def setup_logger(
    name: Optional[str],
    log_file: Optional[Path] = None,
    level: str = "INFO",
    mpi_rank: Optional[int] = None,
    worker_id: Optional[str] = None,
    capture_stdout: bool = False,
    console: bool = True,
) -> logging.Logger:
    """Configure logger for GWDH-NG.

    Args:
        name: Logger name (e.g., "gdwh.optimizer")
        log_file: Path to log file. If None, no file logging.
        level: Log level (DEBUG, INFO, WARNING, ERROR)
        mpi_rank: MPI rank for log file naming and formatting
        worker_id: Worker ID for log file naming and formatting
        capture_stdout: If True, redirect stdout/stderr to log file
        console: If True, also log to stdout. Set False to silence console output.
    """
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper()))

    # Remove existing handlers
    logger.handlers = []

    # Define formatter
    parts = ["%(asctime)s"]
    if mpi_rank is not None:
        parts.append(f"[RANK-{mpi_rank}]")
    if worker_id is not None:
        parts.append(f"[{worker_id}]")
    parts.append("%(levelname)-8s %(name)s: %(message)s")

    format_str = " ".join(parts)
    formatter = logging.Formatter(format_str, datefmt="%Y-%m-%d %H:%M:%S")

    # 1. Console Handler (can be disabled with console=False)
    if console and not capture_stdout:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    # 2. File Handler (Lazy)
    if log_file is not None:
        actual_log_path = get_log_file_path(log_file, mpi_rank, worker_id)
        
        if capture_stdout:
            # Aggressive mode: Capture ALL stdout/stderr to file
            # This CANNOT be lazy because we must redirect sys.stdout immediately
            actual_log_path.parent.mkdir(parents=True, exist_ok=True)
            log_stream = open(actual_log_path, "a")
            sys.stdout = log_stream
            sys.stderr = log_stream
            
            # Add a stream handler pointing to this file
            file_handler = logging.StreamHandler(log_stream)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        else:
            # Silent mode: Only write to file if logger.error() is called
            # Use delay=True so empty log files are NOT created
            actual_log_path.parent.mkdir(parents=True, exist_ok=True)
            
            file_handler = logging.FileHandler(actual_log_path, mode="a", delay=True)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

    return logger


def get_logger(name: str) -> logging.Logger:
    """Get existing logger by name."""
    return logging.getLogger(name)


class ProgressLogger:
    """Simple progress logger with generation tracking."""
    # ... (Existing methods remain unchanged)
    def __init__(self, logger: logging.Logger, total_generations: int):
        self.logger = logger
        self.total_generations = total_generations
        self.current_generation = 0

    def log_generation_start(self, gen: int):
        self.current_generation = gen
        self.logger.info(f"Generation {gen}/{self.total_generations} started")

    def log_generation(self, gen: int, pop_size: int, n_feasible: int, n_evaluated: Optional[int] = None):
        self.current_generation = gen
        total_evaluated = n_evaluated if n_evaluated is not None else pop_size
        feasibility_rate = n_feasible / total_evaluated if total_evaluated > 0 else 0
        self.logger.info(
            f"Generation {gen}/{self.total_generations}: "
            f"evaluated={total_evaluated}, feasible={n_feasible} ({feasibility_rate:.1%}), "
            f"pop_size={pop_size}"
        )

    def log_generation_complete(self, gen: int, n_feasible: int, n_infeasible: int, eval_time_s: float):
        self.logger.info(
            f"Generation {gen}/{self.total_generations} complete: "
            f"{n_feasible} feasible, {n_infeasible} infeasible, "
            f"eval_time={eval_time_s:.1f}s"
        )

    def log_pareto_front(self, gen: int, pareto_size: int, hypervolume: float):
        self.logger.info(f"Generation {gen}: Pareto size={pareto_size}, hypervolume={hypervolume:.6f}")

    def log_convergence(self, message: str):
        self.logger.info(f"CONVERGENCE: {message}")

    def log_checkpoint(self, gen: int, checkpoint_path: Path):
        self.logger.info(f"Checkpoint saved: generation {gen} -> {checkpoint_path}")

    def log_error(self, message: str):
        self.logger.error(message)

    def log_warning(self, message: str):
        self.logger.warning(message)
