"""UUID generation and hashing utilities for GWDH-NG."""

import hashlib
import numpy as np
from typing import Union


def compute_design_uuid(design_vector: np.ndarray) -> str:
    """
    Compute unique UUID for a design vector using full SHA256.

    ADR-017: Changed from 16-char truncated hash to full 64-char hash
    to eliminate collision risk from near-duplicate designs.

    Args:
        design_vector: Design vector array (225 variables)

    Returns:
        Full SHA256 hash (64 hex characters) as design UUID
    """
    # Convert to bytes for hashing
    design_bytes = design_vector.tobytes()

    # Compute SHA256 hash
    hasher = hashlib.sha256()
    hasher.update(design_bytes)

    # ADR-017: Return full hash to prevent collisions
    return hasher.hexdigest()


def compute_npz_uuid(design_uuid: str, target_id: int, npz_type: str) -> str:
    """
    Compute unique UUID for NPZ file.

    Args:
        design_uuid: Design UUID (SHA256[:16])
        target_id: Target RCAS number
        npz_type: Type of NPZ ("pk_hypercube" or "discrete")

    Returns:
        SHA256 hash (first 16 characters) as NPZ UUID
    """
    # Combine design UUID, target ID, and type
    combined = f"{design_uuid}_{target_id}_{npz_type}".encode('utf-8')

    # Compute SHA256 hash
    hasher = hashlib.sha256()
    hasher.update(combined)
    hash_hex = hasher.hexdigest()

    # Return first 16 characters as UUID
    return hash_hex[:16]


def compute_file_checksum(file_path: Union[str, 'Path']) -> str:
    """
    Compute SHA256 checksum of a file.

    Args:
        file_path: Path to file

    Returns:
        SHA256 checksum as hex string
    """
    from pathlib import Path

    file_path = Path(file_path)

    hasher = hashlib.sha256()

    # Read file in chunks for memory efficiency
    with open(file_path, 'rb') as f:
        while chunk := f.read(8192):
            hasher.update(chunk)

    return hasher.hexdigest()


def compute_bytes_checksum(data: bytes) -> str:
    """
    Compute SHA256 checksum of bytes.

    Args:
        data: Bytes to hash

    Returns:
        SHA256 checksum as hex string
    """
    hasher = hashlib.sha256()
    hasher.update(data)
    return hasher.hexdigest()


def verify_checksum(file_path: Union[str, 'Path'], expected_checksum: str) -> bool:
    """
    Verify file checksum matches expected value.

    Args:
        file_path: Path to file
        expected_checksum: Expected SHA256 checksum

    Returns:
        True if checksums match, False otherwise
    """
    actual_checksum = compute_file_checksum(file_path)
    return actual_checksum == expected_checksum
