
"""Cleanup utilities for GWDH artifacts."""

import shutil
import logging
from pathlib import Path

def cleanup_shm(logger=None):
    """
    Clean up GWDH artifacts from /dev/shm.
    
    Removes:
    - megadeth_staging_* directories (MEGADETH worker scratch)
    - megadeth_* directories (Local pool scratch)
    - gdwh_*.h5 files (HDF5 generation staging)
    """
    if logger is None:
        logger = logging.getLogger("gdwh.utils.cleanup")
        
    shm_path = Path("/dev/shm")
    if not shm_path.exists():
        return

    # Clean staging dirs
    try:
        # MEGADETH worker staging
        staging_dirs = list(shm_path.glob("megadeth_staging_*"))
        # Local pool temp dirs (from local_pool.py)
        staging_dirs.extend(list(shm_path.glob("megadeth_*")))
        
        count = 0
        for p in staging_dirs:
            try:
                if p.is_dir():
                    shutil.rmtree(p)
                else:
                    p.unlink()
                count += 1
            except Exception:
                # Ignore permission errors or concurrent modification
                pass
        
        if count > 0:
            logger.info(f"Cleaned up {count} stale staging directories in /dev/shm")
            
    except Exception as e:
        logger.warning(f"Error during SHM cleanup: {e}")
