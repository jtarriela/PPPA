"""ZDATA file generator for warhead fragment data."""

import numpy as np
from io import StringIO
from typing import Optional, Tuple

from ..config import WarheadConfig, VariablesConfig
from ..utils import compute_design_uuid


class ZDATAGenerator:
    """
    Generate ZDATA files from design variables (in-memory, no disk I/O).

    ZDATA Format (from ARL-TN-541):
    - Header: "ZDATA" + number of zones
    - Per zone: angles (lower, mid, upper), velocities (lower, mid, upper), number of bins
    - Mass data: fragment masses in each bin (7 per line)
    - Count data: fragment counts in each bin (7 per line)
    - Footer: shape factor
    """

    def __init__(
        self,
        warhead_config: WarheadConfig,
        variables_config: VariablesConfig,
        shape_factor: Optional[float] = None,
    ):
        """
        Initialize ZDATA generator.

        Args:
            warhead_config: Warhead configuration
            variables_config: Design variables configuration
            shape_factor: Shape factor for drag computation (ft^2 gr^(1/3)/lb).
                          If None, uses warhead_config.physics.shape_factor.
        """
        self.n_zones = warhead_config.n_zones
        self.zdata_number = warhead_config.zdata_number

        # Use provided override or config default
        if shape_factor is not None:
            self.shape_factor = shape_factor
        else:
            # Default from schema is 0.461235589 if not set in yaml
            self.shape_factor = warhead_config.physics.shape_factor

        # Store the velocity strategy
        self.velocity_strategy = variables_config.zone_velocities.strategy

        self.bin_edges = np.array(variables_config.fragment_sizes.bin_edges_grams)
        self.n_bins = len(self.bin_edges) - 1

        # Pre-compute bin center masses (average of edges)
        self.bin_centers_g = (self.bin_edges[:-1] + self.bin_edges[1:]) / 2.0

        # Pre-compute zone angles (evenly distributed)
        self.zone_angles = self._compute_zone_angles()

    def _compute_zone_angles(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute lower, middle, and upper zone angles.

        Returns:
            (lower_angles, mid_angles, upper_angles) in degrees
        """
        zone_width = 180.0 / self.n_zones

        lower_angles = np.arange(self.n_zones) * zone_width
        upper_angles = (np.arange(self.n_zones) + 1) * zone_width
        mid_angles = (lower_angles + upper_angles) / 2.0

        return lower_angles, mid_angles, upper_angles

    def to_bytes(self, design: np.ndarray) -> bytes:
        """
        Convert design vector to ZDATA bytes (in-memory).

        Args:
            design: Design vector, shape (n_vars,)
                   [frag_sizes, frag_quantities, zone_velocities]

        Returns:
            ZDATA file content as ASCII bytes
        """
        # Check for NaN/Inf in design vector
        if not np.isfinite(design).all():
            raise ValueError("Design vector contains NaN or Inf values")

        # Extract variables
        frag_sizes, frag_quantities, zone_velocities = self._extract_variables(design)

        # Generate ZDATA text
        zdata_text = self._generate_zdata_text(frag_sizes, frag_quantities, zone_velocities)

        # Convert to bytes
        return zdata_text.encode('ascii')

    def debug_dump(self, design: np.ndarray, path: str):
        """
        Dump ZDATA content to file for debugging.
        
        Args:
            design: Design vector
            path: Output file path
        """
        try:
            content = self.to_bytes(design).decode('ascii')
            with open(path, 'w') as f:
                f.write(content)
        except Exception as e:
            print(f"Failed to dump debug ZDATA: {e}")

    def _extract_variables(self, design: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Extract structured design variables.

        Args:
            design: Flat design vector

        Returns:
            frag_sizes: shape (n_zones, n_bins)
            frag_quantities: shape (n_zones, n_bins)
            velocities: shape (n_zones+1,) for nodal, (n_zones,) for zonal
        """
        n_zones_bins = self.n_zones * self.n_bins

        frag_sizes_flat = design[:n_zones_bins]
        frag_quantities_flat = design[n_zones_bins : 2 * n_zones_bins]
        velocities = design[2 * n_zones_bins :]

        frag_sizes = frag_sizes_flat.reshape(self.n_zones, self.n_bins)
        frag_quantities = frag_quantities_flat.reshape(self.n_zones, self.n_bins)

        return frag_sizes, frag_quantities, velocities

    def _generate_zdata_text(
        self,
        frag_sizes: np.ndarray,
        frag_quantities: np.ndarray,
        velocities: np.ndarray,
    ) -> str:
        """
        Generate ZDATA file text matching validation format.

        Args:
            velocities: Nodal velocities (n_zones+1,) or zonal velocities (n_zones,)
        """
        output = StringIO()

        # Constants
        GRAMS_TO_GRAINS = 15.4323584

        # Convert velocities from m/s to ft/s (FullSpray uses ft/s)
        velocities_fps = velocities * 3.28084

        # Convert fragment sizes from GRAMS to GRAINS
        frag_sizes_grains = frag_sizes * GRAMS_TO_GRAINS

        # Unpack zone angles
        lower_angles, mid_angles, upper_angles = self.zone_angles

        # Header lines
        output.write(f"ZDATA {self.zdata_number}     \n")
        output.write(f"ZDATA           {float(self.n_zones):.3f}\n")

        # Per-zone data
        for i in range(self.n_zones):
            # --- VELOCITY LOGIC ---
            if self.velocity_strategy == "nodal":
                # NODAL APPROACH: Use boundary velocities directly
                # v_lower = node[i], v_upper = node[i+1], v_mid = average
                v_lower = velocities_fps[i]
                v_upper = velocities_fps[i + 1]
                v_mid = (v_lower + v_upper) / 2.0
            else:
                # ZONAL UNIFORM: All velocities equal (stepped)
                v_mid = velocities_fps[i]
                v_lower = v_mid
                v_upper = v_mid
            # ---------------------------------

            # --- STRICT FORMATTING BLOCK ---
            # 1. Angle Order: Lower, Upper, Mid (Matches ZDATA 1200)
            # 2. Strict 10-char columns: No spaces between {}
            # 3. Bin count: Float formatted (:10.4f)
            output.write(
                f"{lower_angles[i]:10.4f}{upper_angles[i]:10.4f}{mid_angles[i]:10.4f}"
                f"{v_lower:10.4f}{v_upper:10.4f}{v_mid:10.4f}{float(self.n_bins):10.4f}\n"
            )

            # Mass data (7 values per line)
            self._write_values(output, frag_sizes_grains[i], precision=4)

            # Count data (7 values per line)
            self._write_values(output, frag_quantities[i], precision=4)

        # Shape factor
        output.write(f"   {self.shape_factor:10.4f}\n")

        # Footer
        output.write("    1.0000\n")

        return output.getvalue()

    def _write_values(self, output: StringIO, values: np.ndarray, precision: int = 3):
        """
        Write values to output in fixed-width format (optimized with numpy).

        PERFORMANCE: Uses numpy.savetxt to push formatting loop into C,
        avoiding millions of Python iterations for large populations.
        """
        # Reshape to 2D array: 7 columns per row (ZDATA format requirement)
        n_vals = len(values)
        n_complete_rows = n_vals // 7
        remainder = n_vals % 7

        # Format string: 10 chars wide, specified precision, no delimiter
        fmt = f'%10.{precision}f'

        if n_complete_rows > 0:
            # Write complete rows (7 values each)
            complete_data = values[:n_complete_rows * 7].reshape(n_complete_rows, 7)
            np.savetxt(output, complete_data, fmt=fmt, delimiter='')

        if remainder > 0:
            # Write remaining values on final row
            remaining_data = values[n_complete_rows * 7:].reshape(1, -1)
            np.savetxt(output, remaining_data, fmt=fmt, delimiter='')

    def compute_uuid(self, design: np.ndarray) -> str:
        """
        Compute unique UUID for design.

        Args:
            design: Design vector

        Returns:
            SHA256 hash (first 16 characters)
        """
        return compute_design_uuid(design)

    def get_variable_count(self) -> int:
        """Get total number of design variables."""
        if self.velocity_strategy == "nodal":
            n_velocities = self.n_zones + 1  # N+1 boundary velocities
        else:
            n_velocities = self.n_zones  # N zone velocities
        return self.n_zones * self.n_bins * 2 + n_velocities


def generate_zdata_bytes(design_params: dict, generator: Optional[ZDATAGenerator]) -> bytes:
    """
    Generate ZDATA bytes from a design parameter dictionary.

    Expected keys:
        - design_vector (preferred) or design: flat design array/list
        - zdata_bytes: optional precomputed bytes (bypass generator)
    """
    precomputed = design_params.get("zdata_bytes")
    if precomputed is not None:
        return precomputed

    design_vector = design_params.get("design_vector")
    if design_vector is None:
        design_vector = design_params.get("design")

    if design_vector is None:
        raise ValueError("design_params must include a 'design_vector' entry")

    if generator is None:
        raise ValueError("ZDATA generator is required to build bytes from a design vector")

    return generator.to_bytes(np.asarray(design_vector))
