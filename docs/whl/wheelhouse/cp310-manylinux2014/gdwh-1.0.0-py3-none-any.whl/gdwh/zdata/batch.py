"""Parallel batch ZDATA generation with efficient worker initialization."""

import numpy as np
from multiprocessing import Pool
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from .generator import ZDATAGenerator
from ..config import WarheadConfig, VariablesConfig


# Module-level generator for worker processes (initialized once per worker)
_worker_generator: Optional[ZDATAGenerator] = None


@dataclass
class ZDATAGeneratorConfig:
    """Lightweight config for worker initialization (avoids pickling ZDATAGenerator)."""

    n_zones: int
    zdata_number: int
    bin_edges_grams: List[float]
    shape_factor: float = 0.461235589  # Steel Cube default (match schema)

    @classmethod
    def from_generator(cls, generator: ZDATAGenerator) -> "ZDATAGeneratorConfig":
        """Extract config from existing generator."""
        return cls(
            n_zones=generator.n_zones,
            zdata_number=generator.zdata_number,
            bin_edges_grams=generator.bin_edges.tolist(),
            shape_factor=generator.shape_factor,
        )

    def build_generator(self) -> ZDATAGenerator:
        """Instantiate a ZDATAGenerator from this lightweight config."""
        warhead_config = WarheadConfig(
            n_zones=self.n_zones,
            zdata_number=self.zdata_number,
            mass_constraints=WarheadConfig.MassConstraints(
                total_mass_kg=25.0,  # Not used in ZDATA generation
                fragment_mass_kg=15.0,
            ),
            physics=WarheadConfig.Physics(shape_factor=self.shape_factor),
        )

        variables_config = VariablesConfig(
            fragment_sizes=VariablesConfig.FragmentSizes(
                bin_edges_grams=self.bin_edges_grams,
            ),
            fragment_quantities=VariablesConfig.FragmentQuantities(),
            zone_velocities=VariablesConfig.ZoneVelocities(),
        )

        return ZDATAGenerator(
            warhead_config,
            variables_config,
            shape_factor=self.shape_factor,
        )


def _init_worker(config: ZDATAGeneratorConfig) -> None:
    """
    Initialize worker process with its own ZDATAGenerator instance.

    Called once per worker process, not per task. This avoids the overhead
    of pickling/unpickling the generator for every work item.

    Args:
        config: Lightweight config for generator construction
    """
    global _worker_generator

    # Create minimal config objects for generator
    _worker_generator = config.build_generator()


def _generate_single_worker(work_item: Tuple[np.ndarray, str]) -> Tuple[str, bytes]:
    """
    Worker function for parallel ZDATA generation.

    Uses the pre-initialized generator from _init_worker().

    Args:
        work_item: (design_vector, uuid) tuple

    Returns:
        (uuid, zdata_bytes) tuple
    """
    global _worker_generator

    if _worker_generator is None:
        raise RuntimeError("Worker not initialized. Call _init_worker first.")

    design, uuid = work_item
    zdata_bytes = _worker_generator.to_bytes(design)
    return (uuid, zdata_bytes)


class ZDATABatchGenerator:
    """
    Parallel ZDATA file generation for design batches.

    Uses Pool initializer pattern to construct one ZDATAGenerator per worker
    process, avoiding the overhead of pickling the generator for each task.
    This is critical for large worker pools (92+ cores per node).
    """

    def __init__(self, generator: ZDATAGenerator, chunk_size: int = 100):
        """
        Initialize batch generator.

        Args:
            generator: ZDATA generator instance (used for config extraction)
            chunk_size: Number of designs per worker chunk
        """
        self.generator = generator
        self.chunk_size = chunk_size

        # Extract lightweight config for worker initialization
        self._worker_config = ZDATAGeneratorConfig.from_generator(generator)

    def generate_parallel(
        self,
        designs: np.ndarray,
        uuids: List[str],
        n_workers: Optional[int] = None,
    ) -> Dict[str, bytes]:
        """
        Generate ZDATA bytes for multiple designs in parallel.

        Uses Pool initializer to construct generator once per worker,
        avoiding serialization overhead for large worker pools.

        Args:
            designs: Design matrix, shape (n_designs, n_vars)
            uuids: List of UUIDs for each design
            n_workers: Number of parallel workers (None = auto-detect)

        Returns:
            Dictionary mapping UUID -> ZDATA bytes
        """
        n_designs = designs.shape[0]

        if n_designs == 0:
            return {}

        # For small batches, use sequential processing (avoid pool overhead)
        if n_designs < self.chunk_size or n_workers == 1:
            return self._generate_sequential(designs, uuids)

        # Parallel processing with Pool initializer
        # Generator is constructed ONCE per worker process, not per task
        with Pool(
            processes=n_workers,
            initializer=_init_worker,
            initargs=(self._worker_config,),
        ) as pool:
            # Create work items as list of (design, uuid) tuples
            work_items = [
                (designs[i], uuids[i])
                for i in range(n_designs)
            ]

            # Map work to workers with chunking for efficiency
            results = pool.map(
                _generate_single_worker,
                work_items,
                chunksize=self.chunk_size,
            )

        # Combine results into dict
        zdata_dict = {uuid: zdata_bytes for uuid, zdata_bytes in results}

        return zdata_dict

    def _generate_sequential(
        self,
        designs: np.ndarray,
        uuids: List[str],
    ) -> Dict[str, bytes]:
        """Generate ZDATA sequentially (no multiprocessing overhead)."""
        zdata_dict = {}

        for i, uuid in enumerate(uuids):
            zdata_bytes = self.generator.to_bytes(designs[i])
            zdata_dict[uuid] = zdata_bytes

        return zdata_dict

    def estimate_memory_usage(self, n_designs: int) -> float:
        """
        Estimate memory usage for batch generation.

        Args:
            n_designs: Number of designs

        Returns:
            Estimated memory in MB
        """
        # Typical ZDATA file size: 50-100 KB
        bytes_per_design = 75_000

        total_bytes = n_designs * bytes_per_design
        total_mb = total_bytes / (1024 * 1024)

        return total_mb
