"""
GWDH-NG: Next Generation Warhead Optimization Framework

A Python-native genetic algorithm framework for warhead design optimization
using pymoo NSGA-II/III with MEGADETH physics integration.

Key Features:
- In-memory ZDATA generation (zero file I/O)
- Bytes-based MEGADETH API integration
- Parallel evaluation (LocalPool + MPI multi-node)
- Vectorized feasibility checking
- UUID-based storage consolidation with DuckDB
- Checkpoint save/resume support
"""

__version__ = "1.0.0"

from .config import (
    CampaignConfig,
    ConfigLoader,
    InputBytesCache,
    StaticContextBuilder,
)

from .validation import (
    ParallelValidator,
    ValidationBatch,
)

from .zdata import (
    ZDATAGenerator,
    ZDATABatchGenerator,
)

from .ga import (
    GWDHProblem,
    GWDHOptimizer,
    CheckpointData,
)

from .parallel import (
    LocalPoolEvaluator,
    MPICoordinator,
    MPIEvaluator,
    get_mpi_evaluator_or_local,
    detect_resources,
    recommend_workers,
    MPI_AVAILABLE,
)

from .storage import (
    DatabaseSchema,
    BatchedDBWriter,
    HDF5Writer,
)

from .utils import (
    compute_design_uuid,
    setup_logger,
)

__all__ = [
    "__version__",
    # Config
    "CampaignConfig",
    "ConfigLoader",
    "InputBytesCache",
    "StaticContextBuilder",
    # Validation
    "ParallelValidator",
    "ValidationBatch",
    # ZDATA
    "ZDATAGenerator",
    "ZDATABatchGenerator",
    # GA
    "GWDHProblem",
    "GWDHOptimizer",
    "CheckpointData",
    # Parallel
    "LocalPoolEvaluator",
    "MPICoordinator",
    "MPIEvaluator",
    "get_mpi_evaluator_or_local",
    "detect_resources",
    "recommend_workers",
    "MPI_AVAILABLE",
    # Storage
    "DatabaseSchema",
    "BatchedDBWriter",
    "HDF5Writer",
    # Utils
    "compute_design_uuid",
    "setup_logger",
]
